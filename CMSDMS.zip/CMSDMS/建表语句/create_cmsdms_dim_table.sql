drop table if exists coss_dim.dim_tmu_iot_device_info;

create table if not exists coss_dim.dim_tmu_iot_device_info (
    device_code      varchar(200),
    device_name      varchar(200),
    meter_type_code  varchar(20),
    meter_type_desc  varchar(100),
    premise_id       varchar(110),
    serial_no        varchar(16),
    rcv_date         timestamp(6),
    region_abbr      varchar(30),
    sensor_id        varchar(200),
    sensor_name      varchar(200),
    sensor_unit      varchar(120),
    dim_update_time  timestamp(6) null default pg_systimestamp(),
    dim_load_time    timestamp(6) null default pg_systimestamp(),
    primary key (device_code)
);

comment on table coss_dim.dim_tmu_iot_device_info is 'Device Info';
comment on column coss_dim.dim_tmu_iot_device_info.device_code      is 'Device Code';
comment on column coss_dim.dim_tmu_iot_device_info.device_name      is 'Device Name';
comment on column coss_dim.dim_tmu_iot_device_info.meter_type_code  is 'Meter Type Code';
comment on column coss_dim.dim_tmu_iot_device_info.meter_type_desc  is 'Meter Type Desc ';
comment on column coss_dim.dim_tmu_iot_device_info.premise_id       is 'Premise Id';
comment on column coss_dim.dim_tmu_iot_device_info.serial_no        is 'Serial No ';
comment on column coss_dim.dim_tmu_iot_device_info.rcv_date         is 'Receive Date';
comment on column coss_dim.dim_tmu_iot_device_info.region_abbr      is 'Region Abbr';
comment on column coss_dim.dim_tmu_iot_device_info.sensor_id        is 'Sensorid';
comment on column coss_dim.dim_tmu_iot_device_info.sensor_name      is 'Sensor Name';
comment on column coss_dim.dim_tmu_iot_device_info.sensor_unit      is 'Sensor Unit';
comment on column coss_dim.dim_tmu_iot_device_info.dim_update_time  is 'Dim Update Time';
comment on column coss_dim.dim_tmu_iot_device_info.dim_load_time    is 'Dim Load Time';



drop table if exists coss_dim.dim_sz_device_info;
create table if not exists coss_dim.dim_sz_device_info(
    supply_id        varchar(100),
    supply_code      varchar(100),
    device_code      varchar(100),
    device_name      varchar(100),
    sensor_code      varchar(100),
    sensor_name      varchar(100),
    unit             varchar(100),
    coordinate_x     decimal(20,6),
    coordinate_y     decimal(20,6),
    dim_update_time  timestamp(6) default current_timestamp,
    dim_load_time    timestamp(6) default current_timestamp,
    primary key(supply_id, device_code, sensor_code)
);
comment on table coss_dim.dim_sz_device_info                   is 'Supply  Zone Monitoring Device Information';
comment on column coss_dim.dim_sz_device_info.supply_id        is 'Supply ID';
comment on column coss_dim.dim_sz_device_info.supply_code      is 'Supply Code';
comment on column coss_dim.dim_sz_device_info.device_code      is 'Device Code';
comment on column coss_dim.dim_sz_device_info.device_name      is 'Device Name';
comment on column coss_dim.dim_sz_device_info.sensor_code      is 'Sensor Code';
comment on column coss_dim.dim_sz_device_info.sensor_name      is 'Sensor Name';
comment on column coss_dim.dim_sz_device_info.unit             is 'Unit';
comment on column coss_dim.dim_sz_device_info.coordinate_x     is 'X-Axis Coordinate';
comment on column coss_dim.dim_sz_device_info.coordinate_y     is 'Y-Axis Coordinate';
comment on column coss_dim.dim_sz_device_info.dim_update_time  is 'Update Time';
comment on column coss_dim.dim_sz_device_info.dim_load_time    is 'Load Time';


