drop table if exists coss_ods.ods_iot_tmu_device_info_minf;

create table if not exists coss_ods.ods_iot_tmu_device_info_minf (
    device_code      varchar(200),
    device_name      varchar(200),
    sensor_id        varchar(200),
    sensor_name      varchar(200),
    sensor_unit      varchar(120),
    ods_update_time  timestamp(6) null default pg_systimestamp(),
    ods_load_time    timestamp(6) null default pg_systimestamp(),
    primary key (device_code)
);

comment on table coss_ods.ods_iot_tmu_device_info_minf is 'Device Info';
comment on column coss_ods.ods_iot_tmu_device_info_minf.device_code is 'Device Code';
comment on column coss_ods.ods_iot_tmu_device_info_minf.device_name is 'Device Name';
comment on column coss_ods.ods_iot_tmu_device_info_minf.sensor_id is 'Sensorid';
comment on column coss_ods.ods_iot_tmu_device_info_minf.sensor_name is 'Sensor Name';
comment on column coss_ods.ods_iot_tmu_device_info_minf.sensor_unit is 'Sensor Unit';
comment on column coss_ods.ods_iot_tmu_device_info_minf.ods_update_time is 'Ods Update Time';
comment on column coss_ods.ods_iot_tmu_device_info_minf.ods_load_time is 'Ods Load Time';


drop table if exists coss_ods.ods_iot_tmu_more_dev_realtime_minf;

create table if not exists coss_ods.ods_iot_tmu_more_dev_realtime_minf (
    device_code      varchar(200),
    sensor_id        varchar(200),
    value            decimal(20,5),
    "time"           bigint,
    ods_update_time  timestamp(6) null default pg_systimestamp(),
    ods_load_time    timestamp(6) null default pg_systimestamp(),
    primary key (device_code)
);

comment on table coss_ods.ods_iot_tmu_more_dev_realtime_minf is 'More Device Realtime';
comment on column coss_ods.ods_iot_tmu_more_dev_realtime_minf.device_code is 'Device Code';
comment on column coss_ods.ods_iot_tmu_more_dev_realtime_minf.sensor_id is 'Sensor Id';
comment on column coss_ods.ods_iot_tmu_more_dev_realtime_minf.value is 'Sensor Value';
comment on column coss_ods.ods_iot_tmu_more_dev_realtime_minf."time" is 'Sensor Time';
comment on column coss_ods.ods_iot_tmu_more_dev_realtime_minf.ods_update_time is 'Ods Update Time';
comment on column coss_ods.ods_iot_tmu_more_dev_realtime_minf.ods_load_time is 'Ods Load Time';

