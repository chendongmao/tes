drop table if exists coss_dwd.dwd_tmu_more_dev_realtime_minf;

create table if not exists coss_dwd.dwd_tmu_more_dev_realtime_minf (
    device_code      varchar(200),
    sensor_id        varchar(200),
    sensor_value     decimal(20,5),
    sensor_time      timestamp(6),
    dwd_update_time  timestamp(6) null default pg_systimestamp(),
    dwd_load_time    timestamp(6) null default pg_systimestamp(),
    primary key (device_code)
);

comment on table coss_dwd.dwd_tmu_more_dev_realtime_minf is 'More Device Realtime';
comment on column coss_dwd.dwd_tmu_more_dev_realtime_minf.device_code is 'Device Code';
comment on column coss_dwd.dwd_tmu_more_dev_realtime_minf.sensor_id is 'Sensor Id';
comment on column coss_dwd.dwd_tmu_more_dev_realtime_minf.sensor_value is 'Sensor Value';
comment on column coss_dwd.dwd_tmu_more_dev_realtime_minf.sensor_time is 'Sensor Time';
comment on column coss_dwd.dwd_tmu_more_dev_realtime_minf.dwd_update_time is 'Dwd Update Time';
comment on column coss_dwd.dwd_tmu_more_dev_realtime_minf.dwd_load_time is 'Dwd Load Time';