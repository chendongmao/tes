drop table if exists coss_dm.dm_tmu_sensor_data_stg_mini;
create table if not exists coss_dm.dm_tmu_sensor_data_stg_mini(
	id                  varchar(100),
	sensor_code         varchar(100),
	sensor_value        decimal(20,6),
	sensor_time         timestamp(6),
	dm_update_time      timestamp(6) default current_timestamp,
	dm_load_time        timestamp(6) default current_timestamp,
	primary key (sensor_code, sensor_time)
)


-- Drop table if it exists
drop table if exists coss_dm.dm_tmu_sensor_data_mini_month;

-- Create table with range partition by sensor_time
create table if not exists coss_dm.dm_tmu_sensor_data_mini_month (
    id              varchar(100),
    sensor_code     varchar(100),
    sensor_value    decimal(20,6),
    sensor_time     timestamp(6),
    dm_update_time  timestamp(6) default current_timestamp,
    dm_load_time    timestamp(6) default current_timestamp,
    primary key (sensor_code, sensor_time)
)
partition by range (sensor_time) (
    -- 2025 monthly partitions
    partition mh_202501 values less than ('2025-02-01 00:00:00'),
    partition mh_202503 values less than ('2025-04-01 00:00:00'),
    partition mh_202505 values less than ('2025-06-01 00:00:00'),
    partition mh_202507 values less than ('2025-08-01 00:00:00'),
    partition mh_202509 values less than ('2025-10-01 00:00:00'),
    partition mh_202511 values less than ('2025-12-01 00:00:00'),

    -- 2026 monthly partitions
    partition mh_202601 values less than ('2026-02-01 00:00:00'),
    partition mh_202603 values less than ('2026-04-01 00:00:00'),
    partition mh_202605 values less than ('2026-06-01 00:00:00'),
    partition mh_202607 values less than ('2026-08-01 00:00:00'),
    partition mh_202609 values less than ('2026-10-01 00:00:00'),
    partition mh_202611 values less than ('2026-12-01 00:00:00'),

    -- 2027 monthly partitions
    partition mh_202701 values less than ('2027-02-01 00:00:00'),
    partition mh_202703 values less than ('2027-04-01 00:00:00'),
    partition mh_202705 values less than ('2027-06-01 00:00:00'),
    partition mh_202707 values less than ('2027-08-01 00:00:00'),
    partition mh_202709 values less than ('2027-10-01 00:00:00'),
    partition mh_202711 values less than ('2027-12-01 00:00:00'),

    -- 2028 monthly partitions
    partition mh_202801 values less than ('2028-02-01 00:00:00'),
    partition mh_202803 values less than ('2028-04-01 00:00:00'),
    partition mh_202805 values less than ('2028-06-01 00:00:00'),
    partition mh_202807 values less than ('2028-08-01 00:00:00'),
    partition mh_202809 values less than ('2028-10-01 00:00:00'),

    -- Future partition, avoid insertion failure for unexpected time data
    partition mh_future values less than ('9999-01-01 00:00:00')
);

-- Add table comment
comment on table coss_dm.dm_tmu_sensor_data_mini_month
    is 'Terminal User Sensor Monitoring Data';

-- Add column comments
comment on column coss_dm.dm_tmu_sensor_data_mini_month.id
    is 'ID';
comment on column coss_dm.dm_tmu_sensor_data_mini_month.sensor_code
    is 'Sensor Code';
comment on column coss_dm.dm_tmu_sensor_data_mini_month.sensor_value
    is 'Sensor Value';
comment on column coss_dm.dm_tmu_sensor_data_mini_month.sensor_time
    is 'Sensor Time';
comment on column coss_dm.dm_tmu_sensor_data_mini_month.dm_update_time
    is 'Data Update Time';
comment on column coss_dm.dm_tmu_sensor_data_mini_month.dm_load_time
    is 'Data Loading Time';


drop table if exists coss_dm.dm_tmu_more_dev_realtime_minf;

create table if not exists coss_dm.dm_tmu_more_dev_realtime_minf (
    device_code      varchar(200),
    device_name      varchar(200),
    meter_type_code  varchar(20),
    meter_type_desc  varchar(100),
    premise_id       varchar(110),
    serial_no        varchar(16),
    rcv_date         timestamp(6),
    region_abbr      varchar(30),
    sensor_id        varchar(200),
    sensor_name      varchar(200),
    sensor_unit      varchar(120),
    sensor_value     numeric(20, 5),
    sensor_time      timestamp(6),
    dm_update_time   timestamp(6) null default pg_systimestamp(),
    dm_load_time     timestamp(6) null default pg_systimestamp(),
    primary key (device_code)
);

comment on table coss_dm.dm_tmu_more_dev_realtime_minf is 'More Device Realtime';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.device_code      is 'Device Code';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.device_name      is 'Device Name';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.meter_type_code  is 'Meter Type Code';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.meter_type_desc  is 'Meter Type Desc ';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.premise_id       is 'Premise Id';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.serial_no        is 'Serial No ';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.rcv_date         is 'Receive Date';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.region_abbr      is 'Region Abbr';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.sensor_id        is 'Sensorid';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.sensor_name      is 'Sensor Name';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.sensor_unit      is 'Sensor Unit';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.sensor_value     is 'Sensor Value';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.sensor_time      is 'Sensor Time';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.dm_update_time   is 'Dm Update Time';
comment on column coss_dm.dm_tmu_more_dev_realtime_minf.dm_load_time     is 'Dm Load Time';