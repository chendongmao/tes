-- ****************************************************************************************
-- Subject     Areas: Terminal User
-- Function Describe: Terminal User Monitoring For Meter
-- Create         By: dongmaochen
-- Create       Date: 2025-11-13
-- Modify Date                Modify By                    Modify Content
-- None                       None                         None
-- Source Table:  coss_dim.dim_tmu_iot_device_info, coss_dwd.dwd_tmu_more_dev_realtime_minf
-- Target Table:  coss_dm.dm_tmu_more_dev_realtime_minf
-- ****************************************************************************************
insert into coss_dm.dm_tmu_more_dev_realtime_minf (
    device_code,
    device_name,
    meter_type_code,
    meter_type_desc,
    premise_id,
    serial_no,
    rcv_date,
    region_abbr,
    sensor_id,
    sensor_name,
    sensor_unit,
    sensor_value,
    sensor_time,
    dm_update_time,
    dm_load_time
)
select
    t1.device_code,
    t1.device_name,
    t1.meter_type_code,
    t1.meter_type_desc,
    t1.premise_id,
    t1.serial_no,
    t1.rcv_date,
    t1.region_abbr,
    t1.sensor_id,
    t1.sensor_name,
    t1.sensor_unit,
    t.sensor_value,
    t.sensor_time,
    localtimestamp as dm_update_time,
    localtimestamp as dm_load_time
from coss_dwd.dwd_tmu_more_dev_realtime_minf t
inner join coss_dim.dim_tmu_iot_device_info t1 
    on t.device_code = t1.device_code 
    and t.sensor_id = t1.sensor_id
on duplicate key update
    sensor_id = values(sensor_id),
    sensor_name = values(sensor_name),
    sensor_unit = values(sensor_unit),
    sensor_value = values(sensor_value),
    sensor_time = values(sensor_time),
    dm_update_time = values(dm_update_time);