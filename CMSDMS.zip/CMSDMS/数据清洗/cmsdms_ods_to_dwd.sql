-- ****************************************************************************************
-- Subject     Areas: Terminal User
-- Function Describe: Terminal User Monitoring For Meter
-- Create         By: dongmaochen
-- Create       Date: 2025-11-13
-- Modify Date                Modify By                    Modify Content
-- None                       None                         None
-- Source Table:  coss_ods.ods_iot_tmu_more_dev_realtime_minf
-- Target Table:  coss_dwd.dwd_tmu_more_dev_realtime_minf
-- ****************************************************************************************
insert into coss_dwd.dwd_tmu_more_dev_realtime_minf (
    device_code,
    sensor_id,
    sensor_value,
    sensor_time,
    dwd_update_time,
    dwd_load_time
)
select
    device_code as device_code,
    sensor_id as sensor_id,
    value as sensor_value,
    to_timestamp("time" / 1000) as sensor_time,
    localtimestamp as dwd_update_time,
    localtimestamp as dwd_load_time
from coss_ods.ods_iot_tmu_more_dev_realtime_minf
on duplicate key update
    sensor_id = values(sensor_id),
    sensor_value = values(sensor_value),
    sensor_time = values(sensor_time),
    dwd_update_time = values(dwd_update_time);