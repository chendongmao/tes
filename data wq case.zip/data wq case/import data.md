

## 开发环境数据同步到IUAT环境

### dm_cus_water_quality_wo_details_mini 

1. 导出景湾中心的事故数据

   ```sql
   -- arch
   create table coss_tmp.dm_cus_water_quality_wo_details_mini_arch_jw_260602 as 
   select * from coss_dm.dm_cus_water_quality_wo_details_mini 
   where ordernum = '202605288427287554512' 
   or relateorder = '202605288427287554512'
   order by region_receiving_date  desc 
   
   -- delete
   delete from coss_dm.dm_cus_water_quality_wo_details_mini 
   where ordernum = '202605288427287554512' 
   or relateorder = '202605288427287554512'
   
   
   ```

2. 导出太古城的事故数据

   ```sql
   -- arch
   create table coss_tmp.dm_cus_water_quality_wo_details_mini_arch_tg_260602 as 
   select * from coss_dm.dm_cus_water_quality_wo_details_mini 
   where ordernum = '202505178427287551519' 
   or relateorder = '202505178427287551519'
   order by region_receiving_date  desc 
   
   -- delete
   delete from coss_dm.dm_cus_water_quality_wo_details_mini 
   where ordernum = '202505178427287551519' 
   or relateorder = '202505178427287551519'
   ```

3. 导入新的数据

### dm_cus_water_quality_accident_impact_mini

1. 更新表的ordernum值

   ```sql
   -- 水质事件指标
   update coss_dm.dm_cus_water_quality_accident_impact_mini set ordernum = '2605027PX2F' where ordernum = '202605288427287554512';
   update coss_dm.dm_cus_water_quality_accident_impact_mini set ordernum = '251115J3R7B' where ordernum = '202505178427287551519'
   ```

2. 手动修改指标

| accident | BuildingID | BuildingCSUID       | BuildingNameTC   | Georefno | meter num | people |
| -------- | ---------- | ------------------- | ---------------- | -------- | --------- | ------ |
| jw       | 1103126666 | 3620715741T20050430 | 灣景中心大廈Ａ座 | 3E+09    | 302       | 604    |
| jw       | 1103126849 | 3619415714T20050430 | 灣景中心大廈Ｂ座 | 3E+09    | 312       | 624    |
| jw       | 1103126998 | 3621215688T20050430 | 灣景中心大廈Ｃ座 | 3E+09    | 307       | 614    |
|          |            |                     |                  |          | 921       | 1842   |
| tg       | 1103122336 | 4054216351T20050430 | **c**            | 3E+09    | 203       | 406    |
| tg       | 1103122639 | 4057816310T20050430 | 鳳山閣           | 3E+09    | 211       | 422    |
| tg       | 1103122935 | 4053416266T20050430 | 怡山閣           | 3E+09    | 176       | 352    |
| tg       | 1103122918 | 4065216260T20050430 | 寶山閣           |          | 187       | 374    |
|          |            |                     |                  |          | 777       | 1554   |

### dm_cus_water_quality_impact_build_mini 

1. 备份指标数据

   ```sql
   create table coss_tmp.dm_cus_water_quality_impact_build_mini _260602 as 
   select * from coss_dm.dm_cus_water_quality_impact_build_mini   
   ```

2. 删除数据

   ```sql
   delete from coss_dm.dm_cus_water_quality_impact_build_mini 
   ```

3. 导入指标数据

### dm_wqm_accident_logger_info_mini

```sql
-- 水质事件记录仪指标
update coss_dm.dm_wqm_accident_logger_info_mini set ordernum = '2605027PX2F' where ordernum = '202605288427287554512';
update coss_dm.dm_wqm_accident_logger_info_mini set ordernum = '251115J3R7B' where ordernum = '202505178427287551519'
```



### dim_water_quality_accident_sz_installation_info

```sql
-- 水质事件相关设施表
update coss_dim.dim_water_quality_accident_sz_installation_info set ordernum = '2605027PX2F' where ordernum = '202605288427287554512';
update coss_dim.dim_water_quality_accident_sz_installation_info set ordernum = '251115J3R7B' where ordernum = '202505178427287551519'
```



### dm_cus_annon_watersupplyinfo_di 

1. 备份数据表：

   ```sql
   create table coss_tmp.dm_cus_annon_watersupplyinfo_di_260602 as 
   select * from coss_dm.dm_cus_annon_watersupplyinfo_di;
   
   ```

2. 导入数据

### dim_ir_intake_level_info

1. 备份数据表：

   ```sql
   create table coss_tmp.dim_ir_intake_level_info_260602 as 
   select * from coss_dim.dim_ir_intake_level_info;
   delete from  coss_dim.dim_ir_intake_level_info;
   ```

2. 导入数据