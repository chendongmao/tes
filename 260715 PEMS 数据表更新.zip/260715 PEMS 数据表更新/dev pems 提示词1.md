# 提示词

1. 需要创建数仓的两张表，源表和目标表名称和主键

   | 源表                     | 目标表                                          | 主键     |
   | ------------------------ | ----------------------------------------------- | -------- |
   | t_order_workorder        | ods_pems_cus_t_order_workorder_mini_year        | ordernum |
   | t_order_workorder_entity | ods_pems_cus_t_order_workorder_entity_mini_year | ordernum |

2. 原表的表结构：

   | table name               | Column Name                 | #    | Data type     | Identity | Collation | Not Null | Default | Comment EN                                                   |
   | ------------------------ | --------------------------- | ---- | ------------- | -------- | --------- | -------- | ------- | ------------------------------------------------------------ |
   | t_order_workorder        | ordernum                    | 1    | varchar(30)   | [NULL]   | default   | TRUE     | [NULL]  | Work Order ID                                                |
   | t_order_workorder        | msgid                       | 2    | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Message ID                                                   |
   | t_order_workorder        | agentgroupid                | 3    | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Agent Group ID                                               |
   | t_order_workorder        | cusid                       | 4    | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Customer ID (Linked to Customer Table)                       |
   | t_order_workorder        | channeltype                 | 5    | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Channel Type                                                 |
   | t_order_workorder        | busicenter                  | 6    | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Business Center (Department)                                 |
   | t_order_workorder        | classify1                   | 7    | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Work Order Category 1                                        |
   | t_order_workorder        | classify2                   | 8    | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Work Order Category 2                                        |
   | t_order_workorder        | subarea                     | 9    | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Region - Branch                                              |
   | t_order_workorder        | system                      | 10   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Dispatch System                                              |
   | t_order_workorder        | classify3                   | 11   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Work Order Category 3                                        |
   | t_order_workorder        | classify4                   | 12   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Work Order Category 4                                        |
   | t_order_workorder        | realclassify1               | 13   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Actual Work Order Category 3                                 |
   | t_order_workorder        | realclassify2               | 14   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Actual Work Order Category 4                                 |
   | t_order_workorder        | bigregion                   | 15   | varchar(30)   | [NULL]   | default   | FALSE    | [NULL]  | Administrative Region                                        |
   | t_order_workorder        | subregion                   | 16   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Region & Branch – Sub-region                                 |
   | t_order_workorder        | dayshift                    | 17   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Day Shift Team                                               |
   | t_order_workorder        | dutyshift                   | 18   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | On-duty Team                                                 |
   | t_order_workorder        | urgency                     | 19   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Urgency Level                                                |
   | t_order_workorder        | isclosed                    | 20   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | 1=Closed, 2=Dispatched                                       |
   | t_order_workorder        | state                       | 21   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | External Status                                              |
   | t_order_workorder        | orderstate                  | 22   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Work Order Status: 1=Pending, 2=In Progress, 3=Completed     |
   | t_order_workorder        | isdelay                     | 23   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Is Overdue: 1=Yes                                            |
   | t_order_workorder        | delayday                    | 24   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Overdue Days                                                 |
   | t_order_workorder        | iscomplant                  | 25   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Is Complaint Ticket: 1=Yes, 2=Tree-related, 0=No             |
   | t_order_workorder        | isreply                     | 26   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Reply Required: 1=Yes                                        |
   | t_order_workorder        | replychannel                | 27   | varchar(20)   | [NULL]   | default   | FALSE    | [NULL]  | Reply Channel                                                |
   | t_order_workorder        | casesource                  | 28   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Case Source                                                  |
   | t_order_workorder        | transferivr                 | 29   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Transferred to IVR                                           |
   | t_order_workorder        | chargeback                  | 30   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Returned Order                                               |
   | t_order_workorder        | ivrlanguage                 | 31   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | IVR Language Selection                                       |
   | t_order_workorder        | district1                   | 32   | varchar(30)   | [NULL]   | default   | FALSE    | [NULL]  | Primary Concern Area                                         |
   | t_order_workorder        | district2                   | 33   | varchar(30)   | [NULL]   | default   | FALSE    | [NULL]  | Secondary Concern Area                                       |
   | t_order_workorder        | isrepeatedcomplaint         | 34   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Repeat Complaint Flag                                        |
   | t_order_workorder        | subcomplaint                | 35   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Sub-complaint Flag                                           |
   | t_order_workorder        | receivedepartment           | 36   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Acceptance Department                                        |
   | t_order_workorder        | receiver                    | 37   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Handler / Assignee                                           |
   | t_order_workorder        | printedflag                 | 38   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Printed Flag                                                 |
   | t_order_workorder        | isregionorder               | 39   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Region-based Ticket Creation: 1=CS, 2=HW                     |
   | t_order_workorder        | outstandingdays             | 40   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Pending Days as of Current Date                              |
   | t_order_workorder        | finalreplydays              | 41   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Required Final Response Days                                 |
   | t_order_workorder        | completedbyregion           | 42   | varchar(5)    | [NULL]   | default   | FALSE    | [NULL]  | Case Completed by Regional Team                              |
   | t_order_workorder        | pledgeachieved              | 43   | varchar(5)    | [NULL]   | default   | FALSE    | [NULL]  | Service Commitment Met Flag                                  |
   | t_order_workorder        | actualreplytime             | 44   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Actual Response Time                                         |
   | t_order_workorder        | repairdays                  | 45   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Allowed Maintenance Days                                     |
   | t_order_workorder        | grantedhowlong              | 46   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | EOT Extension Days (If Granted)                              |
   | t_order_workorder        | notificationdays            | 47   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Notification Period (Days) Specified in FJ                   |
   | t_order_workorder        | totalprocessingdays         | 48   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Total Handling Days                                          |
   | t_order_workorder        | referinwsd                  | 49   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Internal Transfer Flag: 1=Yes                                |
   | t_order_workorder        | isdelete                    | 50   | bpchar(1)     | [NULL]   | default   | FALSE    | [NULL]  | Deletable Flag: 1=Yes, 0=No                                  |
   | t_order_workorder        | basecallpid                 | 51   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | baseCallPID                                                  |
   | t_order_workorder        | complantlastupdator         | 52   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Last Complaint Ticket Modifier                               |
   | t_order_workorder        | complantlastupdatetime      | 53   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | Last Complaint Ticket Modification Time                      |
   | t_order_workorder        | isdone                      | 54   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Flag: 1=Processed in ABPMS System                            |
   | t_order_workorder        | createdby                   | 55   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Created By                                                   |
   | t_order_workorder        | createdat                   | 56   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | Data Warehouse Load Time                                     |
   | t_order_workorder        | lastupdatedby               | 57   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Last Updated By                                              |
   | t_order_workorder        | lastupdateat                | 58   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | Last Update Time                                             |
   | t_order_workorder_entity | ordernum                    | 1    | varchar(30)   | [NULL]   | default   | TRUE     | [NULL]  | Work Order ID                                                |
   | t_order_workorder_entity | accountid                   | 2    | varchar(20)   | [NULL]   | default   | FALSE    | [NULL]  | Account Number                                               |
   | t_order_workorder_entity | customerid                  | 3    | varchar(20)   | [NULL]   | default   | FALSE    | [NULL]  | Customer ID                                                  |
   | t_order_workorder_entity | meterno                     | 4    | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Water Meter Number                                           |
   | t_order_workorder_entity | consumptionpointid          | 5    | varchar(20)   | [NULL]   | default   | FALSE    | [NULL]  | Water Meter ID                                               |
   | t_order_workorder_entity | telno                       | 6    | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Registration No.                                             |
   | t_order_workorder_entity | faxno                       | 7    | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Fax Number                                                   |
   | t_order_workorder_entity | contactno                   | 8    | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Contact / Landline Phone                                     |
   | t_order_workorder_entity | address                     | 9    | varchar(500)  | [NULL]   | default   | FALSE    | [NULL]  | Address                                                      |
   | t_order_workorder_entity | servicecontent              | 10   | varchar(4000) | [NULL]   | default   | FALSE    | [NULL]  | Service Content                                              |
   | t_order_workorder_entity | compliantmemo               | 11   | varchar(2000) | [NULL]   | default   | FALSE    | [NULL]  | Complaint Description                                        |
   | t_order_workorder_entity | wsdcreateat                 | 12   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | WSD Complaint Receipt Time                                   |
   | t_order_workorder_entity | completedate                | 13   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Completion Deadline Date                                     |
   | t_order_workorder_entity | casenumber                  | 14   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | 1823 Case Reference No.                                      |
   | t_order_workorder_entity | street                      | 15   | varchar(200)  | [NULL]   | default   | FALSE    | [NULL]  | Street                                                       |
   | t_order_workorder_entity | estate                      | 16   | varchar(200)  | [NULL]   | default   | FALSE    | [NULL]  | Estate / Village                                             |
   | t_order_workorder_entity | term                        | 17   | varchar(100)  | [NULL]   | default   | FALSE    | [NULL]  | Phase                                                        |
   | t_order_workorder_entity | village                     | 18   | varchar(200)  | [NULL]   | default   | FALSE    | [NULL]  | Village                                                      |
   | t_order_workorder_entity | buildingno                  | 19   | varchar(100)  | [NULL]   | default   | FALSE    | [NULL]  | Building Number                                              |
   | t_order_workorder_entity | buildingname                | 20   | varchar(200)  | [NULL]   | default   | FALSE    | [NULL]  | Building Name                                                |
   | t_order_workorder_entity | floor                       | 21   | varchar(200)  | [NULL]   | default   | FALSE    | [NULL]  | Floor                                                        |
   | t_order_workorder_entity | company                     | 22   | varchar(200)  | [NULL]   | default   | FALSE    | [NULL]  | Flat / Unit                                                  |
   | t_order_workorder_entity | relateorder                 | 23   | varchar(500)  | [NULL]   | default   | FALSE    | [NULL]  | Linked Work Order ID                                         |
   | t_order_workorder_entity | thirdid                     | 24   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | 3rd Party Work Order ID                                      |
   | t_order_workorder_entity | responsedate                | 25   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Response Deadline Date                                       |
   | t_order_workorder_entity | complainttype               | 26   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Complainant Type                                             |
   | t_order_workorder_entity | initialcomplaintdate        | 27   | timestamp(0)  | [NULL]   | [NULL]    | FALSE    | [NULL]  | Complaint Lodged Time                                        |
   | t_order_workorder_entity | regionreceivingdate         | 28   | timestamp(0)  | [NULL]   | [NULL]    | FALSE    | [NULL]  | Regional Office Receipt Time                                 |
   | t_order_workorder_entity | finishtime                  | 29   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | Work Order Completion Time                                   |
   | t_order_workorder_entity | actiontaken                 | 30   | varchar(1000) | [NULL]   | default   | FALSE    | [NULL]  | Action Taken                                                 |
   | t_order_workorder_entity | nature                      | 31   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Case Type                                                    |
   | t_order_workorder_entity | responsibleofficer          | 32   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Case Handler                                                 |
   | t_order_workorder_entity | interimreplydate            | 33   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Interim Response Date                                        |
   | t_order_workorder_entity | finalreplydate              | 34   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Substantive Response Date                                    |
   | t_order_workorder_entity | casereferredothers          | 35   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Case Referred To Other Staff (e.g. JO/Distribution Team)     |
   | t_order_workorder_entity | actionsreplycontent         | 36   | varchar(1000) | [NULL]   | default   | FALSE    | [NULL]  | Follow-up Actions After Response                             |
   | t_order_workorder_entity | repairtype                  | 37   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Repair Notice Type Issued                                    |
   | t_order_workorder_entity | repairdate                  | 38   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Repair Notice Issue Date                                     |
   | t_order_workorder_entity | repairexpirydate            | 39   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Repair Validity Period                                       |
   | t_order_workorder_entity | firstrepairreinspectiondate | 40   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | 1st Repair Notice Re-inspection Date                         |
   | t_order_workorder_entity | referringcasedate           | 41   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Time Sent to Regional Office                                 |
   | t_order_workorder_entity | issuingdate                 | 42   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | FJ Issue Date                                                |
   | t_order_workorder_entity | expirydate                  | 43   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | FJ Expiry Date (Validity)                                    |
   | t_order_workorder_entity | firstreinspectiondate       | 44   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | 1st FJ Re-inspection Date                                    |
   | t_order_workorder_entity | methodcompletion            | 45   | varchar(100)  | [NULL]   | default   | FALSE    | [NULL]  | Works Completion Method                                      |
   | t_order_workorder_entity | responsibleai               | 46   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Responsible AI Agent                                         |
   | t_order_workorder_entity | responsiblecsi              | 47   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Responsible CSI Officer                                      |
   | t_order_workorder_entity | supplytype                  | 48   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Water Supply Type                                            |
   | t_order_workorder_entity | slopefeature                | 49   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Slope                                                        |
   | t_order_workorder_entity | glano                       | 50   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Glano                                                        |
   | t_order_workorder_entity | groupval                    | 51   | varchar(35)   | [NULL]   | default   | FALSE    | [NULL]  | Group Val                                                    |
   | t_order_workorder_entity | complaintlodged             | 52   | varchar(255)  | [NULL]   | default   | FALSE    | [NULL]  | Complaint Short Code                                         |
   | t_order_workorder_entity | email                       | 53   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Email Address                                                |
   | t_order_workorder_entity | acknowledgementdate         | 54   | timestamp(0)  | [NULL]   | [NULL]    | FALSE    | [NULL]  | Acknowledgement Time                                         |
   | t_order_workorder_entity | regiondistrict              | 55   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | District                                                     |
   | t_order_workorder_entity | venue                       | 56   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Premises                                                     |
   | t_order_workorder_entity | waterqualitycode            | 57   | varchar(50)   | [NULL]   | default   | FALSE    | [NULL]  | Water Quality Dictionary Code                                |
   | t_order_workorder_entity | waterqualitycodecategory    | 58   | bpchar(1)     | [NULL]   | default   | FALSE    | [NULL]  | System Subcategory: Independent(I)/Multiple(M) for other water quality, fresh water turbidity & odour complaints (flushing water) |
   | t_order_workorder_entity | interimreplytargetdate      | 59   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Interim Reply Date                                           |
   | t_order_workorder_entity | buildingcsuid               | 60   | varchar(19)   | [NULL]   | default   | FALSE    | [NULL]  | Lot & Utility Reference No.                                  |
   | t_order_workorder_entity | locationx                   | 61   | varchar(6)    | [NULL]   | default   | FALSE    | [NULL]  | X Coordinate                                                 |
   | t_order_workorder_entity | locationy                   | 62   | varchar(6)    | [NULL]   | default   | FALSE    | [NULL]  | Y Coordinate                                                 |
   | t_order_workorder_entity | intervenescase              | 63   | bpchar(1)     | [NULL]   | default   | FALSE    | [NULL]  | Ombudsman Intervention Flag (Y/N)                            |
   | t_order_workorder_entity | docindexdesc                | 64   | text          | [NULL]   | default   | FALSE    | [NULL]  | Related Document Reference Index                             |
   | t_order_workorder_entity | processingdesc              | 65   | text          | [NULL]   | default   | FALSE    | [NULL]  | Case Handling Status                                         |
   | t_order_workorder_entity | appointmentremovaldate      | 66   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Meter Removal Date (dd/MM/yyyy)                              |
   | t_order_workorder_entity | appointmentremovalapm       | 67   | varchar(2)    | [NULL]   | default   | FALSE    | [NULL]  | Meter Removal Session (AM/PM only)                           |
   | t_order_workorder_entity | appointmentwitnessdate      | 68   | date          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Site Test Witness Date (dd/MM/yyyy)                          |
   | t_order_workorder_entity | appointmentwitnesstime      | 69   | varchar(12)   | [NULL]   | default   | FALSE    | [NULL]  | Site Test Witness Time Slot (HH:mm-HH:mm)                    |
   | t_order_workorder_entity | sourcetype                  | 70   | bpchar(10)    | [NULL]   | default   | FALSE    | [NULL]  | Ticket Creation Source Channel (Page)                        |
   | t_order_workorder_entity | remarks                     | 71   | varchar(2000) | [NULL]   | default   | FALSE    | [NULL]  | Remark                                                       |
   | t_order_workorder_entity | createdby                   | 72   | int4          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Created By                                                   |
   | t_order_workorder_entity | createdat                   | 73   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | Data Warehouse Load Time                                     |
   | t_order_workorder_entity | lastupdatedby               | 74   | int8          | [NULL]   | [NULL]    | FALSE    | [NULL]  | Last Updated By                                              |
   | t_order_workorder_entity | lastupdateat                | 75   | timestamp     | [NULL]   | [NULL]    | FALSE    | [NULL]  | Last Update Time                                             |
   | t_order_workorder_entity | ccid                        | 76   | varchar(15)   | [NULL]   | default   | FALSE    | [NULL]  | CC ID                                                        |

3. 结合下面样例sql，生成两张数仓ods层数据表

   ```sql
   drop table if exists coss_ods.ods_pems_cus_t_order_workorder_mini_year;
   
   create table if not exists coss_ods.ods_pems_cus_t_order_workorder_mini_year(
       ordernum varchar(50),
       msgid int8,
       agentgroupid int8,
       accountno varchar(20),
       cusid varchar(50),
       personid varchar(20),
       meterno varchar(50),
       premisesid varchar(20),
       telno varchar(50),
       faxno varchar(50),
       contactno varchar(50),
       channeltype int4,
       busicenter varchar(50),
       classify1 int8,
       classify2 int8,
       subarea int8,
       system int8,
       classify3 int8,
       classify4 int8,
       realclassify1 int8,
       realclassify2 int8,
       bigregion varchar(30),
       subregion int8,
       dayshift int4,
       dutyshift int4,
       urgency int4,
       address varchar(500),
       servicecontent varchar(4000),
       remarks varchar(2000),
       isclosed int4,
       state int4,
       orderstate int4,
       isdelay int4,
       delayday int4,
       iscomplant int4,
       compliantmemo varchar(2000),
       isreply int4,
       replychannel varchar(20),
       wsdcreateat timestamp(0),
       createdby int4,
       completedate date,
       casenumber varchar(50),
       casesource int8,
       transferivr int4,
       chargeback int4,
       ivrlanguage int4,
       relateorder varchar(50),
       district1 varchar(30),
       district2 varchar(30),
       street varchar(200),
       estate varchar(200),
       term varchar(100),
       village varchar(200),
       buildingno varchar(100),
       buildingname varchar(200),
       floor varchar(200),
       company varchar(200),
       createname varchar(100),
       posttitle varchar(100),
       thirdid varchar(50),
       responsedate date,
       isrepeatedcomplaint int4,
       subcomplaint int4,
       complainttype varchar(50),
       initialcomplaintdate timestamp(0),
       regionreceivingdate timestamp(0),
       createdat timestamp(0),
       receivedepartment int8,
       receiver int8,
       lastupdatedby int8,
       lastupdateat timestamp(0),
       finishtime timestamp,
       printedflag int4,
       isregionorder int4,
       actiontaken varchar(1000),
       nature varchar(35),
       responsibleofficer varchar(35),
       outstandingdays int4,
       interimreplydate date,
       finalreplydate date,
       finalreplydays int4,
       completedbyregion varchar(5),
       pledgeachieved varchar(5),
       casereferredothers varchar(35),
       actualreplytime timestamp,
       actionsreplycontent varchar(1000),
       repairtype varchar(50),
       repairdate date,
       repairdays int4,
       repairexpirydate date,
       firstrepairreinspectiondate date,
       referringcasedate date,
       grantedhowlong int4,
       issuingdate date,
       notificationdays int4,
       expirydate date,
       firstreinspectiondate date,
       casecompletiondate date,
       methodcompletion varchar(100),
       totalprocessingdays int4,
       responsibleai varchar(35),
       responsiblecsi varchar(35),
       supplytype varchar(50),
       venue varchar(35),
       slopefeature varchar(35),
       glano varchar(35),
       groupval varchar(35),
       complaintlodged varchar(255),
       email varchar(50),
       acknowledgementdate date,
       referinwsd int4,
       isdelete bpchar(1),
       regiondistrict varchar(50),
       basecallpid int4,
       complantlastupdator int8,
       complantlastupdatetime timestamp(0),
       waterqualitycode varchar(50),
       interimreplytargetdate date,
       buildingcsuid varchar(19),
       locationx varchar(6),
       locationy varchar(6),
       intervenescase bpchar(1),
       docindexdesc text,
       processingdesc text,
       appointmentremovaldate date,
       appointmentremovalapm varchar(2),
       appointmentwitnessdate date,
       appointmentwitnesstime varchar(12),
       isdone int4,
       sourcetype varchar(10),
       waterqualitycodecategory bpchar(1),
       ods_load_time timestamp(6) default current_timestamp,
       ods_update_time timestamp(6) default current_timestamp,
       primary key (ordernum)
   )
   with (
       orientation = row,
       compression = no
   )
   partition by range (createdat)
   (
       partition yr_2005 values less than ('2006-01-01 00:00:00'),
       partition yr_2006 values less than ('2007-01-01 00:00:00'),
       partition yr_2007 values less than ('2008-01-01 00:00:00'),
       partition yr_2008 values less than ('2009-01-01 00:00:00'),
       partition yr_2009 values less than ('2010-01-01 00:00:00'),
       partition yr_2010 values less than ('2011-01-01 00:00:00'),
       partition yr_2011 values less than ('2012-01-01 00:00:00'),
       partition yr_2012 values less than ('2013-01-01 00:00:00'),
       partition yr_2013 values less than ('2014-01-01 00:00:00'),
       partition yr_2014 values less than ('2015-01-01 00:00:00'),
       partition yr_2015 values less than ('2016-01-01 00:00:00'),
       partition yr_2016 values less than ('2017-01-01 00:00:00'),
       partition yr_2017 values less than ('2018-01-01 00:00:00'),
       partition yr_2018 values less than ('2019-01-01 00:00:00'),
       partition yr_2019 values less than ('2020-01-01 00:00:00'),
       partition yr_2020 values less than ('2021-01-01 00:00:00'),
       partition yr_2021 values less than ('2022-01-01 00:00:00'),
       partition yr_2022 values less than ('2023-01-01 00:00:00'),
       partition yr_2023 values less than ('2024-01-01 00:00:00'),
       partition yr_2024 values less than ('2025-01-01 00:00:00'),
       partition yr_2025 values less than ('2026-01-01 00:00:00'),
       partition yr_2026 values less than ('2027-01-01 00:00:00'),
       partition yr_future values less than ('9999-01-01 00:00:00')
   );
   
   comment on table coss_ods.ods_pems_cus_t_order_workorder_mini_year is 'Work Order Read Time Table';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ordernum is 'Work Order No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.msgid is 'Message ID';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.agentgroupid is 'Agent Group ID';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.accountno is 'Account No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.cusid is 'Customer ID (Relate to Customer Table)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.personid is 'User ID';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.meterno is 'Water Meter No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.premisesid is 'Water Meter ID';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.telno is 'Registration No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.faxno is 'Fax No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.contactno is 'Contact / Landline Phone';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.channeltype is 'Channel Type';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.busicenter is 'Business Centre (Department)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify1 is 'Work Order Category 1';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify2 is 'Work Order Category 2';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.subarea is 'District – Sub-district';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.system is 'Dispatch System';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify3 is 'Work Order Category 3';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify4 is 'Work Order Category 4';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.realclassify1 is 'Actual Work Order Category 3';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.realclassify2 is 'Actual Work Order Category 4';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.bigregion is 'District (Relate to t_dic_district.code)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.subregion is 'District Subdivision – Sub-area';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.dayshift is 'Daily Team';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.dutyshift is 'Duty Team';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.urgency is 'Urgency Level';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.address is 'Address';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.servicecontent is 'Service Content';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.remarks is 'Remarks';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isclosed is '1=Completed, 2=Dispatched';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.state is 'External Status';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.orderstate is 'Work Order Status: 1=Pending, 2=In Progress, 3=Completed';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isdelay is 'Is Delayed: 1=Yes';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.delayday is 'Delayed Days';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.iscomplant is 'Is Complaint Work Order: 1=Yes, 2=Tree Related, 0=No';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.compliantmemo is 'Complaint Description';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isreply is 'Need Reply: 1=Yes';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.replychannel is 'Reply Channel';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.wsdcreateat is 'WSD Complaint Acceptance Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.createdby is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.completedate is 'Deadline Date / Due Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.casenumber is '1823 Case No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.casesource is 'Case Source';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.transferivr is 'Is Transferred to IVR';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.chargeback is 'Is Order Returned';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ivrlanguage is 'IVR Language Selection';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.relateorder is 'Related Work Order No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.district1 is 'Sub-district (Relate to t_dic_sub_district.code)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.district2 is 'Concerned Area Level 2';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.street is 'Street';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.estate is 'Estate';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.term is 'Phase';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.village is 'Village';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.buildingno is 'Building No.';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.buildingname is 'Building Name';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.floor is 'Floor';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.company is 'Unit';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.createname is 'Registrant Name';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.posttitle is 'Registrant Position';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.thirdid is 'Third-party Work Order ID';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.responsedate is 'Response Due Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isrepeatedcomplaint is 'Is Repeat Complaint';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.subcomplaint is 'Is Sub-complaint';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.complainttype is 'Complainant Type';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.initialcomplaintdate is 'Complaint Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.regionreceivingdate is 'District Complaint Receipt Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.createdat is 'Data Loading Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.receivedepartment is 'Acceptance Department';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.receiver is 'Acceptor';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.lastupdatedby is 'Last Updated By';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.lastupdateat is 'Last Updated Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.finishtime is 'Work Order Completion Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.printedflag is 'Is Printed';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isregionorder is 'Is Created by District: 1=CS, 2=HW';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.actiontaken is 'Action Taken';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.nature is 'Type';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.responsibleofficer is 'Person in Charge';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.outstandingdays is 'Outstanding Time as of Today (Days)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.interimreplydate is 'Interim Reply Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.finalreplydate is 'Final Reply Date / Substantive Reply Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.finalreplydays is 'Time Required for Final Reply (Days)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.completedbyregion is 'Is Case Completed by District';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.pledgeachieved is 'Service Commitment Achieved';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.casereferredothers is 'Case Referred to Others (e.g. JO / Distribution)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.actualreplytime is 'Actual Reply Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.actionsreplycontent is 'Follow-up Actions After Reply';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.repairtype is 'Type of Maintenance Notice Issued';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.repairdate is 'Maintenance Notice Issue Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.repairdays is 'Allowed Maintenance Period (Days)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.repairexpirydate is 'Maintenance Validity Period';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.firstrepairreinspectiondate is 'First Maintenance Notice Re-inspection Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.referringcasedate is 'Date of Case Referral to Home Affairs Department';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.grantedhowlong is 'If EOT Granted, Period (Days)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.issuingdate is 'FJ Issue Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.notificationdays is 'Notice Period Specified in FJ (Days)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.expirydate is 'FJ Deadline Date (Validity)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.firstreinspectiondate is 'First FJ Re-inspection Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.casecompletiondate is 'Case Completion Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.methodcompletion is 'Completion Method';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.totalprocessingdays is 'Total Processing Time (Days)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.responsibleai is 'Responsible AI';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.responsiblecsi is 'Responsible CSI';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.supplytype is 'Supply Type';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.venue is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.slopefeature is 'Slope';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.glano is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.groupval is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.complaintlodged is 'Complaint Short Description';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.email is 'Email';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.acknowledgementdate is 'Acknowledgement Receipt Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.referinwsd is 'Is Transferred Internally: 1=Yes';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isdelete is 'Can Be Deleted: 1=Yes, 0=No';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.regiondistrict is 'Region of District';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.basecallpid is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.complantlastupdator is 'Last Modified By of Complaint';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.complantlastupdatetime is 'Last Modified Time of Complaint';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.waterqualitycode is 'Dictionary Code of Water Quality Code';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.interimreplytargetdate is 'Interim Reply Date';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.buildingcsuid is 'BDCSUID';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.locationx is 'Coordinate X';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.locationy is 'Coordinate Y';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.intervenescase is 'Is Ombudsman Involved: Y/N';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.docindexdesc is 'Related Document Index';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.processingdesc is 'Processing Status';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.appointmentremovaldate is 'Meter Removal Date dd/MM/yyyy';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.appointmentremovalapm is 'Meter Removal Slot (AM/PM Only)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.appointmentwitnessdate is 'Meter Removal Date dd/MM/yyyy';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.appointmentwitnesstime is 'On-site Testing Witness Period HH:mm-HH:mm';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isdone is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.sourcetype is '';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.waterqualitycodecategory is 'System Subclass Selection: Select Individual (I) / Multiple (M) for Other Water Quality Issues, Drinking Water Turbidity & Odour Complaints (Flushing Water)';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ods_load_time is 'Ods Load Time';
   comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ods_update_time is 'Ods Update Time';
   
   ```

   

