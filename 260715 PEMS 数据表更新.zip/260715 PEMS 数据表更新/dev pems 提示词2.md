# 提示词

## 输入样例：

1. 需要创建数仓的两张表，源表和目标表名称和主键

   | 源表              | 目标表                                   | 主键     |
   | ----------------- | ---------------------------------------- | -------- |
   | t_order_workorder | ods_pems_cus_t_order_workorder_mini_year | ordernum |
   
2. 原表的表结构：

   ```sql
   -- pems.t_order_workorder definition
   
   -- Drop table
   
   -- DROP TABLE pems.t_order_workorder;
   
   CREATE TABLE pems.t_order_workorder (
   	ordernum varchar(30) NOT NULL, -- 工单编号
   	msgid int8 NULL, -- 消息ID
   	agentgroupid int8 NULL, -- 坐席组ID
   	cusid varchar(50) NULL, -- 客户Id，关联客户表
   	channeltype int4 NULL, -- 渠道类型
   	busicenter varchar(50) NULL, -- 业务中心（部门）
   	classify1 int8 NULL, -- 工单分类1
   	classify2 int8 NULL, -- 工单分类2
   	subarea int8 NULL, -- 分区-分部
   	"system" int8 NULL, -- 派单系统
   	classify3 int8 NULL, -- 工单分类3
   	classify4 int8 NULL, -- 工单分类4
   	realclassify1 int8 NULL, -- 实际工单分类3
   	realclassify2 int8 NULL, -- 实际工单分类4
   	bigregion varchar(30) NULL, -- 行政大区
   	subregion int8 NULL, -- 分区分部——子区域
   	dayshift int4 NULL, -- 日班组
   	dutyshift int4 NULL, -- 值班组
   	urgency int4 NULL, -- 紧急程度
   	isclosed int4 NULL, -- 1=完结，2=派单
   	state int4 NULL, -- 对外状态
   	orderstate int4 NULL, -- 工单状态：1=待处理，2=处理中，3=已完成
   	isdelay int4 NULL, -- 是否延期，1=是
   	delayday int4 NULL, -- 延期天数
   	iscomplant int4 NULL, -- 是否投诉工单，1=是,2=是树木,0=否
   	isreply int4 NULL, -- 是否需要回复，1=是
   	replychannel varchar(20) NULL, -- 回复渠道
   	casesource int8 NULL, -- 个案来源
   	transferivr int4 NULL, -- 是否已转IVR
   	chargeback int4 NULL, -- 是否退单
   	ivrlanguage int4 NULL, -- IVR语言选择
   	district1 varchar(30) NULL, -- 关注地区1级
   	district2 varchar(30) NULL, -- 关注地区2级
   	isrepeatedcomplaint int4 NULL, -- 是否重复投诉
   	subcomplaint int4 NULL, -- 是否子投诉
   	receivedepartment int8 NULL, -- 受理部门
   	receiver int8 NULL, -- 受理人
   	printedflag int4 NULL, -- 是否已打印
   	isregionorder int4 NULL, -- 是否分区建单，1=CS，2=HW
   	outstandingdays int4 NULL, -- 截至当日的未完成时间(天)
   	finalreplydays int4 NULL, -- 最终答复所需时间(天)
   	completedbyregion varchar(5) NULL, -- 是否分区完成的个案
   	pledgeachieved varchar(5) NULL, -- 是否已达成服务承诺
   	actualreplytime int4 NULL, -- 实际答复时间
   	repairdays int4 NULL, -- 允许的维修时间（天）
   	grantedhowlong int4 NULL, -- 如果授予EOT，多长时间（天）
   	notificationdays int4 NULL, -- FJ中指定的通知期（天）
   	totalprocessingdays int4 NULL, -- 总处理时间（天）
   	referinwsd int4 NULL, -- 是否转交内部,1=是
   	isdelete bpchar(1) NULL, -- 是否可以删除 1-是,0-否
   	basecallpid int8 NULL, -- baseCallPID
   	complantlastupdator int8 NULL, -- 投诉单最后更改人
   	complantlastupdatetime timestamp NULL, -- 投诉单最后更改时间
   	isdone int4 NULL, -- 1=已在ABPMS处理  标识
   	createdby int8 NULL,
   	createdat timestamp NULL, -- 数据入库时间
   	lastupdatedby int8 NULL, -- 最后更新人
   	lastupdateat timestamp NULL, -- 最后更新时间
   	CONSTRAINT t_order_workorder_pkey1 PRIMARY KEY (ordernum)
   )
   WITH (
   	orientation=row,
   	compression=no,
   	storage_type=USTORE,
   	segment=off
   );
   CREATE INDEX t_order_workorder_createdat_idx ON pems.t_order_workorder USING ubtree (createdat) WITH (storage_type=USTORE) TABLESPACE pg_default;
   CREATE INDEX t_order_workorder_cusid_idx ON pems.t_order_workorder USING ubtree (cusid) WITH (storage_type=USTORE) TABLESPACE pg_default;
   CREATE INDEX t_order_workorder_lastupdateat_idx ON pems.t_order_workorder USING ubtree (lastupdateat) WITH (storage_type=USTORE) TABLESPACE pg_default;
   CREATE INDEX t_order_workorder_msgid_idx ON pems.t_order_workorder USING ubtree (msgid) WITH (storage_type=USTORE) TABLESPACE pg_default;
   
   -- Column comments
   
   COMMENT ON COLUMN pems.t_order_workorder.ordernum IS '工单编号';
   COMMENT ON COLUMN pems.t_order_workorder.msgid IS '消息ID';
   COMMENT ON COLUMN pems.t_order_workorder.agentgroupid IS '坐席组ID';
   COMMENT ON COLUMN pems.t_order_workorder.cusid IS '客户Id，关联客户表';
   COMMENT ON COLUMN pems.t_order_workorder.channeltype IS '渠道类型';
   COMMENT ON COLUMN pems.t_order_workorder.busicenter IS '业务中心（部门）';
   COMMENT ON COLUMN pems.t_order_workorder.classify1 IS '工单分类1';
   COMMENT ON COLUMN pems.t_order_workorder.classify2 IS '工单分类2';
   COMMENT ON COLUMN pems.t_order_workorder.subarea IS '分区-分部';
   COMMENT ON COLUMN pems.t_order_workorder."system" IS '派单系统';
   COMMENT ON COLUMN pems.t_order_workorder.classify3 IS '工单分类3';
   COMMENT ON COLUMN pems.t_order_workorder.classify4 IS '工单分类4';
   COMMENT ON COLUMN pems.t_order_workorder.realclassify1 IS '实际工单分类3';
   COMMENT ON COLUMN pems.t_order_workorder.realclassify2 IS '实际工单分类4';
   COMMENT ON COLUMN pems.t_order_workorder.bigregion IS '行政大区';
   COMMENT ON COLUMN pems.t_order_workorder.subregion IS '分区分部——子区域';
   COMMENT ON COLUMN pems.t_order_workorder.dayshift IS '日班组';
   COMMENT ON COLUMN pems.t_order_workorder.dutyshift IS '值班组';
   COMMENT ON COLUMN pems.t_order_workorder.urgency IS '紧急程度';
   COMMENT ON COLUMN pems.t_order_workorder.isclosed IS '1=完结，2=派单';
   COMMENT ON COLUMN pems.t_order_workorder.state IS '对外状态';
   COMMENT ON COLUMN pems.t_order_workorder.orderstate IS '工单状态：1=待处理，2=处理中，3=已完成';
   COMMENT ON COLUMN pems.t_order_workorder.isdelay IS '是否延期，1=是';
   COMMENT ON COLUMN pems.t_order_workorder.delayday IS '延期天数';
   COMMENT ON COLUMN pems.t_order_workorder.iscomplant IS '是否投诉工单，1=是,2=是树木,0=否';
   COMMENT ON COLUMN pems.t_order_workorder.isreply IS '是否需要回复，1=是';
   COMMENT ON COLUMN pems.t_order_workorder.replychannel IS '回复渠道';
   COMMENT ON COLUMN pems.t_order_workorder.casesource IS '个案来源';
   COMMENT ON COLUMN pems.t_order_workorder.transferivr IS '是否已转IVR';
   COMMENT ON COLUMN pems.t_order_workorder.chargeback IS '是否退单';
   COMMENT ON COLUMN pems.t_order_workorder.ivrlanguage IS 'IVR语言选择';
   COMMENT ON COLUMN pems.t_order_workorder.district1 IS '关注地区1级';
   COMMENT ON COLUMN pems.t_order_workorder.district2 IS '关注地区2级';
   COMMENT ON COLUMN pems.t_order_workorder.isrepeatedcomplaint IS '是否重复投诉';
   COMMENT ON COLUMN pems.t_order_workorder.subcomplaint IS '是否子投诉';
   COMMENT ON COLUMN pems.t_order_workorder.receivedepartment IS '受理部门';
   COMMENT ON COLUMN pems.t_order_workorder.receiver IS '受理人';
   COMMENT ON COLUMN pems.t_order_workorder.printedflag IS '是否已打印';
   COMMENT ON COLUMN pems.t_order_workorder.isregionorder IS '是否分区建单，1=CS，2=HW';
   COMMENT ON COLUMN pems.t_order_workorder.outstandingdays IS '截至当日的未完成时间(天)';
   COMMENT ON COLUMN pems.t_order_workorder.finalreplydays IS '最终答复所需时间(天)';
   COMMENT ON COLUMN pems.t_order_workorder.completedbyregion IS '是否分区完成的个案';
   COMMENT ON COLUMN pems.t_order_workorder.pledgeachieved IS '是否已达成服务承诺';
   COMMENT ON COLUMN pems.t_order_workorder.actualreplytime IS '实际答复时间';
   COMMENT ON COLUMN pems.t_order_workorder.repairdays IS '允许的维修时间（天）';
   COMMENT ON COLUMN pems.t_order_workorder.grantedhowlong IS '如果授予EOT，多长时间（天）';
   COMMENT ON COLUMN pems.t_order_workorder.notificationdays IS 'FJ中指定的通知期（天）';
   COMMENT ON COLUMN pems.t_order_workorder.totalprocessingdays IS '总处理时间（天）';
   COMMENT ON COLUMN pems.t_order_workorder.referinwsd IS '是否转交内部,1=是';
   COMMENT ON COLUMN pems.t_order_workorder.isdelete IS '是否可以删除 1-是,0-否';
   COMMENT ON COLUMN pems.t_order_workorder.basecallpid IS 'baseCallPID';
   COMMENT ON COLUMN pems.t_order_workorder.complantlastupdator IS '投诉单最后更改人';
   COMMENT ON COLUMN pems.t_order_workorder.complantlastupdatetime IS '投诉单最后更改时间';
   COMMENT ON COLUMN pems.t_order_workorder.isdone IS '1=已在ABPMS处理  标识';
   COMMENT ON COLUMN pems.t_order_workorder.createdat IS '数据入库时间';
   COMMENT ON COLUMN pems.t_order_workorder.lastupdatedby IS '最后更新人';
   COMMENT ON COLUMN pems.t_order_workorder.lastupdateat IS '最后更新时间';
   
   -- Permissions
   
   GRANT ALL ON TABLE pems.t_order_workorder TO pems;
   GRANT SELECT ON TABLE pems.t_order_workorder TO coss;
   ```

# 输出样例

## ods_pems_cus_t_order_workorder_mini_year

### create table

```sql
drop table if exists coss_ods.ods_pems_cus_t_order_workorder_mini_year;

create table if not exists coss_ods.ods_pems_cus_t_order_workorder_mini_year(
    ordernum varchar(30),
    msgid int8,
    agentgroupid int8,
    cusid varchar(50),
    channeltype int4,
    busicenter varchar(50),
    classify1 int8,
    classify2 int8,
    subarea int8,
    system int8,
    classify3 int8,
    classify4 int8,
    realclassify1 int8,
    realclassify2 int8,
    bigregion varchar(30),
    subregion int8,
    dayshift int4,
    dutyshift int4,
    urgency int4,
    isclosed int4,
    state int4,
    orderstate int4,
    isdelay int4,
    delayday int4,
    iscomplant int4,
    isreply int4,
    replychannel varchar(20),
    casesource int8,
    transferivr int4,
    chargeback int4,
    ivrlanguage int4,
    district1 varchar(30),
    district2 varchar(30),
    isrepeatedcomplaint int4,
    subcomplaint int4,
    receivedepartment int8,
    receiver int8,
    printedflag int4,
    isregionorder int4,
    outstandingdays int4,
    finalreplydays int4,
    completedbyregion varchar(5),
    pledgeachieved varchar(5),
    actualreplytime timestamp,
    repairdays int4,
    grantedhowlong int4,
    notificationdays int4,
    totalprocessingdays int4,
    referinwsd int4,
    isdelete bpchar(1),
    basecallpid int8,
    complantlastupdator int8,
    complantlastupdatetime timestamp,
    isdone int4,
    createdby int8,
    createdat timestamp,
    lastupdatedby int8,
    lastupdateat timestamp,
    ods_load_time timestamp(6) default current_timestamp,
    ods_update_time timestamp(6) default current_timestamp,
    primary key (ordernum)
)
with (
    orientation = row,
    compression = no
)
partition by range (createdat)
(
    partition yr_2005 values less than ('2006-01-01 00:00:00'),
    partition yr_2006 values less than ('2007-01-01 00:00:00'),
    partition yr_2007 values less than ('2008-01-01 00:00:00'),
    partition yr_2008 values less than ('2009-01-01 00:00:00'),
    partition yr_2009 values less than ('2010-01-01 00:00:00'),
    partition yr_2010 values less than ('2011-01-01 00:00:00'),
    partition yr_2011 values less than ('2012-01-01 00:00:00'),
    partition yr_2012 values less than ('2013-01-01 00:00:00'),
    partition yr_2013 values less than ('2014-01-01 00:00:00'),
    partition yr_2014 values less than ('2015-01-01 00:00:00'),
    partition yr_2015 values less than ('2016-01-01 00:00:00'),
    partition yr_2016 values less than ('2017-01-01 00:00:00'),
    partition yr_2017 values less than ('2018-01-01 00:00:00'),
    partition yr_2018 values less than ('2019-01-01 00:00:00'),
    partition yr_2019 values less than ('2020-01-01 00:00:00'),
    partition yr_2020 values less than ('2021-01-01 00:00:00'),
    partition yr_2021 values less than ('2022-01-01 00:00:00'),
    partition yr_2022 values less than ('2023-01-01 00:00:00'),
    partition yr_2023 values less than ('2024-01-01 00:00:00'),
    partition yr_2024 values less than ('2025-01-01 00:00:00'),
    partition yr_2025 values less than ('2026-01-01 00:00:00'),
    partition yr_2026 values less than ('2027-01-01 00:00:00'),
    partition yr_future values less than ('9999-01-01 00:00:00')
);

comment on table coss_ods.ods_pems_cus_t_order_workorder_mini_year is 'PEMS System Work Order Main Table';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ordernum is 'Work Order Id';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.msgid is 'Message Id';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.agentgroupid is 'Agent Group Id';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.cusid is 'Customer Id (Linked To Customer Table)';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.channeltype is 'Channel Type';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.busicenter is 'Business Center (Department)';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify1 is 'Work Order Category 1';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify2 is 'Work Order Category 2';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.subarea is 'Region - Branch';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.system is 'Dispatch System';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify3 is 'Work Order Category 3';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.classify4 is 'Work Order Category 4';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.realclassify1 is 'Actual Work Order Category 3';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.realclassify2 is 'Actual Work Order Category 4';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.bigregion is 'Administrative Region';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.subregion is 'Region & Branch – Sub-Region';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.dayshift is 'Day Shift Team';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.dutyshift is 'On-Duty Team';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.urgency is 'Urgency Level';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isclosed is '1=Closed, 2=Dispatched';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.state is 'External Status';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.orderstate is 'Work Order Status: 1=Pending, 2=In Progress, 3=Completed';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isdelay is 'Is Overdue: 1=Yes';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.delayday is 'Overdue Days';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.iscomplant is 'Is Complaint Ticket: 1=Yes, 2=Tree-Related, 0=No';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isreply is 'Reply Required: 1=Yes';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.replychannel is 'Reply Channel';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.casesource is 'Case Source';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.transferivr is 'Transferred To Ivr';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.chargeback is 'Returned Order';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ivrlanguage is 'Ivr Language Selection';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.district1 is 'Primary Concern Area';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.district2 is 'Secondary Concern Area';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isrepeatedcomplaint is 'Repeat Complaint Flag';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.subcomplaint is 'Sub-Complaint Flag';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.receivedepartment is 'Acceptance Department';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.receiver is 'Handler / Assignee';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.printedflag is 'Printed Flag';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isregionorder is 'Region-Based Ticket Creation: 1=Cs, 2=Hw';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.outstandingdays is 'Pending Days As Of Current Date';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.finalreplydays is 'Required Final Response Days';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.completedbyregion is 'Case Completed By Regional Team';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.pledgeachieved is 'Service Commitment Met Flag';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.actualreplytime is 'Actual Response Time';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.repairdays is 'Allowed Maintenance Days';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.grantedhowlong is 'Eot Extension Days (If Granted)';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.notificationdays is 'Notification Period (Days) Specified In Fj';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.totalprocessingdays is 'Total Handling Days';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.referinwsd is 'Internal Transfer Flag: 1=Yes';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isdelete is 'Deletable Flag: 1=Yes, 0=No';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.basecallpid is 'Basecallpid';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.complantlastupdator is 'Last Complaint Ticket Modifier';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.complantlastupdatetime is 'Last Complaint Ticket Modification Time';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.isdone is 'Flag: 1=Processed In Abpms System';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.createdby is 'Created By';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.createdat is 'Data Warehouse Load Time';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.lastupdatedby is 'Last Updated By';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.lastupdateat is 'Last Update Time';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ods_load_time is 'Ods Table Load Timestamp';
comment on column coss_ods.ods_pems_cus_t_order_workorder_mini_year.ods_update_time is 'Ods Table Update Timestamp';
```



### select sql

```sql
select 
    ordernum, -- Work Order Id
    msgid, -- Message Id
    agentgroupid, -- Agent Group Id
    cusid, -- Customer Id (Linked To Customer Table)
    channeltype, -- Channel Type
    busicenter, -- Business Center (Department)
    classify1, -- Work Order Category 1
    classify2, -- Work Order Category 2
    subarea, -- Region - Branch
    system, -- Dispatch System
    classify3, -- Work Order Category 3
    classify4, -- Work Order Category 4
    realclassify1, -- Actual Work Order Category 3
    realclassify2, -- Actual Work Order Category 4
    bigregion, -- Administrative Region
    subregion, -- Region & Branch – Sub-Region
    dayshift, -- Day Shift Team
    dutyshift, -- On-Duty Team
    urgency, -- Urgency Level
    isclosed, -- 1=Closed, 2=Dispatched
    state, -- External Status
    orderstate, -- Work Order Status: 1=Pending, 2=In Progress, 3=Completed
    isdelay, -- Is Overdue: 1=Yes
    delayday, -- Overdue Days
    iscomplant, -- Is Complaint Ticket: 1=Yes, 2=Tree-Related, 0=No
    isreply, -- Reply Required: 1=Yes
    replychannel, -- Reply Channel
    casesource, -- Case Source
    transferivr, -- Transferred To Ivr
    chargeback, -- Returned Order
    ivrlanguage, -- Ivr Language Selection
    district1, -- Primary Concern Area
    district2, -- Secondary Concern Area
    isrepeatedcomplaint, -- Repeat Complaint Flag
    subcomplaint, -- Sub-Complaint Flag
    receivedepartment, -- Acceptance Department
    receiver, -- Handler / Assignee
    printedflag, -- Printed Flag
    isregionorder, -- Region-Based Ticket Creation: 1=Cs, 2=Hw
    outstandingdays, -- Pending Days As Of Current Date
    finalreplydays, -- Required Final Response Days
    completedbyregion, -- Case Completed By Regional Team
    pledgeachieved, -- Service Commitment Met Flag
    actualreplytime, -- Actual Response Time
    repairdays, -- Allowed Maintenance Days
    grantedhowlong, -- Eot Extension Days (If Granted)
    notificationdays, -- Notification Period (Days) Specified In Fj
    totalprocessingdays, -- Total Handling Days
    referinwsd, -- Internal Transfer Flag: 1=Yes
    isdelete, -- Deletable Flag: 1=Yes, 0=No
    basecallpid, -- Basecallpid
    complantlastupdator, -- Last Complaint Ticket Modifier
    complantlastupdatetime, -- Last Complaint Ticket Modification Time
    isdone, -- Flag: 1=Processed In Abpms System
    createdby, -- Created By
    createdat, -- Data Warehouse Load Time
    lastupdatedby, -- Last Updated By
    lastupdateat, -- Last Update Time,
    current_timestamp as ods_load_time, -- Ods Table Load Timestamp
    current_timestamp as ods_update_time -- Ods Table Update Timestamp
from pems.t_order_workorder
where
	(complantlastupdatetime >= '${complantlastupdatetime}'
	or createdat >= '${createdat}')
	and classify3 = 10
```

### update sql

```sql


-- ****************************************************************************************
-- Subject     Areas: Customer Service
-- Function Describe: Main Work Order Info Full Load & Upsert
-- Create         By: dongmaochen
-- Create       Date: 2026-04-23
-- Modify Date                Modify By                    Modify Content
-- None                       None                         None
-- Source Table:  coss_ods.ods_pems_cus_t_order_workorder_stg_mini
-- Target Table:  coss_ods.ods_pems_cus_t_order_workorder_mini_year
-- ****************************************************************************************
insert into coss_ods.ods_pems_cus_t_order_workorder_mini_year
select
    ordernum, -- Work Order Id
    msgid, -- Message Id
    agentgroupid, -- Agent Group Id
    cusid, -- Customer Id (Linked To Customer Table)
    channeltype, -- Channel Type
    busicenter, -- Business Center (Department)
    classify1, -- Work Order Category 1
    classify2, -- Work Order Category 2
    subarea, -- Region - Branch
    system, -- Dispatch System
    classify3, -- Work Order Category 3
    classify4, -- Work Order Category 4
    realclassify1, -- Actual Work Order Category 3
    realclassify2, -- Actual Work Order Category 4
    bigregion, -- Administrative Region
    subregion, -- Region & Branch – Sub-Region
    dayshift, -- Day Shift Team
    dutyshift, -- On-Duty Team
    urgency, -- Urgency Level
    isclosed, -- 1=Closed, 2=Dispatched
    state, -- External Status
    orderstate, -- Work Order Status: 1=Pending, 2=In Progress, 3=Completed
    isdelay, -- Is Overdue: 1=Yes
    delayday, -- Overdue Days
    iscomplant, -- Is Complaint Ticket: 1=Yes, 2=Tree-Related, 0=No
    isreply, -- Reply Required: 1=Yes
    replychannel, -- Reply Channel
    casesource, -- Case Source
    transferivr, -- Transferred To Ivr
    chargeback, -- Returned Order
    ivrlanguage, -- Ivr Language Selection
    district1, -- Primary Concern Area
    district2, -- Secondary Concern Area
    isrepeatedcomplaint, -- Repeat Complaint Flag
    subcomplaint, -- Sub-Complaint Flag
    receivedepartment, -- Acceptance Department
    receiver, -- Handler / Assignee
    printedflag, -- Printed Flag
    isregionorder, -- Region-Based Ticket Creation: 1=Cs, 2=Hw
    outstandingdays, -- Pending Days As Of Current Date
    finalreplydays, -- Required Final Response Days
    completedbyregion, -- Case Completed By Regional Team
    pledgeachieved, -- Service Commitment Met Flag
    actualreplytime, -- Actual Response Time
    repairdays, -- Allowed Maintenance Days
    grantedhowlong, -- Eot Extension Days (If Granted)
    notificationdays, -- Notification Period (Days) Specified In Fj
    totalprocessingdays, -- Total Handling Days
    referinwsd, -- Internal Transfer Flag: 1=Yes
    isdelete, -- Deletable Flag: 1=Yes, 0=No
    basecallpid, -- Basecallpid
    complantlastupdator, -- Last Complaint Ticket Modifier
    complantlastupdatetime, -- Last Complaint Ticket Modification Time
    isdone, -- Flag: 1=Processed In Abpms System
    createdby, -- Created By
    createdat, -- Data Warehouse Load Time
    lastupdatedby, -- Last Updated By
    lastupdateat, -- Last Update Time
    current_timestamp as ods_load_time, -- Ods Table Load Timestamp
    current_timestamp as ods_update_time -- Ods Table Update Timestamp
from coss_ods.ods_pems_cus_t_order_workorder_stg_mini
on duplicate key update
    msgid = values(msgid),
    agentgroupid = values(agentgroupid),
    cusid = values(cusid),
    channeltype = values(channeltype),
    busicenter = values(busicenter),
    classify1 = values(classify1),
    classify2 = values(classify2),
    subarea = values(subarea),
    system = values(system),
    classify3 = values(classify3),
    classify4 = values(classify4),
    realclassify1 = values(realclassify1),
    realclassify2 = values(realclassify2),
    bigregion = values(bigregion),
    subregion = values(subregion),
    dayshift = values(dayshift),
    dutyshift = values(dutyshift),
    urgency = values(urgency),
    isclosed = values(isclosed),
    state = values(state),
    orderstate = values(orderstate),
    isdelay = values(isdelay),
    delayday = values(delayday),
    iscomplant = values(iscomplant),
    isreply = values(isreply),
    replychannel = values(replychannel),
    casesource = values(casesource),
    transferivr = values(transferivr),
    chargeback = values(chargeback),
    ivrlanguage = values(ivrlanguage),
    district1 = values(district1),
    district2 = values(district2),
    isrepeatedcomplaint = values(isrepeatedcomplaint),
    subcomplaint = values(subcomplaint),
    receivedepartment = values(receivedepartment),
    receiver = values(receiver),
    printedflag = values(printedflag),
    isregionorder = values(isregionorder),
    outstandingdays = values(outstandingdays),
    finalreplydays = values(finalreplydays),
    completedbyregion = values(completedbyregion),
    pledgeachieved = values(pledgeachieved),
    actualreplytime = values(actualreplytime),
    repairdays = values(repairdays),
    grantedhowlong = values(grantedhowlong),
    notificationdays = values(notificationdays),
    totalprocessingdays = values(totalprocessingdays),
    referinwsd = values(referinwsd),
    isdelete = values(isdelete),
    basecallpid = values(basecallpid),
    complantlastupdator = values(complantlastupdator),
    complantlastupdatetime = values(complantlastupdatetime),
    isdone = values(isdone),
    createdby = values(createdby),
    createdat = values(createdat),
    lastupdatedby = values(lastupdatedby),
    lastupdateat = values(lastupdateat),
    ods_update_time = values(ods_update_time)
    
 
```



