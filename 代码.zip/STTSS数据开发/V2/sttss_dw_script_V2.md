```
xuigai duobiao guanlian
2.coss_dws.dws_rws_rw_supply_detail_dip[unrunning]
```



# ods

## 1.coss_ods.ods_sttss_rws_calc_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Calculation Lookup
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.calc
-- target table
-- coss_ods.ods_sttss_rws_calc_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_calc_df
;create table if not exists coss_ods.ods_sttss_rws_calc_df(
  "calc_id"         decimal(10)     -- Calculation ID
  ,"ref_id"         varchar(20)     -- Referenced Channel or Internal Circulation
  ,"usage"          varchar(2)      -- Determines if the referenced Channel or Internal Circulation is used as summation or difference. Possible Values:{"S" - Sum, "D" - Difference}
  ,"last_upd_user"  varchar(120)    -- Last Update By (Username)
  ,"last_upd_post"  varchar(52)     -- Last Update By (Post)
  ,"last_upd_dt"    timestamp(6)    -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key("calc_id","ref_id")
)
distribute by hash("calc_id")
;comment on table  coss_ods.ods_sttss_rws_calc_df                   is 'Calculation Lookup'
;comment on column coss_ods.ods_sttss_rws_calc_df."calc_id"         is 'Calculation ID'
;comment on column coss_ods.ods_sttss_rws_calc_df."ref_id"          is 'Referenced Channel or Internal Circulation'
;comment on column coss_ods.ods_sttss_rws_calc_df."usage"           is 'Determines if the referenced Channel or Internal Circulation is used as summation or difference. Possible Values:{"S" - Sum, "D" - Difference}'
;comment on column coss_ods.ods_sttss_rws_calc_df."last_upd_user"   is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_calc_df."last_upd_post"   is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_calc_df."last_upd_dt"     is 'Last Update Date'
;comment on column  coss_ods.ods_sttss_rws_calc_df.ods_update_time  is 'Data Update Time'
;comment on column  coss_ods.ods_sttss_rws_calc_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_calc_df
;insert into coss_ods.ods_sttss_rws_calc_df
select
  calc_id                               -- Calculation ID
  ,ref_id                               -- Referenced Channel or Internal Circulation
  ,usage                                -- Determines if the referenced Channel or Internal Circulation is used as summation or difference. Possible Values:{"S" - Sum, "D" - Difference}
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.calc
```

## 2.coss_ods.ods_sttss_rws_channel_df

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Water transfer channels
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.channel
-- target table
-- coss_ods.ods_sttss_rws_channel_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_channel_df
;create table if not exists coss_ods.ods_sttss_rws_channel_df(
  "option_no"       decimal(10)         -- Option No.
  ,"ch_id"          varchar(20)         -- System generated ID of a water transfer channel
  ,"src_id"         varchar(20)         -- Source of Water Inflow
  ,"dest_id"        varchar(20)         -- Destination of Water outflow
  ,"rlabel"         varchar(2000)       -- Labels used in reports
  ,"water_usage"    decimal(3)          -- Water Usage
  ,"w_type"         varchar(2)          -- Type of water maintained by the installation
  ,"calc_id"        decimal(10)         -- Calculation logic being referenced by daily water transfer volume of channels
  ,"m_code"         varchar(20)         -- Measured By
  ,"last_upd_user"  varchar(120)        -- Last Update By (Username)
  ,"last_upd_post"  varchar(52)         -- Last Update By (Post)
  ,"last_upd_dt"    timestamp(6)        -- Last Update Date
  ,"rlabelc"        varchar(200)        -- Labels used in reports
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key("option_no","ch_id", "src_id","dest_id")
)
distribute by hash("option_no","ch_id")
;comment on table  coss_ods.ods_sttss_rws_channel_df                  is 'Water transfer channels'
;comment on column coss_ods.ods_sttss_rws_channel_df."option_no"      is 'Option No.'
;comment on column coss_ods.ods_sttss_rws_channel_df."ch_id"          is 'System generated ID of a water transfer channel'
;comment on column coss_ods.ods_sttss_rws_channel_df."src_id"         is 'Source of Water Inflow'
;comment on column coss_ods.ods_sttss_rws_channel_df."dest_id"        is 'Destination of Water outflow'
;comment on column coss_ods.ods_sttss_rws_channel_df."rlabel"         is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_channel_df."water_usage"    is 'Water Usage'
;comment on column coss_ods.ods_sttss_rws_channel_df."w_type"         is 'Type of water maintained by the installation'
;comment on column coss_ods.ods_sttss_rws_channel_df."calc_id"        is 'Calculation logic being referenced by daily water transfer volume of channels'
;comment on column coss_ods.ods_sttss_rws_channel_df."m_code"         is 'Measured By'
;comment on column coss_ods.ods_sttss_rws_channel_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_channel_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_channel_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_channel_df."rlabelc"        is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_channel_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_channel_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_channel_df
;insert into coss_ods.ods_sttss_rws_channel_df
select
  option_no                              -- Option No.
  ,ch_id                                 -- System generated ID of a water transfer channel
  ,src_id                                -- Source of Water Inflow
  ,dest_id                               -- Destination of Water outflow
  ,rlabel                                -- Labels used in reports
  ,water_usage                           -- Water Usage
  ,w_type                                -- Type of water maintained by the installation
  ,calc_id                               -- Calculation logic being referenced by daily water transfer volume of channels
  ,m_code                                -- Measured By
  ,last_upd_user                         -- Last Update By (Username)
  ,last_upd_post                         -- Last Update By (Post)
  ,last_upd_dt                           -- Last Update Date
  ,rlabelc                               -- Labels used in reports
  ,localtimestamp as ods_update_time     -- Data Warehouse update Time
  ,localtimestamp as ods_load_time       -- Data Warehouse load Time
from
sttss.channel
```

## 3.coss_ods.ods_sttss_rws_channel_flow_di_year

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Water transfer channels daily flow
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.channel_flow
-- target table
-- coss_ods.ods_sttss_rws_channel_flow_di_year
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_channel_flow_di_year
;create table if not exists coss_ods.ods_sttss_rws_channel_flow_di_year(
  "option_no"       decimal(10)           -- Option No. of Water Transfer Channel being referenced
  ,"ch_id"          varchar(20)           -- Water Transfer Channels being referenced
  ,"qty_del"        decimal(12,4)         -- Quantity delivered of "Water transfer channel. Unit is in Mld
  ,"scada_qty_del"  decimal(12,4)         -- Quantity delivered of "Water transfer channel. Unit is in Mld (SCADA)
  ,"m_code"         varchar(20)           -- Defines how the channel water flow is measured
  ,"rec_dt"         timestamp(6)          -- Date of Record
  ,"remarks"        varchar(2000)         -- Remarks
  ,"submit_dt"      timestamp(6)          -- Submission Date
  ,"last_upd_user"  varchar(120)          -- Last Update By (Username)
  ,"last_upd_post"  varchar(52)           -- Last Update By (Post)
  ,"last_upd_dt"    timestamp(6)          -- Last Update Date
  ,"wl_m"           decimal(12,4)         -- Water Level reading in meter
  ,"wl_mpd"         decimal(13,6)         -- Water Level in mPD
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,"dt"             decimal(10)           -- Daily Partitions
  ,primary key(option_no,ch_id,rec_dt)
)
distribute by hash("option_no")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_ods.ods_sttss_rws_channel_flow_di_year                  is 'Water transfer channels daily flow'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."option_no"      is 'Option No. of Water Transfer Channel being referenced'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."ch_id"          is 'Water Transfer Channels being referenced'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."qty_del"        is 'Quantity delivered of "Water transfer channel. Unit is in Mld'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."scada_qty_del"  is 'Quantity delivered of "Water transfer channel. Unit is in Mld (SCADA)'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."m_code"         is 'Defines how the channel water flow is measured'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."rec_dt"         is 'Date of Record'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."remarks"        is 'Remarks'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."submit_dt"      is 'Submission Date'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."wl_m"           is 'Water Level reading in meter'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."wl_mpd"         is 'Water Level in mPD'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year.ods_load_time    is 'Data Loading Time'
;comment on column coss_ods.ods_sttss_rws_channel_flow_di_year."dt"             is 'Daily Partitions'

;delete from coss_ods.ods_sttss_rws_channel_flow_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_ods.ods_sttss_rws_channel_flow_di_year
select
  option_no                             -- Option No. of Water Transfer Channel being referenced
  ,ch_id                                -- Water Transfer Channels being referenced
  ,qty_del                              -- Quantity delivered of "Water transfer channel. Unit is in Mld
  ,scada_qty_del                        -- Quantity delivered of "Water transfer channel. Unit is in Mld (SCADA)
  ,m_code                               -- Defines how the channel water flow is measured
  ,rec_dt                               -- Date of Record
  ,remarks                              -- Remarks
  ,submit_dt                            -- Submission Date
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,0 wl_m                               -- Water Level reading in meter
  ,0 wl_mpd                             -- Water Level in mPD
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd') dt       -- Daily Partitions
from sttss.channel_flow
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 4.coss_ods.ods_sttss_rws_ir_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Impounding reservoir information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.ir 
-- target table
-- coss_ods.ods_sttss_rws_ir_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_ir_df
;create table if not exists coss_ods.ods_sttss_rws_ir_df(
  "ir_id"           varchar(20)
  ,"ig_id"          varchar(20)
  ,"i_code"         varchar(10)
  ,"rlabel"         varchar(400)
  ,"level_type"     varchar(2)
  ,"level_unit"     varchar(2)
  ,"dead_storage"   decimal(12,4)
  ,"twl"            decimal(12,4)
  ,"capacity"       decimal(12,4)
  ,"min_storage"    decimal(12,4)
  ,"limit_m"        decimal(12,4)
  ,"last_upd_user"  varchar(120)
  ,"last_upd_post"  varchar(52)
  ,"last_upd_dt"    timestamp(6)
  ,"ir_name"        varchar(200)
  ,"ir_cname"       varchar(300)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(ir_id)
)
distribute by hash("ir_id")
;comment on table  coss_ods.ods_sttss_rws_ir_df                  is 'Impounding reservoir information'
;comment on column coss_ods.ods_sttss_rws_ir_df."ir_id"          is 'Impounding Reservoir ID with format IRNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_ir_df."ig_id"          is 'Impounding Reservoir Group being referenced'
;comment on column coss_ods.ods_sttss_rws_ir_df."i_code"         is 'Installation Code of Impounding Reservoir'
;comment on column coss_ods.ods_sttss_rws_ir_df."rlabel"         is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_ir_df."level_type"     is 'Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}'
;comment on column coss_ods.ods_sttss_rws_ir_df."level_unit"     is 'Possible Values:{"F" - Feet / Inch, "M" - Meter}'
;comment on column coss_ods.ods_sttss_rws_ir_df."dead_storage"   is 'Dead Storage of an Impounding Reservoir.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_ir_df."twl"            is 'TWL'
;comment on column coss_ods.ods_sttss_rws_ir_df."capacity"       is 'Capacity of IR.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_ir_df."min_storage"    is 'Allowable Minimum Storage.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_ir_df."limit_m"        is 'Preset Limit for Water Level.  Unit is in m'
;comment on column coss_ods.ods_sttss_rws_ir_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_ir_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_ir_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_ir_df."ir_name"        is 'Impounding reservoir name'
;comment on column coss_ods.ods_sttss_rws_ir_df."ir_cname"       is 'Impounding Reservoir Chinese Name'
;comment on column coss_ods.ods_sttss_rws_ir_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_ir_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_ir_df
;insert into coss_ods.ods_sttss_rws_ir_df
select
  ir_id                                 -- Impounding Reservoir ID with format IRNNNNNNNN
  ,ig_id                                -- Impounding Reservoir Group being referenced
  ,i_code                               -- Installation Code of Impounding Reservoir
  ,rlabel                               -- Labels used in reports
  ,level_type                           -- Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}
  ,level_unit                           -- Possible Values:{"F" - Feet / Inch, "M" - Meter}
  ,dead_storage                         -- Dead Storage of an Impounding Reservoir.  Unit is in mcm
  ,twl                                  -- TWL
  ,capacity                             -- Capacity of IR.  Unit is in mcm
  ,min_storage                          -- Allowable Minimum Storage.  Unit is in mcm
  ,limit_m                              -- Preset Limit for Water Level.  Unit is in m
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,ir_name                              -- Impounding reservoir name
  ,ir_cname                             -- Impounding Reservoir Chinese Name
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.ir 
```

## 5.coss_ods.ods_sttss_rws_ir_group_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Impounding reservoir group information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.ir_group
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_ir_group_df
;create table if not exists coss_ods.ods_sttss_rws_ir_group_df (
  ig_id          varchar(20)         -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,ig_name       varchar(200)        -- Name of Impounding Reservoir Group
  ,ig_cname      varchar(300)        -- Chinese Name of Impounding Reservoir Group
  ,rlabel        varchar(400)        -- Labels used in reports
  ,region        varchar(10)         -- Region
  ,old_ind       varchar(2)          -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
  ,last_upd_user varchar(120)        -- Last Update By (Username)
  ,last_upd_post varchar(52)         -- Last Update By (Post)
  ,last_upd_dt   timestamp(6)        -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(ig_id)
);
;comment on table  coss_ods.ods_sttss_rws_ir_group_df                  is  'Impounding reservoir group information'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.ig_id            is  'Impounding Reservoir Group ID with format IGNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.ig_name          is  'Name of Impounding Reservoir Group'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.ig_cname         is  'Chinese Name of Impounding Reservoir Group'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.rlabel           is  'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.region           is  'Region'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.old_ind          is  'Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New} '
;comment on column coss_ods.ods_sttss_rws_ir_group_df.last_upd_user    is  'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.last_upd_post    is  'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.last_upd_dt      is  'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_ir_group_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_ir_group_df
;insert into coss_ods.ods_sttss_rws_ir_group_df
select
  ig_id                                 -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,ig_name                              -- Name of Impounding Reservoir Group
  ,ig_cname                             -- Chinese Name of Impounding Reservoir Group
  ,rlabel                               -- Labels used in reports
  ,region                               -- Region
  ,old_ind                              -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.ir_group
```

## 6.coss_ods.ods_sttss_rws_ir_storage_di_year

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Daily impounding reservoir storage details
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.ir_storage
-- target table
-- coss_ods.ods_sttss_rws_ir_storage_di_year
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_ir_storage_di_year
;create table if not exists coss_ods.ods_sttss_rws_ir_storage_di_year(
  "ir_id"           varchar(20)              -- Impounding Reservior being referenced
  ,"wl_ft"          decimal(12,4)            -- Water Level reading in feet
  ,"wl_in"          decimal(12,4)            -- Water Level reading in inch
  ,"wl_m"           decimal(12,4)            -- Water Level reading in meter
  ,"wl_mpd"         decimal(13,6)            -- Waler Level in mPD
  ,"scada_wl_mpd"   decimal(13,6)            -- Waler Level in mPD (SCADA)
  ,"storage"        decimal(16,8)            -- Storage of water in IR.  Unit is in mcm
  ,"remarks"        varchar(2000)            -- Remarks
  ,"rec_dt"         timestamp(6)             -- Date of record
  ,"submit_dt"      timestamp(6)             -- Submission Date
  ,"last_upd_user"  varchar(120)             -- Last Update By (Username)
  ,"last_upd_post"  varchar(52)              -- Last Update By (Post)
  ,"last_upd_dt"    timestamp(6)             -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,"dt"             decimal(10)              -- Daily Partitions
  ,primary key(ir_id, rec_dt)
)
distribute by hash("ir_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_ods.ods_sttss_rws_ir_storage_di_year                  is 'Daily impounding reservoir storage details'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."ir_id"          is 'Impounding Reservior being referenced'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."wl_ft"          is 'Water Level reading in feet'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."wl_in"          is 'Water Level reading in inch'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."wl_m"           is 'Water Level reading in meter'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."wl_mpd"         is 'Waler Level in mPD'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."scada_wl_mpd"   is 'Waler Level in mPD (SCADA)'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."storage"        is 'Storage of water in IR.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."remarks"        is 'Remarks'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."rec_dt"         is 'Date of record'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."submit_dt"      is 'Submission Date'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year.ods_load_time    is 'Data Loading Time'
;comment on column coss_ods.ods_sttss_rws_ir_storage_di_year."dt"             is 'Daily Partitions'

;delete from coss_ods.ods_sttss_rws_ir_storage_di_year 
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1

;insert into  coss_ods.ods_sttss_rws_ir_storage_di_year
select
  ir_id                                 -- Impounding Reservior being referenced
  ,wl_ft                                -- Water Level reading in feet
  ,wl_in                                -- Water Level reading in inch
  ,wl_m                                 -- Water Level reading in meter
  ,wl_mpd                               -- Waler Level in mPD
  ,scada_wl_mpd                         -- Waler Level in mPD (SCADA)
  ,storage                              -- Storage of water in IR.  Unit is in mcm
  ,remarks                              -- Remarks
  ,rec_dt                               -- Date of record
  ,submit_dt                            -- Submission Date
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd')          -- Daily Partitions
from sttss.ir_storage
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 7.coss_ods.ods_sttss_rws_measurement_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Measurement Type
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.measurement
-- target table
-- coss_ods.ods_sttss_rws_measurement_df
-- ****************************************************************************************

;drop table if exists coss_ods.ods_sttss_rws_measurement_df
;create table if not exists coss_ods.ods_sttss_rws_measurement_df(
  "code"           varchar(20)    -- Defines how water level are measured
  ,"descrip"       varchar(200)   -- Description of Measurement
  ,"cdescrip"      varchar(300)   -- Chinese Description of Measurement Type
  ,"last_upd_user" varchar(120)   -- Last Update By (Username)
  ,"last_upd_post" varchar(60)    -- Last Update By (Post)
  ,"last_upd_dt"   timestamp(6)   -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(code)
)
distribute by hash("code")
;comment on table  coss_ods.ods_sttss_rws_measurement_df                    is  'Measurement Type'
;comment on column coss_ods.ods_sttss_rws_measurement_df."code"             is  'Defines how water level are measured'
;comment on column coss_ods.ods_sttss_rws_measurement_df."descrip"          is  'Description of Measurement'
;comment on column coss_ods.ods_sttss_rws_measurement_df."cdescrip"         is  'Chinese Description of Measurement Type'
;comment on column coss_ods.ods_sttss_rws_measurement_df."last_upd_user"    is  'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_measurement_df."last_upd_post"    is  'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_measurement_df."last_upd_dt"      is  'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_measurement_df.ods_update_time    is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_measurement_df.ods_load_time      is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_measurement_df
;insert into coss_ods.ods_sttss_rws_measurement_df
select
  code                                  -- Defines how water level are measured
  ,descrip                              -- Description of Measurement
  ,cdescrip                             -- Chinese Description of Measurement Type
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from
sttss.measurement
```

## 8.coss_ods.ods_sttss_rws_pqty_detail_di_year

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Proposed Quantity Details
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.pqty_detail
-- target table
-- coss_ods.ods_sttss_rws_pqty_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_pqty_detail_di_year
;create table if not exists coss_ods.ods_sttss_rws_pqty_detail_di_year(
  "prop_qty_id"     decimal(10)
  ,"ref_entity"     varchar(100)
  ,"ref_id"         varchar(20)
  ,"item_no"        decimal(10)
  ,"p_qty"          decimal(12,4)
  ,"last_upd_user"  varchar(120)
  ,"last_upd_post"  varchar(52)
  ,"last_upd_dt"    timestamp(6)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time   timestamp(6) default current_timestamp
  ,"mh"             decimal(10)
  ,primary key(prop_qty_id,ref_id,item_no)
)
distribute by hash("prop_qty_id")
partition by range (last_upd_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_ods.ods_sttss_rws_pqty_detail_di_year                  is 'Proposed Quantity Details'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."prop_qty_id"    is 'Proposed Quantity ID'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."ref_entity"     is 'Referenced Entity'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."ref_id"         is 'Installations being referenced'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."item_no"        is 'Item No.  To be used for Key Delivery'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."p_qty"          is 'Proposed Quantity.  Unit is Mld'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year.ods_load_time    is 'Data Loading Time'
;comment on column coss_ods.ods_sttss_rws_pqty_detail_di_year."mh"             is 'Daily Partitions'

;delete from coss_ods.ods_sttss_rws_pqty_detail_di_year
where last_upd_dt >= to_date(${dt1},'yyyy-mm-dd')-200
  and last_upd_dt < to_date(${dt1},'yyyy-mm-dd')+1 
;insert into coss_ods.ods_sttss_rws_pqty_detail_di_year
select
  prop_qty_id
  ,ref_entity
  ,ref_id
  ,item_no
  ,p_qty
  ,last_upd_user
  ,last_upd_post
  ,last_upd_dt
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
  ,to_char(last_upd_dt , 'yyyymm') mh
from
sttss.pqty_detail
where last_upd_dt >= to_date(${dt1},'yyyy-mm-dd')-200
  and last_upd_dt < to_date(${dt1},'yyyy-mm-dd')+1 
```

## 9.coss_ods.ods_sttss_rws_pqty_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Proposed Quantity
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.pqty
-- target table
-- coss_ods.ods_sttss_rws_pqty_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_pqty_df
;create table if not exists coss_ods.ods_sttss_rws_pqty_df(
  "prop_qty_id"     decimal(10)      -- Proposed Quantity
  ,"start_dt"       timestamp(6)     -- Proposed Quantity ID
  ,"end_dt"         timestamp(6)     -- Effective Start Date
  ,"create_dt"      timestamp(6)     -- Effective End Date
  ,"create_by"      varchar(40)      -- Created Date
  ,"last_upd_user"  varchar(120)     -- Created By
  ,"last_upd_post"  varchar(52)      -- Last Update By (Username)
  ,"last_upd_dt"    timestamp(6)     -- Last Update By (Post)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(prop_qty_id)
)
distribute by hash("prop_qty_id")
;comment on table  coss_ods.ods_sttss_rws_pqty_df                  is 'Proposed Quantity'
;comment on column coss_ods.ods_sttss_rws_pqty_df."prop_qty_id"    is 'Proposed Quantity ID'
;comment on column coss_ods.ods_sttss_rws_pqty_df."start_dt"       is 'Effective Start Date'
;comment on column coss_ods.ods_sttss_rws_pqty_df."end_dt"         is 'Effective End Date'
;comment on column coss_ods.ods_sttss_rws_pqty_df."create_dt"      is 'Created Date'
;comment on column coss_ods.ods_sttss_rws_pqty_df."create_by"      is 'Created By'
;comment on column coss_ods.ods_sttss_rws_pqty_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_pqty_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_pqty_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_pqty_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_pqty_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_pqty_df 
;insert into coss_ods.ods_sttss_rws_pqty_df
select
  prop_qty_id                           -- Proposed Quantity
  ,start_dt                             -- Proposed Quantity ID
  ,end_dt                               -- Effective Start Date
  ,create_dt                            -- Effective End Date
  ,create_by                            -- Created Date
  ,last_upd_user                        -- Created By
  ,last_upd_post                        -- Last Update By (Username)
  ,last_upd_dt                          -- Last Update By (Post)
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.pqty
```

## 10.coss_ods.ods_sttss_rws_ps_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Pumping station
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.ps
-- target table
-- coss_ods.ods_sttss_rws_ps_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_ps_df
;create table if not exists coss_ods.ods_sttss_rws_ps_df(
  "ps_id"           varchar(20)       -- Pumping station
  ,"i_code"         varchar(10)       -- Pumping Station ID with format PSNNNNNNNN
  ,"rlabel"         varchar(400)      -- Installation Code of Pumping Station
  ,"region"         varchar(10)       -- Labels used in reports
  ,"w_type"         varchar(2)        -- Region
  ,"repumping"      varchar(2)        -- Type of water maintained in the pumping station
  ,"last_upd_user"  varchar(120)      -- Repumping
  ,"last_upd_post"  varchar(52)       -- Last Update By (Username)
  ,"last_upd_dt"    timestamp(6)      -- Last Update By (Post)
  ,"remark"         varchar(200)      -- Last Update Date
  ,"ps_name"        varchar(200)      -- Remarks
  ,"ps_cname"       varchar(300)      -- Pumping station name
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(ps_id)
)
distribute by hash("ps_id")
;comment on table  coss_ods.ods_sttss_rws_ps_df                  is 'Pumping station'
;comment on column coss_ods.ods_sttss_rws_ps_df."ps_id"          is 'Pumping Station ID with format PSNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_ps_df."i_code"         is 'Installation Code of Pumping Station'
;comment on column coss_ods.ods_sttss_rws_ps_df."rlabel"         is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_ps_df."region"         is 'Region'
;comment on column coss_ods.ods_sttss_rws_ps_df."w_type"         is 'Type of water maintained in the pumping station'
;comment on column coss_ods.ods_sttss_rws_ps_df."repumping"      is 'Repumping'
;comment on column coss_ods.ods_sttss_rws_ps_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_ps_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_ps_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_ps_df."remark"         is 'Remarks'
;comment on column coss_ods.ods_sttss_rws_ps_df."ps_name"        is 'Pumping station name'
;comment on column coss_ods.ods_sttss_rws_ps_df."ps_cname"       is 'Pumping Station Chinese Name'
;comment on column coss_ods.ods_sttss_rws_ps_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_ps_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_ps_df
;insert into coss_ods.ods_sttss_rws_ps_df 
select 
  ps_id                                 -- Pumping station
  ,i_code                               -- Pumping Station ID with format PSNNNNNNNN
  ,rlabel                               -- Installation Code of Pumping Station
  ,region                               -- Labels used in reports
  ,w_type                               -- Region
  ,repumping                            -- Type of water maintained in the pumping station
  ,last_upd_user                        -- Repumping
  ,last_upd_post                        -- Last Update By (Username)
  ,last_upd_dt                          -- Last Update By (Post)
  ,remark                               -- Last Update Date
  ,ps_name                              -- Remarks
  ,ps_cname                             -- Pumping station name
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.ps
```

## 11.coss_ods.ods_sttss_rws_region_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Region
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.region
-- target table
-- coss_ods.ods_sttss_rws_region_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_region_df
;create table if not exists coss_ods.ods_sttss_rws_region_df(
  "code"            varchar(10)     -- Region
  ,"descrip"        varchar(60)     -- Possible Values: {"HK" - HK Island, "K" - Kowloon, "NTE" -  New Territories East, "NTW" - New Territories West}
  ,"cdescrip"       varchar(300)    -- Description of Region
  ,"indicator"      varchar(2)      -- Chinese Description of Region
  ,"last_upd_user"  varchar(120)    -- Possible Values: {"I" - HK Island, "M" - Mainland} 
  ,"last_upd_post"  varchar(52)     -- Last Update By (Username)
  ,"last_upd_dt"    timestamp(6)    -- Last Update By (Post)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(code)
)
distribute by hash("code")
;comment on table  coss_ods.ods_sttss_rws_region_df                  is 'Region'
;comment on column coss_ods.ods_sttss_rws_region_df."code"           is 'Possible Values: {"HK" - HK Island, "K" - Kowloon, "NTE" -  New Territories East, "NTW" - New Territories West}'
;comment on column coss_ods.ods_sttss_rws_region_df."descrip"        is 'Description of Region'
;comment on column coss_ods.ods_sttss_rws_region_df."cdescrip"       is 'Chinese Description of Region'
;comment on column coss_ods.ods_sttss_rws_region_df."indicator"      is 'Possible Values: {"I" - HK Island, "M" - Mainland} '
;comment on column coss_ods.ods_sttss_rws_region_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_region_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_region_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_region_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_region_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_region_df
;insert into coss_ods.ods_sttss_rws_region_df 
select 
  code                                  -- Region
  ,descrip                              -- Possible Values: {"HK" - HK Island, "K" - Kowloon, "NTE" -  New Territories East, "NTW" - New Territories West}
  ,cdescrip                             -- Description of Region
  ,indicator                            -- Chinese Description of Region
  ,last_upd_user                        -- Possible Values: {"I" - HK Island, "M" - Mainland} 
  ,last_upd_post                        -- Last Update By (Username)
  ,last_upd_dt                          -- Last Update By (Post)
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.region
```

## 12.coss_ods.ods_sttss_rws_rw_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw Water Source
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.rw
-- target table
-- coss_ods.ods_sttss_rws_rw_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_rw_df
;create table if not exists coss_ods.ods_sttss_rws_rw_df(
  "rw_id"           varchar(20)      -- Raw Water Source
  ,"rw_name"        varchar(200)     -- Raw Water Source ID with format RWNNNNNNNN
  ,"rw_cname"       varchar(300)     -- Name of Raw Water
  ,"rlabel"         varchar(400)     -- Chinese Name of Raw Water
  ,"region"         varchar(10)      -- Labels used in reports
  ,"source"         varchar(2)       -- Region
  ,"last_upd_user"  varchar(120)     -- Source of raw water
  ,"last_upd_post"  varchar(52)      -- Last Update By (Username)
  ,"last_upd_dt"    timestamp(6)     -- Last Update By (Post)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(rw_id)
)
distribute by hash("rw_id")
;comment on table  coss_ods.ods_sttss_rws_rw_df                  is 'Raw Water Source'
;comment on column coss_ods.ods_sttss_rws_rw_df."rw_id"          is 'Raw Water Source ID with format RWNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_rw_df."rw_name"        is 'Name of Raw Water'
;comment on column coss_ods.ods_sttss_rws_rw_df."rw_cname"       is 'Chinese Name of Raw Water'
;comment on column coss_ods.ods_sttss_rws_rw_df."rlabel"         is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_rw_df."region"         is 'Region'
;comment on column coss_ods.ods_sttss_rws_rw_df."source"         is 'Source of raw water'
;comment on column coss_ods.ods_sttss_rws_rw_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_rw_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_rw_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_rw_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_rw_df.ods_load_time    is 'Data Loading Time'


;delete from coss_ods.ods_sttss_rws_rw_df
;insert into coss_ods.ods_sttss_rws_rw_df 
select 
  rw_id                                 -- Raw Water Source
  ,rw_name                              -- Raw Water Source ID with format RWNNNNNNNN
  ,rw_cname                             -- Name of Raw Water
  ,rlabel                               -- Chinese Name of Raw Water
  ,region                               -- Labels used in reports
  ,source                               -- Region
  ,last_upd_user                        -- Source of raw water
  ,last_upd_post                        -- Last Update By (Username)
  ,last_upd_dt                          -- Last Update By (Post)
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from 
  sttss.rw
```

## 13.coss_ods.ods_sttss_rws_rw_type_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw Water Type
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.rw_type
-- target table
-- coss_ods.ods_sttss_rws_rw_type_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_rw_type_df
;create table if not exists coss_ods.ods_sttss_rws_rw_type_df(
  "code"         varchar(4)     -- Possible Values:{"G" - Guangdong, "R" - River, "O" - Others}
  ,"descrip"     varchar(90)    -- Description of Raw Water Source
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(code)
)
distribute by hash("code")
;comment on table coss_ods.ods_sttss_rws_rw_type_df                   is 'Raw Water Type'
;comment on column coss_ods.ods_sttss_rws_rw_type_df."code"           is 'Possible Values:{"G" - Guangdong, "R" - River, "O" - Others}'
;comment on column coss_ods.ods_sttss_rws_rw_type_df."descrip"        is 'Description of Raw Water Source'
;comment on column coss_ods.ods_sttss_rws_rw_type_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_rw_type_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_rw_type_df
;insert into coss_ods.ods_sttss_rws_rw_type_df 
select 
  code                                  -- Possible Values:{"G" - Guangdong, "R" - River, "O" - Others}
  ,descrip                              -- Description of Raw Water Source
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from 
  sttss.rw_type
```

## 14.coss_ods.ods_sttss_rws_sp_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Salt Water Pumping System Information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.sp
-- target table
-- coss_ods.ods_sttss_rws_sp_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_sp_df
;create table if not exists coss_ods.ods_sttss_rws_sp_df(
  sp_id             varchar(20)      -- Salt Water Pumping System Information
  ,sp_name          varchar(200)     -- Salt Water Pumping System ID with format SPNNNNNNNN
  ,rlabel           varchar(400)     -- Name of Salt Water Pumping System
  ,region           varchar(10)      -- Labels used in reports
  ,last_upd_user    varchar(120)     -- Region
  ,last_upd_post    varchar(52)      -- Last Update By (Username)
  ,last_upd_dt      timestamp(6)     -- Last Update By (Post)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(sp_id)
)
distribute by hash("sp_id")
;comment on table  coss_ods.ods_sttss_rws_sp_df                  is  'Salt Water Pumping System Information'
;comment on column coss_ods.ods_sttss_rws_sp_df.sp_id            is  'Salt Water Pumping System ID with format SPNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_sp_df.sp_name          is  'Name of Salt Water Pumping System'
;comment on column coss_ods.ods_sttss_rws_sp_df.rlabel           is  'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_sp_df.region           is  'Region'
;comment on column coss_ods.ods_sttss_rws_sp_df.last_upd_user    is  'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_sp_df.last_upd_post    is  'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_sp_df.last_upd_dt      is  'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_sp_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_sp_df.ods_load_time    is 'Data Loading Time'

;delete from  coss_ods.ods_sttss_rws_sp_df
;insert into coss_ods.ods_sttss_rws_sp_df           
select
  sp_id                               -- Salt Water Pumping System Information
  ,sp_name                            -- Salt Water Pumping System ID with format SPNNNNNNNN
  ,rlabel                             -- Name of Salt Water Pumping System
  ,region                             -- Labels used in reports
  ,last_upd_user                      -- Region
  ,last_upd_post                      -- Last Update By (Username)
  ,last_upd_dt                        -- Last Update By (Post)
  ,localtimestamp as ods_update_time  -- Data Warehouse update Time
  ,localtimestamp as ods_load_time    -- Data Warehouse load Time
from sttss.sp
```

## 15.coss_ods.ods_sttss_rws_sp_supply_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Salt Water Pumping System Supply Zones
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.sp_supply
-- target table
-- coss_ods.ods_sttss_rws_sp_supply_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_sp_supply_df
;create table if not exists coss_ods.ods_sttss_rws_sp_supply_df(
  sp_id              varchar(20)       -- Salt Water Pumping System being referenced
  ,sz_id             varchar(20)       -- Pumping Station or Service Reservoir being referenced
  ,last_upd_user     varchar(120)      -- Last Update By (Username)
  ,last_upd_post     varchar(52)       -- Last Update By (Post)
  ,last_upd_dt       timestamp(6)      -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(sp_id,sz_id)
)
distribute by hash("sp_id")

;comment on table  coss_ods.ods_sttss_rws_sp_supply_df                  is 'Salt Water Pumping System Supply Zones'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.sp_id            is 'Salt Water Pumping System being referenced'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.sz_id            is 'Pumping Station or Service Reservoir being referenced'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.last_upd_user    is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.last_upd_post    is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.last_upd_dt      is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_sp_supply_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_sp_supply_df
;insert into coss_ods.ods_sttss_rws_sp_supply_df
select
  sp_id                                 -- Salt Water Pumping System being referenced
  ,sz_id                                -- Pumping Station or Service Reservoir being referenced
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.sp_supply

```

## 16.coss_ods.ods_sttss_rws_sps_flow_di_year

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Salt Water Pumping Station Volume
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.sps_flow
-- target table
-- coss_ods.ods_sttss_rws_sps_flow_di_year
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_sps_flow_di_year
;create table if not exists coss_ods.ods_sttss_rws_sps_flow_di_year(
  ps_id              varchar(20)         -- Pumping Station being referenced
  ,qty               decimal(12,4)       -- Quantity delivered by Salt water pumping station.  Unit is in Mld
  ,scada_qty         decimal(12,4)       -- Quantity delivered by Salt water pumping station.  Unit is in Mld (SCADA)
  ,rec_dt            timestamp(6)        -- Date of record
  ,remarks           varchar(2000)       -- Remarks
  ,submit_dt         timestamp(6)        -- Submission Date
  ,last_upd_user     varchar(120)        -- Last Update By (Username)
  ,last_upd_post     varchar(52)         -- Last Update By (Post)
  ,last_upd_dt       timestamp(6)        -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,dt                decimal(10)         -- Daily Partitions
  ,primary key(ps_id, rec_dt)
)
distribute by hash("ps_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_ods.ods_sttss_rws_sps_flow_di_year                  is  'Salt Water Pumping Station Volume'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.ps_id            is  'Pumping Station being referenced'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.qty              is  'Quantity delivered by Salt water pumping station.  Unit is in Mld'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.scada_qty        is  'Quantity delivered by Salt water pumping station.  Unit is in Mld (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.rec_dt           is  'Date of record'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.remarks          is  'Remarks'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.submit_dt        is  'Submission Date'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.last_upd_user    is  'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.last_upd_post    is  'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.last_upd_dt      is  'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.ods_load_time    is 'Data Loading Time'
;comment on column coss_ods.ods_sttss_rws_sps_flow_di_year.dt               is  'Daily Partitions'

;delete from coss_ods.ods_sttss_rws_sps_flow_di_year 
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_ods.ods_sttss_rws_sps_flow_di_year
select
  ps_id                                 -- Pumping Station being referenced
  ,qty                                  -- Quantity delivered by Salt water pumping station.  Unit is in Mld
  ,scada_qty                            -- Quantity delivered by Salt water pumping station.  Unit is in Mld (SCADA)
  ,rec_dt                               -- Date of record
  ,remarks                              -- Remarks
  ,submit_dt                            -- Submission Date
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd') dt       -- Daily Partitions
from sttss.sps_flow sf
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 17.coss_ods.ods_sttss_rws_sr_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Service Reservoir
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.sr
-- target table
-- coss_ods.ods_sttss_rws_sr_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_sr_df
;create table if not exists coss_ods.ods_sttss_rws_sr_df(
  "sr_id"            varchar(20)        -- Service Reservoir ID with format SRNNNNNNNN
  ,"i_code"          varchar(10)        -- Installation Code of Service Reservoir
  ,"rlabel"          varchar(400)       -- Labels used in reports
  ,"region"          varchar(10)        -- Region
  ,"w_type"          varchar(2)         -- Type of water maintained by the service reservoir
  ,"div_height"      decimal(12,4)      -- Height of Division Wall.  Unit is in m
  ,"capacity"        decimal(12,4)      -- Capacity of Service Reservoir.  Unit is in cu m
  ,"limit"           decimal(12,4)      -- Preset Limit for Water Level above division wall.  Unit is in m
  ,"num_of_storage"  decimal            -- No. of Storage/Compartment
  ,"last_upd_user"   varchar(120)       -- Last Update By (Username)
  ,"last_upd_post"   varchar(52)        -- Last Update By (Post)
  ,"last_upd_dt"     timestamp(6)       -- Last Update Date
  ,"sr_name"         varchar(200)       -- Service Reservoir Name 
  ,"sr_cname"        varchar(300)       -- Service Reservoir Chinese Name
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(sr_id)
)
distribute by hash("sr_id")
;comment on table  coss_ods.ods_sttss_rws_sr_df                   is 'Service Reservoir'
;comment on column coss_ods.ods_sttss_rws_sr_df."sr_id"           is 'Service Reservoir ID with format SRNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_sr_df."i_code"          is 'Installation Code of Service Reservoir'
;comment on column coss_ods.ods_sttss_rws_sr_df."rlabel"          is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_sr_df."region"          is 'Region'
;comment on column coss_ods.ods_sttss_rws_sr_df."w_type"          is 'Type of water maintained by the service reservoir'
;comment on column coss_ods.ods_sttss_rws_sr_df."div_height"      is 'Height of Division Wall.  Unit is in m'
;comment on column coss_ods.ods_sttss_rws_sr_df."capacity"        is 'Capacity of Service Reservoir.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_df."limit"           is 'Preset Limit for Water Level above division wall.  Unit is in m'
;comment on column coss_ods.ods_sttss_rws_sr_df."num_of_storage"  is 'No. of Storage/Compartment'
;comment on column coss_ods.ods_sttss_rws_sr_df."last_upd_user"   is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_sr_df."last_upd_post"   is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_sr_df."last_upd_dt"     is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_sr_df."sr_name"         is 'Service Reservoir Name '
;comment on column coss_ods.ods_sttss_rws_sr_df."sr_cname"        is 'Service Reservoir Chinese Name'
;comment on column coss_ods.ods_sttss_rws_sr_df.ods_update_time   is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_sr_df.ods_load_time     is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_sr_df
;insert into coss_ods.ods_sttss_rws_sr_df 
select 
  sr_id                                 -- Service Reservoir ID with format SRNNNNNNNN
  ,i_code                               -- Installation Code of Service Reservoir
  ,rlabel                               -- Labels used in reports
  ,region                               -- Region
  ,w_type                               -- Type of water maintained by the service reservoir
  ,div_height                           -- Height of Division Wall.  Unit is in m
  ,capacity                             -- Capacity of Service Reservoir.  Unit is in cu m
  ,0 "limit"                            -- Preset Limit for Water Level above division wall.  Unit is in m
  ,num_of_storage                       -- No. of Storage/Compartment
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,sr_name                              -- Service Reservoir Name 
  ,sr_cname                             -- Service Reservoir Chinese Name
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.sr
```

## 18.coss_ods.ods_sttss_rws_sr_storage_di_year

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Daily SR Storage Details
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.sr_storage
-- target table
-- coss_ods.ods_sttss_rws_sr_storage_di_year
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_sr_storage_di_year
;create table if not exists coss_ods.ods_sttss_rws_sr_storage_di_year(
  "sr_id"            varchar(20)       -- Service Reservior being referenced
  ,"a_wlevel"        decimal(9,2)      -- A Compartment Water Level
  ,"b_wlevel"        decimal(9,2)      -- B Compartment Water Level
  ,"c_wlevel"        decimal(9,2)      -- C Compartment Water Level
  ,"d_wlevel"        decimal(9,2)      -- D Compartment Water Level
  ,"e_wlevel"        decimal(9,2)      -- E Compartment Water Level
  ,"f_wlevel"        decimal(9,2)      -- F Compartment Water Level
  ,"g_wlevel"        decimal(9,2)      -- G Compartment Water Level
  ,"h_wlevel"        decimal(9,2)      -- H Compartment Water Level
  ,"i_wlevel"        decimal(9,2)      -- I Compartment Water Level
  ,"j_wlevel"        decimal(9,2)      -- J Compartment Water Level
  ,"k_wlevel"        decimal(9,2)      -- K Compartment Water Level
  ,"l_wlevel"        decimal(9,2)      -- L Compartment Water Level
  ,"m_wlevel"        decimal(9,2)      -- M Compartment Water Level
  ,"n_wlevel"        decimal(9,2)      -- N Compartment Water Level
  ,"o_wlevel"        decimal(9,2)      -- O Compartment Water Level
  ,"p_wlevel"        decimal(9,2)      -- P Compartment Water Level
  ,"q_wlevel"        decimal(9,2)      -- Q Compartment Water Level
  ,"r_wlevel"        decimal(9,2)      -- R Compartment Water Level
  ,"scada_a_wlevel"  decimal(9,2)      -- A Compartment Water Level (SCADA)
  ,"scada_b_wlevel"  decimal(9,2)      -- B Compartment Water Level (SCADA)
  ,"scada_c_wlevel"  decimal(9,2)      -- C Compartment Water Level (SCADA)
  ,"scada_d_wlevel"  decimal(9,2)      -- D Compartment Water Level (SCADA)
  ,"scada_e_wlevel"  decimal(9,2)      -- E Compartment Water Level (SCADA)
  ,"scada_f_wlevel"  decimal(9,2)      -- F Compartment Water Level (SCADA)
  ,"scada_g_wlevel"  decimal(9,2)      -- G Compartment Water Level (SCADA)
  ,"scada_h_wlevel"  decimal(9,2)      -- H Compartment Water Level (SCADA)
  ,"scada_i_wlevel"  decimal(9,2)      -- I Compartment Water Level (SCADA)
  ,"scada_j_wlevel"  decimal(9,2)      -- J Compartment Water Level (SCADA)
  ,"scada_k_wlevel"  decimal(9,2)      -- K Compartment Water Level (SCADA)
  ,"scada_l_wlevel"  decimal(9,2)      -- L Compartment Water Level (SCADA)
  ,"scada_m_wlevel"  decimal(9,2)      -- M Compartment Water Level (SCADA)
  ,"scada_n_wlevel"  decimal(9,2)      -- N Compartment Water Level (SCADA)
  ,"scada_o_wlevel"  decimal(9,2)      -- O Compartment Water Level (SCADA)
  ,"scada_p_wlevel"  decimal(9,2)      -- P Compartment Water Level (SCADA)
  ,"scada_q_wlevel"  decimal(9,2)      -- Q Compartment Water Level (SCADA)
  ,"scada_r_wlevel"  decimal(9,2)      -- R Compartment Water Level (SCADA)
  ,"a_storage"       decimal(12,4)     -- Volume of water in A compartment of an SR.  Unit is in cu m
  ,"b_storage"       decimal(12,4)     -- Volume of water in B compartment of an SR.  Unit is in cu m
  ,"c_storage"       decimal(12,4)     -- Volume of water in C compartment of an SR.  Unit is in cu m
  ,"d_storage"       decimal(12,4)     -- Volume of water in D compartment of an SR.  Unit is in cu m
  ,"e_storage"       decimal(12,4)     -- Volume of water in E compartment of an SR.  Unit is in cu m
  ,"f_storage"       decimal(12,4)     -- Volume of water in F compartment of an SR.  Unit is in cu m
  ,"g_storage"       decimal(12,4)     -- Volume of water in G compartment of an SR.  Unit is in cu m
  ,"h_storage"       decimal(12,4)     -- Volume of water in H compartment of an SR.  Unit is in cu m
  ,"i_storage"       decimal(12,4)     -- Volume of water in I compartment of an SR.  Unit is in cu m
  ,"j_storage"       decimal(12,4)     -- Volume of water in J compartment of an SR.  Unit is in cu m
  ,"k_storage"       decimal(12,4)     -- Volume of water in K compartment of an SR.  Unit is in cu m
  ,"l_storage"       decimal(12,4)     -- Volume of water in L compartment of an SR.  Unit is in cu m
  ,"m_storage"       decimal(12,4)     -- Volume of water in M compartment of an SR.  Unit is in cu m
  ,"n_storage"       decimal(12,4)     -- Volume of water in N compartment of an SR.  Unit is in cu m
  ,"o_storage"       decimal(12,4)     -- Volume of water in O compartment of an SR.  Unit is in cu m
  ,"p_storage"       decimal(12,4)     -- Volume of water in P compartment of an SR.  Unit is in cu m
  ,"q_storage"       decimal(12,4)     -- Volume of water in Q compartment of an SR.  Unit is in cu m
  ,"r_storage"       decimal(12,4)     -- Volume of water in R compartment of an SR.  Unit is in cu m
  ,"tot_storage"     decimal(12,4)     -- Total volume of water in A+ B+..+R.  Unit is in cu m
  ,"remarks"         varchar(2000)     -- Remarks
  ,"rec_dt"          timestamp(6)      -- Date of record
  ,"submit_dt"       timestamp(6)      -- Submission Date
  ,"last_upd_user"   varchar(120)      -- Last Update By (Username)
  ,"last_upd_post"   varchar(52)       -- Last Update By (Post)
  ,"last_upd_dt"     timestamp(6)      -- Last Update Date
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,"dt"              decimal(10)       -- Daily Partitions
)
distribute by hash("sr_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_ods.ods_sttss_rws_sr_storage_di_year                   is 'Daily SR Storage Details'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."sr_id"           is 'Service Reservior being referenced'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."a_wlevel"        is 'A Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."b_wlevel"        is 'B Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."c_wlevel"        is 'C Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."d_wlevel"        is 'D Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."e_wlevel"        is 'E Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."f_wlevel"        is 'F Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."g_wlevel"        is 'G Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."h_wlevel"        is 'H Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."i_wlevel"        is 'I Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."j_wlevel"        is 'J Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."k_wlevel"        is 'K Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."l_wlevel"        is 'L Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."m_wlevel"        is 'M Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."n_wlevel"        is 'N Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."o_wlevel"        is 'O Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."p_wlevel"        is 'P Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."q_wlevel"        is 'Q Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."r_wlevel"        is 'R Compartment Water Level'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_a_wlevel"  is 'A Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_b_wlevel"  is 'B Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_c_wlevel"  is 'C Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_d_wlevel"  is 'D Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_e_wlevel"  is 'E Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_f_wlevel"  is 'F Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_g_wlevel"  is 'G Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_h_wlevel"  is 'H Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_i_wlevel"  is 'I Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_j_wlevel"  is 'J Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_k_wlevel"  is 'K Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_l_wlevel"  is 'L Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_m_wlevel"  is 'M Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_n_wlevel"  is 'N Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_o_wlevel"  is 'O Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_p_wlevel"  is 'P Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_q_wlevel"  is 'Q Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."scada_r_wlevel"  is 'R Compartment Water Level (SCADA)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."a_storage"       is 'Volume of water in A compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."b_storage"       is 'Volume of water in B compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."c_storage"       is 'Volume of water in C compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."d_storage"       is 'Volume of water in D compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."e_storage"       is 'Volume of water in E compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."f_storage"       is 'Volume of water in F compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."g_storage"       is 'Volume of water in G compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."h_storage"       is 'Volume of water in H compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."i_storage"       is 'Volume of water in I compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."j_storage"       is 'Volume of water in J compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."k_storage"       is 'Volume of water in K compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."l_storage"       is 'Volume of water in L compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."m_storage"       is 'Volume of water in M compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."n_storage"       is 'Volume of water in N compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."o_storage"       is 'Volume of water in O compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."p_storage"       is 'Volume of water in P compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."q_storage"       is 'Volume of water in Q compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."r_storage"       is 'Volume of water in R compartment of an SR.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."tot_storage"     is 'Total volume of water in A+ B+..+R.  Unit is in cu m'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."remarks"         is 'Remarks'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."rec_dt"          is 'Date of record'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."submit_dt"       is 'Submission Date'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."last_upd_user"   is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."last_upd_post"   is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."last_upd_dt"     is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year.ods_update_time   is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year.ods_load_time     is 'Data Loading Time'
;comment on column coss_ods.ods_sttss_rws_sr_storage_di_year."dt"              is 'Daily Partitions'

;delete from coss_ods.ods_sttss_rws_sr_storage_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_ods.ods_sttss_rws_sr_storage_di_year
select
  sr_id                                 -- Service Reservior being referenced
  ,a_wlevel                             -- A Compartment Water Level
  ,b_wlevel                             -- B Compartment Water Level
  ,c_wlevel                             -- C Compartment Water Level
  ,d_wlevel                             -- D Compartment Water Level
  ,e_wlevel                             -- E Compartment Water Level
  ,f_wlevel                             -- F Compartment Water Level
  ,g_wlevel                             -- G Compartment Water Level
  ,h_wlevel                             -- H Compartment Water Level
  ,i_wlevel                             -- I Compartment Water Level
  ,j_wlevel                             -- J Compartment Water Level
  ,k_wlevel                             -- K Compartment Water Level
  ,l_wlevel                             -- L Compartment Water Level
  ,m_wlevel                             -- M Compartment Water Level
  ,n_wlevel                             -- N Compartment Water Level
  ,o_wlevel                             -- O Compartment Water Level
  ,p_wlevel                             -- P Compartment Water Level
  ,q_wlevel                             -- Q Compartment Water Level
  ,r_wlevel                             -- R Compartment Water Level
  ,scada_a_wlevel                       -- A Compartment Water Level (SCADA)
  ,scada_b_wlevel                       -- B Compartment Water Level (SCADA)
  ,scada_c_wlevel                       -- C Compartment Water Level (SCADA)
  ,scada_d_wlevel                       -- D Compartment Water Level (SCADA)
  ,scada_e_wlevel                       -- E Compartment Water Level (SCADA)
  ,scada_f_wlevel                       -- F Compartment Water Level (SCADA)
  ,scada_g_wlevel                       -- G Compartment Water Level (SCADA)
  ,scada_h_wlevel                       -- H Compartment Water Level (SCADA)
  ,scada_i_wlevel                       -- I Compartment Water Level (SCADA)
  ,scada_j_wlevel                       -- J Compartment Water Level (SCADA)
  ,scada_k_wlevel                       -- K Compartment Water Level (SCADA)
  ,scada_l_wlevel                       -- L Compartment Water Level (SCADA)
  ,scada_m_wlevel                       -- M Compartment Water Level (SCADA)
  ,scada_n_wlevel                       -- N Compartment Water Level (SCADA)
  ,scada_o_wlevel                       -- O Compartment Water Level (SCADA)
  ,scada_p_wlevel                       -- P Compartment Water Level (SCADA)
  ,scada_q_wlevel                       -- Q Compartment Water Level (SCADA)
  ,scada_r_wlevel                       -- R Compartment Water Level (SCADA)
  ,a_storage                            -- Volume of water in A compartment of an SR.  Unit is in cu m
  ,b_storage                            -- Volume of water in B compartment of an SR.  Unit is in cu m
  ,c_storage                            -- Volume of water in C compartment of an SR.  Unit is in cu m
  ,d_storage                            -- Volume of water in D compartment of an SR.  Unit is in cu m
  ,e_storage                            -- Volume of water in E compartment of an SR.  Unit is in cu m
  ,f_storage                            -- Volume of water in F compartment of an SR.  Unit is in cu m
  ,g_storage                            -- Volume of water in G compartment of an SR.  Unit is in cu m
  ,h_storage                            -- Volume of water in H compartment of an SR.  Unit is in cu m
  ,i_storage                            -- Volume of water in I compartment of an SR.  Unit is in cu m
  ,j_storage                            -- Volume of water in J compartment of an SR.  Unit is in cu m
  ,k_storage                            -- Volume of water in K compartment of an SR.  Unit is in cu m
  ,l_storage                            -- Volume of water in L compartment of an SR.  Unit is in cu m
  ,m_storage                            -- Volume of water in M compartment of an SR.  Unit is in cu m
  ,n_storage                            -- Volume of water in N compartment of an SR.  Unit is in cu m
  ,o_storage                            -- Volume of water in O compartment of an SR.  Unit is in cu m
  ,p_storage                            -- Volume of water in P compartment of an SR.  Unit is in cu m
  ,q_storage                            -- Volume of water in Q compartment of an SR.  Unit is in cu m
  ,r_storage                            -- Volume of water in R compartment of an SR.  Unit is in cu m
  ,tot_storage                          -- Total volume of water in A+ B+..+R.  Unit is in cu m
  ,remarks                              -- Remarks
  ,rec_dt                               -- Date of record
  ,submit_dt                            -- Submission Date
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd') dt       -- Daily Partitions
from sttss.sr_storage
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 19.coss_ods.ods_sttss_rws_w_type_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw Water Type
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.w_type
-- target table
-- coss_ods.ods_sttss_rws_w_type_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_w_type_df
;create table if not exists coss_ods.ods_sttss_rws_w_type_df(
  code varchar(4)             -- Possible Values{G - Guangdong, R - River, O - Others}
  ,descrip varchar(90)        -- Description of Raw Water Source
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(code)
)
distribute by hash(code)
;comment on table  coss_ods.ods_sttss_rws_w_type_df                  is 'Raw Water Type'
;comment on column coss_ods.ods_sttss_rws_w_type_df.code             is 'Possible Values{G - Guangdong, R - River, O - Others}'
;comment on column coss_ods.ods_sttss_rws_w_type_df.descrip          is 'Description of Raw Water Source'
;comment on column coss_ods.ods_sttss_rws_w_type_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_w_type_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_w_type_df
;insert into coss_ods.ods_sttss_rws_w_type_df 
select 
  code                                  -- Possible Values{G - Guangdong, R - River, O - Others}
  ,descrip                              -- Description of Raw Water Source
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from 
sttss.w_type
```

## 20.coss_ods.ods_sttss_rws_water_usage_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Water Usage
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.water_usage
-- target table
-- coss_ods.ods_sttss_rws_water_usage_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_water_usage_df
;create table if not exists coss_ods.ods_sttss_rws_water_usage_df(
  "code"         decimal(3)        -- Code
  ,"descrip"     varchar(200)      -- Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(code)
)
distribute by hash("code")
;comment on table  coss_ods.ods_sttss_rws_water_usage_df                  is 'Water Usage'
;comment on column coss_ods.ods_sttss_rws_water_usage_df."code"           is 'Code'
;comment on column coss_ods.ods_sttss_rws_water_usage_df."descrip"        is 'Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}'
;comment on column coss_ods.ods_sttss_rws_water_usage_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_water_usage_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_water_usage_df
;insert into coss_ods.ods_sttss_rws_water_usage_df 
select 
  code                                  -- Code
  ,descrip                              -- Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.water_usage
```

## 21.coss_ods.ods_sttss_rws_wtw_df

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Water Treatment Works
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
--  sttss.wtw
-- target table
-- coss_ods.ods_sttss_rws_wtw_df
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_wtw_df
;create table if not exists coss_ods.ods_sttss_rws_wtw_df(
  "tw_id"           varchar(20)       -- Water Treatment Woks ID with format TWNNNNNNNN
  ,"i_code"         varchar(10)       -- Installation Code of Water Treatment Works
  ,"rlabel"         varchar(400)      -- Labels used in reports
  ,"region"         varchar(10)       -- Region
  ,"capacity"       decimal(12,4)     -- Capacity of WTW.  Unit is in Mld
  ,"last_upd_user"  varchar(120)      -- Last Update By (Username)
  ,"last_upd_post"  varchar(52)       -- Last Update By (Post)
  ,"last_upd_dt"    timestamp(6)      -- Last Update Date
  ,"tw_name"        varchar(200)      -- Water Treatment Works Name
  ,"tw_cname"       varchar(300)      -- Water Treatment Works Chinese Name
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,primary key(tw_id)
)
distribute by hash("tw_id")
;comment on table  coss_ods.ods_sttss_rws_wtw_df                  is 'Water Treatment Works'
;comment on column coss_ods.ods_sttss_rws_wtw_df."tw_id"          is 'Water Treatment Woks ID with format TWNNNNNNNN'
;comment on column coss_ods.ods_sttss_rws_wtw_df."i_code"         is 'Installation Code of Water Treatment Works'
;comment on column coss_ods.ods_sttss_rws_wtw_df."rlabel"         is 'Labels used in reports'
;comment on column coss_ods.ods_sttss_rws_wtw_df."region"         is 'Region'
;comment on column coss_ods.ods_sttss_rws_wtw_df."capacity"       is 'Capacity of WTW.  Unit is in Mld'
;comment on column coss_ods.ods_sttss_rws_wtw_df."last_upd_user"  is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_wtw_df."last_upd_post"  is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_wtw_df."last_upd_dt"    is 'Last Update Date'
;comment on column coss_ods.ods_sttss_rws_wtw_df."tw_name"        is 'Water Treatment Works Name'
;comment on column coss_ods.ods_sttss_rws_wtw_df."tw_cname"       is 'Water Treatment Works Chinese Name'
;comment on column coss_ods.ods_sttss_rws_wtw_df.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_wtw_df.ods_load_time    is 'Data Loading Time'

;delete from coss_ods.ods_sttss_rws_wtw_df
;insert into coss_ods.ods_sttss_rws_wtw_df
select
  tw_id                                 -- Water Treatment Woks ID with format TWNNNNNNNN
  ,i_code                               -- Installation Code of Water Treatment Works
  ,rlabel                               -- Labels used in reports
  ,region                               -- Region
  ,capacity                             -- Capacity of WTW.  Unit is in Mld
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,last_upd_dt                          -- Last Update Date
  ,tw_name                              -- Water Treatment Works Name
  ,tw_cname                             -- Water Treatment Works Chinese Name
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
from sttss.wtw
```

## 22.coss_ods.ods_sttss_rws_gd_agr_supply_di_year

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Daily GD Water Supply
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- sttss.gd_agr_supply
-- target table
-- coss_ods.ods_sttss_rws_gd_agr_supply_di_year
-- ****************************************************************************************
;drop table if exists coss_ods.ods_sttss_rws_gd_agr_supply_di_year
;create table if not exists coss_ods.ods_sttss_rws_gd_agr_supply_di_year( 
  rw_id             varchar(20)         -- Raw water Source being referenced
  ,hk_vol           numeric(14, 6)      -- Volume at HK Side.  Unit is in mcm
  ,gd_vol           numeric(14, 6)      -- Volume at GD Side. Unit is in mcm
  ,agr_vol          numeric(14, 6)      -- Agreed volume.  Unit is in mcm
  ,dis_vol          numeric(14, 6)      -- Discharged volume.  Unit is in mcm
  ,sz_wlevel        numeric(12, 4)      -- Shen Zhen Water Level.  Unit is in m
  ,dis_ind          varchar(3)          -- Possible Values:Y - Yes,N - No
  ,rec_dt           date                -- Date of record
  ,submit_dt        timestamp(6)        -- Submission Date
  ,last_upd_user    varchar(100)        -- Last Update By (Username)
  ,last_upd_post    varchar(50)         -- Last Update By (Post)
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp
  ,"dt"             decimal(10)         -- Daily Partitions
)
distribute by hash("rw_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_ods.ods_sttss_rws_gd_agr_supply_di_year                  is 'Daily GD Water Supply'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.rw_id            is 'Raw water Source being referenced'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.hk_vol           is 'Volume at HK Side.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.gd_vol           is 'Volume at GD Side. Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.agr_vol          is 'Agreed volume.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.dis_vol          is 'Discharged volume.  Unit is in mcm'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.sz_wlevel        is 'Shen Zhen Water Level.  Unit is in m'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.dis_ind          is 'Possible Values:Y - Yes,N - No'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.rec_dt           is 'Date of record'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.submit_dt        is 'Submission Date'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.last_upd_user    is 'Last Update By (Username)'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.last_upd_post    is 'Last Update By (Post)'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.ods_load_time    is 'Data Loading Time'
;comment on column coss_ods.ods_sttss_rws_gd_agr_supply_di_year.dt               is 'Daily Partitions'

;delete from coss_ods.ods_sttss_rws_gd_agr_supply_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into  coss_ods.ods_sttss_rws_gd_agr_supply_di_year
select
  rw_id                                 -- Raw water Source being referenced
  ,hk_vol                               -- Volume at HK Side.  Unit is in mcm
  ,gd_vol                               -- Volume at GD Side. Unit is in mcm
  ,agr_vol                              -- Agreed volume.  Unit is in mcm
  ,dis_vol                              -- Discharged volume.  Unit is in mcm
  ,sz_wlevel                            -- Shen Zhen Water Level.  Unit is in m
  ,dis_ind                              -- Possible Values:Y - Yes,N - No
  ,rec_dt                               -- Date of record
  ,submit_dt                            -- Submission Date
  ,last_upd_user                        -- Last Update By (Username)
  ,last_upd_post                        -- Last Update By (Post)
  ,localtimestamp as ods_update_time    -- Data Warehouse update Time
  ,localtimestamp as ods_load_time      -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd') as dt    -- Daily Partitions
from sttss.gd_agr_supply
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

# dim

## 1.coss_dim.dim_ass_channels_df

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Water Transfer Channels Information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_water_usage_df
-- coss_ods.ods_sttss_rws_w_type_df
-- coss_ods.ods_sttss_rws_calc_df
-- coss_ods.ods_sttss_rws_measurement_df
-- target table
-- coss_dim.dim_ass_channels_df
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_channels_df
;create table if not exists  coss_dim.dim_ass_channels_df(
    option_no        decimal(10)         -- Option No.
    ,ch_id            varchar(20)        -- System generated ID of a water transfer channel
    ,src_id           varchar(20)        -- Source of Water Inflow
    ,dest_id          varchar(20)        -- Destination of Water outflow
    ,rlabel           varchar(2000)      -- Labels used in reports
    ,w_usage          decimal(3)         -- Water Usage
    ,w_usage_desc     varchar(200)       -- Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}
    ,w_type           varchar(2)         -- Type of water maintained by the installation
    ,w_type_desc      varchar(200)       -- Description of Water Type
    ,calc_id          decimal(10)        -- Calculation logic being referenced by daily water transfer volume of channels
    ,calc_usage       varchar(2)         -- Determines if the referenced Channel or Internal Circulation is used as summation or difference Possible Values:{"S" - Sum, "D" - Difference}
    ,meas_code        varchar(20)        -- Measured By
    ,meas_desc        varchar(200)       -- Description of Measurement
    ,meas_cdesc       varchar(300)       -- Chinese Description of Measurement Type
    ,dim_update_time  timestamp(6)       default current_timestamp
    ,dim_load_time    timestamp(6)       default current_timestamp
    ,primary key(option_no, ch_id, src_id, dest_id)
)
distribute by hash("ch_id")
;comment on table  coss_dim.dim_ass_channels_df                  is  'Water Transfer Channels Information'
;comment on column coss_dim.dim_ass_channels_df.option_no        is  'Option No.'
;comment on column coss_dim.dim_ass_channels_df.ch_id            is  'System generated ID of a water transfer channel'
;comment on column coss_dim.dim_ass_channels_df.src_id           is  'Source of Water Inflow'
;comment on column coss_dim.dim_ass_channels_df.dest_id          is  'Destination of Water outflow'
;comment on column coss_dim.dim_ass_channels_df.rlabel           is  'Labels used in reports'
;comment on column coss_dim.dim_ass_channels_df.w_usage          is  'Water Usage'
;comment on column coss_dim.dim_ass_channels_df.w_usage_desc     is  'Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}'
;comment on column coss_dim.dim_ass_channels_df.w_type           is  'Type of water maintained by the installation'
;comment on column coss_dim.dim_ass_channels_df.w_type_desc      is  'Description of Water Type'
;comment on column coss_dim.dim_ass_channels_df.calc_id          is  'Calculation logic being referenced by daily water transfer volume of channels'
;comment on column coss_dim.dim_ass_channels_df.calc_usage       is  'Determines if the referenced Channel or Internal Circulation is used as summation or difference Possible Values:{"S" - Sum, "D" - Difference}'
;comment on column coss_dim.dim_ass_channels_df.meas_code        is  'Measured By'
;comment on column coss_dim.dim_ass_channels_df.meas_desc        is  'Description of Measurement'
;comment on column coss_dim.dim_ass_channels_df.meas_cdesc       is  'Chinese Description of Measurement Type'
;comment on column coss_dim.dim_ass_channels_df.dim_update_time  is  'Data Update Time'
;comment on column coss_dim.dim_ass_channels_df.dim_load_time    is  'Data Loading Time'

;drop table if exists coss_tmp.tmp_dim_ass_channels_df_1
;create table if not exists coss_tmp.tmp_dim_ass_channels_df_1 as 
select
  t.option_no      as  option_no       -- Option No.
  ,t.ch_id         as  ch_id           -- System generated ID of a water transfer channel
  ,t.src_id        as  src_id          -- Source of Water Inflow
  ,t.dest_id       as  dest_id         -- Destination of Water outflow
  ,t.rlabel        as  rlabel          -- Labels used in reports
  ,t.water_usage   as  w_usage         -- Water Usage
  ,t1.descrip      as  w_usage_desc    -- Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}
  ,t.w_type        as  w_type          -- Type of water maintained by the installation
  ,t2.descrip      as  w_type_desc     -- Description of Water Type
  ,t.calc_id       as  calc_id         -- Calculation logic being referenced by daily water transfer volume of channels
  ,t.m_code        as  meas_code       -- Measured By
from 
coss_ods.ods_sttss_rws_channel_df  t
  left join coss_ods.ods_sttss_rws_water_usage_df  t1 on t.water_usage = t1.code
  left join coss_ods.ods_sttss_rws_w_type_df  t2 on t.w_type = t2.code 

;delete from coss_dim.dim_ass_channels_df
;insert into coss_dim.dim_ass_channels_df
select
  t.option_no      as  option_no       -- Option No.
  ,t.ch_id         as  ch_id           -- System generated ID of a water transfer channel
  ,t.src_id        as  src_id          -- Source of Water Inflow
  ,t.dest_id       as  dest_id         -- Destination of Water outflow
  ,t.rlabel        as  rlabel          -- Labels used in reports
  ,t.w_usage       as  w_usage         -- Water Usage
  ,t.w_usage_desc  as  w_usage_desc    -- Possible Values: {"Commissioning Test to Waste", "Commissioning Test to be Returned to System", "Augmented Supply for Flushing", Commission Test to be Used for Consumption}
  ,t.w_type        as  w_type          -- Type of water maintained by the installation
  ,t.w_type_desc   as  w_type_desc     -- Description of Water Type
  ,t.calc_id       as  calc_id         -- Calculation logic being referenced by daily water transfer volume of channels
  ,t2.usage        as  calc_usage      -- Determines if the referenced Channel or Internal Circulation is used as summation or difference Possible Values:{"S" - Sum, "D" - Difference}
  ,t.meas_code     as  meas_code       -- Measured By
  ,t3.descrip      as  meas_desc       -- Description of Measurement
  ,t3.cdescrip     as  meas_cdesc      -- Chinese Description of Measurement Type
  ,localtimestamp  as  dim_update_time -- Data Warehouse update Time
  ,localtimestamp  as  dim_load_time   -- Data Warehouse load Time
from coss_tmp.tmp_dim_ass_channels_df_1 t
  left join coss_ods.ods_sttss_rws_calc_df t2 on t.calc_id = t2.calc_id and t.ch_id = t2.ref_id
  left join coss_ods.ods_sttss_rws_measurement_df t3 on t.meas_code =t3.code
```

## 2.coss_dim.dim_ass_ir_df

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Impounding Reservoir Information
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_ir_df
-- coss_ods.ods_sttss_rws_ir_group_df
-- coss_ods.ods_sttss_rws_region_df
-- target table
-- coss_dim.dim_ass_ir_df
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_ir_df
;create table if not exists coss_dim.dim_ass_ir_df(
  ig_id             varchar(20)        -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,ig_name           varchar(200)      -- Name of Impounding Reservoir Group
  ,ig_cname          varchar(300)      -- Chinese Name of Impounding Reservoir Group
  ,ig_rpt_label      varchar(400)      -- Labels used in reports
  ,region_code       varchar(10)       -- Region
  ,region_name       varchar(60)       -- Description of Region
  ,region_cname      varchar(300)      -- Chinese Description of Region
  ,region_ind        varchar(2)        -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,ig_ind            varchar(2)        -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
  ,ir_id             varchar(20)       -- Impounding Reservoir ID with format IRNNNNNNNN
  ,i_code            varchar(10)       -- Installation Code of Impounding Reservoir
  ,ir_rpt_label      varchar(400)      -- Labels used in reports
  ,ir_name           varchar(200)      -- Impounding reservoir name
  ,ir_cname          varchar(300)      -- Impounding Reservoir Chinese Name
  ,level_type        varchar(2)        -- Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}
  ,level_unit        varchar(2)        -- Possible Values:{"F" - Feet / Inch, "M" - Meter}
  ,dead_storage      decimal(12,4)     -- Dead Storage of an Impounding Reservoir.  Unit is in mcm
  ,twl               decimal(12,4)     -- TWL
  ,capacity          decimal(12,4)     -- Capacity of IR.  Unit is in mcm
  ,min_storage       decimal(12,4)     -- Allowable Minimum Storage.  Unit is in mcm
  ,limit_m           decimal(12,4)     -- Preset Limit for Water Level.  Unit is in m
  ,dim_update_time   timestamp(6)      default current_timestamp
  ,dim_load_time     timestamp(6)      default current_timestamp
  ,primary key(ig_id,ir_id)
)
distribute by hash("ir_id")
;comment on table  coss_dim.dim_ass_ir_df                  is 'Impounding Reservoir Information'
;comment on column coss_dim.dim_ass_ir_df.ig_id            is 'Impounding Reservoir Group ID with format IGNNNNNNNN'
;comment on column coss_dim.dim_ass_ir_df.ig_name          is 'Name of Impounding Reservoir Group'
;comment on column coss_dim.dim_ass_ir_df.ig_cname         is 'Chinese Name of Impounding Reservoir Group'
;comment on column coss_dim.dim_ass_ir_df.ig_rpt_label     is 'Labels used in reports'
;comment on column coss_dim.dim_ass_ir_df.region_code      is 'Region'
;comment on column coss_dim.dim_ass_ir_df.region_name      is 'Description of Region'
;comment on column coss_dim.dim_ass_ir_df.region_cname     is 'Chinese Description of Region'
;comment on column coss_dim.dim_ass_ir_df.region_ind       is 'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dim.dim_ass_ir_df.ig_ind           is 'Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}'
;comment on column coss_dim.dim_ass_ir_df.ir_id            is 'Impounding Reservoir ID with format IRNNNNNNNN'
;comment on column coss_dim.dim_ass_ir_df.i_code           is 'Installation Code of Impounding Reservoir'
;comment on column coss_dim.dim_ass_ir_df.ir_rpt_label     is 'Labels used in reports'
;comment on column coss_dim.dim_ass_ir_df.ir_name          is 'Impounding reservoir name'
;comment on column coss_dim.dim_ass_ir_df.ir_cname         is 'Impounding Reservoir Chinese Name'
;comment on column coss_dim.dim_ass_ir_df.level_type       is 'Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}'
;comment on column coss_dim.dim_ass_ir_df.level_unit       is 'Possible Values:{"F" - Feet / Inch, "M" - Meter}'
;comment on column coss_dim.dim_ass_ir_df.dead_storage     is 'Dead Storage of an Impounding Reservoir.  Unit is in mcm'
;comment on column coss_dim.dim_ass_ir_df.twl              is 'TWL'
;comment on column coss_dim.dim_ass_ir_df.capacity         is 'Capacity of IR.  Unit is in mcm'
;comment on column coss_dim.dim_ass_ir_df.min_storage      is 'Allowable Minimum Storage.  Unit is in mcm'
;comment on column coss_dim.dim_ass_ir_df.limit_m          is 'Preset Limit for Water Level.  Unit is in m'
;comment on column coss_dim.dim_ass_ir_df.dim_update_time  is 'Data Update Time'
;comment on column coss_dim.dim_ass_ir_df.dim_load_time    is 'Data Loading Time'

;delete from coss_dim.dim_ass_ir_df
;insert into coss_dim.dim_ass_ir_df
select
  t1.ig_id           as ig_id            -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,t1.ig_name        as ig_name          -- Name of Impounding Reservoir Group
  ,t1.ig_cname       as ig_cname         -- Chinese Name of Impounding Reservoir Group
  ,t1.rlabel         as ig_rpt_label     -- Labels used in reports
  ,case
  when t1.region = 'HK' then 'HKI'
  else t1.region        end region_code  -- Region
  ,t2.descrip        as region_name      -- Description of Region
  ,t2.cdescrip       as region_cname     -- Chinese Description of Region
  ,t2.indicator      as region_ind       -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,t1.old_ind        as ig_ind           -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
  ,t.ir_id           as ir_id            -- Impounding Reservoir ID with format IRNNNNNNNN
  ,t.i_code          as i_code           -- Installation Code of Impounding Reservoir
  ,t.rlabel          as ir_rpt_label     -- Labels used in reports
  ,t.ir_name         as ir_name          -- Impounding reservoir name
  ,t.ir_cname        as ir_cname         -- Impounding Reservoir Chinese Name
  ,t.level_type      as level_type       -- Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}
  ,t.level_unit      as level_unit       -- Possible Values:{"F" - Feet / Inch, "M" - Meter}
  ,t.dead_storage    as dead_storage     -- Dead Storage of an Impounding Reservoir.  Unit is in mcm
  ,t.twl             as twl              -- TWL
  ,t.capacity        as capacity         -- Capacity of IR.  Unit is in mcm
  ,t.min_storage     as min_storage      -- Allowable Minimum Storage.  Unit is in mcm
  ,t.limit_m         as limit_m          -- Preset Limit for Water Level.  Unit is in m
  ,localtimestamp    as dim_update_time  -- Data Warehouse update Time
  ,localtimestamp    as dim_load_time    -- Data Warehouse load Time
from coss_ods.ods_sttss_rws_ir_df t
  left join coss_ods.ods_sttss_rws_ir_group_df t1 on t.ig_id = t1.ig_id
  left join coss_ods.ods_sttss_rws_region_df t2 on t1.region = t2.code

```

## 3.coss_dim.dim_ass_ps_df

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Pumping station Information
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_ps_df
-- coss_ods.ods_sttss_rws_region_df
-- coss_ods.ods_sttss_rws_w_type_df
-- target table
-- coss_dim.dim_ass_ps_df
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_ps_df
;create table if not exists coss_dim.dim_ass_ps_df(
  ps_id             varchar(20)        -- Pumping Station ID with format PSNNNNNNNN
  ,i_code           varchar(10)        -- Installation Code of Pumping Station
  ,ps_name          varchar(200)       -- Pumping station name
  ,ps_cname         varchar(300)       -- Pumping Station Chinese Name
  ,rpt_label        varchar(400)       -- Labels used in reports
  ,region_code      varchar(10)        -- Region
  ,region_name      varchar(60)        -- Description of Region
  ,region_cname     varchar(300)       -- Chinese Description of Region
  ,region_ind       varchar(2)         -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,w_type           varchar(2)         -- Type of water maintained in the pumping station
  ,w_type_desc      varchar(200)       -- Description of Water Type
  ,repumping        varchar(2)         -- Repumping
  ,remarks          varchar(200)       -- Remarks
  ,dim_update_time timestamp(6) default current_timestamp
  ,dim_load_time   timestamp(6) default current_timestamp
  ,primary key(ps_id)
)
distribute by hash("ps_id")
;comment on table  coss_dim.dim_ass_ps_df                  is 'Pumping station Information'
;comment on column coss_dim.dim_ass_ps_df.ps_id            is 'Pumping Station ID with format PSNNNNNNNN'
;comment on column coss_dim.dim_ass_ps_df.i_code           is 'Installation Code of Pumping Station'
;comment on column coss_dim.dim_ass_ps_df.ps_name          is 'Pumping station name'
;comment on column coss_dim.dim_ass_ps_df.ps_cname         is 'Pumping Station Chinese Name'
;comment on column coss_dim.dim_ass_ps_df.rpt_label        is 'Labels used in reports'
;comment on column coss_dim.dim_ass_ps_df.region_code      is 'Region'
;comment on column coss_dim.dim_ass_ps_df.region_name      is 'Description of Region'
;comment on column coss_dim.dim_ass_ps_df.region_cname     is 'Chinese Description of Region'
;comment on column coss_dim.dim_ass_ps_df.region_ind       is 'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dim.dim_ass_ps_df.w_type           is 'Type of water maintained in the pumping station'
;comment on column coss_dim.dim_ass_ps_df.w_type_desc      is 'Description of Water Type'
;comment on column coss_dim.dim_ass_ps_df.repumping        is 'Repumping'
;comment on column coss_dim.dim_ass_ps_df.remarks          is 'Remarks'
;comment on column coss_dim.dim_ass_ps_df.dim_update_time  is 'Data Update Time'
;comment on column coss_dim.dim_ass_ps_df.dim_load_time    is 'Data Loading Time'

;delete from coss_dim.dim_ass_ps_df
;insert into coss_dim.dim_ass_ps_df
select
  t.ps_id            as  ps_id              -- Pumping Station ID with format PSNNNNNNNN
  ,t.i_code          as  i_code             -- Installation Code of Pumping Station
  ,t.ps_name         as  ps_name            -- Pumping station name
  ,t.ps_cname        as  ps_cname           -- Pumping Station Chinese Name
  ,t.rlabel          as  rpt_label          -- Labels used in reports
  ,case
  when t.region = 'HK' then 'HKI'
  else t.region        end region_code  -- Region
  ,t1.descrip        as  region_name        -- Description of Region
  ,t1.cdescrip       as  region_cname       -- Chinese Description of Region
  ,t1.indicator      as  region_ind         -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,t.w_type          as  w_type             -- Type of water maintained in the pumping station
  ,t2.descrip        as  w_type_desc        -- Description of Water Type
  ,t.repumping       as  repumping          -- Repumping
  ,t.remark          as  remarks            -- Remarks
  ,localtimestamp    as dim_update_time     -- Data Warehouse update Time
  ,localtimestamp    as dim_load_time       -- Data Warehouse load Time
from coss_ods.ods_sttss_rws_ps_df t
  left join coss_ods.ods_sttss_rws_region_df t1  on t.region = t1.code
  left join coss_ods.ods_sttss_rws_w_type_df t2  on t.w_type = t2.code
```

## 4.coss_dim.dim_ass_rw_src_df

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Raw Water Source Information
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_ir_group_df
-- coss_ods.ods_sttss_rws_region_df
-- coss_ods.ods_sttss_rws_rw_df
-- coss_ods.ods_sttss_rws_rw_type_df
-- target table
-- coss_dim.dim_ass_rw_src_df
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_rw_src_df
;create table if not exists coss_dim.dim_ass_rw_src_df(
    rw_id            varchar(20)         -- Raw Water Source ID with format RWNNNNNNNN
    ,rw_name         varchar(200)        -- Name of Raw Water
    ,rw_cname        varchar(300)        -- Chinese Name of Raw Water
    ,rpt_label       varchar(400)        -- Labels used in reports
    ,region_code     varchar(10)         -- Region Code
    ,region_name     varchar(60)         -- Description of Region
    ,region_cname    varchar(300)        -- Chinese Description of Region
    ,region_ind      varchar(2)          -- Possible Values: {"I" - HK Island, "M" - Mainland}
    ,ig_ind          varchar(2)          -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
    ,source_rw       varchar(2)          -- Source of raw water
    ,source_desc     varchar(60)         -- Description of Raw Water Source
    ,dim_update_time timestamp(6)        default current_timestamp
    ,dim_load_time   timestamp(6)        default current_timestamp
    ,primary key(rw_id)
)

distribute by hash("rw_id")
;comment on table  coss_dim.dim_ass_rw_src_df                  is  'Raw Water Source Information'
;comment on column coss_dim.dim_ass_rw_src_df.rw_id            is  'Raw Water Source ID with format RWNNNNNNNN'
;comment on column coss_dim.dim_ass_rw_src_df.rw_name          is  'Name of Raw Water'
;comment on column coss_dim.dim_ass_rw_src_df.rw_cname         is  'Chinese Name of Raw Water'
;comment on column coss_dim.dim_ass_rw_src_df.rpt_label        is  'Labels used in reports'
;comment on column coss_dim.dim_ass_rw_src_df.region_code      is  'Region Code'
;comment on column coss_dim.dim_ass_rw_src_df.region_name      is  'Description of Region'
;comment on column coss_dim.dim_ass_rw_src_df.region_cname     is  'Chinese Description of Region'
;comment on column coss_dim.dim_ass_rw_src_df.region_ind       is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dim.dim_ass_rw_src_df.ig_ind           is  'Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}'
;comment on column coss_dim.dim_ass_rw_src_df.source_rw        is  'Source of raw water'
;comment on column coss_dim.dim_ass_rw_src_df.source_desc      is  'Description of Raw Water Source'
;comment on column coss_dim.dim_ass_rw_src_df.dim_update_time  is 'Data Update Time'
;comment on column coss_dim.dim_ass_rw_src_df.dim_load_time    is 'Data Loading Time'


;drop table if exists coss_tmp.tmp_dim_ass_rw_src_df_1
;create table if not exists coss_tmp.tmp_dim_ass_rw_src_df_1 as
select
    ig_id               as rw_id               -- Raw Water Source ID with format RWNNNNNNNN
    ,ig_name            as rw_name             -- Name of Raw Water
    ,ig_cname           as rw_cname            -- Chinese Name of Raw Water
    ,rlabel             as rpt_label           -- Labels used in reports
    ,region             as region_code         -- Region Code
    ,descrip            as region_name         -- Description of Region
    ,cdescrip           as region_cname        -- Chinese Description of Region
    ,indicator          as region_ind          -- Possible Values: {"I" - HK Island, "M" - Mainland}
    ,old_ind            as ig_ind              -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
    ,'O'                as source_rw           -- Source of raw water
    ,'Others'           as source_desc         -- Description of Raw Water Source
from coss_ods.ods_sttss_rws_ir_group_df t
  left join coss_ods.ods_sttss_rws_region_df t1 on t.region = t1.code

;drop table if exists coss_tmp.tmp_dim_ass_rw_src_df_2
;create table if not exists coss_tmp.tmp_dim_ass_rw_src_df_2 as
select
    t.rw_id             as rw_id             -- Raw Water Source ID with format RWNNNNNNNN
    ,t.rw_name          as rw_name           -- Name of Raw Water
    ,t.rw_cname         as rw_cname          -- Chinese Name of Raw Water
    ,t.rlabel           as rpt_label         -- Labels used in reports
    ,t.region           as region_code       -- Region Code
    ,t1.descrip         as region_name       -- Description of Region
    ,t1.cdescrip        as region_cname      -- Chinese Description of Region
    ,t1.indicator       as region_ind        -- Possible Values: {"I" - HK Island, "M" - Mainland}
    ,' '                as ig_ind            -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
    ,t.source           as source_rw         -- Source of raw water
    ,t2.descrip         as source_desc       -- Description of Raw Water Source
from coss_ods.ods_sttss_rws_rw_df t
  left join coss_ods.ods_sttss_rws_region_df t1 on t.region = t1.code
  left join coss_ods.ods_sttss_rws_rw_type_df t2 on t.source = t2.code

;delete from coss_dim.dim_ass_rw_src_df
;insert into coss_dim.dim_ass_rw_src_df
select
    rw_id             -- Raw Water Source ID with format RWNNNNNNNN
    ,rw_name          -- Name of Raw Water
    ,rw_cname         -- Chinese Name of Raw Water
    ,rpt_label        -- Labels used in reports
    ,region_code      -- Region Code
    ,region_name      -- Description of Region
    ,region_cname     -- Chinese Description of Region
    ,region_ind       -- Possible Values: {"I" - HK Island, "M" - Mainland}
    ,ig_ind           -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
    ,source_rw        -- Source of raw water
    ,source_desc      -- Description of Raw Water Source
    ,dim_update_time  -- Data Warehouse update Time
    ,dim_load_time    -- Data Warehouse load Time
from
(
select
    rw_id                               -- Raw Water Source ID with format RWNNNNNNNN
    ,rw_name                            -- Name of Raw Water
    ,rw_cname                           -- Chinese Name of Raw Water
    ,rpt_label                          -- Labels used in reports
    ,case
    when region_code = 'HK' then 'HKI'
    else region_code  end region_code  -- Region Code
    ,region_name                        -- Description of Region
    ,region_cname                       -- Chinese Description of Region
    ,region_ind                         -- Possible Values: {"I" - HK Island, "M" - Mainland}
    ,ig_ind                             -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
    ,source_rw                          -- Source of raw water
    ,source_desc                        -- Description of Raw Water Source
    ,localtimestamp as dim_update_time  -- Data Warehouse update Time
    ,localtimestamp as dim_load_time    -- Data Warehouse load Time
from coss_tmp.tmp_dim_ass_rw_src_df_1
)
union all
(
select
    rw_id                               -- Raw Water Source ID with format RWNNNNNNNN
    ,rw_name                            -- Name of Raw Water
    ,rw_cname                           -- Chinese Name of Raw Water
    ,rpt_label                          -- Labels used in reports
    ,case
    when region_code = 'HK' then 'HKI'
    else region_code  end region_code  -- Region Code
    ,region_name                        -- Description of Region
    ,region_cname                       -- Chinese Description of Region
    ,region_ind                         -- Possible Values: {"I" - HK Island, "M" - Mainland}
    ,ig_ind                             -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
    ,source_rw                          -- Source of raw water
    ,source_desc                        -- Description of Raw Water Source
    ,localtimestamp as dim_update_time  -- Data Warehouse update Time
    ,localtimestamp as dim_load_time    -- Data Warehouse load Time
from coss_tmp.tmp_dim_ass_rw_src_df_2
)
```

## 5.coss_dim.dim_ass_sr_df

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Service Reservoir Information
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_sr_df
-- coss_ods.ods_sttss_rws_region_df
-- coss_ods.ods_sttss_rws_w_type_df
-- target table
-- coss_dim.dim_ass_sr_df
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_sr_df
;create table if not exists coss_dim.dim_ass_sr_df(
  sr_id             varchar(20)        -- Service Reservoir ID with format SRNNNNNNNN
  ,i_code           varchar(10)        -- Installation Code of Service Reservoir
  ,sr_name          varchar(200)       -- Service Reservoir Name
  ,sr_cname         varchar(300)       -- Service Reservoir Chinese Name
  ,rpt_label        varchar(400)       -- Labels used in reports
  ,region_code      varchar(5)         -- Region
  ,region_name      varchar(60)        -- Description of Region
  ,region_cname     varchar(300)       -- Chinese Description of Region
  ,region_ind       varchar(2)         -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,w_type           varchar(2)         -- Type of water maintained by the service reservoir
  ,w_type_desc      varchar(200)       -- Description of Water Type
  ,div_height       decimal(12,4)      -- Height of Division Wall.  Unit is in m
  ,capacity         decimal(12,4)      -- Capacity of Service Reservoir.  Unit is in cu m
  ,w_lim            decimal(12,4)      -- Preset Limit for Water Level above division wall.  Unit is in m
  ,num_of_storage   decimal(10)        -- No. of Storage/Compartment
  ,dim_update_time timestamp(6)        default current_timestamp
  ,dim_load_time   timestamp(6)        default current_timestamp
  ,primary key(sr_id)
)
distribute by hash("sr_id")
;comment on table  coss_dim.dim_ass_sr_df                   is  'Service Reservoir Information'
;comment on column coss_dim.dim_ass_sr_df.sr_id             is  'Service Reservoir ID with format SRNNNNNNNN'
;comment on column coss_dim.dim_ass_sr_df.i_code            is  'Installation Code of Service Reservoir'
;comment on column coss_dim.dim_ass_sr_df.sr_name           is  'Service Reservoir Name '
;comment on column coss_dim.dim_ass_sr_df.sr_cname          is  'Service Reservoir Chinese Name'
;comment on column coss_dim.dim_ass_sr_df.rpt_label         is  'Labels used in reports'
;comment on column coss_dim.dim_ass_sr_df.region_code       is  'Region'
;comment on column coss_dim.dim_ass_sr_df.region_name       is  'Description of Region'
;comment on column coss_dim.dim_ass_sr_df.region_cname      is  'Chinese Description of Region'
;comment on column coss_dim.dim_ass_sr_df.region_ind        is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dim.dim_ass_sr_df.w_type            is  'Type of water maintained by the service reservoir'
;comment on column coss_dim.dim_ass_sr_df.w_type_desc       is  'Description of Water Type'
;comment on column coss_dim.dim_ass_sr_df.div_height        is  'Height of Division Wall.  Unit is in m'
;comment on column coss_dim.dim_ass_sr_df.capacity          is  'Capacity of Service Reservoir.  Unit is in cu m'
;comment on column coss_dim.dim_ass_sr_df.w_lim             is  'Preset Limit for Water Level above division wall.  Unit is in m'
;comment on column coss_dim.dim_ass_sr_df.num_of_storage    is  'No. of Storage/Compartment'
;comment on column coss_dim.dim_ass_sr_df.dim_update_time   is  'Data Update Time'
;comment on column coss_dim.dim_ass_sr_df.dim_load_time     is  'Data Loading Time'

;delete from coss_dim.dim_ass_sr_df
;insert into coss_dim.dim_ass_sr_df
select
  t.sr_id             as  sr_id            -- Service Reservoir ID with format SRNNNNNNNN
  ,t.i_code           as  i_code           -- Installation Code of Service Reservoir
  ,t.sr_name          as  sr_name          -- Service Reservoir Name
  ,t.sr_cname         as  sr_cname         -- Service Reservoir Chinese Name
  ,t.rlabel           as  rpt_label        -- Labels used in reports
  ,case
  when t.region = 'HK' then 'HKI'
  else t.region  end  as  region_code      -- Region Code
  ,t1.descrip         as  region_name      -- Description of Region
  ,t1.cdescrip        as  region_cname     -- Chinese Description of Region
  ,t1.indicator       as  region_ind       -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,t.w_type           as  w_type           -- Type of water maintained by the service reservoir
  ,t2.descrip         as  w_type_desc      -- Description of Water Type
  ,t.div_height       as  div_height       -- Height of Division Wall.  Unit is in m
  ,t.capacity         as  capacity         -- Capacity of Service Reservoir.  Unit is in cu m
  ,t.limit            as  w_lim            -- Preset Limit for Water Level above division wall.  Unit is in m
  ,t.num_of_storage   as  num_of_storag    -- No. of Storage/Compartment
  ,localtimestamp     as dim_update_time   -- Data Warehouse update Time
  ,localtimestamp     as dim_load_time     -- Data Warehouse load Time
from coss_ods.ods_sttss_rws_sr_df t
  left join coss_ods.ods_sttss_rws_region_df t1  on t.region = t1.code
  left join coss_ods.ods_sttss_rws_w_type_df t2  on t.w_type = t2.code

```

## 6.coss_dim.dim_ass_wtw_df

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Water Treatment Works Information
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_wtw_df
-- coss_ods.ods_sttss_rws_region_df
-- target table
-- coss_dim.dim_ass_wtw_df
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_wtw_df
;create table if not exists coss_dim.dim_ass_wtw_df(
   tw_id           varchar(20)         -- Water Treatment Works Information
  ,i_code          varchar(10)         -- Water Treatment Woks ID with format TWNNNNNNNN
  ,tw_name         varchar(200)        -- Installation Code of Water Treatment Works
  ,tw_cname        varchar(300)        -- Water Treatment Works Name
  ,rpt_label       varchar(400)        -- Water Treatment Works Chinese Name
  ,region_code     varchar(10)         -- Labels used in reports
  ,region_name     varchar(60)         -- Region
  ,region_cname    varchar(300)        -- Description of Region
  ,region_ind      varchar(2)          -- Chinese Description of Region
  ,capacity        decimal(12,4)       -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,dim_update_time timestamp(6)        default current_timestamp
  ,dim_load_time   timestamp(6)        default current_timestamp
  ,primary key(tw_id)
)
distribute by hash("tw_id")
;comment on table  coss_dim.dim_ass_wtw_df                  is  'Water Treatment Works Information'
;comment on column coss_dim.dim_ass_wtw_df.tw_id            is  'Water Treatment Woks ID with format TWNNNNNNNN'
;comment on column coss_dim.dim_ass_wtw_df.i_code           is  'Installation Code of Water Treatment Works'
;comment on column coss_dim.dim_ass_wtw_df.tw_name          is  'Water Treatment Works Name'
;comment on column coss_dim.dim_ass_wtw_df.tw_cname         is  'Water Treatment Works Chinese Name'
;comment on column coss_dim.dim_ass_wtw_df.rpt_label        is  'Labels used in reports'
;comment on column coss_dim.dim_ass_wtw_df.region_code      is  'Region'
;comment on column coss_dim.dim_ass_wtw_df.region_name      is  'Description of Region'
;comment on column coss_dim.dim_ass_wtw_df.region_cname     is  'Chinese Description of Region'
;comment on column coss_dim.dim_ass_wtw_df.region_ind       is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dim.dim_ass_wtw_df.capacity         is  'Capacity of WTW.  Unit is in Mld'
;comment on column coss_dim.dim_ass_wtw_df.dim_update_time  is 'Data Update Time'
;comment on column coss_dim.dim_ass_wtw_df.dim_load_time    is 'Data Loading Time'

;delete from coss_dim.dim_ass_wtw_df
;insert into coss_dim.dim_ass_wtw_df
select
  t.tw_id            as  tw_id              -- Water Treatment Works Information
  ,t.i_code          as  i_code             -- Water Treatment Woks ID with format TWNNNNNNNN
  ,t.tw_name         as  tw_name            -- Installation Code of Water Treatment Works
  ,t.tw_cname        as  tw_cname           -- Water Treatment Works Name
  ,t.rlabel          as  rpt_label          -- Water Treatment Works Chinese Name
  ,case
  when t.region = 'HK' then 'HKI'
  else t.region  end as  region_code        -- Region Code
  ,t1.descrip        as  region_name        -- Region
  ,t1.cdescrip       as  region_cname       -- Description of Region
  ,t1.indicator      as  region_ind         -- Chinese Description of Region
  ,t.capacity        as  capacity           -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,localtimestamp    as dim_update_time     -- Data Warehouse update Time
  ,localtimestamp    as dim_load_time       -- Data Warehouse load Time
from coss_ods.ods_sttss_rws_wtw_df t
  left join coss_ods.ods_sttss_rws_region_df t1 on t.region = t1.code
```

## 7.coss_dim.dim_ass_sr_qty_del_info{写死的维表}

```sql
-- ****************************************************************************************
-- subject     areas: Water Assets
-- function describe: Service Reservoir Information
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_sr_df
-- coss_ods.ods_sttss_rws_region_df
-- coss_ods.ods_sttss_rws_w_type_df
-- target table
-- coss_dim.dim_ass_sr_qty_del_info
-- ****************************************************************************************
;drop table if exists coss_dim.dim_ass_sr_qty_del_info
;create table if not exists coss_dim.dim_ass_sr_qty_del_info(
  sr_id             varchar(20)        -- Service Reservoir ID with format SRNNNNNNNN
  ,i_code           varchar(10)        -- Installation Code of Service Reservoir
  ,sr_name          varchar(200)       -- Service Reservoir Name
  ,sr_cname         varchar(300)       -- Service Reservoir Chinese Name
  ,rpt_label        varchar(400)       -- Labels used in reports
  ,region_code      varchar(5)         -- Region
  ,region_name      varchar(60)        -- Description of Region
  ,region_cname     varchar(300)       -- Chinese Description of Region
  ,region_ind       varchar(2)         -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,w_type           varchar(2)         -- Type of water maintained by the service reservoir
  ,w_type_desc      varchar(200)       -- Description of Water Type
  ,div_height       decimal(12,4)      -- Height of Division Wall.  Unit is in m
  ,capacity         decimal(12,4)      -- Capacity of Service Reservoir.  Unit is in cu m
  ,w_lim            decimal(12,4)      -- Preset Limit for Water Level above division wall.  Unit is in m
  ,num_of_storage   decimal(10)        -- No. of Storage/Compartment
  ,dim_update_time timestamp(6)        default current_timestamp
  ,dim_load_time   timestamp(6)        default current_timestamp
  ,primary key(sr_id)
)
;comment on table  coss_dim.dim_ass_sr_qty_del_info                   is  'Service Reservoir Information'
;comment on column coss_dim.dim_ass_sr_qty_del_info.sr_id             is  'Service Reservoir ID with format SRNNNNNNNN'
;comment on column coss_dim.dim_ass_sr_qty_del_info.i_code            is  'Installation Code of Service Reservoir'
;comment on column coss_dim.dim_ass_sr_qty_del_info.sr_name           is  'Service Reservoir Name '
;comment on column coss_dim.dim_ass_sr_qty_del_info.sr_cname          is  'Service Reservoir Chinese Name'
;comment on column coss_dim.dim_ass_sr_qty_del_info.rpt_label         is  'Labels used in reports'
;comment on column coss_dim.dim_ass_sr_qty_del_info.region_code       is  'Region'
;comment on column coss_dim.dim_ass_sr_qty_del_info.region_name       is  'Description of Region'
;comment on column coss_dim.dim_ass_sr_qty_del_info.region_cname      is  'Chinese Description of Region'
;comment on column coss_dim.dim_ass_sr_qty_del_info.region_ind        is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dim.dim_ass_sr_qty_del_info.w_type            is  'Type of water maintained by the service reservoir'
;comment on column coss_dim.dim_ass_sr_qty_del_info.w_type_desc       is  'Description of Water Type'
;comment on column coss_dim.dim_ass_sr_qty_del_info.div_height        is  'Height of Division Wall.  Unit is in m'
;comment on column coss_dim.dim_ass_sr_qty_del_info.capacity          is  'Capacity of Service Reservoir.  Unit is in cu m'
;comment on column coss_dim.dim_ass_sr_qty_del_info.w_lim             is  'Preset Limit for Water Level above division wall.  Unit is in m'
;comment on column coss_dim.dim_ass_sr_qty_del_info.num_of_storage    is  'No. of Storage/Compartment'
;comment on column coss_dim.dim_ass_sr_qty_del_info.dim_update_time   is  'Data Update Time'
;comment on column coss_dim.dim_ass_sr_qty_del_info.dim_load_time     is  'Data Loading Time'

```

Load Data

```sql
insert into coss_dim.dim_ass_sr_qty_del_info
select
*
from 
coss_dim.dim_ass_sr_df
where sr_id in (
'SR00000346',
'SR00000147',
'SR00000191',
'SR00000026',
'SR00000040',
'SR00000022',
'SR00000172',
'SR00000035',
'SR00000196',
'SR00000180',
'SR00000023',
'SR00000298',
'SR00000093',
'SR00000210',
'SR00000175',
'SR00000154',
'SR00000294',
'SR00000020',
'SR00000395',
'SR00000329',
'SR00000062',
'SR00000369',
'SR00000017',
'SR00000061',
'SR00000080',
'SR00000396',
'SR00000053',
'SR00000378',
'SR00000047',
'SR00000052',
'SR00000332',
'SR00000108'
)
```



# dwd

## 1.coss_dwd.dwd_rws_channel_flow_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Water Transfer Channels Daily Flow Detail
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_channel_flow_di_year
-- coss_ods.ods_sttss_rws_channel_df
-- coss_ods.ods_sttss_rws_measurement_df
-- target table
-- coss_dwd.dwd_rws_channel_flow_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dwd.dwd_rws_channel_flow_detail_di_year
;create table if not exists coss_dwd.dwd_rws_channel_flow_detail_di_year(
  option_no          decimal(20)          -- Option No. of Water Transfer Channel being referenced
  ,ch_id             varchar(20)          -- Water Transfer Channels being referenced
  ,src_id            varchar(20)          -- Source of Water Inflow
  ,dest_id           varchar(20)          -- Destination of Water outflow
  ,qty_del           decimal(12,4)        -- Quantity delivered of Water transfer channel. Unit is in Mld
  ,scada_qty_del     decimal(12,4)        -- Quantity delivered of Water transfer channel. Unit is in Mld (SCADA)
  ,meas_code         varchar(20)          -- Defines how the channel water flow is measured
  ,meas_desc         varchar(200)         -- Description of Measurement
  ,meas_cdesc        varchar(300)         -- Chinese Description of Measurement Type
  ,remarks           varchar(2000)        -- Remarks
  ,wl_m              decimal(12,4)        -- Water Level reading in meter
  ,wl_mpd            decimal(13,6)        -- Waler Level in mPD
  ,rec_dt            timestamp(6)         -- Date of Record
  ,dim_update_time   timestamp(6)         default current_timestamp
  ,dim_load_time     timestamp(6)         default current_timestamp
  ,dt                decimal(10)          -- Daily Partitions
  ,primary key(option_no, ch_id,src_id,dest_id,rec_dt)
)
distribute by hash("ch_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_rws_channel_flow_detail_di_year                  is 'Water Transfer Channels Daily Flow Detail'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.option_no        is 'Option No. of Water Transfer Channel being referenced'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.ch_id            is 'Water Transfer Channels being referenced'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.src_id           is 'Source of Water Inflow'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.dest_id          is 'Destination of Water outflow'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.qty_del          is 'Quantity delivered of Water transfer channel. Unit is in Mld'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.scada_qty_del    is 'Quantity delivered of Water transfer channel. Unit is in Mld (SCADA)'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.meas_code        is 'Defines how the channel water flow is measured'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.meas_desc        is 'Description of Measurement'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.meas_cdesc       is 'Chinese Description of Measurement Type'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.remarks          is 'Remarks'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.wl_m             is 'Water Level reading in meter'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.wl_mpd           is 'Waler Level in mPD'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.rec_dt           is 'Date of Record'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.dim_update_time  is 'Data Update Time'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.dim_load_time    is 'Data Loading Time'
;comment on column coss_dwd.dwd_rws_channel_flow_detail_di_year.dt               is 'Daily Partitions'

;delete from coss_dwd.dwd_rws_channel_flow_detail_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1

insert into coss_dwd.dwd_rws_channel_flow_detail_di_year
select
  t.option_no                     as option_no       -- Option No. of Water Transfer Channel being referenced
  ,t.ch_id                        as ch_id           -- Water Transfer Channels being referenced
  ,t1.src_id                      as src_id          -- Source of Water Inflow
  ,t1.dest_id                     as dest_id         -- Destination of Water outflow
  ,t.qty_del                      as qty_del         -- Quantity delivered of Water transfer channel. Unit is in Mld
  ,t.scada_qty_del                as scada_qty_del   -- Quantity delivered of Water transfer channel. Unit is in Mld (SCADA)
  ,t.m_code                       as meas_code       -- Defines how the channel water flow is measured
  ,t2.descrip                     as meas_desc       -- Description of Measurement
  ,t2.cdescrip                    as meas_cdesc      -- Chinese Description of Measurement Type
  ,t.remarks                      as remarks         -- Remarks
  ,t.wl_m                         as wl_m            -- Water Level reading in meter
  ,t.wl_mpd                       as wl_mpd          -- Waler Level in mPD
  ,t.rec_dt                       as rec_dt          -- Date of Record
  ,localtimestamp                 as dim_update_time -- Data Warehouse update Time
  ,localtimestamp                 as dim_load_time   -- Data Warehouse load Time
  ,to_char(t.rec_dt, 'yyyymmdd')  as dt              -- Daily Partitions
from coss_ods.ods_sttss_rws_channel_flow_di_year t
  inner join coss_ods.ods_sttss_rws_channel_df t1 on t.option_no = t1.option_no and t.ch_id = t1.ch_id
  left join coss_ods.ods_sttss_rws_measurement_df t2 on t.m_code = t2.code
where t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 2.coss_dwd.dwd_rws_ir_storage_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Impounding Reservoir Storage Details
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_ir_storage_di_year
-- coss_ods.ods_sttss_rws_ir_df
-- target table
-- coss_dwd.dwd_rws_ir_storage_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dwd.dwd_rws_ir_storage_detail_di_year
;create table if not exists coss_dwd.dwd_rws_ir_storage_detail_di_year(
  ig_id             varchar(20)      -- Impounding Reservoir Group being referenced
  ,ir_id            varchar(20)      -- Impounding Reservoir being referenced
  ,wl_ft            decimal(12,4)    -- Water Level reading in feet
  ,wl_in            decimal(12,4)    -- Water Level reading in inch
  ,wl_m             decimal(12,4)    -- Water Level reading in meter
  ,wl_mpd           decimal(13,6)    -- Water Level in mPD
  ,present_storage  decimal(16,8)    -- Storage of water in IR.  Unit is in mcm
  ,remarks          varchar(2000)    -- Remarks
  ,rec_dt           timestamp(6)     -- Date of record
  ,dim_update_time timestamp(6)      default current_timestamp
  ,dim_load_time   timestamp(6)      default current_timestamp
  ,dt               decimal(10)      -- Daily Partitions
  ,primary key(ig_id,ir_id,rec_dt)
)
distribute by hash("ir_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_rws_ir_storage_detail_di_year                  is  'Daily impounding reservoir storage details'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.ig_id            is  'Impounding Reservoir Group being referenced'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.ir_id            is  'Impounding Reservoir being referenced'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.wl_ft            is  'Water Level reading in feet'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.wl_in            is  'Water Level reading in inch'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.wl_m             is  'Water Level reading in meter'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.wl_mpd           is  'Water Level in mPD'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.present_storage  is  'Storage of water in IR.  Unit is in mcm'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.remarks          is  'Remarks'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.rec_dt           is  'Date of record'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.dim_update_time  is 'Data Update Time'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.dim_load_time    is 'Data Loading Time'
;comment on column coss_dwd.dwd_rws_ir_storage_detail_di_year.dt               is  'Daily Partitions'

;delete from coss_dwd.dwd_rws_ir_storage_detail_di_year 
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
insert into coss_dwd.dwd_rws_ir_storage_detail_di_year
select
  t1.ig_id                      as ig_id            -- Impounding Reservoir Group being referenced
  ,t.ir_id                      as ir_id            -- Impounding Reservoir being referenced
  ,t.wl_ft                      as wl_ft            -- Water Level reading in feet
  ,t.wl_in                      as wl_in            -- Water Level reading in inch
  ,t.wl_m                       as wl_m             -- Water Level reading in meter
  ,t.wl_mpd                     as wl_mpd           -- Waler Level in mPD
  ,t.storage                    as present_storage  -- Storage of water in IR At Present.  Unit is in mcm
  ,t.remarks                    as remarks          -- Remarks
  ,t.rec_dt                     as rec_dt           -- Date of record
  ,localtimestamp               as dim_update_time  -- Data Warehouse update Time
  ,localtimestamp               as dim_load_time    -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd')  as dt               -- Daily Partitions
from coss_ods.ods_sttss_rws_ir_storage_di_year t
  left join coss_ods.ods_sttss_rws_ir_df t1 on t.ir_id = t1.ir_id
where
  t.last_upd_user != 'system'
  and t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 3.coss_dwd.dwd_rws_pqty_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Proposed Quantity Details
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_pqty_detail_di_year
-- coss_ods.ods_sttss_rws_pqty_df
-- target table
-- coss_dwd.dwd_rws_pqty_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dwd.dwd_rws_pqty_detail_di_year
;create table if not exists coss_dwd.dwd_rws_pqty_detail_di_year(
  prop_qty_id       decimal(10)       -- Proposed Quantity ID
  ,ref_entity       varchar(100)      -- Referenced Entity
  ,ref_id           varchar(20)       -- Installations being referenced
  ,item_no          decimal(10)       -- Item No. To be used for Key Delivery
  ,p_qty            decimal(12,4)     -- Proposed Quantity.  Unit is Mld
  ,start_dt         timestamp(6)      -- Effective Start Date
  ,end_dt           timestamp(6)      -- Effective End Date
  ,dim_update_time timestamp(6)       default current_timestamp
  ,dim_load_time   timestamp(6)       default current_timestamp
  ,mh               decimal(10)       -- Monthly Partitions
  ,primary key(prop_qty_id, ref_id, item_no)
)
distribute by hash("prop_qty_id")
partition by range (start_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_rws_pqty_detail_di_year                  is 'Proposed Quantity Details'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.prop_qty_id      is 'Proposed Quantity ID'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.ref_entity       is 'Referenced Entity'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.ref_id           is 'Installations being referenced'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.item_no          is 'Item No.  To be used for Key Delivery'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.p_qty            is 'Proposed Quantity.  Unit is Mld'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.start_dt         is 'Effective Start Date'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.end_dt           is 'Effective End Date'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.dim_update_time  is 'Data Update Time'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.dim_load_time    is 'Data Loading Time'
;comment on column coss_dwd.dwd_rws_pqty_detail_di_year.mh               is 'Monthly Partitions'

;delete from coss_dwd.dwd_rws_pqty_detail_di_year 
where start_dt >= to_date(${dt1},'yyyy-mm-dd')-200
  and start_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dwd.dwd_rws_pqty_detail_di_year
select
  t1.prop_qty_id                   -- Proposed Quantity ID
  ,t.ref_entity                    -- Referenced Entity
  ,t.ref_id                        -- Installations being referenced
  ,t.item_no                       -- Item No.  To be used for Key Delivery
  ,t.p_qty                         -- Proposed Quantity.  Unit is Mld
  ,t1.start_dt                     -- Effective Start Date
  ,t1.end_dt                       -- Effective End Date
  ,localtimestamp                  -- Data Warehouse update Time
  ,localtimestamp                  -- Data Warehouse load Time
  ,to_char(t1.start_dt, 'yyyymm')  -- Monthly Partitions
from coss_ods.ods_sttss_rws_pqty_detail_di_year t
  inner join coss_ods.ods_sttss_rws_pqty_df t1 on t.prop_qty_id = t1.prop_qty_id
where t1.start_dt is not null
  and t1.start_dt >= to_date(${dt1},'yyyy-mm-dd')-200
  and t1.start_dt < to_date(${dt1},'yyyy-mm-dd')+1
  
  
```

## 4.coss_dwd.dwd_rws_sw_supply_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Salt Water Pumping Station Supply Volume
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_sps_flow_di_year
-- coss_ods.ods_sttss_rws_sp_supply_df
-- coss_ods.ods_sttss_rws_sp_df
-- target table 
-- coss_dwd.dwd_rws_sw_supply_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dwd.dwd_rws_sw_supply_detail_di_year
;create table if not exists coss_dwd.dwd_rws_sw_supply_detail_di_year(
  sw_pump_sys_id            varchar(20)     -- Salt Water Pumping System ID with format SPNNNNNNNN 
  ,sw_pump_sys_name         varchar(200)    -- Name of Salt Water Pumping System 
  ,sw_pump_sys_rpt_label    varchar(400)    -- Labels used in reports 
  ,ps_id                    varchar(20)     -- Pumping Station being referenced 
  ,qty                      decimal(12,4)   -- Quantity delivered by Salt water pumping station.  Unit is in Mld 
  ,scada_qty                decimal(12,4)   -- Quantity delivered by Salt water pumping station.  Unit is in Mld (SCADA) 
  ,remarks                  varchar(2000)   -- Remarks 
  ,rec_dt                   timestamp(6)    -- Date of record 
  ,dim_update_time          timestamp(6)    default current_timestamp
  ,dim_load_time            timestamp(6)    default current_timestamp
  ,dt                       decimal(10)     -- Daily Partitions 
  ,primary key(sw_pump_sys_id,ps_id,rec_dt)
)
distribute by hash("ps_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_rws_sw_supply_detail_di_year                         is  'Salt Water Pumping Station Supply Volume'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.sw_pump_sys_id          is  'Salt Water Pumping System ID with format SPNNNNNNNN'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.sw_pump_sys_name        is  'Name of Salt Water Pumping System'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.sw_pump_sys_rpt_label   is  'Labels used in reports'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.ps_id                   is  'Pumping Station being referenced'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.qty                     is  'Quantity delivered by Salt water pumping station.  Unit is in Mld'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.scada_qty               is  'Quantity delivered by Sa
lt water pumping station.  Unit is in Mld (SCADA)'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.remarks                 is  'Remarks'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.rec_dt                  is  'Date of record'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.dim_update_time         is 'Data Update Time'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.dim_load_time           is 'Data Loading Time'
;comment on column coss_dwd.dwd_rws_sw_supply_detail_di_year.dt                      is  'Daily Partitions'

;delete from coss_dwd.dwd_rws_sw_supply_detail_di_year 
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dwd.dwd_rws_sw_supply_detail_di_year
select
   t2.sp_id                      as sw_pump_sys_id         -- Salt Water Pumping System ID with format SPNNNNNNNN
   ,t2.sp_name                   as sw_pump_sys_name       -- Name of Salt Water Pumping System
   ,t2.rlabel                    as sw_pump_sys_rpt_label  -- Labels used in reports
   ,t.ps_id                      as ps_id                  -- Pumping Station being referenced
   ,t.qty                        as qty                    -- Quantity delivered by Salt water pumping station.  Unit is in Mld
   ,t.scada_qty                  as scada_qty              -- Quantity delivered by Salt water pumping station.  Unit is in Mld (SCADA)
   ,remarks                      as remarks                -- Remarks
   ,rec_dt                       as rec_dt                 -- Date of record
   ,localtimestamp               as dim_update_time        -- Data Warehouse update Time
   ,localtimestamp               as dim_load_time          -- Data Warehouse load Time
   ,to_char(rec_dt,'yyyymmdd')   as dt                     -- Daily Partitions
from coss_ods.ods_sttss_rws_sps_flow_di_year t
  left join coss_ods.ods_sttss_rws_sp_supply_df t1 on t.ps_id  = t1.sz_id
  left join coss_ods.ods_sttss_rws_sp_df t2 on t1.sp_id  = t2.sp_id
where t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 5.coss_dwd.dwd_srs_sr_storage_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Service Reservoir Supply
-- function describe: Daily SR Storage Details
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_sttss_rws_sr_storage_di_year
-- target table
-- coss_dwd.dwd_srs_sr_storage_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dwd.dwd_srs_sr_storage_detail_di_year
;create table if not exists coss_dwd.dwd_srs_sr_storage_detail_di_year(
  sr_id            varchar(20)          -- Service Reservoir being referenced
  ,a_wl            decimal(9,2)         -- A Compartment Water Level
  ,b_wl            decimal(9,2)         -- B Compartment Water Level
  ,a_storage       decimal(12,4)        -- Volume of water in A compartment of an SR.  Unit is in cu m
  ,b_storage       decimal(12,4)        -- Volume of water in B compartment of an SR.  Unit is in cu m
  ,tot_storage     decimal(12,4)        -- Total volume of water in A+ B+..+R.  Unit is in cu m
  ,remarks         varchar(2000)        -- Remarks
  ,rec_dt          timestamp(6)         -- Date of record
  ,dim_update_time timestamp(6)         default current_timestamp
  ,dim_load_time   timestamp(6)         default current_timestamp
  ,dt              decimal(10)          -- Daily Partitions
  ,primary key(sr_id,rec_dt)
)
distribute by hash("sr_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)

;comment on table  coss_dwd.dwd_srs_sr_storage_detail_di_year                  is 'Daily SR Storage Details'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.sr_id            is 'Service Reservoir being referenced'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.a_wl             is 'A Compartment Water Level'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.b_wl             is 'B Compartment Water Level'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.a_storage        is 'Volume of water in A compartment of an SR.  Unit is in cu m'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.b_storage        is 'Volume of water in B compartment of an SR.  Unit is in cu m'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.tot_storage      is 'Total volume of water in A+ B+..+R.  Unit is in cu m'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.remarks          is 'Remarks'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.rec_dt           is 'Date of record'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.dim_update_time  is 'Data Update Time'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.dim_load_time    is 'Data Loading Time'
;comment on column coss_dwd.dwd_srs_sr_storage_detail_di_year.dt               is 'Daily Partitions'

;delete from coss_dwd.dwd_srs_sr_storage_detail_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dwd.dwd_srs_sr_storage_detail_di_year
select
  sr_id                         as sr_id            -- Service Reservoir being referenced
  ,a_wlevel                     as a_wl             -- A Compartment Water Level
  ,b_wlevel                     as b_wl             -- B Compartment Water Level
  ,a_storage                    as a_storage        -- Volume of water in A compartment of an SR.  Unit is in cu m
  ,b_storage                    as b_storage        -- Volume of water in B compartment of an SR.  Unit is in cu m
  ,tot_storage                  as b_storage        -- Total volume of water in A+ B+..+R.  Unit is in cu m
  ,remarks                      as remarks          -- Remarks
  ,rec_dt                       as rec_dt           -- Date of record
  ,localtimestamp               as dim_update_time  -- Data Warehouse update Time
  ,localtimestamp               as dim_load_time    -- Data Warehouse load Time
  ,to_char(rec_dt, 'yyyymmdd')  as dt               -- Daily Partitions
from coss_ods.ods_sttss_rws_sr_storage_di_year t
where t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 6.coss_dwd.dwd_srs_sr_storage_detail_di_year

```sql
-- coss_dwd.dwd_rws_gd_agr_supply_di_year definition

-- Drop table

-- DROP TABLE coss_dwd.dwd_rws_gd_agr_supply_di_year;

CREATE TABLE coss_dwd.dwd_rws_gd_agr_supply_di_year (
	rw_id varchar(20) NULL, -- Raw water Source being referenced
	hk_vol numeric(14, 6) NULL, -- Volume at HK Side.  Unit is in mcm
	gd_vol numeric(14, 6) NULL, -- Volume at GD Side. Unit is in mcm
	agr_vol numeric(14, 6) NULL, -- Agreed volume.  Unit is in mcm
	dis_vol numeric(14, 6) NULL, -- Discharged volume.  Unit is in mcm
	sz_wlevel numeric(12, 4) NULL, -- Shen Zhen Water Level.  Unit is in m
	dis_ind varchar(3) NULL, -- Possible Values:Y - Yes,N - No
	rec_dt date NULL, -- Date of record
	submit_dt timestamp(6) NULL, -- Submission Date
	dwd_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Update Time
	dwd_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Loading Time
	primary key(rw_id, rec_dt)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
)
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;
COMMENT ON TABLE coss_dwd.dwd_rws_gd_agr_supply_di_year IS 'Daily GD Water Supply';

-- Column comments

COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.rw_id IS 'Raw water Source being referenced';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.hk_vol IS 'Volume at HK Side.  Unit is in mcm';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.gd_vol IS 'Volume at GD Side. Unit is in mcm';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.agr_vol IS 'Agreed volume.  Unit is in mcm';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.dis_vol IS 'Discharged volume.  Unit is in mcm';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.sz_wlevel IS 'Shen Zhen Water Level.  Unit is in m';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.dis_ind IS 'Possible Values:Y - Yes,N - No';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.rec_dt IS 'Date of record';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.submit_dt IS 'Submission Date';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.dwd_update_time IS 'Data Update Time';
COMMENT ON COLUMN coss_dwd.dwd_rws_gd_agr_supply_di_year.dwd_load_time IS 'Data Loading Time';

```



```sql
;delete from coss_dwd.dwd_rws_gd_agr_supply_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dwd.dwd_rws_gd_agr_supply_di_year
select
    rw_id,
    hk_vol,
    gd_vol,
    agr_vol,
    dis_vol,
    sz_wlevel,
    dis_ind,
    rec_dt,
    submit_dt,
    current_timestamp dwd_update_time,
    current_timestamp dwd_load_time
from coss_ods.ods_sttss_rws_gd_agr_supply_di_year t
where t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```



# dws

## 1.coss_dws.dws_rws_ir_storage_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Impounding Reservoir Storage Details
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_rws_ir_storage_detail_di_year
-- coss_dim.dim_ass_ir_df
-- target table
-- coss_dws.dws_rws_ir_storage_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dws.dws_rws_ir_storage_detail_di_year
;create table if not exists coss_dws.dws_rws_ir_storage_detail_di_year(
  ig_id             varchar(20)         -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,ig_name           varchar(200)       -- Name of Impounding Reservoir Group
  ,ig_cname          varchar(300)       -- Chinese Name of Impounding Reservoir Group
  ,ig_rpt_label      varchar(400)       -- Labels used in reports
  ,region_code       varchar(10)        -- Region
  ,region_name       varchar(60)        -- Description of Region
  ,region_cname      varchar(300)       -- Chinese Description of Region
  ,region_ind        varchar(2)         -- Possible Values: {"I" - HK Island, M" - Mainland}
  ,ig_ind            varchar(2)         -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {Y" - Old, "N - New}
  ,ir_id             varchar(20)        -- Impounding Reservoir ID with format IRNNNNNNNN
  ,i_code            varchar(10)        -- Installation Code of Impounding Reservoir
  ,ir_rpt_label      varchar(400)       -- Labels used in reports
  ,ir_name           varchar(200)       -- Impounding reservoir name
  ,ir_cname          varchar(300)       -- Impounding Reservoir Chinese Name
  ,level_type        varchar(2)         -- Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}
  ,level_unit        varchar(2)         -- Possible Values:{"F" - Feet / Inch, "M" - Meter}
  ,dead_storage      decimal(12,4)      -- Dead Storage of an Impounding Reservoir.  Unit is in mcm
  ,twl               decimal(12,4)      -- TWL
  ,capacity          decimal(12,4)      -- Capacity of IR.  Unit is in mcm
  ,min_storage       decimal(12,4)      -- Allowable Minimum Storage.  Unit is in mcm
  ,limit_m           decimal(12,4)      -- Preset Limit for Water Level.  Unit is in m
  ,wl_ft             decimal(12,4)      -- Water Level reading in feet
  ,wl_in             decimal(12,4)      -- Water Level reading in inch
  ,wl_m              decimal(12,4)      -- Water Level reading in meter
  ,wl_mpd            decimal(13,6)      -- Waler Level in mPD
  ,present_storage   decimal(16,8)      -- Storage of water in IR.  Unit is Mld
  ,remarks           varchar(2000)      -- Remarks
  ,rec_dt            timestamp(6)       -- Date of record
  ,dws_update_time   timestamp(6)       default current_timestamp
  ,dws_load_time     timestamp(6)       default current_timestamp
  ,dt                decimal(10)        -- Daily Partitions
  ,primary key(ir_id,rec_dt)
)
distribute by hash("ig_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dws.dws_rws_ir_storage_detail_di_year                    is  'Daily impounding reservoir storage details'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ig_id              is  'Impounding Reservoir Group ID with format IGNNNNNNNN'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ig_name            is  'Name of Impounding Reservoir Group'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ig_cname           is  'Chinese Name of Impounding Reservoir Group'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ig_rpt_label       is  'Labels used in reports'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.region_code        is  'Region'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.region_name        is  'Description of Region'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.region_cname       is  'Chinese Description of Region'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.region_ind         is  'Possible Values: {"I" - HK Island, M" - Mainland}'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ig_ind             is  'Indicates if Impounding Reservoir Group is old or new. Possible Values: {Y" - Old, "N - New}'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ir_id              is  'Impounding Reservoir ID with format IRNNNNNNNN'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.i_code             is  'Installation Code of Impounding Reservoir'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ir_rpt_label       is  'Labels used in reports'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ir_name            is  'Impounding reservoir name'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.ir_cname           is  'Impounding Reservoir Chinese Name'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.level_type         is  'Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.level_unit         is  'Possible Values:{"F" - Feet / Inch, "M" - Meter}'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.dead_storage       is  'Dead Storage of an Impounding Reservoir.  Unit is in mcm'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.twl                is  'TWL'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.capacity           is  'Capacity of IR.  Unit is in mcm'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.min_storage        is  'Allowable Minimum Storage.  Unit is in mcm'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.limit_m            is  'Preset Limit for Water Level.  Unit is in m'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.wl_ft              is  'Water Level reading in feet'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.wl_in              is  'Water Level reading in inch'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.wl_m               is  'Water Level reading in meter'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.wl_mpd             is  'Waler Level in mPD'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.present_storage    is  'Storage of water in IR.  Unit is Mld'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.remarks            is  'Remarks'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.rec_dt             is  'Date of record'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.dws_update_time    is 'Data Update Time'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.dws_load_time      is 'Data Loading Time'
;comment on column coss_dws.dws_rws_ir_storage_detail_di_year.dt                 is  'Daily Partitions'

;delete from coss_dws.dws_rws_ir_storage_detail_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dws.dws_rws_ir_storage_detail_di_year
select
  t1.ig_id                         as  ig_id              -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,t1.ig_name                      as  ig_name            -- Name of Impounding Reservoir Group
  ,t1.ig_cname                     as  ig_cname           -- Chinese Name of Impounding Reservoir Group
  ,t1.ig_rpt_label                 as  ig_rpt_label       -- Labels used in reports
  ,t1.region_code                  as  region_code        -- Region
  ,t1.region_name                  as  region_name        -- Description of Region
  ,t1.region_cname                 as  region_cname       -- Chinese Description of Region
  ,t1.region_ind                   as  region_ind         -- Possible Values: {"I" - HK Island, M" - Mainland}
  ,t1.ig_ind                       as  ig_ind             -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {Y" - Old, "N - New}
  ,t1.ir_id                        as  ir_id              -- Impounding Reservoir ID with format IRNNNNNNNN
  ,t1.i_code                       as  i_code             -- Installation Code of Impounding Reservoir
  ,t1.ir_rpt_label                 as  ir_rpt_label       -- Labels used in reports
  ,t1.ir_name                      as  ir_name            -- Impounding reservoir name
  ,t1.ir_cname                     as  ir_cname           -- Impounding Reservoir Chinese Name
  ,t1.level_type                   as  level_type         -- Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}
  ,t1.level_unit                   as  level_unit         -- Possible Values:{"F" - Feet / Inch, "M" - Meter}
  ,t1.dead_storage                 as  dead_storage       -- Dead Storage of an Impounding Reservoir.  Unit is in mcm
  ,t1.twl                          as  twl                -- TWL
  ,t1.capacity                     as  capacity           -- Capacity of IR.  Unit is in mcm
  ,t1.min_storage                  as  min_storage        -- Allowable Minimum Storage.  Unit is in mcm
  ,t1.limit_m                      as  limit_m            -- Preset Limit for Water Level.  Unit is in m
  ,t.wl_ft                         as  wl_ft              -- Water Level reading in feet
  ,t.wl_in                         as  wl_in              -- Water Level reading in inch
  ,t.wl_m                          as  wl_m               -- Water Level reading in meter
  ,t.wl_mpd                        as  wl_mpd             -- Waler Level in mPD
  ,t.present_storage * 1000        as  present_storage    -- Storage of water in IR.  Unit is Mld
  ,t.remarks                       as  remarks            -- Remarks
  ,t.rec_dt                        as  rec_dt             -- Date of record
  ,localtimestamp                  dws_update_time
  ,localtimestamp                  dws_load_time  
  ,to_char(t.rec_dt, 'yyyymmdd')   as  dt                 -- Daily Partitions
from coss_dwd.dwd_rws_ir_storage_detail_di_year t
inner join coss_dim.dim_ass_ir_df t1 on t.ir_id = t1.ir_id
where t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
```

## 2.coss_dws.dws_rws_rw_supply_detail_dip

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Raw Water Supply Daily Volume Detail
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_rws_channel_flow_detail_di_year
-- coss_dwd.dwd_rws_ir_storage_detail_di_year
-- coss_dwd.dwd_rws_pqty_detail_di_year
-- coss_dim.dim_ass_ir_df
-- coss_dim.dim_ass_rw_src_df
-- target table
-- coss_dws.dws_rws_rw_supply_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dws.dws_rws_rw_supply_detail_di_year
;create table if not exists coss_dws.dws_rws_rw_supply_detail_di_year(
  rw_id                   varchar(20)         -- Raw Water Source ID with format RWNNNNNNNN'
  ,rw_name                varchar(200)        -- Name of Raw Water'
  ,rw_cname               varchar(300)        -- Chinese Name of Raw Water'
  ,rpt_label              varchar(400)        -- Labels used in reports'
  ,region_code            varchar(10)         -- Region Code'
  ,region_name            varchar(60)         -- Description of Region'
  ,region_cname           varchar(300)        -- Chinese Description of Region'
  ,region_ind             varchar(2)          -- Possible Values: {"I" - HK Island, "M" - Mainland}'
  ,ig_ind                 varchar(2)          -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}'
  ,source_rw              varchar(2)          -- Source of raw water'
  ,source_desc            varchar(60)         -- Description of Raw Water Source'
  ,p_qty                  decimal(12,4)       -- Proposed Quantity.  Unit is Mld'
  ,qty_del                decimal(12,4)       -- Quantity delivered of Water transfer channel. Unit is in Mld'
  ,present_storage        decimal(16,8)       -- Storage of water in IR At Present.  Unit is Mld'
  ,capacity               decimal(12,4)       -- Capacity of IR.  Unit is Mld'
  ,min_storage            decimal(12,4)       -- Allowable Minimum Storage.  Unit is Mld'
  ,rec_dt                 timestamp(6)        -- Date of Record'
  ,dws_update_time        timestamp(6) default current_timestamp
  ,dws_load_time          timestamp(6) default current_timestamp
  ,dt                     decimal(10)         -- Daily Partitions'
  ,primary key(rw_id, rec_dt)
)
distribute by hash("rw_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dws.dws_rws_rw_supply_detail_di_year                   is  'Raw Water Supply Daily Volume Detail'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.rw_id             is  'Raw Water Source ID with format RWNNNNNNNN'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.rw_name           is  'Name of Raw Water'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.rw_cname          is  'Chinese Name of Raw Water'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.rpt_label         is  'Labels used in reports'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.region_code       is  'Region Code'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.region_name       is  'Description of Region'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.region_cname      is  'Chinese Description of Region'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.region_ind        is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.ig_ind            is  'Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.source_rw         is  'Source of raw water'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.source_desc       is  'Description of Raw Water Source'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.p_qty             is  'Proposed Quantity.  Unit is Mld'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.qty_del           is  'Quantity delivered of Water transfer channel. Unit is in Mld'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.present_storage   is  'Storage of water in IR At Present.  Unit is Mld'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.capacity          is  'Capacity of IR.  Unit is Mld'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.min_storage       is  'Allowable Minimum Storage.  Unit is Mld'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.rec_dt            is  'Date of Record'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.dws_update_time   is 'Data Update Time'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.dws_load_time     is 'Data Loading Time'
;comment on column coss_dws.dws_rws_rw_supply_detail_di_year.dt                is  'Daily Partitions'

;drop table if exists coss_tmp.tmp_dws_rws_rw_supply_detail_di_year_1
;create table if not exists coss_tmp.tmp_dws_rws_rw_supply_detail_di_year_1 as
select
  t_a.rw_id                            as rw_id
--  ,ifnull(t_d.p_qty, 0)                as p_qty
  ,t_a.qty_del                         as qty_del
  ,ifnull(t_b.present_storage, 0)*1000 as present_storage
  ,ifnull(t_c.capacity, 0)*1000        as capacity
  ,ifnull(t_c.min_storage, 0)*1000     as min_storage
  ,t_a.rec_dt                          as rec_dt
  ,t_a.dt                              as dt
from
 (
 -- Calculation For Quantity delivered of Raw Water
select
  t.src_id                 as rw_id
  ,rec_dt                  as rec_dt
  ,dt                      as dt
  ,sum(ifnull(qty_del,0))  as qty_del
from coss_dwd.dwd_rws_channel_flow_detail_di_year t
where (left(src_id,2)= 'IG' or left(src_id,2) = 'RW' )
   and left(dest_id,2) != 'IG'
   and rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
group  by
  t.src_id
  ,rec_dt
  ,dt
  ) t_a
 left join
 (
  -- Calculation For Impounding Reservoir Group Storage At Present
  select
    t.ig_id               as ig_id
    ,t.rec_dt             as rec_dt
    ,sum(present_storage) as present_storage
 from coss_dwd.dwd_rws_ir_storage_detail_di_year t
 where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
group by
  t.ig_id
  ,t.rec_dt
 )t_b on t_a.rw_id = t_b.ig_id and t_a.rec_dt = t_b.rec_dt
 left join (
 select
  t.ig_id           as ig_id
  ,sum(t.capacity)  as capacity
  ,sum(min_storage) as min_storage
from coss_dim.dim_ass_ir_df t
group by
  t.ig_id
 )t_c on t_a.rw_id = t_c.ig_id

;drop table if exists coss_tmp.tmp_dws_rws_rw_supply_detail_di_year_2
;create table if not exists coss_tmp.tmp_dws_rws_rw_supply_detail_di_year_2 as
 select
  t.rw_id                            as rw_id
  ,ifnull(t1.p_qty, 0)               as p_qty
  ,t.qty_del                         as qty_del
  ,t.present_storage                 as present_storage
  ,t.capacity                        as capacity
  ,t.min_storage                     as min_storage
  ,t.rec_dt                          as rec_dt
from coss_tmp.tmp_dws_rws_rw_supply_detail_di_year_1 t
left join (
select
  t.ref_id
  ,t.ref_entity
  ,t.p_qty
  ,t.start_dt
  ,t.end_dt
 from coss_dwd.dwd_rws_pqty_detail_di_year t
 where  ref_entity in ('RW','IR_GROUP')
      and mh >= to_char(add_months(to_date(${dt1},'yyyy-mm-dd'),-12),'yyyymm')
      and mh <= round(${dt1}/100,0)
) t1 on t.rw_id = t1.ref_id and t.rec_dt >= t1.start_dt and t.rec_dt <= t1.end_dt

;delete from coss_dws.dws_rws_rw_supply_detail_di_year 
where  rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dws.dws_rws_rw_supply_detail_di_year
select
   t1.rw_id                       as rw_id            -- Raw Water Source ID with format RWNNNNNNNN
   ,t1.rw_name                    as rw_name          -- Name of Raw Water
   ,t1.rw_cname                   as rw_cname         -- Chinese Name of Raw Water
   ,t1.rpt_label                  as rpt_label        -- Labels used in reports
   ,t1.region_code                as region_code      -- Region Code
   ,t1.region_name                as region_name      -- Description of Region
   ,t1.region_cname               as region_cname     -- Chinese Description of Region
   ,t1.region_ind                 as region_ind       -- Possible Values: {"I" - HK Island, "M" - Mainland}
   ,t1.ig_ind                     as ig_ind           -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
   ,t1.source_rw                  as source_rw        -- Source of raw water
   ,t1.source_desc                as source_desc      -- Description of Raw Water Source
   ,t.p_qty                       as p_qty            -- Proposed Quantity.  Unit is Mld
   ,t.qty_del                     as qty_del          -- Quantity delivered of Water transfer channel. Unit is in Mld
   ,t.present_storage             as present_storage  -- Storage of water in IR At Present.  Unit is Mld
   ,t.capacity                    as capacity         -- Capacity of IR.  Unit is Mld
   ,t.min_storage                 as min_storage      -- Allowable Minimum Storage.  Unit is Mld
   ,t.rec_dt                      as rec_dt           -- Date of Record
   ,localtimestamp                as dws_update_time  -- Data Warehouse update Time
   ,localtimestamp                as dws_load_time    -- Data Warehouse load Time
   ,to_char(t.rec_dt, 'yyyymmdd') as dt               -- Daily Partitions
from coss_tmp.tmp_dws_rws_rw_supply_detail_di_year_2 t
inner join coss_dim.dim_ass_rw_src_df t1 on t.rw_id = t1.rw_id

```

## 3.coss_dws.dws_rws_sw_supply_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Raw Water Supply
-- function describe: Salt Water Supply Detail
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_rws_sw_supply_detail_di_year
-- coss_dim.dim_ass_ps_df
-- target table
-- coss_dws.dws_rws_sw_supply_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dws.dws_rws_sw_supply_detail_di_year
;create table coss_dws.dws_rws_sw_supply_detail_di_year(
  ps_id                   varchar(10)         -- Pumping Station ID with format PSNNNNNNNN
  ,i_code                 varchar(200)        -- Installation Code of Pumping Station
  ,ps_name                varchar(300)        -- Pumping station name
  ,ps_cname               varchar(400)        -- Pumping Station Chinese Name
  ,rpt_label              varchar(200)         -- Labels used in reports
  ,region_code            varchar(10)         -- Region
  ,region_name            varchar(60)         -- Description of Region
  ,region_cname           varchar(300)        -- Chinese Description of Region
  ,region_ind             varchar(2)          -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,w_type                 varchar(2)          -- Type of water maintained in the pumping station
  ,w_type_desc            varchar(200)        -- Description of Water Type
  ,repumping              varchar(2)          -- Repumping
  ,remarks                varchar(200)        -- Remarks
  ,sw_pump_sys_id         varchar(20)         -- Salt Water Pumping System ID with format SPNNNNNNNN
  ,sw_pump_sys_name       varchar(200)        -- Name of Salt Water Pumping System
  ,sw_pump_sys_rpt_label  varchar(400)        -- Labels used in reports
  ,qty                    decimal(12,4)       -- Quantity delivered by Salt water pumping station.  Unit is in Mld
  ,rec_dt                 timestamp(6)        -- Date of record
  ,dws_update_time        timestamp(6)        default current_timestamp
  ,dws_load_time          timestamp(6)        default current_timestamp
  ,dt                     decimal(10)         -- Daily Partitions
  ,primary key(ps_id, rec_dt)
)
distribute by hash("ps_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dws.dws_rws_sw_supply_detail_di_year                         is  'Salt Water Supply Detail'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.ps_id                   is  'Pumping Station ID with format PSNNNNNNNN'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.i_code                  is  'Installation Code of Pumping Station'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.ps_name                 is  'Pumping station name'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.ps_cname                is  'Pumping Station Chinese Name'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.rpt_label               is  'Labels used in reports'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.region_code             is  'Region'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.region_name             is  'Description of Region'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.region_cname            is  'Chinese Description of Region'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.region_ind              is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.w_type                  is  'Type of water maintained in the pumping station'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.w_type_desc             is  'Description of Water Type'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.repumping               is  'Repumping'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.remarks                 is  'Remarks'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.sw_pump_sys_id          is  'Salt Water Pumping System ID with format SPNNNNNNNN'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.sw_pump_sys_name        is  'Name of Salt Water Pumping System'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.sw_pump_sys_rpt_label   is  'Labels used in reports'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.qty                     is  'Quantity delivered by Salt water pumping station.  Unit is in Mld'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.rec_dt                  is  'Date of record'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.dws_update_time         is 'Data Update Time'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.dws_load_time           is 'Data Loading Time'
;comment on column coss_dws.dws_rws_sw_supply_detail_di_year.dt                      is  'Daily Partitions'

;delete from coss_dws.dws_rws_sw_supply_detail_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dws.dws_rws_sw_supply_detail_di_year
select
  t1.ps_id                        as  ps_id                      -- Pumping Station ID with format PSNNNNNNNN
  ,t1.i_code                      as  i_code                     -- Installation Code of Pumping Station
  ,t1.ps_name                     as  ps_name                    -- Pumping station name
  ,t1.ps_cname                    as  ps_cname                   -- Pumping Station Chinese Name
  ,t1.rpt_label                   as  rpt_label                  -- Labels used in reports
  ,t1.region_code                 as  region_code                -- Region
  ,t1.region_name                 as  region_name                -- Description of Region
  ,t1.region_cname                as  region_cname               -- Chinese Description of Region
  ,t1.region_ind                  as  region_ind                 -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,t1.w_type                      as  w_type                     -- Type of water maintained in the pumping station
  ,t1.w_type_desc                 as  w_type_desc                -- Description of Water Type
  ,t1.repumping                   as  repumping                  -- Repumping
  ,t1.remarks                     as  remarks                    -- Remarks
  ,t.sw_pump_sys_id               as  sw_pump_sys_id             -- Salt Water Pumping System ID with format SPNNNNNNNN
  ,t.sw_pump_sys_name             as  sw_pump_sys_name           -- Name of Salt Water Pumping System
  ,t.sw_pump_sys_rpt_label        as  sw_pump_sys_rpt_label      -- Labels used in reports
  ,t.qty                          as  qty                        -- Quantity delivered by Salt water pumping station.  Unit is in Mld
  ,t.rec_dt                       as  rec_dt                     -- Date of record
  ,localtimestamp                 as  dws_update_time            -- Data Warehouse update Time
  ,localtimestamp                 as  dws_load_time              -- Data Warehouse load Time
  ,to_char(t.rec_dt, 'yyyymmdd')  as  dt                         -- Daily Partitions
from coss_dwd.dwd_rws_sw_supply_detail_di_year t
inner join coss_dim.dim_ass_ps_df t1 on t.ps_id = t1.ps_id
where t.rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and t.rec_dt < to_date(${dt1},'yyyy-mm-dd')+1


```

## 4.coss_dws.dws_srs_sr_storage_detail_di_year

```sql
-- ****************************************************************************************
-- subject     areas: Service Reservoir Supply
-- function describe: Service Reservoir Storage Details
-- create         by: dongmaochen
-- create       date: 2025-04-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_srs_sr_storage_detail_di_year
-- coss_dwd.dwd_rws_channel_flow_detail_di_year
-- coss_dwd.dwd_rws_pqty_detail_di_year
-- coss_dim.dim_ass_sr_df
-- target table
-- coss_dws.dws_srs_sr_storage_detail_di_year
-- ****************************************************************************************
;drop table if exists coss_dws.dws_srs_sr_storage_detail_di_year
;create table if not exists coss_dws.dws_srs_sr_storage_detail_di_year(
  sr_id             varchar(20)        -- Service Reservoir ID with format SRNNNNNNNN
  ,i_code           varchar(10)        -- Installation Code of Service Reservoir
  ,sr_name          varchar(200)       -- Service Reservoir Name
  ,sr_cname         varchar(300)       -- Service Reservoir Chinese Name
  ,rpt_label        varchar(400)       -- Labels used in reports
  ,region_code      varchar(10)        -- Region
  ,region_name      varchar(60)        -- Description of Region
  ,region_cname     varchar(300)       -- Chinese Description of Region
  ,region_ind       varchar(2)         -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,w_type           varchar(2)         -- Type of water maintained by the service reservoir
  ,w_type_desc      varchar(200)       -- Description of Water Type
  ,div_height       decimal(12,4)      -- Height of Division Wall.  Unit is in m
  ,capacity         decimal(12,4)      -- Capacity of Service Reservoir.  Unit is in cum
  ,w_lim            decimal(12,4)      -- Preset Limit for Water Level above division wall.  Unit is in m
  ,num_of_storage   decimal            -- No. of Storage/Compartment
  ,a_wl             decimal(9,2)       -- A Compartment Water Level
  ,b_wl             decimal(9,2)       -- B Compartment Water Level
  ,a_storage        decimal(12,4)      -- Volume of water in A compartment of an SR.  Unit is in cu m
  ,b_storage        decimal(12,4)      -- Volume of water in B compartment of an SR.  Unit is in cu m
  ,tot_storage      decimal(12,4)      -- Total volume of water in A+ B+..+R.  Unit is in cu m
  ,qty_del          decimal(12,4)      -- Quantity delivered of Water transfer channel. Unit is in Mld
  ,p_qty            decimal(12,4)      -- Proposed Quantity.  Unit is Mld
  ,remarks          varchar(1000)      -- Remarks
  ,rec_dt           timestamp(6)       -- Date of record
  ,dws_update_time  timestamp(6)       default current_timestamp
  ,dws_load_time    timestamp(6)       default current_timestamp
  ,dt               decimal(10)        -- Daily Partitions
  ,primary key(sr_id,rec_dt)
)
distribute by hash("sr_id")
partition by range (rec_dt)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dws.dws_srs_sr_storage_detail_di_year                   is  'Service reservoir Storage Details'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.sr_id             is  'Service Reservoir ID with format SRNNNNNNNN'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.i_code            is  'Installation Code of Service Reservoir'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.sr_name           is  'Service Reservoir Name'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.sr_cname          is  'Service Reservoir Chinese Name'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.rpt_label         is  'Labels used in reports'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.region_code       is  'Region'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.region_name       is  'Description of Region'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.region_cname      is  'Chinese Description of Region'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.region_ind        is  'Possible Values: {"I" - HK Island, "M" - Mainland}'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.w_type            is  'Type of water maintained by the service reservoir'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.w_type_desc       is  'Description of Water Type'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.div_height        is  'Height of Division Wall.  Unit is in m'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.capacity          is  'Capacity of Service Reservoir.  Unit is in cum'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.w_lim             is  'Preset Limit for Water Level above division wall.  Unit is in m'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.num_of_storage    is  'No. of Storage/Compartment'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.a_wl              is  'A Compartment Water Level'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.b_wl              is  'B Compartment Water Level'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.a_storage         is  'Volume of water in A compartment of an SR.  Unit is in cu m'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.b_storage         is  'Volume of water in B compartment of an SR.  Unit is in cu m'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.tot_storage       is  'Total volume of water in A+ B+..+R.  Unit is in cu m'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.qty_del           is  'Quantity delivered of Water transfer channel. Unit is in Mld'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.p_qty             is  'Proposed Quantity.  Unit is Mld'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.remarks           is  'Remarks'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.rec_dt            is  'Date of record'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.dws_update_time   is 'Data Update Time'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.dws_load_time     is 'Data Loading Time'
;comment on column coss_dws.dws_srs_sr_storage_detail_di_year.dt                is  'Daily Partitions'

;drop table if exists coss_tmp.tmp_dws_srs_sr_storage_detail_di_year_1
;create table if not exists coss_tmp.tmp_dws_srs_sr_storage_detail_di_year_1 as 
select
    t.sr_id
    ,t.a_wl
    ,t.b_wl
    ,t.a_storage
    ,t.b_storage
    ,t.tot_storage
    ,t1.qty_del
    ,t2.p_qty
    ,t.remarks
    ,t.rec_dt
from 
    (
    select
      sr_id                         as sr_id
      ,a_wl                         as a_wl
      ,b_wl                         as b_wl
      ,a_storage                    as a_storage
      ,b_storage                    as b_storage
      ,tot_storage                  as tot_storage
      ,remarks                      as remarks
      ,rec_dt                       as rec_dt
      ,localtimestamp               as dw_etl_time
      ,to_char(rec_dt, 'yyyymmdd')  as dt
    from coss_dwd.dwd_srs_sr_storage_detail_di_year t
    where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
      and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
    ) t
  left join 
    (
    select
      src_id
      ,rec_dt
      ,sum(qty_del) qty_del
    from coss_dwd.dwd_rws_channel_flow_detail_di_year t
    where left(src_id, 2) = 'SR'
      and rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
      and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
    group by
      src_id
      ,rec_dt
      ) t1 on t.sr_id = t1.src_id and t.rec_dt = t1.rec_dt
  left join 
     (
    select
      t.ref_id
      ,t.p_qty
      ,t.start_dt
      ,t.end_dt
    from coss_dwd.dwd_rws_pqty_detail_di_year t
    where ref_entity ='SR'
      and mh >= to_char(add_months(to_date(${dt1},'yyyy-mm-dd'),-12),'yyyymm')
      and mh <= round(${dt1}/100,0)
    ) t2 on t1.src_id = t2.ref_id and t1.rec_dt >= t2.start_dt and t1.rec_dt <= t2.end_dt

;delete from coss_dws.dws_srs_sr_storage_detail_di_year
where rec_dt >= to_date(${dt1},'yyyy-mm-dd')-30
  and rec_dt < to_date(${dt1},'yyyy-mm-dd')+1
;insert into coss_dws.dws_srs_sr_storage_detail_di_year
select
  t.sr_id                         -- Service Reservoir ID with format SRNNNNNNNN
  ,t1.i_code                      -- Installation Code of Service Reservoir
  ,t1.sr_name                     -- Service Reservoir Name
  ,t1.sr_cname                    -- Service Reservoir Chinese Name
  ,t1.rpt_label                   -- Labels used in reports
  ,t1.region_code                 -- Region
  ,t1.region_name                 -- Description of Region
  ,t1.region_cname                -- Chinese Description of Region
  ,t1.region_ind                  -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,t1.w_type                      -- Type of water maintained by the service reservoir
  ,t1.w_type_desc                 -- Description of Water Type
  ,t1.div_height                  -- Height of Division Wall.  Unit is in m
  ,t1.capacity                    -- Capacity of Service Reservoir.  Unit is in cum
  ,t1.w_lim                       -- Preset Limit for Water Level above division wall.  Unit is in m
  ,t1.num_of_storage              -- No. of Storage/Compartment
  ,t.a_wl                         -- A Compartment Water Level
  ,t.b_wl                         -- B Compartment Water Level
  ,t.a_storage                    -- Volume of water in A compartment of an SR.  Unit is in cu m
  ,t.b_storage                    -- Volume of water in B compartment of an SR.  Unit is in cu m
  ,t.tot_storage                  -- Total volume of water in A+ B+..+R.  Unit is in cu m
  ,t.qty_del                      -- Quantity delivered of Water transfer channel. Unit is in Mld
  ,t.p_qty                        -- Proposed Quantity.  Unit is Mld
  ,t.remarks                      -- Remarks
  ,t.rec_dt                       -- Date of record
  ,localtimestamp                 -- Data Warehouse update Time
  ,localtimestamp                 -- Data Warehouse load Time
  ,to_char(t.rec_dt, 'yyyymmdd')  -- Daily Partitions
from coss_tmp.tmp_dws_srs_sr_storage_detail_di_year_1 t
inner join coss_dim.dim_ass_sr_df t1 on t.sr_id = t1.sr_id

```



















# template



```sql
  ,ods_update_time timestamp(6) default current_timestamp
  ,ods_load_time timestamp(6) default current_timestamp

partition by range (==)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)


;comment on column coss_ods.ods_update_time  is 'Data Update Time'
;comment on column coss_ods.ods_load_time    is 'Data Loading Time'


  ,localtimestamp    -- Data Warehouse update Time
  ,localtimestamp    -- Data Warehouse load Time
```







```sql
drop table if exists coss_dwd.dwd_wqm_sample_result_di_year;
create table if not exists coss_dwd.dwd_wqm_sample_result_di_year(
	sample_code varchar(21) not null,
	analysis_code varchar(72) not null,
	analysis_name varchar(300),
	result_modify_date timestamp(6),
	raw_result float8,
	local_code varchar(24),
	point_code varchar(12),
	water_type_code varchar(12),
	water_nature varchar(20),
	region_abbr varchar(5),
	admin_division_code varchar(12),
	collection_date timestamp(6),
	dwd_update_time timestamp(6) default current_timestamp,
	dwd_load_time timestamp(6) default current_timestamp,
	primary key (analysis_code, analysis_name, sample_code)
)
with (orientation = row, compression = no)
distribute by hash (analysis_code, analysis_name, sample_code)
partition by range (collection_date)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
);
comment on table coss_dwd.dwd_wqm_sample_result_di_year is 'Sample Inspection Result';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.sample_code is 'Sample ID';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.analysis_code is 'Analysis Code';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.analysis_name is 'Analysis Name';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.result_modify_date is 'Result Modified Date';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.raw_result is 'Raw Result';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.local_code is 'Sample Point Code';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.point_code is 'Sample Point Code';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.water_type_code is 'Water Type Code';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.water_nature is 'Water Nature';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.region_abbr is 'Regional Abbreviation';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.admin_division_code is 'Administrative Division Code';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.collection_date is 'Sample Collection Date';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.dwd_update_time is 'Data Update Time';
comment on column coss_dwd.dwd_wqm_sample_result_di_year.dwd_load_time is 'Data Loading Time';

drop table if exists coss_dwd.dwd_wqm_sample_local_info_df;
create table if not exists coss_dwd.dwd_wqm_sample_local_info_df(
	point_code varchar(12),
	local_code varchar(72),
	local_description varchar(180),
	region_abbr varchar(5),
	admin_division_code varchar(12),
	dwd_update_time timestamp(6) default current_timestamp,
	dwd_load_time timestamp(6) default current_timestamp,
	primary key (local_code)
)
with (orientation = row, compression = no)
distribute by replication;
comment on table coss_dwd.dwd_wqm_sample_local_info_df is 'Location Information of Sampling Points';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.point_code is 'Sample Point Code';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.local_code is 'Sample Point Code';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.local_description is 'Sample Point Description';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.region_abbr is 'Regional Abbreviation';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.admin_division_code is 'Administrative Division Code';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.dwd_update_time is 'Data Update Time';
comment on column coss_dwd.dwd_wqm_sample_local_info_df.dwd_load_time is 'Data Loading Time';
```

