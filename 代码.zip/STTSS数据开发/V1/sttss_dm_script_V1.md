# 1.RWS

## 1.❤🆗coss_tmp.tmp_dm_rws_region_ind_yield_dip

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw water yield daily kpi information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_tmp.tmp_dm_rws_region_ind_yield_dip
-- coss_dwd.dwd_rws_channel_flow_detail_dip
-- coss_dwd.dim_ass_rw_src_dfn
-- target table
-- coss_tmp.tmp_dm_rws_region_ind_yield_dip
-- ****************************************************************************************
;drop table if exists coss_tmp.tmp_dm_rws_region_ind_yield_dip
;create table if not exists coss_tmp.tmp_dm_rws_region_ind_yield_dip(
rw_id varchar(30)
,dt bigint
,yield decimal(20,5)
,current_storage decimal(20,5)
,design_storage decimal(20,5)
, change_storage  decimal(20,5)
)
-- delivery volume
;with t_a as (
select
dt
,t1.src_id as ig_id
,if(sum(if(left(t1.src_id, 2) = 'IG' and t.qty_del >= 0 , t.qty_del ,0)) <0, 0, sum(if(left(t1.src_id, 2) = 'IG' and t.qty_del >= 0  , t.qty_del ,0))) as to_wtc
from 
(select * from coss_dwd.dwd_rws_channel_flow_detail_dip ) t
inner join  coss_dwd.dim_ass_channels_dfn t1 on t.option_no = t1.option_no and t.ch_id =t1.ch_id 
where left(t1.src_id, 2) = 'IG' 
group by
dt
,ig_id
), t_b as (
select 
dt
,t1.dest_id as ig_id
,if(sum(if(left(t1.dest_id, 2) = 'IG' and t.qty_del >= 0 , t.qty_del ,0))<0,0, sum(if(left(t1.dest_id, 2) = 'IG' and t.qty_del >= 0 , t.qty_del ,0))) as from_wtc
from 
(select * from coss_dwd.dwd_rws_channel_flow_detail_dip) t
inner join  coss_dwd.dim_ass_channels_dfn t1 on t.option_no = t1.option_no and t.ch_id =t1.ch_id 
where left(t1.dest_id, 2) = 'IG'
group by
dt
,ig_id
), t_c as(
select 
rw_id
,dt
,rw_name
,rw_cname
,present_storage
,capacity
from 
(select * from coss_dws.dws_rws_rw_supply_detail_dip) t 
where left(rw_id, 2) = 'IG'
), t_d as(
select 
rw_id
,dt
,rw_name
,rw_cname
,present_storage
,capacity
from 
(select * from coss_dws.dws_rws_rw_supply_detail_dip) t 
where left(rw_id, 2) = 'IG'
)

 insert into coss_tmp.tmp_dm_rws_region_ind_yield_dip
--ir supply
select 
t.ig_id rw_id
,t.dt
,t.delivery + t1.change_storage as yield
,t1.present_storage  current_storage
,t1.capacity         design_storage
,t1.change_storage   change_storage
from 
(select 
ig_id
,dt
,rw_name
,rw_cname
,to_wtc
,from_wtc
,delivery
from 
(select 
t.dt
,t.ig_id
,t.to_wtc
,t1.from_wtc
,t.to_wtc - ifnull(t1.from_wtc, 0) as delivery
from 
t_a t
left join t_b t1 on t.dt = t1.dt and t.ig_id = t1.ig_id) t 
left join coss_dwd.dim_ass_rw_src_dfn t1 on t.ig_id = t1.rw_id ) t
left join 
(select 
t.rw_id as ig_id
,t.dt
,t.rw_name
,t.rw_cname
,t.present_storage
,t.capacity
,(t1.present_storage - t.present_storage) change_storage
from t_c t 
left join t_d t1 on t.dt = to_char(to_date(t1.dt,'yyyymmdd') + integer '-1','yyyymmdd')
and t.rw_id = t1.rw_id) t1 on t.ig_id = t1.ig_id and t.dt = t1.dt

-- river supply
union all
select 
t.src_id rw_id
,cast(to_char(rec_dt,'yyyymmdd') as int) dt
,qty_del yield
,0  current_storage
,0  design_storage
,0  change_storage
from 
(select * from coss_dwd.dwd_rws_channel_flow_detail_dip where src_id = 'RW00000003') t
left join coss_dwd.dim_ass_channels_dfn t1 on t.option_no = t1.option_no and t.ch_id = t1.ch_id 

--DJ supply
union all 
select 
rw_id
,cast(to_char(rec_dt,'yyyymmdd') as int) dt
,(agr_vol - dis_vol) as yield
,0  current_storage
,0  design_storage
,0  change_storage
from coss_ods.ods_sttss_sttss_gd_agr_supply_dip
```



## 2.❤🆗coss_dm.dm_rws_daily_rw_yield_di

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw water yield daily kpi information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_tmp.tmp_dm_rws_region_ind_yield_dip
-- coss_dwd.dim_ass_rw_src_dfn
-- target table
-- coss_dm.dm_rws_daily_rw_yield_di
-- ****************************************************************************************
;drop table if exists coss_dm.dm_rws_daily_rw_yield_di
;create table if not exists coss_dm.dm_rws_daily_rw_yield_di(
id                             varchar(50)
,statistical_day               decimal(20,0)
,island_change_storage         decimal(20,5)
,mainland_change_storage       decimal(20,5)
,total_change_storage          decimal(20,5)
,island_current_storage        decimal(20,5)
,island_design_storage         decimal(20,5)
,mainland_current_storage      decimal(20,5)
,mainland_design_storage       decimal(20,5)
,total_current_storage         decimal(20,5)
,total_design_storage          decimal(20,5)
,island_yield                  decimal(20,5)
,mainland_yield                decimal(20,5)
,total_local_yield             decimal(20,5)
,dj_yield                      decimal(20,5)
,total_yield                   decimal(20,5)
)
;with t_a as (
select 
t.rw_id 
,dt 
,yield
,change_storage
,current_storage
,design_storage
,region_ind 
from 
(select * from coss_tmp.tmp_dm_rws_region_ind_yield_dip ) t
left join coss_dwd.dim_ass_rw_src_dfn t1 on t.rw_id = t1.rw_id 
where 
t1.rw_id != 'RW00000001'
),t_b as (
select 
t.rw_id 
,dt 
,yield
,region_ind 
,change_storage
,current_storage
,design_storage
from 
(select * from coss_tmp.tmp_dm_rws_region_ind_yield_dip) t
left join coss_dwd.dim_ass_rw_src_dfn t1 on t.rw_id = t1.rw_id 
where 
t1.rw_id = 'RW00000001'
)
insert into coss_dm.dm_rws_daily_rw_yield_di 
select
  uuid()                                         as id 
  ,t.dt                                          as statistical_day
  ,if(t.current_storage=0 or t.current_storage is null,0, (t.change_storage/t.current_storage)*100) as island_change_storage
  ,if(t1.current_storage=0 or t1.current_storage is null,0, (t1.change_storage/t1.current_storage)*100) as mainland_change_storage
  ,if((t.current_storage+t1.current_storage) = 0 or (t.current_storage+t1.current_storage) is null,0,
(t.change_storage+t1.change_storage)/(t.current_storage+t1.current_storage)*100) as total_change_storage
  ,(t.current_storage)/1000                      as island_current_storage      -- convert ML to mcm
  ,(t.design_storage)/1000                       as island_design_storage       -- convert ML to mcm
  ,(t1.current_storage)/1000                     as mainland_current_storage    -- convert ML to mcm
  ,(t1.design_storage)/1000                      as mainland_design_storage     -- convert ML to mcm
  ,(t.current_storage + t1.current_storage)/1000 as total_current_storage       -- convert ML to mcm
  ,(t.design_storage + t1.design_storage)/1000   as total_design_storage        -- convert ML to mcm
  ,(t.yield)/1000                                as island_yield                -- convert ML to mcm
  ,(t1.yield)/1000                               as mainland_yield              -- convert ML to mcm
  ,(t.yield + t1.yield)/1000                     as total_local_yield           -- convert ML to mcm
  ,(t2.yield)/1000                               as dj_yield                    -- convert ML to mcm
  ,(t.yield + t1.yield + t2.yield)/1000          as total_yield                 -- convert ML to mcm
from 
(select
dt
,sum(yield)          as yield
,sum(change_storage) as change_storage
,sum(current_storage) as current_storage
,sum(design_storage)  as design_storage
from t_a t
where t.region_ind = 'I'
group by 
dt) t
left join 
(select
dt
,sum(yield) as yield
,sum(change_storage) as change_storage
,sum(current_storage) as current_storage
,sum(design_storage)  as design_storage
from t_a t
where t.region_ind = 'M'
group by 
dt)t1 on t.dt = t1.dt
left join t_b t2 on t1.dt = t2.dt     
```

## 3.❤🆗coss_dm.dm_rws_monthly_rw_yield_di

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw water yield monthly kpi information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_rws_daily_rw_yield_di
-- target table
-- coss_dm.dm_rws_monthly_rw_yield_di
-- ****************************************************************************************
;drop table if exists coss_dm.dm_rws_monthly_rw_yield_di
;create table if not exists coss_dm.dm_rws_monthly_rw_yield_di (
  id                     varchar(50)
  ,statistical_month     decimal(20,0)
  ,island_yield          decimal(20,5)
  ,mainland_yield        decimal(20,5)
  ,total_local_yield     decimal(20,5)
  ,dj_yield              decimal(20,5)
  ,total_yield           decimal(20,5)
)
;insert into coss_dm.dm_rws_monthly_rw_yield_di
select
  uuid()                      as id 
  ,round(statistical_day/100) as statistical_month
  ,sum(island_yield)          as island_yield                  
  ,sum(mainland_yield)        as mainland_yield                
  ,sum(total_local_yield)     as total_local_yield       
  ,sum(dj_yield)              as dj_yield                
  ,sum(total_yield)           as total_yield   
from coss_dm.dm_rws_daily_rw_yield_di
where island_yield          is not null
and mainland_yield       is not null
and total_local_yield    is not null
and dj_yield             is not null
and total_yield          is not null
group by 
  statistical_month
```

## 4.❤🆗coss_dm.dm_rws_annual_rw_yield_di

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw water yield annual kpi information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_rws_daily_rw_yield_di
-- target table
-- coss_dm.dm_rws_annual_rw_yield_di
-- ****************************************************************************************
;drop table if exists coss_dm.dm_rws_annual_rw_yield_di
;create table if not exists coss_dm.dm_rws_annual_rw_yield_di (
  id                     varchar(50)
  ,statistical_year      decimal(20,0)
  ,island_yield          decimal(20,5)
  ,mainland_yield        decimal(20,5)
  ,total_local_yield     decimal(20,5)
  ,dj_yield              decimal(20,5)
  ,total_yield           decimal(20,5)
)
;insert into coss_dm.dm_rws_annual_rw_yield_di
select
  uuid()                        as id 
  ,round(statistical_day/10000) as statistical_year
  ,sum(island_yield)            as island_yield                  
  ,sum(mainland_yield)          as mainland_yield                
  ,sum(total_local_yield)       as total_local_yield       
  ,sum(dj_yield)                as dj_yield                
  ,sum(total_yield)             as total_yield   
from coss_dm.dm_rws_daily_rw_yield_di
where island_yield       is not null 
and mainland_yield     is not null 
and total_local_yield  is not null 
and dj_yield           is not null 
and total_yield   is not null 
group by 
  statistical_year
```

## 5.❤🆗coss_dm.dm_srs_region_day_kpi_dip

```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Service reservoir daily kpi information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dim_ass_sr_dfn
-- target table
-- coss_dm.dm_srs_region_day_kpi_dip
-- ****************************************************************************************
;CREATE TABLE coss_dm.dm_srs_region_day_kpi_dip (
	id varchar(42) NULL,
	region varchar(200) NULL,
	item_code varchar(200) NULL,
	item_name varchar(300) NULL,
	item_value numeric(20, 5) NULL,
	"unit" varchar(50) NULL,
	etl_time timestamp(6) NULL,
	dt numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);
/**
 * delete history metrics data
 * input parameter ${dt} = 20250314
 * fresh and salt water design capacity
 */
;delete
from coss_dm.dm_srs_region_day_kpi_dip
where  item_code in  ('bi_p_212'
  ,'bi_p_213'
  ,'bi_p_214'
  ,'bi_p_215'
  )
  and dt = ${dt1}
/**
 * Calculation for fresh and salt water design capacity
 */
;with t_a as(
select
  region_code         as region
  ,w_type             as w_type
  ,sum(capacity)      as capacity
  ,${dt1}             as dt
from coss_dwd.dim_ass_sr_dfn
group by
  region_code
  ,w_type
)

insert into coss_dm.dm_srs_region_day_kpi_dip
select
  uuid()                                     as id
  ,'HKSAR'                                   as region
  ,'bi_p_212'                                as item_code
  ,'Fresh Water Service Reservoir Capacity'  as item_name
  , sum(capacity)/1000000                    as item_value -- convert cum to mcm
  ,'mcm'                                     as unit
  ,localtimestamp                            as etl_time
  ,t.dt                                      as dt
from t_a t
where w_type = 'F'
group by
  t.dt

union all

select
  uuid()                                     as id
  ,t.region                                  as region
  ,'bi_p_213'                                as item_code
  ,'Fresh Water Service Reservoir Capacity'  as item_name
  ,  capacity/1000000                        as item_value -- convert cum to mcm
  ,'mcm'                                     as unit
  ,localtimestamp                            as etl_time
  ,t.dt                                      as dt
from t_a t
where w_type = 'F'

 union all

select
  uuid()                                   as id
  ,'HKSAR'                                 as region
  ,'bi_p_214'                              as item_code
  ,'Salt Water Service Reservoir Capacity' as item_name
  , sum(capacity)/1000000                  as item_value -- convert cum to mcm
  ,'mcm'                                   as unit
  ,localtimestamp                          as etl_time
  ,t.dt                                    as dt
from t_a t
where w_type = 'S'
group by
  t.dt

union all

select
  uuid()                                   as id
  ,t.region                                as region
  ,'bi_p_215'                              as item_code
  ,'Salt Water Service Reservoir Capacity' as item_name
  ,capacity/1000000                        as item_value -- convert cum to mcm
  ,'mcm'                                   as unit
  ,localtimestamp                          as etl_time
  ,t.dt                                    as dt
from t_a t
where w_type = 'S'
```

## coss_dm.dm_srs_region_month_kpi_dip

```sql
/**
 * delete history metrics data
 * input parameter ${dt} = 20250314
 */
;delete
from coss_dm.dm_srs_region_month_kpi_dip
where  item_code in  ('bi_p_212'
  ,'bi_p_213'
  ,'bi_p_214'
  ,'bi_p_215')
  and mh = round(${dt1}/100, 0)
  
/**
 * Calculation for Service Reservoir Capacity
 */
;with t_a as(
select 
  region_code         as region 
  ,w_type             as w_type
  ,sum(capacity)      as capacity  
  ,round(${dt}/100,0) as mh
from
coss_dwd.dim_ass_sr_dfn 
group by 
  region_code
  ,w_type
)
insert into coss_dm.dm_srs_region_month_kpi_dip
select
  uuid()                                                   as id
  ,'HKSAR'                                                 as region
  ,'bi_p_212'                                              as item_code
  ,'Fresh Water Service Reservoir Capacity' as item_name
  , sum(capacity)/1000000                                  as item_value -- convert cum to mcm
  ,'mcm'                                                   as unit
  ,localtimestamp                                          as etl_time
  ,t.mh                                                    as mh
from t_a t
where w_type = 'F'
group by 
  t.mh
  
union all 

select
  uuid()                                                   as id
  ,t.region                                                as region
  ,'bi_p_213'                                              as item_code
  ,'Fresh Water Service Reservoir Capacity' as item_name
  ,  capacity/1000000                                      as item_value -- convert cum to mcm
  ,'mcm'                                                   as unit
  ,localtimestamp                                          as etl_time
  ,t.mh                                                    as mh
from t_a t
where w_type = 'F'
  
 union all
 
select
  uuid()                                                   as id
  ,'HKSAR'                                                 as region
  ,'bi_p_214'                                              as item_code
  ,'Salt Water Service Reservoir Capacity' as item_name
  , sum(capacity)/1000000                                  as item_value -- convert cum to mcm
  ,'mcm'                                                   as unit
  ,localtimestamp                                          as etl_time
  ,t.mh                                                    as mh
from t_a t
where w_type = 'S'
group by 
  t.mh
  
union all 

select
  uuid()                                                   as id
  ,t.region                                                as region
  ,'bi_p_215'                                              as item_code
  ,'Salt Water Service Reservoir Capacity' as item_name
  ,  capacity/1000000                                      as item_value -- convert cum to mcm
  ,'mcm'                                                   as unit
  ,localtimestamp                                          as etl_time
  ,t.mh                                                    as mh
from t_a t
where w_type = 'S'
```

## coss_dm.dm_srs_region_month_kpi_dip

```sql
/**
 * Calculation for quantity delivery of region monthly
 */

;drop table if exists coss_tmp.tmp_srs_sr_storage_detail_dip_1
;create table if not exists coss_tmp.tmp_srs_sr_storage_detail_dip_1 as
select
  region_code      as region
  ,sum(qty_del)    as qty_del
  ,round(dt/100,0) as mh
from coss_dws.dws_srs_sr_storage_detail_dip
where w_type = 'F' 
  and qty_del is not null
  and dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt}
group by
  region_code
  ,w_type
  ,round(dt/100,0)
  
/**
 * delete history metrics data
 */
;delete 
from coss_dm.dm_srs_region_month_kpi_dip
 where item_code in 
  ('bi_p_216'
  ,'bi_p_217')
  and mh= round(${dt1}/100, 0)

;with t_a as(
select
  region                                      as region
  ,qty_del                                    as qty_del
  ,sum(qty_del) over(
  partition by region
  order by mh desc
  rows between current row and 5 following ) as qty_del_6mh
  ,mh                                        as mh
from coss_tmp.tmp_srs_sr_storage_detail_dip_1 t
order by
  mh
),t_b as (
select
  qty_del                                      as qty_del
  ,sum(qty_del) over(
   order by mh desc
   rows between current row and 5 following )  as qty_del_6mh
  ,mh                                          as mh
from
(
select
  sum(qty_del)   as qty_del
  ,mh            as mh
from coss_tmp.tmp_srs_sr_storage_detail_dip_1 t
group by
  mh
) t
)

insert into  coss_dm.dm_srs_region_month_kpi_dip
select
  uuid()                               as id
  ,'HKSAR'                             as region
  ,'bi_p_216'                          as item_code
  ,'Service Reservoir Supply Volume'   as item_name
  ,(t.qty_del_6mh*1000)/6              as item_value -- convert Mld to cum
  ,'cum'                               as unit
  ,localtimestamp                      as etl_time
  ,t.mh                                as mh
from t_b t

union all

select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_217'                        as item_code
  ,'Service Reservoir Supply Volume' as item_name
  ,(t.qty_del_6mh*1000)/6            as item_value -- convert Mld to cum
  ,'cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t
```



## 6.❤🆗coss_dm.dm_srs_region_year_kpi_dip

```sql
CREATE TABLE coss_dm.dm_srs_region_year_kpi_dip (
	id varchar(42) NULL,
	region varchar(200) NULL,
	item_code varchar(200) NULL,
	item_name varchar(300) NULL,
	item_value numeric(20, 5) NULL,
	"unit" varchar(50) NULL,
	etl_time timestamp(6) NULL,
	yr numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);
/**
 * delete history metrics data
 */
;delete 
from coss_dm.dm_srs_region_year_kpi_dip
 where item_code in 
  ('bi_p_216'
  ,'bi_p_217')
  and yr = round(${dt1}/10000)
  
;with t_a as(
select
  region_code        as region
  ,sum(qty_del)/1000 as qty_del         -- convert Mld to mcm
  ,round(dt/10000,0) as yr
from coss_dws.dws_srs_sr_storage_detail_dip
where w_type = 'F' and qty_del is not null
and dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
and dt <= ${dt1}
group by
  region_code
  ,yr
), t_b as(
select
  sum(qty_del)/1000     as qty_del       -- convert Mld to mcm
  ,round(dt/10000,0)    as yr
from coss_dws.dws_srs_sr_storage_detail_dip
where w_type = 'F' and qty_del is not null
and dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
and dt <= ${dt1}
group by
  yr
)

insert into  coss_dm.dm_srs_region_year_kpi_dip
select
  uuid()                               as id
  ,'HKSAR'                             as region
  ,'bi_p_216'                          as item_code
  ,'Service Reservoir Supply Volume'   as item_name
  ,qty_del                             as item_value
  ,'cum'                               as unit
  ,localtimestamp                      as etl_time
  ,t.yr                                as yr
from t_b t

union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_217'                        as item_code
  ,'Service Reservoir Supply Volume' as item_name
  ,qty_del                           as item_value
  ,'cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.yr                              as yr
from t_a t
```

## 7.❤coss_dm.dm_rws_region_day_kpi_dip 

```sql
;drop table if exists coss_dm.dm_rws_region_day_kpi_dip
;CREATE TABLE if not exists coss_dm.dm_rws_region_day_kpi_dip (
	id varchar(42) NULL,
	region varchar(200) NULL,
	item_code varchar(200) NULL,
	item_name varchar(300) NULL,
	item_value numeric(20, 5) NULL,
	"unit" varchar(50) NULL,
	etl_time timestamp(6) NULL,
	dt numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);
```



```sql
-- ****************************************************************************************
-- source     system: STTSS(Smart Trunk Transfer Support System)
-- function describe: Raw water supply daily kpi information
-- create         by: dongmaochen
-- create       date: 2025-04-24
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dws.dws_rws_rw_supply_detail_dip
-- target table
-- coss_dm.dm_rws_region_day_kpi_dip
-- ****************************************************************************************
/**
 * delete history metrics data
 */
;delete
from coss_dm.dm_rws_region_day_kpi_dip 
where item_code in ('bi_p_224'
  ,'bi_p_225'
  ,'bi_p_226'
  ,'bi_p_227'
  ,'bi_p_230'
  ,'bi_p_231'
  ,'bi_p_234'
  ,'bi_p_235')

/**
 * precomputation Metrics of propose and actual supply
 */
;with t_a as (
select
  region_code region
  ,sum(p_qty) p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
group by 
  region_code
  ,dt
), t_b as(
select
  'HKSAR'           region    
  ,sum(p_qty)  p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
group by 
  region_code
  ,dt
),t_a1 as (
select
  region_code region
  ,dt
  ,sum(p_qty)/count(1) p_qty   
  ,sum(qty_del)/count(1) qty_del  
from coss_dws.dws_rws_rw_supply_detail_dip
group by 
  region_code
  ,dt
), t_b1 as(
select
  'HKSAR'           as region 
  ,dt               as dt
  ,sum(p_qty)       as p_qty   
  ,sum(qty_del)     as qty_del  
from coss_dws.dws_rws_rw_supply_detail_dip
group by 
  region_code
  ,dt
)
insert into coss_dm.dm_rws_region_day_kpi_dip
-- HKSAR Raw Water Actual Supply Volume
select 
   uuid()                            as id
   ,region                           as region
   ,'bi_p_224'                       as item_code
   ,'Raw Water Actual Supply Volume' as item_name
   ,qty_del                          as item_value
   ,'Ml'                             as unit
   ,localtimestamp                   as etl_time
   ,t.dt                             as dt
from t_b t

union all
-- Region Raw Water Actual Supply Volume
select 
   uuid()                            as id
   ,region                           as region
   ,'bi_p_225'                       as item_code
   ,'Raw Water Actual Supply Volume' as item_name
   ,qty_del                          as item_value
   ,'Ml'                             as unit
   ,localtimestamp                   as etl_time
   ,t.dt                             as dt
from t_a t

union all
-- HKSAR Raw Water Propose Supply Volume
select 
   uuid()                             as id
   ,region                            as region
   ,'bi_p_226'                        as item_code
   ,'Raw Water Propose Supply Volume' as item_name
   ,p_qty                             as item_value
   ,'Ml'                              as unit
   ,localtimestamp                    as etl_time
   ,t.dt                              as dt
from t_b t

union all 
-- Region Raw Water Propose Supply Volume
select 
   uuid()                             as id
   ,region                            as region
   ,'bi_p_227'                        as item_code
   ,'Raw Water Propose Supply Volume' as item_name
   ,p_qty                             as item_value
   ,'Ml'                              as unit
   ,localtimestamp                    as etl_time
   ,t.dt                              as dt
from t_a t

union all
-- HKSAR Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water
select
  uuid()                                                                               as id
  ,t.region                                                                            as region
  ,'bi_p_230'                                                                          as item_code
  ,'Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water'                   as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                   as item_value
  ,'%'                                                                                  as unit
  ,localtimestamp                                                                       as etl_time
  ,t.dt                                                                                   as dt
from t_b1 t
left join t_b1 t1 on t.dt = t1.dt+10000

union all 
-- Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water
select
  uuid()                                                                                as id
  ,t.region                                                                             as region
  ,'bi_p_231'                                                                           as item_code
  ,'Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water'                    as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                   as item_value
  ,'%'                                                                                  as unit
  ,localtimestamp                                                                       as etl_time
  ,t.dt                                                                                   as dt
from t_a1 t
left join t_a1 t1 on t.region = t1.region and t.dt = t1.dt+10000

union all 
-- HKSAR Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water
select
  uuid()                                                                                  as id
  ,t.region                                                                               as region
  ,'bi_p_234'                                                                             as item_code
  ,'Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water'                    as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                     as item_value
  ,'%'                                                                                    as unit
  ,localtimestamp                                                                         as etl_time
  ,t.dt                                                                                     as dt
from t_b1 t
left join t_b1 t1 on t.dt = t1.dt+10000


union all 
-- Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water
select
  uuid()                                                                                  as id
  ,t.region                                                                               as region
  ,'bi_p_235'                                                                             as item_code
  ,'Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water '                   as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                     as item_value
  ,'%'                                                                                    as unit
  ,localtimestamp                                                                         as etl_time
  ,t.dt                                                                                     as dt
from t_a1 t
left join t_a1 t1 on t.region = t1.region and t.dt = t1.dt+10000

```

## 8.❤coss_dm.dm_rws_region_month_kpi_dip

```sql
;drop table if exists coss_dm.dm_rws_region_month_kpi_dip
;create table if not exists coss_dm.dm_rws_region_month_kpi_dip (
	id varchar(42) NULL,
	region varchar(200) NULL,
	item_code varchar(200) NULL,
	item_name varchar(300) NULL,
	item_value numeric(20, 5) NULL,
	"unit" varchar(50) NULL,
	etl_time timestamp(6) NULL,
	mh numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);
```



```sql
/**
 * delete history metrics data
 */
;delete
from coss_dm.dm_rws_region_month_kpi_dip 
where item_code in ('bi_p_224'
  ,'bi_p_225'
  ,'bi_p_226'
  ,'bi_p_227'
  ,'bi_p_230'
  ,'bi_p_231'
  ,'bi_p_234'
  ,'bi_p_235')
  and mh = round(${dt1}/100)

/**
 * precomputation Metrics of propose and quantity delivery volume
 */
;with t_a as (
select
  region_code region
  ,sum(p_qty) p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1}
group by 
  region_code
  ,dt
), t_b as(
select
  'HKSAR'           region    
  ,sum(p_qty)  p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1}
group by 
  region_code
  ,dt
),t_a1 as (
select 
  region                  as region
  ,round(dt/100)          as mh
  ,sum(p_qty)/count(1)    as p_qty
  ,sum(qty_del)/ count(1) as qty_del
from 
(select
  region_code region
  ,sum(p_qty) p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where (dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1})
  or(dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')-10000
  and dt <= ${dt1}-10000)
group by 
  region_code
  ,dt) t
group by 
  region
 ,mh
), t_b1 as(

select 
  region                  as region
  ,round(dt/100)          as mh
  ,sum(p_qty)/count(1)    as p_qty
  ,sum(qty_del)/ count(1) as qty_del
from 
(select
  'HKSAR'           as region    
  ,sum(p_qty)       as p_qty   
  ,sum(qty_del)     as qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where (dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1})
  or(dt >= to_char(date_trunc('month', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')-10000
  and dt <= ${dt1}-10000)
group by 
  region_code
  ,dt) t
group by 
  region
 ,mh
 
)
insert into coss_dm.dm_rws_region_month_kpi_dip
-- HKSAR Raw Water Actual Supply Volume
select 
   uuid()                            as id
   ,region                           as region
   ,'bi_p_224'                       as item_code
   ,'Raw Water Actual Supply Volume' as item_name
   ,sum(qty_del)/count(*)            as item_value
   ,'Ml'                             as unit
   ,localtimestamp                   as etl_time
   ,round(t.dt/100)                  as mh
from t_b t
group by 
  region
  ,mh

union all
-- Region Raw Water Actual Supply Volume
select 
   uuid()                            as id
   ,region                           as region
   ,'bi_p_225'                       as item_code
   ,'Raw Water Actual Supply Volume' as item_name
   ,sum(qty_del)/count(*)            as item_value
   ,'Ml'                             as unit
   ,localtimestamp                   as etl_time
   ,round(t.dt/100)                  as mh
from t_a t
group by 
  region
  ,mh
  
union all
-- HKSAR Raw Water Propose Supply Volume
select 
   uuid()                             as id
   ,region                            as region
   ,'bi_p_226'                        as item_code
   ,'Raw Water Propose Supply Volume' as item_name
   ,sum(p_qty)/count(*)               as item_value
   ,'Ml'                              as unit
   ,localtimestamp                    as etl_time
   ,round(t.dt/100)                  as mh
from t_b t
group by 
  region
  ,mh
  
union all 
-- Region Raw Water Propose Supply Volume
select 
   uuid()                             as id
   ,region                            as region
   ,'bi_p_227'                        as item_code
   ,'Raw Water Propose Supply Volume' as item_name
   ,sum(p_qty)/count(*)               as item_value
   ,'Ml'                              as unit
   ,localtimestamp                    as etl_time
   ,round(t.dt/100)                  as mh
from t_a t
group by 
  region
  ,mh
  
union all
-- HKSAR Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water
select
  uuid()                                                                               as id
  ,t.region                                                                            as region
  ,'bi_p_230'                                                                          as item_code
  ,'Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water'                   as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                   as item_value
  ,'%'                                                                                  as unit
  ,localtimestamp                                                                       as etl_time
  ,t.mh                                                                                 as mh
from t_b1 t
left join t_b1 t1 on t.mh = t1.mh+100

union all 
-- Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water
select
  uuid()                                                                                as id
  ,t.region                                                                             as region
  ,'bi_p_231'                                                                           as item_code
  ,'Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water'                    as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                   as item_value
  ,'%'                                                                                  as unit
  ,localtimestamp                                                                       as etl_time
  ,t.mh                                                                                 as mh
from t_a1 t
left join t_a1 t1 on t.region = t1.region and t.mh = t1.mh+100

union all 
-- HKSAR Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water
select
  uuid()                                                                                  as id
  ,t.region                                                                               as region
  ,'bi_p_234'                                                                             as item_code
  ,'Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water'                    as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                     as item_value
  ,'%'                                                                                    as unit
  ,localtimestamp                                                                         as etl_time
  ,t.mh                                                                                   as mh
from t_b1 t
left join t_b1 t1 on t.mh = t1.mh+100

union all 
-- Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water
select
  uuid()                                                                                  as id
  ,t.region                                                                               as region
  ,'bi_p_235'                                                                             as item_code
  ,'Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water '                   as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                     as item_value
  ,'%'                                                                                    as unit
  ,localtimestamp                                                                         as etl_time
  ,t.mh                                                                                   as mh
from t_a1 t
left join t_a1 t1 on t.region = t1.region and t.mh = t1.mh+100
```

## 9.❤coss_dm.dm_rws_region_year_kpi_dip

```sql
CREATE TABLE coss_dm.dm_rws_region_year_kpi_dip (
	id varchar(42) NULL,
	region varchar(200) NULL,
	item_code varchar(200) NULL,
	item_name varchar(300) NULL,
	item_value numeric(20, 5) NULL,
	"unit" varchar(50) NULL,
	etl_time timestamp(6) NULL,
	yr numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);

/**
 * delete history metrics data
 */
;delete
from coss_dm.dm_rws_region_year_kpi_dip 
where item_code in ('bi_p_224'
  ,'bi_p_225'
  ,'bi_p_226'
  ,'bi_p_227'
  ,'bi_p_230'
  ,'bi_p_231'
  ,'bi_p_234'
  ,'bi_p_235')
  and yr = round(${dt1}/10000)

/**
 * precomputation Metrics of propose and quantity delivery volume
 */
;with t_a as (
select
  region_code region
  ,sum(p_qty) p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1}
group by 
  region_code
  ,dt
), t_b as(
select
  'HKSAR'           region    
  ,sum(p_qty)  p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1}
group by 
  region_code
  ,dt
),t_a1 as (
select 
  region                  as region
  ,round(dt/10000)          as yr
  ,sum(p_qty)/count(1)    as p_qty
  ,sum(qty_del)/ count(1) as qty_del
from 
(select
  region_code region
  ,sum(p_qty) p_qty   
  ,sum(qty_del) qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where (dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1}) 
  or(dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')-10000
  and dt <= ${dt1}-10000)
group by 
  region_code
  ,dt) t
group by 
  region
 ,yr

), t_b1 as(
select 
  region                  as region
  ,round(dt/10000)          as yr
  ,sum(p_qty)/count(1)    as p_qty
  ,sum(qty_del)/ count(1) as qty_del
from 
(select
  'HKSAR'           as region    
  ,sum(p_qty)       as p_qty   
  ,sum(qty_del)     as qty_del  
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where  (dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')
  and dt <= ${dt1}) 
  or(dt >= to_char(date_trunc('year', to_date(${dt1},'yyyy-mm-dd')),'yyyymmdd')-10000
  and dt <= ${dt1}-10000)
group by 
  region_code
  ,dt) t
group by 
  region
 ,yr
)

insert into coss_dm.dm_rws_region_year_kpi_dip
-- HKSAR Raw Water Actual Supply Volume
select 
   uuid()                            as id
   ,region                           as region
   ,'bi_p_224'                       as item_code
   ,'Raw Water Actual Supply Volume' as item_name
   ,sum(qty_del)/count(1)            as item_value
   ,'Ml'                             as unit
   ,localtimestamp                   as etl_time
   ,round(t.dt/10000)                as yr
from t_b t
group by 
  region
  ,yr

union all
-- Region Raw Water Actual Supply Volume
select 
   uuid()                            as id
   ,region                           as region
   ,'bi_p_225'                       as item_code
   ,'Raw Water Actual Supply Volume' as item_name
   ,sum(qty_del)/count(1)            as item_value
   ,'Ml'                             as unit
   ,localtimestamp                   as etl_time
   ,round(t.dt/10000)                as yr
from t_a t
group by 
  region
  ,yr
  
union all
-- HKSAR Raw Water Propose Supply Volume
select 
   uuid()                             as id
   ,region                            as region
   ,'bi_p_226'                        as item_code
   ,'Raw Water Propose Supply Volume' as item_name
   ,sum(p_qty)/count(1)               as item_value
   ,'Ml'                              as unit
   ,localtimestamp                    as etl_time
   ,round(t.dt/10000)                 as yr
from t_b t
group by 
  region
  ,yr
  
union all 
-- Region Raw Water Propose Supply Volume
select 
   uuid()                             as id
   ,region                            as region
   ,'bi_p_227'                        as item_code
   ,'Raw Water Propose Supply Volume' as item_name
   ,sum(p_qty)/count(1)               as item_value
   ,'Ml'                              as unit
   ,localtimestamp                    as etl_time
   ,round(t.dt/10000)                 as yr
from t_a t
group by 
  region
  ,yr
  
union all

-- HKSAR Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water
select
  uuid()                                                                               as id
  ,t.region                                                                            as region
  ,'bi_p_230'                                                                          as item_code
  ,'Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water'                   as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                   as item_value
  ,'%'                                                                                  as unit
  ,localtimestamp                                                                       as etl_time
  ,t.yr                                                                                 as yr
from t_b1 t
left join t_b1 t1 on t.yr = t1.yr+1

union all 
-- Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water
select
  uuid()                                                                                as id
  ,t.region                                                                             as region
  ,'bi_p_231'                                                                           as item_code
  ,'Year-On-Year Rises Of Average Actual Supply Volume Of Raw Water'                    as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                   as item_value
  ,'%'                                                                                  as unit
  ,localtimestamp                                                                       as etl_time
  ,t.yr                                                                                 as yr
from t_a1 t
left join t_a1 t1 on t.region = t1.region and t.yr = t1.yr+1

union all 
-- HKSAR Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water
select
  uuid()                                                                                  as id
  ,t.region                                                                               as region
  ,'bi_p_234'                                                                             as item_code
  ,'Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water'                    as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                     as item_value
  ,'%'                                                                                    as unit
  ,localtimestamp                                                                         as etl_time
  ,t.yr                                                                                   as yr
from t_b1 t
left join t_b1 t1 on t.yr = t1.yr+1


union all 
-- Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water
select
  uuid()                                                                                  as id
  ,t.region                                                                               as region
  ,'bi_p_235'                                                                             as item_code
  ,'Year-On-Year Rises Of Average Proposed Supply Volume Of Raw Water '                   as item_name
  ,case
    when t1.qty_del is null or t1.qty_del = 0  then 0.0
    else (t.qty_del - t1.qty_del) / t1.qty_del * 100
  end                                                                                     as item_value
  ,'%'                                                                                    as unit
  ,localtimestamp                                                                         as etl_time
  ,t.yr                                                                                   as yr
from t_a1 t
left join t_a1 t1 on t.region = t1.region and t.yr = t1.yr+1

```

## 10.❤coss_dm.dm_rws_rw_supply_hist_dip

```sql
CREATE TABLE coss_dm.dm_rws_rw_supply_hist_dip (
	rw_id varchar(20) NULL,
	rw_name varchar(200) NULL,
	rw_cname varchar(300) NULL,
	region_code varchar(10) NULL,
	source_rw varchar(2) NULL,
	p_qty numeric(12, 4) NULL,
	qty_del numeric(12, 4) NULL,
	present_storage numeric(16, 8) NULL,
	capacity numeric(12, 4) NULL,
	min_storage numeric(12, 4) NULL,
	rec_dt timestamp(6) NULL,
	dt numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);

;delete from coss_dm.dm_rws_rw_supply_hist_dip where dt = ${dt1}
;insert into coss_dm.dm_rws_rw_supply_hist_dip
select
  rw_id 
  ,rw_name
  ,rw_cname 
  ,region_code 
  ,source_rw 
  ,p_qty 
  ,qty_del
  ,present_storage 
  ,capacity 
  ,min_storage 
  ,rec_dt
  ,dt
from coss_dws.dws_rws_rw_supply_detail_dip
where dt = ${dt1}
```

## ❤coss_dm.dm_rws_daily_ir_storage_yield_di 

```sql
;drop table if exists coss_dm.dm_rws_daily_ir_storage_yield_di 
;create table if not exists coss_dm.dm_rws_daily_ir_storage_yield_di (
id                    varchar(50)
,rw_id                varchar(50)
,rw_name              varchar(50)
,rw_cname             varchar(50)
,rpt_label            varchar(50)
,region_code          varchar(50)
,region_name          varchar(100)
,region_cname         varchar(200)
,region_ind           varchar(50)
,ig_ind               varchar(50)
,yield                decimal(20,5)
,current_storage      decimal(20,5)
,design_storage       decimal(20,5)
,change_storage       decimal(20,5)
,dt                   decimal(10)
,primary key(id)
)
-- delivery volume
;with t_a as (
select
dt
,t1.src_id as ig_id
,if(sum(if(left(t1.src_id, 2) = 'IG' and t.qty_del >= 0 , t.qty_del ,0)) <0, 0, sum(if(left(t1.src_id, 2) = 'IG' and t.qty_del >= 0  , t.qty_del ,0))) as to_wtc
from 
(select * from coss_dwd.dwd_rws_channel_flow_detail_dip ) t
inner join  coss_dwd.dim_ass_channels_dfn t1 on t.option_no = t1.option_no and t.ch_id =t1.ch_id 
where left(t1.src_id, 2) = 'IG' 
group by
dt
,ig_id
), t_b as (
select 
dt
,t1.dest_id as ig_id
,if(sum(if(left(t1.dest_id, 2) = 'IG' and t.qty_del >= 0 , t.qty_del ,0))<0,0, sum(if(left(t1.dest_id, 2) = 'IG' and t.qty_del >= 0 , t.qty_del ,0))) as from_wtc
from 
(select * from coss_dwd.dwd_rws_channel_flow_detail_dip) t
inner join  coss_dwd.dim_ass_channels_dfn t1 on t.option_no = t1.option_no and t.ch_id =t1.ch_id 
where left(t1.dest_id, 2) = 'IG'
group by
dt
,ig_id
), t_c as(
select 
rw_id
,dt
,rw_name
,rw_cname
,present_storage
,capacity
from 
(select * from coss_dws.dws_rws_rw_supply_detail_dip) t 
where left(rw_id, 2) = 'IG'
), t_d as(
select 
rw_id
,dt
,rw_name
,rw_cname
,present_storage
,capacity
from 
(select * from coss_dws.dws_rws_rw_supply_detail_dip) t 
where left(rw_id, 2) = 'IG'
)
insert into coss_dm.dm_rws_daily_ir_storage_yield_di 
--ir supply
select 
uuid() id 
,t.ig_id rw_id
,t2.rw_name
,t2.rw_cname
,t2.rpt_label
,t2.region_code
,t2.region_name
,t2.region_cname
,t2.region_ind
,t2.ig_ind
,t.delivery + t1.change_storage as yield
,t1.present_storage  current_storage
,t1.capacity         design_storage
,t1.change_storage   change_storage
,t.dt
from 
(select 
ig_id
,dt
,rw_name
,rw_cname
,to_wtc
,from_wtc
,delivery
from 
(select 
t.dt
,t.ig_id
,t.to_wtc
,t1.from_wtc
,t.to_wtc - ifnull(t1.from_wtc, 0) as delivery
from 
t_a t
left join t_b t1 on t.dt = t1.dt and t.ig_id = t1.ig_id) t 
left join coss_dwd.dim_ass_rw_src_dfn t1 on t.ig_id = t1.rw_id ) t
left join 
(select 
t.rw_id as ig_id
,t.dt
,t.rw_name
,t.rw_cname
,t.present_storage
,t.capacity
,(t1.present_storage - t.present_storage) change_storage
from t_c t 
left join t_d t1 on t.dt = to_char(to_date(t1.dt,'yyyymmdd') + integer '-1','yyyymmdd')
and t.rw_id = t1.rw_id) t1 on t.ig_id = t1.ig_id and t.dt = t1.dt
left join coss_dwd.dim_ass_rw_src_dfn t2 on t.ig_id = t2.rw_id
where t1.present_storage != 0
```

## ❤coss_dm.dm_rws_daily_ir_level_storage_di

```sql
;drop table if exists coss_dm.dm_rws_daily_ir_level_storage_di
;create table if not exists coss_dm.dm_rws_daily_ir_level_storage_di(
id                varchar(50)
,ir_id             varchar(50)
,i_code           varchar(50)
,ir_rpt_label     varchar(100)
,ir_name          varchar(100)
,ir_cname         varchar(100)
,region_code      varchar(100)
,region_name      varchar(100)
,region_cname     varchar(100)
,region_ind       varchar(50)
,level_type       varchar(50)
,level_unit       varchar(50)
,dead_storage     decimal(20,5)
,twl              decimal(20,5)
,capacity         decimal(20,5)
,min_storage      decimal(20,5)
,limit_m          decimal(20,5)
,wl_mpd           decimal(20,5)
,storage          decimal(20,5)
,avg_7_mpd        decimal(20,5)
,avg_7_storage    decimal(20,5)
,avg_28_mpd       decimal(20,5)
,avg_28_storage   decimal(20,5)
,rec_dt           timestamp(6)
)


```

```python
sql00 = """
select 
ir_id
,rec_dt 
,wl_mpd
,storage
,sum(wl_mpd) over(
  partition by ir_id
  order by rec_dt desc
  rows between current row and 6 following )/7 as avg_7_mpd
,sum(storage) over(
  partition by ir_id
  order by rec_dt desc
  rows between current row and 6 following )/7 as avg_7_storage

  ,sum(wl_mpd) over(
  partition by ir_id
  order by rec_dt desc
  rows between current row and 27 following )/28 as avg_28_mpd
,sum(storage) over(
  partition by ir_id
  order by rec_dt desc
  rows between current row and 27 following )/28 as avg_28_storage
from ir_storage
where wl_mpd is not null 
and storage is not null 
order by rec_dt
"""
sql01 = """
select
  t1.ig_id           as ig_id            -- Impounding Reservoir Group ID with format IGNNNNNNNN
  ,t1.ig_name        as ig_name          -- Name of Impounding Reservoir Group
  ,t1.ig_cname       as ig_cname         -- Chinese Name of Impounding Reservoir Group
  ,t1.rlabel         as ig_rpt_label     -- Labels used in reports
  ,t1.region         as region_code      -- Region
  ,t2.descrip        as region_name      -- Description of Region
  ,t2.cdescrip       as region_cname     -- Chinese Description of Region
  ,t2.indicator      as region_ind       -- Possible Values: {"I" - HK Island, "M" - Mainland}
  ,t1.old_ind        as ig_ind           -- Indicates if Impounding Reservoir Group is old or new. Possible Values: {"Y" - Old, "N" - New}
  ,t.ir_id           as ir_id            -- Impounding Reservoir ID with format IRNNNNNNNN
  ,t.i_code          as i_code           -- Installation Code of Impounding Reservoir
  ,t.rlabel          as ir_rpt_label     -- Labels used in reports
  ,t.ir_name         as ir_name          -- Impounding reservoir name
  ,t.ir_cname        as ir_cname         -- Impounding Reservoir Chinese Name
  ,t.level_type      as level_type       -- Possible Values: {"A" - Above TWL, "B" - Below TWL, "P" - APD}
  ,t.level_unit      as level_unit       -- Possible Values:{"F" - Feet / Inch, "M" - Meter}
  ,t.dead_storage    as dead_storage     -- Dead Storage of an Impounding Reservoir.  Unit is in mcm
  ,t.twl             as twl              -- TWL
  ,t.capacity        as capacity         -- Capacity of IR.  Unit is in mcm
  ,t.min_storage     as min_storage      -- Allowable Minimum Storage.  Unit is in mcm
  ,t.limit_m         as limit_m          -- Preset Limit for Water Level.  Unit is in m
  ,now()    as dw_etl_time      -- Data Warehouse ETL Time
from ods_sttss_sttss_ir_dfn t
  left join ods_sttss_sttss_ir_group_dfn t1 on t.ig_id = t1.ig_id
  left join ods_sttss_sttss_region_dfn t2 on t1.region = t2.code
"""
sql02 = """select 
  uuid() id
  ,t1.ir_id
  ,t1.i_code
  ,t1.ir_rpt_label
  ,t1.ir_name
  ,t1.ir_cname
  ,t1.region_code
  ,t1.region_name
  ,t1.region_cname
  ,t1.region_ind
  ,t1.level_type
  ,t1.level_unit
  ,t1.dead_storage
  ,t1.twl
  ,t1.capacity
  ,t1.min_storage
  ,t1.limit_m
  ,t.wl_mpd
  ,t.storage/t1.capacity*100  as storage
  ,t.avg_7_mpd
  ,t.avg_7_storage/t1.capacity*100 as avg_7_storage
  ,t.avg_28_mpd
  ,t.avg_28_storage/t1.capacity*100 as avg_28_storage
  ,t.rec_dt
from sql00 t 
  left join sql01 t1 on t.ir_id = t1.ir_id"""
spark.sql(sql00).createOrReplaceTempView('sql00')
spark.sql(sql01).createOrReplaceTempView('sql01')
spark.sql(sql02).createOrReplaceTempView('sql02')
```

## ❤coss_dm.dm_srs_daily_sr_wl_qty_item_di

```sql
;drop table if exists coss_dm.dm_srs_daily_sr_wl_qty_item_di
;create table if not exists coss_dm.dm_srs_daily_sr_wl_qty_item_di(
  sr_id               varchar(50)
  ,i_code              varchar(50)
  ,sr_name             varchar(200)
  ,sr_cname            varchar(300)
  ,rpt_label           varchar(100)
  ,region_code         varchar(50)
  ,sub_region          varchar(50)
  ,region_name         varchar(50)
  ,region_cname        varchar(50)
  ,region_ind          varchar(50)
  ,w_type              varchar(50)
  ,w_type_desc         varchar(50)
  ,div_height          varchar(50)
  ,capacity            decimal(20,5)
  ,w_lim               decimal(20,5)
  ,num_of_storage      decimal(20,2)
  ,a_wl                decimal(20,5)
  ,b_wl                decimal(20,5)
  ,qty_del             decimal(20,5)
  ,rec_dt              timestamp(6)
  ,dw_etl_time         timestamp(6)
)
;with t_a as (
select 
"INSTALLATION_ID", "REGION"
from (
select "INSTALLATION_ID", "REGION", "SYSTEM"  from coss_ods.ods_dms_f_svcrsvrtnk_dfn  where char_length("INSTALLATION_ID") !=0
union all 
select "INSTALLATION_ID", "REGION", "SYSTEM"  from coss_ods.ods_dms_r_svcrsvrtnk_dfn  where char_length("INSTALLATION_ID") !=0
union all
select "INSTALLATION_ID", "REGION", "SYSTEM"  from coss_ods.ods_dms_s_svcrsvrtnk_dfn  where char_length("INSTALLATION_ID") !=0
) t
group by 
"INSTALLATION_ID", "REGION"
),t_b as(
 select 
 t.sr_id
,t.a_wl
,t.b_wl
,t1.qty_del
,t.rec_dt
 from (
select 
sr_id
, a_wl
,b_wl
,rec_dt 
from coss_dwd.dwd_srs_sr_storage_detail_dip) t
left join (
select 
src_id
,rec_dt
,sum(qty_del) as qty_del
from coss_dwd.dwd_rws_channel_flow_detail_dip 
where left(src_id,2) = 'SR'  
and qty_del is not null 
and qty_del > 0
group by 
src_id
,rec_dt
) t1 on t.sr_id = t1.src_id and t.rec_dt = t1.rec_dt
)
insert into coss_dm.dm_srs_daily_sr_wl_qty_item_di
select 
t1.sr_id
,t1.i_code
,t1.sr_name
,t1.sr_cname
,t1.rpt_label
,t1.region_code
,split_part(split_part("REGION",'(',2), ')', 1) as sub_region
,t1.region_name
,t1.region_cname
,t1.region_ind
,t1.w_type
,t1.w_type_desc
,t1.div_height
,t1.capacity
,t1.w_lim
,t1.num_of_storage
,t.a_wl
,t.b_wl
,t.qty_del
,t.rec_dt
,localtimestamp dw_etl_time
from t_b t
left join coss_dwd.dim_ass_sr_dfn t1 on t.sr_id = t1.sr_id
left join t_a t2 on t1.i_code =  t2."INSTALLATION_ID"
```

