# ods

## 1.ods_dcs_wtw_data_tuenmun

### 1.create table

1. ods_dcs_opc_wtw_data_tuenmun_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_tuenmun_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.ods_load_time     is 'ods load time'
   ```

   

2. ods_dcs_opc_wtw_data_full_tuenmun_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_tuenmun_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month                   is 'water treatment work tag poc data full'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month.ods_load_time     is 'ods load time'
   ```

   

### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For tuenmun
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_tuenmun
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf
   -- ****************************************************************************************
   select
   	t.id                             -- id
   	,t.tag_name                      -- tag name
   	,t.tag_value                     -- tag value
   	,t.quality                       -- quality
   	,t.tag_time                      -- tag time
   	,t.ms_sql_time                   -- ms sql time
   	,localtimestamp ods_update_time  -- ods update time
       ,localtimestamp ods_load_time    -- ods load time
   from coss_dcs.opc_data_tuenmun t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW016'
   ```

   

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For tuenmun
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

   

## 2.ods_dcs_wtw_data_yaukomtau

### 1.create table

1. ods_dcs_opc_wtw_data_yaukomtau_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_yaukomtau_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )  
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_yaukomtau_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_yaukomtau_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month.ods_load_time     is 'ods load time'
   ```

   

### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For yaukomtau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_yaukomtau
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf
   -- ****************************************************************************************
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_dcs.opc_data_yaukomtau t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW018'
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For yaukomtau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month
   select
   	t.id                               -- id
   	,t.tag_name                        -- tag name
   	,t.tag_value                       -- tag value
   	,t.quality                         -- quality
   	,t.tag_time                        -- tag time
   	,t.ms_sql_time                     -- ms sql time
   	,localtimestamp ods_update_time    -- ods update time
       ,localtimestamp ods_load_time      -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

## 3.ods_dcs_wtw_data_shatin

### 1.create table 

1. ods_dcs_opc_wtw_data_shatin_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_shatin_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_shatin_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_shatin_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_shatin_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_shatin_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_shatin_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_shatin_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month.ods_load_time     is 'ods load time'
   ```

   

### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For shatin
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_shatin
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_shatin_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_shatin t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW013'
   
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For shatin
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_shatin_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_shatin_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```


## 4.ods_dcs_wtw_data_silverminebay

### 1.create table 

1. ods_dcs_opc_wtw_data_silverminebay_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_silverminebay_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_silverminebay_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_silverminebay_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month.ods_load_time     is 'ods load time'
   ```


### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For silverminebay
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_silverminebay
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_silverminebay t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW009'
   ```
   
2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For silverminebay
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```


## 5.ods_dcs_wtw_data_autau

### 1.create table 

1. ods_dcs_opc_wtw_data_autau_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_autau_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_autau_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_autau_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_autau_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_autau_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_autau_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_autau_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month.ods_load_time     is 'ods load time'
   ```


### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For autau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_autau
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_autau_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_autau t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW021'
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For autau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_autau_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_autau_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```




## 6.ods_dcs_wtw_data_ngautammei

### 1.create table 

1. ods_dcs_opc_wtw_data_ngautammei_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_ngautammei_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_ngautammei_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_ngautammei_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month.ods_load_time     is 'ods load time'
   ```


### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For ngautammei
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_ngautammei
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_ngautammei t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW027'
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For ngautammei
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```



## 7.ods_dcs_wtw_data_maonshan

### 1.create table 

1. ods_dcs_opc_wtw_data_maonshan_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_maonshan_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_maonshan_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_maonshan_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_maonshan_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_maonshan_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_maonshan_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month.ods_load_time     is 'ods load time'
   ```


### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For maonshan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_maonshan
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_maonshan_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_maonshan t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW024'
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For maonshan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_maonshan_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_maonshan_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

## 8.ods_dcs_wtw_data_siuhowan

### 1.create table 

1. ods_dcs_opc_wtw_data_siuhowan_minf

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf (
   	id bigserial not null,
   	tag_name varchar(128) null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_siuhowan_unique unique (tag_name)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf                   is 'water treatment work tag poc data latest'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.ods_load_time     is 'ods load time'
   ```

2. ods_dcs_opc_wtw_data_full_siuhowan_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_siuhowan_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.ods_load_time     is 'ods load time'
   ```


### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_siuhowan
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_siuhowan t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW025'
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

## 













# dwd

## 1.coss_dwd.dwd_wtw_opc_data_latest_minf

### 1.create table 

```sql
;drop table if exists coss_dwd.dwd_wtw_opc_data_latest_minf
;create table coss_dwd.dwd_wtw_opc_data_latest_minf (
	id bigserial not null,
	i_code varchar(50) not null,
	tag_name varchar(128) null,
	tag_value varchar(128) null,
	quality int4 not null,
	tag_time timestamp not null,
	dwd_update_time timestamp not null,
    dwd_load_time timestamp(6) not null,
    primary key(i_code, tag_name, tag_time)
)
with (
	orientation=row,
	compression=no,
	storage_type=ustore,
	segment=off
)
;comment on table  coss_dwd.dwd_wtw_opc_data_latest_minf                     is 'water treatment work tag poc data latest'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.id                  is 'id'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.i_code              is 'install code'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.tag_name            is 'tag name'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.tag_value           is 'tag value'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.quality             is 'quality'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.tag_time            is 'tag time'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.dwd_update_time     is 'dwd update time'
;comment on column coss_dwd.dwd_wtw_opc_data_latest_minf.dwd_load_time       is 'dwd load time'


```

### 2.select sql

1. tuenmun

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For tuenmun
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW016'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW016' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf 
   ```

   

2. yaukomtau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For yaukomtau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW018'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW018' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf 
   ```

3. shatin

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For shatin
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_shatin_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW013'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW013' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_shatin_minf 
   ```

4. silverminebay

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For silverminebay
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW009'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW009' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf 
   ```

5. autau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For autau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_autau_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW021'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW021' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_autau_minf 
   ```

6. ngautammei

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For ngautammei
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW027'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW027' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf 
   ```

7. maonshan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For maonshan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_maonshan_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW024'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW024' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_maonshan_minf 
   ```

8. siuhowan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf 
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dwd.dwd_wtw_opc_data_latest_minf where i_code = 'TW025'
   ;insert into coss_dwd.dwd_wtw_opc_data_latest_minf
   select 
     id                               -- id
     ,'TW025' as i_code               -- install code
     ,tag_name                        -- tag name
     ,tag_value                       -- tag value
     ,quality                         -- quality
     ,tag_time                        -- tag time
     ,localtimestamp dwd_update_time  -- dwd update time
     ,localtimestamp dwd_load_time    -- dwd load time
   from coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf 
   ```

   

## 2.coss_dwd.dwd_wtw_opc_data_mini_day

### 1.create table

```sql
;drop table if exists coss_dwd.dwd_wtw_opc_data_mini_day
;create table if not exists coss_dwd.dwd_wtw_opc_data_mini_day(
	id bigserial not null,
	i_code varchar(50) not null,
	tag_name varchar(128) null,
	tag_value varchar(128) null,
	quality int4 not null,
	tag_time timestamp not null,
	dwd_update_time timestamp not null,
    dwd_load_time timestamp(6) not null,
    primary key(i_code, tag_name, tag_time)
)
with (
	orientation=row,
	compression=no,
	storage_type=ustore,
	segment=off
)
partition by range (tag_time)
(
partition dt_20250101 values less than ('2025-01-02 00:00:00'),
    partition dt_20250102 values less than ('2025-01-03 00:00:00'),
    partition dt_20250103 values less than ('2025-01-04 00:00:00'),
    partition dt_20250104 values less than ('2025-01-05 00:00:00'),
    partition dt_20250105 values less than ('2025-01-06 00:00:00'),
    partition dt_20250106 values less than ('2025-01-07 00:00:00'),
    partition dt_20250107 values less than ('2025-01-08 00:00:00'),
    partition dt_20250108 values less than ('2025-01-09 00:00:00'),
    partition dt_20250109 values less than ('2025-01-10 00:00:00'),
    partition dt_20250110 values less than ('2025-01-11 00:00:00'),
    partition dt_20250111 values less than ('2025-01-12 00:00:00'),
    partition dt_20250112 values less than ('2025-01-13 00:00:00'),
    partition dt_20250113 values less than ('2025-01-14 00:00:00'),
    partition dt_20250114 values less than ('2025-01-15 00:00:00'),
    partition dt_20250115 values less than ('2025-01-16 00:00:00'),
    partition dt_20250116 values less than ('2025-01-17 00:00:00'),
    partition dt_20250117 values less than ('2025-01-18 00:00:00'),
    partition dt_20250118 values less than ('2025-01-19 00:00:00'),
    partition dt_20250119 values less than ('2025-01-20 00:00:00'),
    partition dt_20250120 values less than ('2025-01-21 00:00:00'),
    partition dt_20250121 values less than ('2025-01-22 00:00:00'),
    partition dt_20250122 values less than ('2025-01-23 00:00:00'),
    partition dt_20250123 values less than ('2025-01-24 00:00:00'),
    partition dt_20250124 values less than ('2025-01-25 00:00:00'),
    partition dt_20250125 values less than ('2025-01-26 00:00:00'),
    partition dt_20250126 values less than ('2025-01-27 00:00:00'),
    partition dt_20250127 values less than ('2025-01-28 00:00:00'),
    partition dt_20250128 values less than ('2025-01-29 00:00:00'),
    partition dt_20250129 values less than ('2025-01-30 00:00:00'),
    partition dt_20250130 values less than ('2025-01-31 00:00:00'),
    partition dt_20250131 values less than ('2025-02-01 00:00:00'),
    partition dt_20250201 values less than ('2025-02-02 00:00:00'),
    partition dt_20250202 values less than ('2025-02-03 00:00:00'),
    partition dt_20250203 values less than ('2025-02-04 00:00:00'),
    partition dt_20250204 values less than ('2025-02-05 00:00:00'),
    partition dt_20250205 values less than ('2025-02-06 00:00:00'),
    partition dt_20250206 values less than ('2025-02-07 00:00:00'),
    partition dt_20250207 values less than ('2025-02-08 00:00:00'),
    partition dt_20250208 values less than ('2025-02-09 00:00:00'),
    partition dt_20250209 values less than ('2025-02-10 00:00:00'),
    partition dt_20250210 values less than ('2025-02-11 00:00:00'),
    partition dt_20250211 values less than ('2025-02-12 00:00:00'),
    partition dt_20250212 values less than ('2025-02-13 00:00:00'),
    partition dt_20250213 values less than ('2025-02-14 00:00:00'),
    partition dt_20250214 values less than ('2025-02-15 00:00:00'),
    partition dt_20250215 values less than ('2025-02-16 00:00:00'),
    partition dt_20250216 values less than ('2025-02-17 00:00:00'),
    partition dt_20250217 values less than ('2025-02-18 00:00:00'),
    partition dt_20250218 values less than ('2025-02-19 00:00:00'),
    partition dt_20250219 values less than ('2025-02-20 00:00:00'),
    partition dt_20250220 values less than ('2025-02-21 00:00:00'),
    partition dt_20250221 values less than ('2025-02-22 00:00:00'),
    partition dt_20250222 values less than ('2025-02-23 00:00:00'),
    partition dt_20250223 values less than ('2025-02-24 00:00:00'),
    partition dt_20250224 values less than ('2025-02-25 00:00:00'),
    partition dt_20250225 values less than ('2025-02-26 00:00:00'),
    partition dt_20250226 values less than ('2025-02-27 00:00:00'),
    partition dt_20250227 values less than ('2025-02-28 00:00:00'),
    partition dt_20250228 values less than ('2025-03-01 00:00:00'),
    partition dt_20250301 values less than ('2025-03-02 00:00:00'),
    partition dt_20250302 values less than ('2025-03-03 00:00:00'),
    partition dt_20250303 values less than ('2025-03-04 00:00:00'),
    partition dt_20250304 values less than ('2025-03-05 00:00:00'),
    partition dt_20250305 values less than ('2025-03-06 00:00:00'),
    partition dt_20250306 values less than ('2025-03-07 00:00:00'),
    partition dt_20250307 values less than ('2025-03-08 00:00:00'),
    partition dt_20250308 values less than ('2025-03-09 00:00:00'),
    partition dt_20250309 values less than ('2025-03-10 00:00:00'),
    partition dt_20250310 values less than ('2025-03-11 00:00:00'),
    partition dt_20250311 values less than ('2025-03-12 00:00:00'),
    partition dt_20250312 values less than ('2025-03-13 00:00:00'),
    partition dt_20250313 values less than ('2025-03-14 00:00:00'),
    partition dt_20250314 values less than ('2025-03-15 00:00:00'),
    partition dt_20250315 values less than ('2025-03-16 00:00:00'),
    partition dt_20250316 values less than ('2025-03-17 00:00:00'),
    partition dt_20250317 values less than ('2025-03-18 00:00:00'),
    partition dt_20250318 values less than ('2025-03-19 00:00:00'),
    partition dt_20250319 values less than ('2025-03-20 00:00:00'),
    partition dt_20250320 values less than ('2025-03-21 00:00:00'),
    partition dt_20250321 values less than ('2025-03-22 00:00:00'),
    partition dt_20250322 values less than ('2025-03-23 00:00:00'),
    partition dt_20250323 values less than ('2025-03-24 00:00:00'),
    partition dt_20250324 values less than ('2025-03-25 00:00:00'),
    partition dt_20250325 values less than ('2025-03-26 00:00:00'),
    partition dt_20250326 values less than ('2025-03-27 00:00:00'),
    partition dt_20250327 values less than ('2025-03-28 00:00:00'),
    partition dt_20250328 values less than ('2025-03-29 00:00:00'),
    partition dt_20250329 values less than ('2025-03-30 00:00:00'),
    partition dt_20250330 values less than ('2025-03-31 00:00:00'),
    partition dt_20250331 values less than ('2025-04-01 00:00:00'),
    partition dt_20250401 values less than ('2025-04-02 00:00:00'),
    partition dt_20250402 values less than ('2025-04-03 00:00:00'),
    partition dt_20250403 values less than ('2025-04-04 00:00:00'),
    partition dt_20250404 values less than ('2025-04-05 00:00:00'),
    partition dt_20250405 values less than ('2025-04-06 00:00:00'),
    partition dt_20250406 values less than ('2025-04-07 00:00:00'),
    partition dt_20250407 values less than ('2025-04-08 00:00:00'),
    partition dt_20250408 values less than ('2025-04-09 00:00:00'),
    partition dt_20250409 values less than ('2025-04-10 00:00:00'),
    partition dt_20250410 values less than ('2025-04-11 00:00:00'),
    partition dt_20250411 values less than ('2025-04-12 00:00:00'),
    partition dt_20250412 values less than ('2025-04-13 00:00:00'),
    partition dt_20250413 values less than ('2025-04-14 00:00:00'),
    partition dt_20250414 values less than ('2025-04-15 00:00:00'),
    partition dt_20250415 values less than ('2025-04-16 00:00:00'),
    partition dt_20250416 values less than ('2025-04-17 00:00:00'),
    partition dt_20250417 values less than ('2025-04-18 00:00:00'),
    partition dt_20250418 values less than ('2025-04-19 00:00:00'),
    partition dt_20250419 values less than ('2025-04-20 00:00:00'),
    partition dt_20250420 values less than ('2025-04-21 00:00:00'),
    partition dt_20250421 values less than ('2025-04-22 00:00:00'),
    partition dt_20250422 values less than ('2025-04-23 00:00:00'),
    partition dt_20250423 values less than ('2025-04-24 00:00:00'),
    partition dt_20250424 values less than ('2025-04-25 00:00:00'),
    partition dt_20250425 values less than ('2025-04-26 00:00:00'),
    partition dt_20250426 values less than ('2025-04-27 00:00:00'),
    partition dt_20250427 values less than ('2025-04-28 00:00:00'),
    partition dt_20250428 values less than ('2025-04-29 00:00:00'),
    partition dt_20250429 values less than ('2025-04-30 00:00:00'),
    partition dt_20250430 values less than ('2025-05-01 00:00:00'),
    partition dt_20250501 values less than ('2025-05-02 00:00:00'),
    partition dt_20250502 values less than ('2025-05-03 00:00:00'),
    partition dt_20250503 values less than ('2025-05-04 00:00:00'),
    partition dt_20250504 values less than ('2025-05-05 00:00:00'),
    partition dt_20250505 values less than ('2025-05-06 00:00:00'),
    partition dt_20250506 values less than ('2025-05-07 00:00:00'),
    partition dt_20250507 values less than ('2025-05-08 00:00:00'),
    partition dt_20250508 values less than ('2025-05-09 00:00:00'),
    partition dt_20250509 values less than ('2025-05-10 00:00:00'),
    partition dt_20250510 values less than ('2025-05-11 00:00:00'),
    partition dt_20250511 values less than ('2025-05-12 00:00:00'),
    partition dt_20250512 values less than ('2025-05-13 00:00:00'),
    partition dt_20250513 values less than ('2025-05-14 00:00:00'),
    partition dt_20250514 values less than ('2025-05-15 00:00:00'),
    partition dt_20250515 values less than ('2025-05-16 00:00:00'),
    partition dt_20250516 values less than ('2025-05-17 00:00:00'),
    partition dt_20250517 values less than ('2025-05-18 00:00:00'),
    partition dt_20250518 values less than ('2025-05-19 00:00:00'),
    partition dt_20250519 values less than ('2025-05-20 00:00:00'),
    partition dt_20250520 values less than ('2025-05-21 00:00:00'),
    partition dt_20250521 values less than ('2025-05-22 00:00:00'),
    partition dt_20250522 values less than ('2025-05-23 00:00:00'),
    partition dt_20250523 values less than ('2025-05-24 00:00:00'),
    partition dt_20250524 values less than ('2025-05-25 00:00:00'),
    partition dt_20250525 values less than ('2025-05-26 00:00:00'),
    partition dt_20250526 values less than ('2025-05-27 00:00:00'),
    partition dt_20250527 values less than ('2025-05-28 00:00:00'),
    partition dt_20250528 values less than ('2025-05-29 00:00:00'),
    partition dt_20250529 values less than ('2025-05-30 00:00:00'),
    partition dt_20250530 values less than ('2025-05-31 00:00:00'),
    partition dt_20250531 values less than ('2025-06-01 00:00:00'),
    partition dt_20250601 values less than ('2025-06-02 00:00:00'),
    partition dt_20250602 values less than ('2025-06-03 00:00:00'),
    partition dt_20250603 values less than ('2025-06-04 00:00:00'),
    partition dt_20250604 values less than ('2025-06-05 00:00:00'),
    partition dt_20250605 values less than ('2025-06-06 00:00:00'),
    partition dt_20250606 values less than ('2025-06-07 00:00:00'),
    partition dt_20250607 values less than ('2025-06-08 00:00:00'),
    partition dt_20250608 values less than ('2025-06-09 00:00:00'),
    partition dt_20250609 values less than ('2025-06-10 00:00:00'),
    partition dt_20250610 values less than ('2025-06-11 00:00:00'),
    partition dt_20250611 values less than ('2025-06-12 00:00:00'),
    partition dt_20250612 values less than ('2025-06-13 00:00:00'),
    partition dt_20250613 values less than ('2025-06-14 00:00:00'),
    partition dt_20250614 values less than ('2025-06-15 00:00:00'),
    partition dt_20250615 values less than ('2025-06-16 00:00:00'),
    partition dt_20250616 values less than ('2025-06-17 00:00:00'),
    partition dt_20250617 values less than ('2025-06-18 00:00:00'),
    partition dt_20250618 values less than ('2025-06-19 00:00:00'),
    partition dt_20250619 values less than ('2025-06-20 00:00:00'),
    partition dt_20250620 values less than ('2025-06-21 00:00:00'),
    partition dt_20250621 values less than ('2025-06-22 00:00:00'),
    partition dt_20250622 values less than ('2025-06-23 00:00:00'),
    partition dt_20250623 values less than ('2025-06-24 00:00:00'),
    partition dt_20250624 values less than ('2025-06-25 00:00:00'),
    partition dt_20250625 values less than ('2025-06-26 00:00:00'),
    partition dt_20250626 values less than ('2025-06-27 00:00:00'),
    partition dt_20250627 values less than ('2025-06-28 00:00:00'),
    partition dt_20250628 values less than ('2025-06-29 00:00:00'),
    partition dt_20250629 values less than ('2025-06-30 00:00:00'),
    partition dt_20250630 values less than ('2025-07-01 00:00:00'),
    partition dt_20250701 values less than ('2025-07-02 00:00:00'),
    partition dt_20250702 values less than ('2025-07-03 00:00:00'),
    partition dt_20250703 values less than ('2025-07-04 00:00:00'),
    partition dt_20250704 values less than ('2025-07-05 00:00:00'),
    partition dt_20250705 values less than ('2025-07-06 00:00:00'),
    partition dt_20250706 values less than ('2025-07-07 00:00:00'),
    partition dt_20250707 values less than ('2025-07-08 00:00:00'),
    partition dt_20250708 values less than ('2025-07-09 00:00:00'),
    partition dt_20250709 values less than ('2025-07-10 00:00:00'),
    partition dt_20250710 values less than ('2025-07-11 00:00:00'),
    partition dt_20250711 values less than ('2025-07-12 00:00:00'),
    partition dt_20250712 values less than ('2025-07-13 00:00:00'),
    partition dt_20250713 values less than ('2025-07-14 00:00:00'),
    partition dt_20250714 values less than ('2025-07-15 00:00:00'),
    partition dt_20250715 values less than ('2025-07-16 00:00:00'),
    partition dt_20250716 values less than ('2025-07-17 00:00:00'),
    partition dt_20250717 values less than ('2025-07-18 00:00:00'),
    partition dt_20250718 values less than ('2025-07-19 00:00:00'),
    partition dt_20250719 values less than ('2025-07-20 00:00:00'),
    partition dt_20250720 values less than ('2025-07-21 00:00:00'),
    partition dt_20250721 values less than ('2025-07-22 00:00:00'),
    partition dt_20250722 values less than ('2025-07-23 00:00:00'),
    partition dt_20250723 values less than ('2025-07-24 00:00:00'),
    partition dt_20250724 values less than ('2025-07-25 00:00:00'),
    partition dt_20250725 values less than ('2025-07-26 00:00:00'),
    partition dt_20250726 values less than ('2025-07-27 00:00:00'),
    partition dt_20250727 values less than ('2025-07-28 00:00:00'),
    partition dt_20250728 values less than ('2025-07-29 00:00:00'),
    partition dt_20250729 values less than ('2025-07-30 00:00:00'),
    partition dt_20250730 values less than ('2025-07-31 00:00:00'),
    partition dt_20250731 values less than ('2025-08-01 00:00:00'),
    partition dt_20250801 values less than ('2025-08-02 00:00:00'),
    partition dt_20250802 values less than ('2025-08-03 00:00:00'),
    partition dt_20250803 values less than ('2025-08-04 00:00:00'),
    partition dt_20250804 values less than ('2025-08-05 00:00:00'),
    partition dt_20250805 values less than ('2025-08-06 00:00:00'),
    partition dt_20250806 values less than ('2025-08-07 00:00:00'),
    partition dt_20250807 values less than ('2025-08-08 00:00:00'),
    partition dt_20250808 values less than ('2025-08-09 00:00:00'),
    partition dt_20250809 values less than ('2025-08-10 00:00:00'),
    partition dt_20250810 values less than ('2025-08-11 00:00:00'),
    partition dt_20250811 values less than ('2025-08-12 00:00:00'),
    partition dt_20250812 values less than ('2025-08-13 00:00:00'),
    partition dt_20250813 values less than ('2025-08-14 00:00:00'),
    partition dt_20250814 values less than ('2025-08-15 00:00:00'),
    partition dt_20250815 values less than ('2025-08-16 00:00:00'),
    partition dt_20250816 values less than ('2025-08-17 00:00:00'),
    partition dt_20250817 values less than ('2025-08-18 00:00:00'),
    partition dt_20250818 values less than ('2025-08-19 00:00:00'),
    partition dt_20250819 values less than ('2025-08-20 00:00:00'),
    partition dt_20250820 values less than ('2025-08-21 00:00:00'),
    partition dt_20250821 values less than ('2025-08-22 00:00:00'),
    partition dt_20250822 values less than ('2025-08-23 00:00:00'),
    partition dt_20250823 values less than ('2025-08-24 00:00:00'),
    partition dt_20250824 values less than ('2025-08-25 00:00:00'),
    partition dt_20250825 values less than ('2025-08-26 00:00:00'),
    partition dt_20250826 values less than ('2025-08-27 00:00:00'),
    partition dt_20250827 values less than ('2025-08-28 00:00:00'),
    partition dt_20250828 values less than ('2025-08-29 00:00:00'),
    partition dt_20250829 values less than ('2025-08-30 00:00:00'),
    partition dt_20250830 values less than ('2025-08-31 00:00:00'),
    partition dt_20250831 values less than ('2025-09-01 00:00:00'),
    partition dt_20250901 values less than ('2025-09-02 00:00:00'),
    partition dt_20250902 values less than ('2025-09-03 00:00:00'),
    partition dt_20250903 values less than ('2025-09-04 00:00:00'),
    partition dt_20250904 values less than ('2025-09-05 00:00:00'),
    partition dt_20250905 values less than ('2025-09-06 00:00:00'),
    partition dt_20250906 values less than ('2025-09-07 00:00:00'),
    partition dt_20250907 values less than ('2025-09-08 00:00:00'),
    partition dt_20250908 values less than ('2025-09-09 00:00:00'),
    partition dt_20250909 values less than ('2025-09-10 00:00:00'),
    partition dt_20250910 values less than ('2025-09-11 00:00:00'),
    partition dt_20250911 values less than ('2025-09-12 00:00:00'),
    partition dt_20250912 values less than ('2025-09-13 00:00:00'),
    partition dt_20250913 values less than ('2025-09-14 00:00:00'),
    partition dt_20250914 values less than ('2025-09-15 00:00:00'),
    partition dt_20250915 values less than ('2025-09-16 00:00:00'),
    partition dt_20250916 values less than ('2025-09-17 00:00:00'),
    partition dt_20250917 values less than ('2025-09-18 00:00:00'),
    partition dt_20250918 values less than ('2025-09-19 00:00:00'),
    partition dt_20250919 values less than ('2025-09-20 00:00:00'),
    partition dt_20250920 values less than ('2025-09-21 00:00:00'),
    partition dt_20250921 values less than ('2025-09-22 00:00:00'),
    partition dt_20250922 values less than ('2025-09-23 00:00:00'),
    partition dt_20250923 values less than ('2025-09-24 00:00:00'),
    partition dt_20250924 values less than ('2025-09-25 00:00:00'),
    partition dt_20250925 values less than ('2025-09-26 00:00:00'),
    partition dt_20250926 values less than ('2025-09-27 00:00:00'),
    partition dt_20250927 values less than ('2025-09-28 00:00:00'),
    partition dt_20250928 values less than ('2025-09-29 00:00:00'),
    partition dt_20250929 values less than ('2025-09-30 00:00:00'),
    partition dt_20250930 values less than ('2025-10-01 00:00:00'),
    partition dt_20251001 values less than ('2025-10-02 00:00:00'),
    partition dt_20251002 values less than ('2025-10-03 00:00:00'),
    partition dt_20251003 values less than ('2025-10-04 00:00:00'),
    partition dt_20251004 values less than ('2025-10-05 00:00:00'),
    partition dt_20251005 values less than ('2025-10-06 00:00:00'),
    partition dt_20251006 values less than ('2025-10-07 00:00:00'),
    partition dt_20251007 values less than ('2025-10-08 00:00:00'),
    partition dt_20251008 values less than ('2025-10-09 00:00:00'),
    partition dt_20251009 values less than ('2025-10-10 00:00:00'),
    partition dt_20251010 values less than ('2025-10-11 00:00:00'),
    partition dt_20251011 values less than ('2025-10-12 00:00:00'),
    partition dt_20251012 values less than ('2025-10-13 00:00:00'),
    partition dt_20251013 values less than ('2025-10-14 00:00:00'),
    partition dt_20251014 values less than ('2025-10-15 00:00:00'),
    partition dt_20251015 values less than ('2025-10-16 00:00:00'),
    partition dt_20251016 values less than ('2025-10-17 00:00:00'),
    partition dt_20251017 values less than ('2025-10-18 00:00:00'),
    partition dt_20251018 values less than ('2025-10-19 00:00:00'),
    partition dt_20251019 values less than ('2025-10-20 00:00:00'),
    partition dt_20251020 values less than ('2025-10-21 00:00:00'),
    partition dt_20251021 values less than ('2025-10-22 00:00:00'),
    partition dt_20251022 values less than ('2025-10-23 00:00:00'),
    partition dt_20251023 values less than ('2025-10-24 00:00:00'),
    partition dt_20251024 values less than ('2025-10-25 00:00:00'),
    partition dt_20251025 values less than ('2025-10-26 00:00:00'),
    partition dt_20251026 values less than ('2025-10-27 00:00:00'),
    partition dt_20251027 values less than ('2025-10-28 00:00:00'),
    partition dt_20251028 values less than ('2025-10-29 00:00:00'),
    partition dt_20251029 values less than ('2025-10-30 00:00:00'),
    partition dt_20251030 values less than ('2025-10-31 00:00:00'),
    partition dt_20251031 values less than ('2025-11-01 00:00:00'),
    partition dt_20251101 values less than ('2025-11-02 00:00:00'),
    partition dt_20251102 values less than ('2025-11-03 00:00:00'),
    partition dt_20251103 values less than ('2025-11-04 00:00:00'),
    partition dt_20251104 values less than ('2025-11-05 00:00:00'),
    partition dt_20251105 values less than ('2025-11-06 00:00:00'),
    partition dt_20251106 values less than ('2025-11-07 00:00:00'),
    partition dt_20251107 values less than ('2025-11-08 00:00:00'),
    partition dt_20251108 values less than ('2025-11-09 00:00:00'),
    partition dt_20251109 values less than ('2025-11-10 00:00:00'),
    partition dt_20251110 values less than ('2025-11-11 00:00:00'),
    partition dt_20251111 values less than ('2025-11-12 00:00:00'),
    partition dt_20251112 values less than ('2025-11-13 00:00:00'),
    partition dt_20251113 values less than ('2025-11-14 00:00:00'),
    partition dt_20251114 values less than ('2025-11-15 00:00:00'),
    partition dt_20251115 values less than ('2025-11-16 00:00:00'),
    partition dt_20251116 values less than ('2025-11-17 00:00:00'),
    partition dt_20251117 values less than ('2025-11-18 00:00:00'),
    partition dt_20251118 values less than ('2025-11-19 00:00:00'),
    partition dt_20251119 values less than ('2025-11-20 00:00:00'),
    partition dt_20251120 values less than ('2025-11-21 00:00:00'),
    partition dt_20251121 values less than ('2025-11-22 00:00:00'),
    partition dt_20251122 values less than ('2025-11-23 00:00:00'),
    partition dt_20251123 values less than ('2025-11-24 00:00:00'),
    partition dt_20251124 values less than ('2025-11-25 00:00:00'),
    partition dt_20251125 values less than ('2025-11-26 00:00:00'),
    partition dt_20251126 values less than ('2025-11-27 00:00:00'),
    partition dt_20251127 values less than ('2025-11-28 00:00:00'),
    partition dt_20251128 values less than ('2025-11-29 00:00:00'),
    partition dt_20251129 values less than ('2025-11-30 00:00:00'),
    partition dt_20251130 values less than ('2025-12-01 00:00:00'),
    partition dt_20251201 values less than ('2025-12-02 00:00:00'),
    partition dt_20251202 values less than ('2025-12-03 00:00:00'),
    partition dt_20251203 values less than ('2025-12-04 00:00:00'),
    partition dt_20251204 values less than ('2025-12-05 00:00:00'),
    partition dt_20251205 values less than ('2025-12-06 00:00:00'),
    partition dt_20251206 values less than ('2025-12-07 00:00:00'),
    partition dt_20251207 values less than ('2025-12-08 00:00:00'),
    partition dt_20251208 values less than ('2025-12-09 00:00:00'),
    partition dt_20251209 values less than ('2025-12-10 00:00:00'),
    partition dt_20251210 values less than ('2025-12-11 00:00:00'),
    partition dt_20251211 values less than ('2025-12-12 00:00:00'),
    partition dt_20251212 values less than ('2025-12-13 00:00:00'),
    partition dt_20251213 values less than ('2025-12-14 00:00:00'),
    partition dt_20251214 values less than ('2025-12-15 00:00:00'),
    partition dt_20251215 values less than ('2025-12-16 00:00:00'),
    partition dt_20251216 values less than ('2025-12-17 00:00:00'),
    partition dt_20251217 values less than ('2025-12-18 00:00:00'),
    partition dt_20251218 values less than ('2025-12-19 00:00:00'),
    partition dt_20251219 values less than ('2025-12-20 00:00:00'),
    partition dt_20251220 values less than ('2025-12-21 00:00:00'),
    partition dt_20251221 values less than ('2025-12-22 00:00:00'),
    partition dt_20251222 values less than ('2025-12-23 00:00:00'),
    partition dt_20251223 values less than ('2025-12-24 00:00:00'),
    partition dt_20251224 values less than ('2025-12-25 00:00:00'),
    partition dt_20251225 values less than ('2025-12-26 00:00:00'),
    partition dt_20251226 values less than ('2025-12-27 00:00:00'),
    partition dt_20251227 values less than ('2025-12-28 00:00:00'),
    partition dt_20251228 values less than ('2025-12-29 00:00:00'),
    partition dt_20251229 values less than ('2025-12-30 00:00:00'),
    partition dt_20251230 values less than ('2025-12-31 00:00:00'),
    partition dt_20251231 values less than ('2026-01-01 00:00:00'),
    partition dt_20260101 values less than ('2026-01-02 00:00:00'),
    partition dt_20260102 values less than ('2026-01-03 00:00:00'),
    partition dt_20260103 values less than ('2026-01-04 00:00:00'),
    partition dt_20260104 values less than ('2026-01-05 00:00:00'),
    partition dt_20260105 values less than ('2026-01-06 00:00:00'),
    partition dt_20260106 values less than ('2026-01-07 00:00:00'),
    partition dt_20260107 values less than ('2026-01-08 00:00:00'),
    partition dt_20260108 values less than ('2026-01-09 00:00:00'),
    partition dt_20260109 values less than ('2026-01-10 00:00:00'),
    partition dt_20260110 values less than ('2026-01-11 00:00:00'),
    partition dt_20260111 values less than ('2026-01-12 00:00:00'),
    partition dt_20260112 values less than ('2026-01-13 00:00:00'),
    partition dt_20260113 values less than ('2026-01-14 00:00:00'),
    partition dt_20260114 values less than ('2026-01-15 00:00:00'),
    partition dt_20260115 values less than ('2026-01-16 00:00:00'),
    partition dt_20260116 values less than ('2026-01-17 00:00:00'),
    partition dt_20260117 values less than ('2026-01-18 00:00:00'),
    partition dt_20260118 values less than ('2026-01-19 00:00:00'),
    partition dt_20260119 values less than ('2026-01-20 00:00:00'),
    partition dt_20260120 values less than ('2026-01-21 00:00:00'),
    partition dt_20260121 values less than ('2026-01-22 00:00:00'),
    partition dt_20260122 values less than ('2026-01-23 00:00:00'),
    partition dt_20260123 values less than ('2026-01-24 00:00:00'),
    partition dt_20260124 values less than ('2026-01-25 00:00:00'),
    partition dt_20260125 values less than ('2026-01-26 00:00:00'),
    partition dt_20260126 values less than ('2026-01-27 00:00:00'),
    partition dt_20260127 values less than ('2026-01-28 00:00:00'),
    partition dt_20260128 values less than ('2026-01-29 00:00:00'),
    partition dt_20260129 values less than ('2026-01-30 00:00:00'),
    partition dt_20260130 values less than ('2026-01-31 00:00:00'),
    partition dt_20260131 values less than ('2026-02-01 00:00:00'),
    partition dt_20260201 values less than ('2026-02-02 00:00:00'),
    partition dt_20260202 values less than ('2026-02-03 00:00:00'),
    partition dt_20260203 values less than ('2026-02-04 00:00:00'),
    partition dt_20260204 values less than ('2026-02-05 00:00:00'),
    partition dt_20260205 values less than ('2026-02-06 00:00:00'),
    partition dt_20260206 values less than ('2026-02-07 00:00:00'),
    partition dt_20260207 values less than ('2026-02-08 00:00:00'),
    partition dt_20260208 values less than ('2026-02-09 00:00:00'),
    partition dt_20260209 values less than ('2026-02-10 00:00:00'),
    partition dt_20260210 values less than ('2026-02-11 00:00:00'),
    partition dt_20260211 values less than ('2026-02-12 00:00:00'),
    partition dt_20260212 values less than ('2026-02-13 00:00:00'),
    partition dt_20260213 values less than ('2026-02-14 00:00:00'),
    partition dt_20260214 values less than ('2026-02-15 00:00:00'),
    partition dt_20260215 values less than ('2026-02-16 00:00:00'),
    partition dt_20260216 values less than ('2026-02-17 00:00:00'),
    partition dt_20260217 values less than ('2026-02-18 00:00:00'),
    partition dt_20260218 values less than ('2026-02-19 00:00:00'),
    partition dt_20260219 values less than ('2026-02-20 00:00:00'),
    partition dt_20260220 values less than ('2026-02-21 00:00:00'),
    partition dt_20260221 values less than ('2026-02-22 00:00:00'),
    partition dt_20260222 values less than ('2026-02-23 00:00:00'),
    partition dt_20260223 values less than ('2026-02-24 00:00:00'),
    partition dt_20260224 values less than ('2026-02-25 00:00:00'),
    partition dt_20260225 values less than ('2026-02-26 00:00:00'),
    partition dt_20260226 values less than ('2026-02-27 00:00:00'),
    partition dt_20260227 values less than ('2026-02-28 00:00:00'),
    partition dt_20260228 values less than ('2026-03-01 00:00:00'),
    partition dt_20260301 values less than ('2026-03-02 00:00:00'),
    partition dt_20260302 values less than ('2026-03-03 00:00:00'),
    partition dt_20260303 values less than ('2026-03-04 00:00:00'),
    partition dt_20260304 values less than ('2026-03-05 00:00:00'),
    partition dt_20260305 values less than ('2026-03-06 00:00:00'),
    partition dt_20260306 values less than ('2026-03-07 00:00:00'),
    partition dt_20260307 values less than ('2026-03-08 00:00:00'),
    partition dt_20260308 values less than ('2026-03-09 00:00:00'),
    partition dt_20260309 values less than ('2026-03-10 00:00:00'),
    partition dt_20260310 values less than ('2026-03-11 00:00:00'),
    partition dt_20260311 values less than ('2026-03-12 00:00:00'),
    partition dt_20260312 values less than ('2026-03-13 00:00:00'),
    partition dt_20260313 values less than ('2026-03-14 00:00:00'),
    partition dt_20260314 values less than ('2026-03-15 00:00:00'),
    partition dt_20260315 values less than ('2026-03-16 00:00:00'),
    partition dt_20260316 values less than ('2026-03-17 00:00:00'),
    partition dt_20260317 values less than ('2026-03-18 00:00:00'),
    partition dt_20260318 values less than ('2026-03-19 00:00:00'),
    partition dt_20260319 values less than ('2026-03-20 00:00:00'),
    partition dt_20260320 values less than ('2026-03-21 00:00:00'),
    partition dt_20260321 values less than ('2026-03-22 00:00:00'),
    partition dt_20260322 values less than ('2026-03-23 00:00:00'),
    partition dt_20260323 values less than ('2026-03-24 00:00:00'),
    partition dt_20260324 values less than ('2026-03-25 00:00:00'),
    partition dt_20260325 values less than ('2026-03-26 00:00:00'),
    partition dt_20260326 values less than ('2026-03-27 00:00:00'),
    partition dt_20260327 values less than ('2026-03-28 00:00:00'),
    partition dt_20260328 values less than ('2026-03-29 00:00:00'),
    partition dt_20260329 values less than ('2026-03-30 00:00:00'),
    partition dt_20260330 values less than ('2026-03-31 00:00:00'),
    partition dt_20260331 values less than ('2026-04-01 00:00:00'),
    partition dt_20260401 values less than ('2026-04-02 00:00:00'),
    partition dt_20260402 values less than ('2026-04-03 00:00:00'),
    partition dt_20260403 values less than ('2026-04-04 00:00:00'),
    partition dt_20260404 values less than ('2026-04-05 00:00:00'),
    partition dt_20260405 values less than ('2026-04-06 00:00:00'),
    partition dt_20260406 values less than ('2026-04-07 00:00:00'),
    partition dt_20260407 values less than ('2026-04-08 00:00:00'),
    partition dt_20260408 values less than ('2026-04-09 00:00:00'),
    partition dt_20260409 values less than ('2026-04-10 00:00:00'),
    partition dt_20260410 values less than ('2026-04-11 00:00:00'),
    partition dt_20260411 values less than ('2026-04-12 00:00:00'),
    partition dt_20260412 values less than ('2026-04-13 00:00:00'),
    partition dt_20260413 values less than ('2026-04-14 00:00:00'),
    partition dt_20260414 values less than ('2026-04-15 00:00:00'),
    partition dt_20260415 values less than ('2026-04-16 00:00:00'),
    partition dt_20260416 values less than ('2026-04-17 00:00:00'),
    partition dt_20260417 values less than ('2026-04-18 00:00:00'),
    partition dt_20260418 values less than ('2026-04-19 00:00:00'),
    partition dt_20260419 values less than ('2026-04-20 00:00:00'),
    partition dt_20260420 values less than ('2026-04-21 00:00:00'),
    partition dt_20260421 values less than ('2026-04-22 00:00:00'),
    partition dt_20260422 values less than ('2026-04-23 00:00:00'),
    partition dt_20260423 values less than ('2026-04-24 00:00:00'),
    partition dt_20260424 values less than ('2026-04-25 00:00:00'),
    partition dt_20260425 values less than ('2026-04-26 00:00:00'),
    partition dt_20260426 values less than ('2026-04-27 00:00:00'),
    partition dt_20260427 values less than ('2026-04-28 00:00:00'),
    partition dt_20260428 values less than ('2026-04-29 00:00:00'),
    partition dt_20260429 values less than ('2026-04-30 00:00:00'),
    partition dt_20260430 values less than ('2026-05-01 00:00:00'),
    partition dt_20260501 values less than ('2026-05-02 00:00:00'),
    partition dt_20260502 values less than ('2026-05-03 00:00:00'),
    partition dt_20260503 values less than ('2026-05-04 00:00:00'),
    partition dt_20260504 values less than ('2026-05-05 00:00:00'),
    partition dt_20260505 values less than ('2026-05-06 00:00:00'),
    partition dt_20260506 values less than ('2026-05-07 00:00:00'),
    partition dt_20260507 values less than ('2026-05-08 00:00:00'),
    partition dt_20260508 values less than ('2026-05-09 00:00:00'),
    partition dt_20260509 values less than ('2026-05-10 00:00:00'),
    partition dt_20260510 values less than ('2026-05-11 00:00:00'),
    partition dt_20260511 values less than ('2026-05-12 00:00:00'),
    partition dt_20260512 values less than ('2026-05-13 00:00:00'),
    partition dt_20260513 values less than ('2026-05-14 00:00:00'),
    partition dt_20260514 values less than ('2026-05-15 00:00:00'),
    partition dt_20260515 values less than ('2026-05-16 00:00:00'),
    partition dt_20260516 values less than ('2026-05-17 00:00:00'),
    partition dt_20260517 values less than ('2026-05-18 00:00:00'),
    partition dt_20260518 values less than ('2026-05-19 00:00:00'),
    partition dt_20260519 values less than ('2026-05-20 00:00:00'),
    partition dt_20260520 values less than ('2026-05-21 00:00:00'),
    partition dt_20260521 values less than ('2026-05-22 00:00:00'),
    partition dt_20260522 values less than ('2026-05-23 00:00:00'),
    partition dt_20260523 values less than ('2026-05-24 00:00:00'),
    partition dt_20260524 values less than ('2026-05-25 00:00:00'),
    partition dt_20260525 values less than ('2026-05-26 00:00:00'),
    partition dt_20260526 values less than ('2026-05-27 00:00:00'),
    partition dt_20260527 values less than ('2026-05-28 00:00:00'),
    partition dt_20260528 values less than ('2026-05-29 00:00:00'),
    partition dt_20260529 values less than ('2026-05-30 00:00:00'),
    partition dt_20260530 values less than ('2026-05-31 00:00:00'),
    partition dt_20260531 values less than ('2026-06-01 00:00:00'),
    partition dt_20260601 values less than ('2026-06-02 00:00:00'),
    partition dt_20260602 values less than ('2026-06-03 00:00:00'),
    partition dt_20260603 values less than ('2026-06-04 00:00:00'),
    partition dt_20260604 values less than ('2026-06-05 00:00:00'),
    partition dt_20260605 values less than ('2026-06-06 00:00:00'),
    partition dt_20260606 values less than ('2026-06-07 00:00:00'),
    partition dt_20260607 values less than ('2026-06-08 00:00:00'),
    partition dt_20260608 values less than ('2026-06-09 00:00:00'),
    partition dt_20260609 values less than ('2026-06-10 00:00:00'),
    partition dt_20260610 values less than ('2026-06-11 00:00:00'),
    partition dt_20260611 values less than ('2026-06-12 00:00:00'),
    partition dt_20260612 values less than ('2026-06-13 00:00:00'),
    partition dt_20260613 values less than ('2026-06-14 00:00:00'),
    partition dt_20260614 values less than ('2026-06-15 00:00:00'),
    partition dt_20260615 values less than ('2026-06-16 00:00:00'),
    partition dt_20260616 values less than ('2026-06-17 00:00:00'),
    partition dt_20260617 values less than ('2026-06-18 00:00:00'),
    partition dt_20260618 values less than ('2026-06-19 00:00:00'),
    partition dt_20260619 values less than ('2026-06-20 00:00:00'),
    partition dt_20260620 values less than ('2026-06-21 00:00:00'),
    partition dt_20260621 values less than ('2026-06-22 00:00:00'),
    partition dt_20260622 values less than ('2026-06-23 00:00:00'),
    partition dt_20260623 values less than ('2026-06-24 00:00:00'),
    partition dt_20260624 values less than ('2026-06-25 00:00:00'),
    partition dt_20260625 values less than ('2026-06-26 00:00:00'),
    partition dt_20260626 values less than ('2026-06-27 00:00:00'),
    partition dt_20260627 values less than ('2026-06-28 00:00:00'),
    partition dt_20260628 values less than ('2026-06-29 00:00:00'),
    partition dt_20260629 values less than ('2026-06-30 00:00:00'),
    partition dt_20260630 values less than ('2026-07-01 00:00:00'),
    partition dt_20260701 values less than ('2026-07-02 00:00:00'),
    partition dt_20260702 values less than ('2026-07-03 00:00:00'),
    partition dt_20260703 values less than ('2026-07-04 00:00:00'),
    partition dt_20260704 values less than ('2026-07-05 00:00:00'),
    partition dt_20260705 values less than ('2026-07-06 00:00:00'),
    partition dt_20260706 values less than ('2026-07-07 00:00:00'),
    partition dt_20260707 values less than ('2026-07-08 00:00:00'),
    partition dt_20260708 values less than ('2026-07-09 00:00:00'),
    partition dt_20260709 values less than ('2026-07-10 00:00:00'),
    partition dt_20260710 values less than ('2026-07-11 00:00:00'),
    partition dt_20260711 values less than ('2026-07-12 00:00:00'),
    partition dt_20260712 values less than ('2026-07-13 00:00:00'),
    partition dt_20260713 values less than ('2026-07-14 00:00:00'),
    partition dt_20260714 values less than ('2026-07-15 00:00:00'),
    partition dt_20260715 values less than ('2026-07-16 00:00:00'),
    partition dt_20260716 values less than ('2026-07-17 00:00:00'),
    partition dt_20260717 values less than ('2026-07-18 00:00:00'),
    partition dt_20260718 values less than ('2026-07-19 00:00:00'),
    partition dt_20260719 values less than ('2026-07-20 00:00:00'),
    partition dt_20260720 values less than ('2026-07-21 00:00:00'),
    partition dt_20260721 values less than ('2026-07-22 00:00:00'),
    partition dt_20260722 values less than ('2026-07-23 00:00:00'),
    partition dt_20260723 values less than ('2026-07-24 00:00:00'),
    partition dt_20260724 values less than ('2026-07-25 00:00:00'),
    partition dt_20260725 values less than ('2026-07-26 00:00:00'),
    partition dt_20260726 values less than ('2026-07-27 00:00:00'),
    partition dt_20260727 values less than ('2026-07-28 00:00:00'),
    partition dt_20260728 values less than ('2026-07-29 00:00:00'),
    partition dt_20260729 values less than ('2026-07-30 00:00:00'),
    partition dt_20260730 values less than ('2026-07-31 00:00:00'),
    partition dt_20260731 values less than ('2026-08-01 00:00:00'),
    partition dt_20260801 values less than ('2026-08-02 00:00:00'),
    partition dt_20260802 values less than ('2026-08-03 00:00:00'),
    partition dt_20260803 values less than ('2026-08-04 00:00:00'),
    partition dt_20260804 values less than ('2026-08-05 00:00:00'),
    partition dt_20260805 values less than ('2026-08-06 00:00:00'),
    partition dt_20260806 values less than ('2026-08-07 00:00:00'),
    partition dt_20260807 values less than ('2026-08-08 00:00:00'),
    partition dt_20260808 values less than ('2026-08-09 00:00:00'),
    partition dt_20260809 values less than ('2026-08-10 00:00:00'),
    partition dt_20260810 values less than ('2026-08-11 00:00:00'),
    partition dt_20260811 values less than ('2026-08-12 00:00:00'),
    partition dt_20260812 values less than ('2026-08-13 00:00:00'),
    partition dt_20260813 values less than ('2026-08-14 00:00:00'),
    partition dt_20260814 values less than ('2026-08-15 00:00:00'),
    partition dt_20260815 values less than ('2026-08-16 00:00:00'),
    partition dt_20260816 values less than ('2026-08-17 00:00:00'),
    partition dt_20260817 values less than ('2026-08-18 00:00:00'),
    partition dt_20260818 values less than ('2026-08-19 00:00:00'),
    partition dt_20260819 values less than ('2026-08-20 00:00:00'),
    partition dt_20260820 values less than ('2026-08-21 00:00:00'),
    partition dt_20260821 values less than ('2026-08-22 00:00:00'),
    partition dt_20260822 values less than ('2026-08-23 00:00:00'),
    partition dt_20260823 values less than ('2026-08-24 00:00:00'),
    partition dt_20260824 values less than ('2026-08-25 00:00:00'),
    partition dt_20260825 values less than ('2026-08-26 00:00:00'),
    partition dt_20260826 values less than ('2026-08-27 00:00:00'),
    partition dt_20260827 values less than ('2026-08-28 00:00:00'),
    partition dt_20260828 values less than ('2026-08-29 00:00:00'),
    partition dt_20260829 values less than ('2026-08-30 00:00:00'),
    partition dt_20260830 values less than ('2026-08-31 00:00:00'),
    partition dt_20260831 values less than ('2026-09-01 00:00:00'),
    partition dt_20260901 values less than ('2026-09-02 00:00:00'),
    partition dt_20260902 values less than ('2026-09-03 00:00:00'),
    partition dt_20260903 values less than ('2026-09-04 00:00:00'),
    partition dt_20260904 values less than ('2026-09-05 00:00:00'),
    partition dt_20260905 values less than ('2026-09-06 00:00:00'),
    partition dt_20260906 values less than ('2026-09-07 00:00:00'),
    partition dt_20260907 values less than ('2026-09-08 00:00:00'),
    partition dt_20260908 values less than ('2026-09-09 00:00:00'),
    partition dt_20260909 values less than ('2026-09-10 00:00:00'),
    partition dt_20260910 values less than ('2026-09-11 00:00:00'),
    partition dt_20260911 values less than ('2026-09-12 00:00:00'),
    partition dt_20260912 values less than ('2026-09-13 00:00:00'),
    partition dt_20260913 values less than ('2026-09-14 00:00:00'),
    partition dt_20260914 values less than ('2026-09-15 00:00:00'),
    partition dt_20260915 values less than ('2026-09-16 00:00:00'),
    partition dt_20260916 values less than ('2026-09-17 00:00:00'),
    partition dt_20260917 values less than ('2026-09-18 00:00:00'),
    partition dt_20260918 values less than ('2026-09-19 00:00:00'),
    partition dt_20260919 values less than ('2026-09-20 00:00:00'),
    partition dt_20260920 values less than ('2026-09-21 00:00:00'),
    partition dt_20260921 values less than ('2026-09-22 00:00:00'),
    partition dt_20260922 values less than ('2026-09-23 00:00:00'),
    partition dt_20260923 values less than ('2026-09-24 00:00:00'),
    partition dt_20260924 values less than ('2026-09-25 00:00:00'),
    partition dt_20260925 values less than ('2026-09-26 00:00:00'),
    partition dt_20260926 values less than ('2026-09-27 00:00:00'),
    partition dt_20260927 values less than ('2026-09-28 00:00:00'),
    partition dt_20260928 values less than ('2026-09-29 00:00:00'),
    partition dt_20260929 values less than ('2026-09-30 00:00:00'),
    partition dt_20260930 values less than ('2026-10-01 00:00:00'),
    partition dt_20261001 values less than ('2026-10-02 00:00:00'),
    partition dt_20261002 values less than ('2026-10-03 00:00:00'),
    partition dt_20261003 values less than ('2026-10-04 00:00:00'),
    partition dt_20261004 values less than ('2026-10-05 00:00:00'),
    partition dt_20261005 values less than ('2026-10-06 00:00:00'),
    partition dt_20261006 values less than ('2026-10-07 00:00:00'),
    partition dt_20261007 values less than ('2026-10-08 00:00:00'),
    partition dt_20261008 values less than ('2026-10-09 00:00:00'),
    partition dt_20261009 values less than ('2026-10-10 00:00:00'),
    partition dt_20261010 values less than ('2026-10-11 00:00:00'),
    partition dt_20261011 values less than ('2026-10-12 00:00:00'),
    partition dt_20261012 values less than ('2026-10-13 00:00:00'),
    partition dt_20261013 values less than ('2026-10-14 00:00:00'),
    partition dt_20261014 values less than ('2026-10-15 00:00:00'),
    partition dt_20261015 values less than ('2026-10-16 00:00:00'),
    partition dt_20261016 values less than ('2026-10-17 00:00:00'),
    partition dt_20261017 values less than ('2026-10-18 00:00:00'),
    partition dt_20261018 values less than ('2026-10-19 00:00:00'),
    partition dt_20261019 values less than ('2026-10-20 00:00:00'),
    partition dt_20261020 values less than ('2026-10-21 00:00:00'),
    partition dt_20261021 values less than ('2026-10-22 00:00:00'),
    partition dt_20261022 values less than ('2026-10-23 00:00:00'),
    partition dt_20261023 values less than ('2026-10-24 00:00:00'),
    partition dt_20261024 values less than ('2026-10-25 00:00:00'),
    partition dt_20261025 values less than ('2026-10-26 00:00:00'),
    partition dt_20261026 values less than ('2026-10-27 00:00:00'),
    partition dt_20261027 values less than ('2026-10-28 00:00:00'),
    partition dt_20261028 values less than ('2026-10-29 00:00:00'),
    partition dt_20261029 values less than ('2026-10-30 00:00:00'),
    partition dt_20261030 values less than ('2026-10-31 00:00:00'),
    partition dt_20261031 values less than ('2026-11-01 00:00:00'),
    partition dt_20261101 values less than ('2026-11-02 00:00:00'),
    partition dt_20261102 values less than ('2026-11-03 00:00:00'),
    partition dt_20261103 values less than ('2026-11-04 00:00:00'),
    partition dt_20261104 values less than ('2026-11-05 00:00:00'),
    partition dt_20261105 values less than ('2026-11-06 00:00:00'),
    partition dt_20261106 values less than ('2026-11-07 00:00:00'),
    partition dt_20261107 values less than ('2026-11-08 00:00:00'),
    partition dt_20261108 values less than ('2026-11-09 00:00:00'),
    partition dt_20261109 values less than ('2026-11-10 00:00:00'),
    partition dt_20261110 values less than ('2026-11-11 00:00:00'),
    partition dt_20261111 values less than ('2026-11-12 00:00:00'),
    partition dt_20261112 values less than ('2026-11-13 00:00:00'),
    partition dt_20261113 values less than ('2026-11-14 00:00:00'),
    partition dt_20261114 values less than ('2026-11-15 00:00:00'),
    partition dt_20261115 values less than ('2026-11-16 00:00:00'),
    partition dt_20261116 values less than ('2026-11-17 00:00:00'),
    partition dt_20261117 values less than ('2026-11-18 00:00:00'),
    partition dt_20261118 values less than ('2026-11-19 00:00:00'),
    partition dt_20261119 values less than ('2026-11-20 00:00:00'),
    partition dt_20261120 values less than ('2026-11-21 00:00:00'),
    partition dt_20261121 values less than ('2026-11-22 00:00:00'),
    partition dt_20261122 values less than ('2026-11-23 00:00:00'),
    partition dt_20261123 values less than ('2026-11-24 00:00:00'),
    partition dt_20261124 values less than ('2026-11-25 00:00:00'),
    partition dt_20261125 values less than ('2026-11-26 00:00:00'),
    partition dt_20261126 values less than ('2026-11-27 00:00:00'),
    partition dt_20261127 values less than ('2026-11-28 00:00:00'),
    partition dt_20261128 values less than ('2026-11-29 00:00:00'),
    partition dt_20261129 values less than ('2026-11-30 00:00:00'),
    partition dt_20261130 values less than ('2026-12-01 00:00:00'),
    partition dt_20261201 values less than ('2026-12-02 00:00:00'),
    partition dt_20261202 values less than ('2026-12-03 00:00:00'),
    partition dt_20261203 values less than ('2026-12-04 00:00:00'),
    partition dt_20261204 values less than ('2026-12-05 00:00:00'),
    partition dt_20261205 values less than ('2026-12-06 00:00:00'),
    partition dt_20261206 values less than ('2026-12-07 00:00:00'),
    partition dt_20261207 values less than ('2026-12-08 00:00:00'),
    partition dt_20261208 values less than ('2026-12-09 00:00:00'),
    partition dt_20261209 values less than ('2026-12-10 00:00:00'),
    partition dt_20261210 values less than ('2026-12-11 00:00:00'),
    partition dt_20261211 values less than ('2026-12-12 00:00:00'),
    partition dt_20261212 values less than ('2026-12-13 00:00:00'),
    partition dt_20261213 values less than ('2026-12-14 00:00:00'),
    partition dt_20261214 values less than ('2026-12-15 00:00:00'),
    partition dt_20261215 values less than ('2026-12-16 00:00:00'),
    partition dt_20261216 values less than ('2026-12-17 00:00:00'),
    partition dt_20261217 values less than ('2026-12-18 00:00:00'),
    partition dt_20261218 values less than ('2026-12-19 00:00:00'),
    partition dt_20261219 values less than ('2026-12-20 00:00:00'),
    partition dt_20261220 values less than ('2026-12-21 00:00:00'),
    partition dt_20261221 values less than ('2026-12-22 00:00:00'),
    partition dt_20261222 values less than ('2026-12-23 00:00:00'),
    partition dt_20261223 values less than ('2026-12-24 00:00:00'),
    partition dt_20261224 values less than ('2026-12-25 00:00:00'),
    partition dt_20261225 values less than ('2026-12-26 00:00:00'),
    partition dt_20261226 values less than ('2026-12-27 00:00:00'),
    partition dt_20261227 values less than ('2026-12-28 00:00:00'),
    partition dt_20261228 values less than ('2026-12-29 00:00:00'),
    partition dt_20261229 values less than ('2026-12-30 00:00:00'),
    partition dt_20261230 values less than ('2026-12-31 00:00:00'),
    partition dt_20261231 values less than ('2027-01-01 00:00:00'),
    partition dt_20270101 values less than ('2027-01-02 00:00:00'),
    partition dt_20270102 values less than ('2027-01-03 00:00:00'),
    partition dt_20270103 values less than ('2027-01-04 00:00:00'),
    partition dt_20270104 values less than ('2027-01-05 00:00:00'),
    partition dt_20270105 values less than ('2027-01-06 00:00:00'),
    partition dt_20270106 values less than ('2027-01-07 00:00:00'),
    partition dt_20270107 values less than ('2027-01-08 00:00:00'),
    partition dt_20270108 values less than ('2027-01-09 00:00:00'),
    partition dt_20270109 values less than ('2027-01-10 00:00:00'),
    partition dt_20270110 values less than ('2027-01-11 00:00:00'),
    partition dt_20270111 values less than ('2027-01-12 00:00:00'),
    partition dt_20270112 values less than ('2027-01-13 00:00:00'),
    partition dt_20270113 values less than ('2027-01-14 00:00:00'),
    partition dt_20270114 values less than ('2027-01-15 00:00:00'),
    partition dt_20270115 values less than ('2027-01-16 00:00:00'),
    partition dt_20270116 values less than ('2027-01-17 00:00:00'),
    partition dt_20270117 values less than ('2027-01-18 00:00:00'),
    partition dt_20270118 values less than ('2027-01-19 00:00:00'),
    partition dt_20270119 values less than ('2027-01-20 00:00:00'),
    partition dt_20270120 values less than ('2027-01-21 00:00:00'),
    partition dt_20270121 values less than ('2027-01-22 00:00:00'),
    partition dt_20270122 values less than ('2027-01-23 00:00:00'),
    partition dt_20270123 values less than ('2027-01-24 00:00:00'),
    partition dt_20270124 values less than ('2027-01-25 00:00:00'),
    partition dt_20270125 values less than ('2027-01-26 00:00:00'),
    partition dt_20270126 values less than ('2027-01-27 00:00:00'),
    partition dt_20270127 values less than ('2027-01-28 00:00:00'),
    partition dt_20270128 values less than ('2027-01-29 00:00:00'),
    partition dt_20270129 values less than ('2027-01-30 00:00:00'),
    partition dt_20270130 values less than ('2027-01-31 00:00:00'),
    partition dt_20270131 values less than ('2027-02-01 00:00:00'),
    partition dt_20270201 values less than ('2027-02-02 00:00:00'),
    partition dt_20270202 values less than ('2027-02-03 00:00:00'),
    partition dt_20270203 values less than ('2027-02-04 00:00:00'),
    partition dt_20270204 values less than ('2027-02-05 00:00:00'),
    partition dt_20270205 values less than ('2027-02-06 00:00:00'),
    partition dt_20270206 values less than ('2027-02-07 00:00:00'),
    partition dt_20270207 values less than ('2027-02-08 00:00:00'),
    partition dt_20270208 values less than ('2027-02-09 00:00:00'),
    partition dt_20270209 values less than ('2027-02-10 00:00:00'),
    partition dt_20270210 values less than ('2027-02-11 00:00:00'),
    partition dt_20270211 values less than ('2027-02-12 00:00:00'),
    partition dt_20270212 values less than ('2027-02-13 00:00:00'),
    partition dt_20270213 values less than ('2027-02-14 00:00:00'),
    partition dt_20270214 values less than ('2027-02-15 00:00:00'),
    partition dt_20270215 values less than ('2027-02-16 00:00:00'),
    partition dt_20270216 values less than ('2027-02-17 00:00:00'),
    partition dt_20270217 values less than ('2027-02-18 00:00:00'),
    partition dt_20270218 values less than ('2027-02-19 00:00:00'),
    partition dt_20270219 values less than ('2027-02-20 00:00:00'),
    partition dt_20270220 values less than ('2027-02-21 00:00:00'),
    partition dt_20270221 values less than ('2027-02-22 00:00:00'),
    partition dt_20270222 values less than ('2027-02-23 00:00:00'),
    partition dt_20270223 values less than ('2027-02-24 00:00:00'),
    partition dt_20270224 values less than ('2027-02-25 00:00:00'),
    partition dt_20270225 values less than ('2027-02-26 00:00:00'),
    partition dt_20270226 values less than ('2027-02-27 00:00:00'),
    partition dt_20270227 values less than ('2027-02-28 00:00:00'),
    partition dt_20270228 values less than ('2027-03-01 00:00:00'),
    partition dt_20270301 values less than ('2027-03-02 00:00:00'),
    partition dt_20270302 values less than ('2027-03-03 00:00:00'),
    partition dt_20270303 values less than ('2027-03-04 00:00:00'),
    partition dt_20270304 values less than ('2027-03-05 00:00:00'),
    partition dt_20270305 values less than ('2027-03-06 00:00:00'),
    partition dt_20270306 values less than ('2027-03-07 00:00:00'),
    partition dt_20270307 values less than ('2027-03-08 00:00:00'),
    partition dt_20270308 values less than ('2027-03-09 00:00:00'),
    partition dt_20270309 values less than ('2027-03-10 00:00:00'),
    partition dt_20270310 values less than ('2027-03-11 00:00:00'),
    partition dt_20270311 values less than ('2027-03-12 00:00:00'),
    partition dt_20270312 values less than ('2027-03-13 00:00:00'),
    partition dt_20270313 values less than ('2027-03-14 00:00:00'),
    partition dt_20270314 values less than ('2027-03-15 00:00:00'),
    partition dt_20270315 values less than ('2027-03-16 00:00:00'),
    partition dt_20270316 values less than ('2027-03-17 00:00:00'),
    partition dt_20270317 values less than ('2027-03-18 00:00:00'),
    partition dt_20270318 values less than ('2027-03-19 00:00:00'),
    partition dt_20270319 values less than ('2027-03-20 00:00:00'),
    partition dt_20270320 values less than ('2027-03-21 00:00:00'),
    partition dt_20270321 values less than ('2027-03-22 00:00:00'),
    partition dt_20270322 values less than ('2027-03-23 00:00:00'),
    partition dt_20270323 values less than ('2027-03-24 00:00:00'),
    partition dt_20270324 values less than ('2027-03-25 00:00:00'),
    partition dt_20270325 values less than ('2027-03-26 00:00:00'),
    partition dt_20270326 values less than ('2027-03-27 00:00:00'),
    partition dt_20270327 values less than ('2027-03-28 00:00:00'),
    partition dt_20270328 values less than ('2027-03-29 00:00:00'),
    partition dt_20270329 values less than ('2027-03-30 00:00:00'),
    partition dt_20270330 values less than ('2027-03-31 00:00:00'),
    partition dt_20270331 values less than ('2027-04-01 00:00:00'),
    partition dt_20270401 values less than ('2027-04-02 00:00:00'),
    partition dt_20270402 values less than ('2027-04-03 00:00:00'),
    partition dt_20270403 values less than ('2027-04-04 00:00:00'),
    partition dt_20270404 values less than ('2027-04-05 00:00:00'),
    partition dt_20270405 values less than ('2027-04-06 00:00:00'),
    partition dt_20270406 values less than ('2027-04-07 00:00:00'),
    partition dt_20270407 values less than ('2027-04-08 00:00:00'),
    partition dt_20270408 values less than ('2027-04-09 00:00:00'),
    partition dt_20270409 values less than ('2027-04-10 00:00:00'),
    partition dt_20270410 values less than ('2027-04-11 00:00:00'),
    partition dt_20270411 values less than ('2027-04-12 00:00:00'),
    partition dt_20270412 values less than ('2027-04-13 00:00:00'),
    partition dt_20270413 values less than ('2027-04-14 00:00:00'),
    partition dt_20270414 values less than ('2027-04-15 00:00:00'),
    partition dt_20270415 values less than ('2027-04-16 00:00:00'),
    partition dt_20270416 values less than ('2027-04-17 00:00:00'),
    partition dt_20270417 values less than ('2027-04-18 00:00:00'),
    partition dt_20270418 values less than ('2027-04-19 00:00:00'),
    partition dt_20270419 values less than ('2027-04-20 00:00:00'),
    partition dt_20270420 values less than ('2027-04-21 00:00:00'),
    partition dt_20270421 values less than ('2027-04-22 00:00:00'),
    partition dt_20270422 values less than ('2027-04-23 00:00:00'),
    partition dt_20270423 values less than ('2027-04-24 00:00:00'),
    partition dt_20270424 values less than ('2027-04-25 00:00:00'),
    partition dt_20270425 values less than ('2027-04-26 00:00:00'),
    partition dt_20270426 values less than ('2027-04-27 00:00:00'),
    partition dt_20270427 values less than ('2027-04-28 00:00:00'),
    partition dt_20270428 values less than ('2027-04-29 00:00:00'),
    partition dt_20270429 values less than ('2027-04-30 00:00:00'),
    partition dt_20270430 values less than ('2027-05-01 00:00:00'),
    partition dt_20270501 values less than ('2027-05-02 00:00:00'),
    partition dt_20270502 values less than ('2027-05-03 00:00:00'),
    partition dt_20270503 values less than ('2027-05-04 00:00:00'),
    partition dt_20270504 values less than ('2027-05-05 00:00:00'),
    partition dt_20270505 values less than ('2027-05-06 00:00:00'),
    partition dt_20270506 values less than ('2027-05-07 00:00:00'),
    partition dt_20270507 values less than ('2027-05-08 00:00:00'),
    partition dt_20270508 values less than ('2027-05-09 00:00:00'),
    partition dt_20270509 values less than ('2027-05-10 00:00:00'),
    partition dt_20270510 values less than ('2027-05-11 00:00:00'),
    partition dt_20270511 values less than ('2027-05-12 00:00:00'),
    partition dt_20270512 values less than ('2027-05-13 00:00:00'),
    partition dt_20270513 values less than ('2027-05-14 00:00:00'),
    partition dt_20270514 values less than ('2027-05-15 00:00:00'),
    partition dt_20270515 values less than ('2027-05-16 00:00:00'),
    partition dt_20270516 values less than ('2027-05-17 00:00:00'),
    partition dt_20270517 values less than ('2027-05-18 00:00:00'),
    partition dt_20270518 values less than ('2027-05-19 00:00:00'),
    partition dt_20270519 values less than ('2027-05-20 00:00:00'),
    partition dt_20270520 values less than ('2027-05-21 00:00:00'),
    partition dt_20270521 values less than ('2027-05-22 00:00:00'),
    partition dt_20270522 values less than ('2027-05-23 00:00:00'),
    partition dt_20270523 values less than ('2027-05-24 00:00:00'),
    partition dt_20270524 values less than ('2027-05-25 00:00:00'),
    partition dt_20270525 values less than ('2027-05-26 00:00:00'),
    partition dt_20270526 values less than ('2027-05-27 00:00:00'),
    partition dt_20270527 values less than ('2027-05-28 00:00:00'),
    partition dt_20270528 values less than ('2027-05-29 00:00:00'),
    partition dt_20270529 values less than ('2027-05-30 00:00:00'),
    partition dt_20270530 values less than ('2027-05-31 00:00:00'),
    partition dt_20270531 values less than ('2027-06-01 00:00:00'),
    partition dt_20270601 values less than ('2027-06-02 00:00:00'),
    partition dt_20270602 values less than ('2027-06-03 00:00:00'),
    partition dt_20270603 values less than ('2027-06-04 00:00:00'),
    partition dt_20270604 values less than ('2027-06-05 00:00:00'),
    partition dt_20270605 values less than ('2027-06-06 00:00:00'),
    partition dt_20270606 values less than ('2027-06-07 00:00:00'),
    partition dt_20270607 values less than ('2027-06-08 00:00:00'),
    partition dt_20270608 values less than ('2027-06-09 00:00:00'),
    partition dt_20270609 values less than ('2027-06-10 00:00:00'),
    partition dt_20270610 values less than ('2027-06-11 00:00:00'),
    partition dt_20270611 values less than ('2027-06-12 00:00:00'),
    partition dt_20270612 values less than ('2027-06-13 00:00:00'),
    partition dt_20270613 values less than ('2027-06-14 00:00:00'),
    partition dt_20270614 values less than ('2027-06-15 00:00:00'),
    partition dt_20270615 values less than ('2027-06-16 00:00:00'),
    partition dt_20270616 values less than ('2027-06-17 00:00:00'),
    partition dt_20270617 values less than ('2027-06-18 00:00:00'),
    partition dt_20270618 values less than ('2027-06-19 00:00:00'),
    partition dt_20270619 values less than ('2027-06-20 00:00:00'),
    partition dt_20270620 values less than ('2027-06-21 00:00:00'),
    partition dt_20270621 values less than ('2027-06-22 00:00:00'),
    partition dt_20270622 values less than ('2027-06-23 00:00:00'),
    partition dt_20270623 values less than ('2027-06-24 00:00:00'),
    partition dt_20270624 values less than ('2027-06-25 00:00:00'),
    partition dt_20270625 values less than ('2027-06-26 00:00:00'),
    partition dt_20270626 values less than ('2027-06-27 00:00:00'),
    partition dt_20270627 values less than ('2027-06-28 00:00:00'),
    partition dt_20270628 values less than ('2027-06-29 00:00:00'),
    partition dt_20270629 values less than ('2027-06-30 00:00:00'),
    partition dt_20270630 values less than ('2027-07-01 00:00:00'),
    partition dt_20270701 values less than ('2027-07-02 00:00:00'),
    partition dt_20270702 values less than ('2027-07-03 00:00:00'),
    partition dt_20270703 values less than ('2027-07-04 00:00:00'),
    partition dt_20270704 values less than ('2027-07-05 00:00:00'),
    partition dt_20270705 values less than ('2027-07-06 00:00:00'),
    partition dt_20270706 values less than ('2027-07-07 00:00:00'),
    partition dt_20270707 values less than ('2027-07-08 00:00:00'),
    partition dt_20270708 values less than ('2027-07-09 00:00:00'),
    partition dt_20270709 values less than ('2027-07-10 00:00:00'),
    partition dt_20270710 values less than ('2027-07-11 00:00:00'),
    partition dt_20270711 values less than ('2027-07-12 00:00:00'),
    partition dt_20270712 values less than ('2027-07-13 00:00:00'),
    partition dt_20270713 values less than ('2027-07-14 00:00:00'),
    partition dt_20270714 values less than ('2027-07-15 00:00:00'),
    partition dt_20270715 values less than ('2027-07-16 00:00:00'),
    partition dt_20270716 values less than ('2027-07-17 00:00:00'),
    partition dt_20270717 values less than ('2027-07-18 00:00:00'),
    partition dt_20270718 values less than ('2027-07-19 00:00:00'),
    partition dt_20270719 values less than ('2027-07-20 00:00:00'),
    partition dt_20270720 values less than ('2027-07-21 00:00:00'),
    partition dt_20270721 values less than ('2027-07-22 00:00:00'),
    partition dt_20270722 values less than ('2027-07-23 00:00:00'),
    partition dt_20270723 values less than ('2027-07-24 00:00:00'),
    partition dt_20270724 values less than ('2027-07-25 00:00:00'),
    partition dt_20270725 values less than ('2027-07-26 00:00:00'),
    partition dt_20270726 values less than ('2027-07-27 00:00:00'),
    partition dt_20270727 values less than ('2027-07-28 00:00:00'),
    partition dt_20270728 values less than ('2027-07-29 00:00:00'),
    partition dt_20270729 values less than ('2027-07-30 00:00:00'),
    partition dt_20270730 values less than ('2027-07-31 00:00:00'),
    partition dt_20270731 values less than ('2027-08-01 00:00:00'),
    partition dt_20270801 values less than ('2027-08-02 00:00:00'),
    partition dt_20270802 values less than ('2027-08-03 00:00:00'),
    partition dt_20270803 values less than ('2027-08-04 00:00:00'),
    partition dt_20270804 values less than ('2027-08-05 00:00:00'),
    partition dt_20270805 values less than ('2027-08-06 00:00:00'),
    partition dt_20270806 values less than ('2027-08-07 00:00:00'),
    partition dt_20270807 values less than ('2027-08-08 00:00:00'),
    partition dt_20270808 values less than ('2027-08-09 00:00:00'),
    partition dt_20270809 values less than ('2027-08-10 00:00:00'),
    partition dt_20270810 values less than ('2027-08-11 00:00:00'),
    partition dt_20270811 values less than ('2027-08-12 00:00:00'),
    partition dt_20270812 values less than ('2027-08-13 00:00:00'),
    partition dt_20270813 values less than ('2027-08-14 00:00:00'),
    partition dt_20270814 values less than ('2027-08-15 00:00:00'),
    partition dt_20270815 values less than ('2027-08-16 00:00:00'),
    partition dt_20270816 values less than ('2027-08-17 00:00:00'),
    partition dt_20270817 values less than ('2027-08-18 00:00:00'),
    partition dt_20270818 values less than ('2027-08-19 00:00:00'),
    partition dt_20270819 values less than ('2027-08-20 00:00:00'),
    partition dt_20270820 values less than ('2027-08-21 00:00:00'),
    partition dt_20270821 values less than ('2027-08-22 00:00:00'),
    partition dt_20270822 values less than ('2027-08-23 00:00:00'),
    partition dt_20270823 values less than ('2027-08-24 00:00:00'),
    partition dt_20270824 values less than ('2027-08-25 00:00:00'),
    partition dt_20270825 values less than ('2027-08-26 00:00:00'),
    partition dt_20270826 values less than ('2027-08-27 00:00:00'),
    partition dt_20270827 values less than ('2027-08-28 00:00:00'),
    partition dt_20270828 values less than ('2027-08-29 00:00:00'),
    partition dt_20270829 values less than ('2027-08-30 00:00:00'),
    partition dt_20270830 values less than ('2027-08-31 00:00:00'),
    partition dt_20270831 values less than ('2027-09-01 00:00:00'),
    partition dt_20270901 values less than ('2027-09-02 00:00:00'),
    partition dt_20270902 values less than ('2027-09-03 00:00:00'),
    partition dt_20270903 values less than ('2027-09-04 00:00:00'),
    partition dt_20270904 values less than ('2027-09-05 00:00:00'),
    partition dt_20270905 values less than ('2027-09-06 00:00:00'),
    partition dt_20270906 values less than ('2027-09-07 00:00:00'),
    partition dt_20270907 values less than ('2027-09-08 00:00:00'),
    partition dt_20270908 values less than ('2027-09-09 00:00:00'),
    partition dt_20270909 values less than ('2027-09-10 00:00:00'),
    partition dt_20270910 values less than ('2027-09-11 00:00:00'),
    partition dt_20270911 values less than ('2027-09-12 00:00:00'),
    partition dt_20270912 values less than ('2027-09-13 00:00:00'),
    partition dt_20270913 values less than ('2027-09-14 00:00:00'),
    partition dt_20270914 values less than ('2027-09-15 00:00:00'),
    partition dt_20270915 values less than ('2027-09-16 00:00:00'),
    partition dt_20270916 values less than ('2027-09-17 00:00:00'),
    partition dt_20270917 values less than ('2027-09-18 00:00:00'),
    partition dt_20270918 values less than ('2027-09-19 00:00:00'),
    partition dt_20270919 values less than ('2027-09-20 00:00:00'),
    partition dt_20270920 values less than ('2027-09-21 00:00:00'),
    partition dt_20270921 values less than ('2027-09-22 00:00:00'),
    partition dt_20270922 values less than ('2027-09-23 00:00:00'),
    partition dt_20270923 values less than ('2027-09-24 00:00:00'),
    partition dt_20270924 values less than ('2027-09-25 00:00:00'),
    partition dt_20270925 values less than ('2027-09-26 00:00:00'),
    partition dt_20270926 values less than ('2027-09-27 00:00:00'),
    partition dt_20270927 values less than ('2027-09-28 00:00:00'),
    partition dt_20270928 values less than ('2027-09-29 00:00:00'),
    partition dt_20270929 values less than ('2027-09-30 00:00:00'),
    partition dt_20270930 values less than ('2027-10-01 00:00:00'),
    partition dt_20271001 values less than ('2027-10-02 00:00:00'),
    partition dt_20271002 values less than ('2027-10-03 00:00:00'),
    partition dt_20271003 values less than ('2027-10-04 00:00:00'),
    partition dt_20271004 values less than ('2027-10-05 00:00:00'),
    partition dt_20271005 values less than ('2027-10-06 00:00:00'),
    partition dt_20271006 values less than ('2027-10-07 00:00:00'),
    partition dt_20271007 values less than ('2027-10-08 00:00:00'),
    partition dt_20271008 values less than ('2027-10-09 00:00:00'),
    partition dt_20271009 values less than ('2027-10-10 00:00:00'),
    partition dt_20271010 values less than ('2027-10-11 00:00:00'),
    partition dt_20271011 values less than ('2027-10-12 00:00:00'),
    partition dt_20271012 values less than ('2027-10-13 00:00:00'),
    partition dt_20271013 values less than ('2027-10-14 00:00:00'),
    partition dt_20271014 values less than ('2027-10-15 00:00:00'),
    partition dt_20271015 values less than ('2027-10-16 00:00:00'),
    partition dt_20271016 values less than ('2027-10-17 00:00:00'),
    partition dt_20271017 values less than ('2027-10-18 00:00:00'),
    partition dt_20271018 values less than ('2027-10-19 00:00:00'),
    partition dt_20271019 values less than ('2027-10-20 00:00:00'),
    partition dt_20271020 values less than ('2027-10-21 00:00:00'),
    partition dt_20271021 values less than ('2027-10-22 00:00:00'),
    partition dt_20271022 values less than ('2027-10-23 00:00:00'),
    partition dt_20271023 values less than ('2027-10-24 00:00:00'),
    partition dt_20271024 values less than ('2027-10-25 00:00:00'),
    partition dt_20271025 values less than ('2027-10-26 00:00:00'),
    partition dt_20271026 values less than ('2027-10-27 00:00:00'),
    partition dt_20271027 values less than ('2027-10-28 00:00:00'),
    partition dt_20271028 values less than ('2027-10-29 00:00:00'),
    partition dt_20271029 values less than ('2027-10-30 00:00:00'),
    partition dt_20271030 values less than ('2027-10-31 00:00:00'),
    partition dt_20271031 values less than ('2027-11-01 00:00:00'),
    partition dt_20271101 values less than ('2027-11-02 00:00:00'),
    partition dt_20271102 values less than ('2027-11-03 00:00:00'),
    partition dt_20271103 values less than ('2027-11-04 00:00:00'),
    partition dt_20271104 values less than ('2027-11-05 00:00:00'),
    partition dt_20271105 values less than ('2027-11-06 00:00:00'),
    partition dt_20271106 values less than ('2027-11-07 00:00:00'),
    partition dt_20271107 values less than ('2027-11-08 00:00:00'),
    partition dt_20271108 values less than ('2027-11-09 00:00:00'),
    partition dt_20271109 values less than ('2027-11-10 00:00:00'),
    partition dt_20271110 values less than ('2027-11-11 00:00:00'),
    partition dt_20271111 values less than ('2027-11-12 00:00:00'),
    partition dt_20271112 values less than ('2027-11-13 00:00:00'),
    partition dt_20271113 values less than ('2027-11-14 00:00:00'),
    partition dt_20271114 values less than ('2027-11-15 00:00:00'),
    partition dt_20271115 values less than ('2027-11-16 00:00:00'),
    partition dt_20271116 values less than ('2027-11-17 00:00:00'),
    partition dt_20271117 values less than ('2027-11-18 00:00:00'),
    partition dt_20271118 values less than ('2027-11-19 00:00:00'),
    partition dt_20271119 values less than ('2027-11-20 00:00:00'),
    partition dt_20271120 values less than ('2027-11-21 00:00:00'),
    partition dt_20271121 values less than ('2027-11-22 00:00:00'),
    partition dt_20271122 values less than ('2027-11-23 00:00:00'),
    partition dt_20271123 values less than ('2027-11-24 00:00:00'),
    partition dt_20271124 values less than ('2027-11-25 00:00:00'),
    partition dt_20271125 values less than ('2027-11-26 00:00:00'),
    partition dt_20271126 values less than ('2027-11-27 00:00:00'),
    partition dt_20271127 values less than ('2027-11-28 00:00:00'),
    partition dt_20271128 values less than ('2027-11-29 00:00:00'),
    partition dt_20271129 values less than ('2027-11-30 00:00:00'),
    partition dt_20271130 values less than ('2027-12-01 00:00:00'),
    partition dt_20271201 values less than ('2027-12-02 00:00:00'),
    partition dt_20271202 values less than ('2027-12-03 00:00:00'),
    partition dt_20271203 values less than ('2027-12-04 00:00:00'),
    partition dt_20271204 values less than ('2027-12-05 00:00:00'),
    partition dt_20271205 values less than ('2027-12-06 00:00:00'),
    partition dt_20271206 values less than ('2027-12-07 00:00:00'),
    partition dt_20271207 values less than ('2027-12-08 00:00:00'),
    partition dt_20271208 values less than ('2027-12-09 00:00:00'),
    partition dt_20271209 values less than ('2027-12-10 00:00:00'),
    partition dt_20271210 values less than ('2027-12-11 00:00:00'),
    partition dt_20271211 values less than ('2027-12-12 00:00:00'),
    partition dt_20271212 values less than ('2027-12-13 00:00:00'),
    partition dt_20271213 values less than ('2027-12-14 00:00:00'),
    partition dt_20271214 values less than ('2027-12-15 00:00:00'),
    partition dt_20271215 values less than ('2027-12-16 00:00:00'),
    partition dt_20271216 values less than ('2027-12-17 00:00:00'),
    partition dt_20271217 values less than ('2027-12-18 00:00:00'),
    partition dt_20271218 values less than ('2027-12-19 00:00:00'),
    partition dt_20271219 values less than ('2027-12-20 00:00:00'),
    partition dt_20271220 values less than ('2027-12-21 00:00:00'),
    partition dt_20271221 values less than ('2027-12-22 00:00:00'),
    partition dt_20271222 values less than ('2027-12-23 00:00:00'),
    partition dt_20271223 values less than ('2027-12-24 00:00:00'),
    partition dt_20271224 values less than ('2027-12-25 00:00:00'),
    partition dt_20271225 values less than ('2027-12-26 00:00:00'),
    partition dt_20271226 values less than ('2027-12-27 00:00:00'),
    partition dt_20271227 values less than ('2027-12-28 00:00:00'),
    partition dt_20271228 values less than ('2027-12-29 00:00:00'),
    partition dt_20271229 values less than ('2027-12-30 00:00:00'),
    partition dt_20271230 values less than ('2027-12-31 00:00:00'),
    partition dt_20271231 values less than ('2028-01-01 00:00:00'),
    partition dt_20280101 values less than ('2028-01-02 00:00:00'),
    partition dt_20280102 values less than ('2028-01-03 00:00:00'),
    partition dt_20280103 values less than ('2028-01-04 00:00:00'),
    partition dt_20280104 values less than ('2028-01-05 00:00:00'),
    partition dt_20280105 values less than ('2028-01-06 00:00:00'),
    partition dt_20280106 values less than ('2028-01-07 00:00:00'),
    partition dt_20280107 values less than ('2028-01-08 00:00:00'),
    partition dt_20280108 values less than ('2028-01-09 00:00:00'),
    partition dt_20280109 values less than ('2028-01-10 00:00:00'),
    partition dt_20280110 values less than ('2028-01-11 00:00:00'),
    partition dt_20280111 values less than ('2028-01-12 00:00:00'),
    partition dt_20280112 values less than ('2028-01-13 00:00:00'),
    partition dt_20280113 values less than ('2028-01-14 00:00:00'),
    partition dt_20280114 values less than ('2028-01-15 00:00:00'),
    partition dt_20280115 values less than ('2028-01-16 00:00:00'),
    partition dt_20280116 values less than ('2028-01-17 00:00:00'),
    partition dt_20280117 values less than ('2028-01-18 00:00:00'),
    partition dt_20280118 values less than ('2028-01-19 00:00:00'),
    partition dt_20280119 values less than ('2028-01-20 00:00:00'),
    partition dt_20280120 values less than ('2028-01-21 00:00:00'),
    partition dt_20280121 values less than ('2028-01-22 00:00:00'),
    partition dt_20280122 values less than ('2028-01-23 00:00:00'),
    partition dt_20280123 values less than ('2028-01-24 00:00:00'),
    partition dt_20280124 values less than ('2028-01-25 00:00:00'),
    partition dt_20280125 values less than ('2028-01-26 00:00:00'),
    partition dt_20280126 values less than ('2028-01-27 00:00:00'),
    partition dt_20280127 values less than ('2028-01-28 00:00:00'),
    partition dt_20280128 values less than ('2028-01-29 00:00:00'),
    partition dt_20280129 values less than ('2028-01-30 00:00:00'),
    partition dt_20280130 values less than ('2028-01-31 00:00:00'),
    partition dt_20280131 values less than ('2028-02-01 00:00:00'),
    partition dt_20280201 values less than ('2028-02-02 00:00:00'),
    partition dt_20280202 values less than ('2028-02-03 00:00:00'),
    partition dt_20280203 values less than ('2028-02-04 00:00:00'),
    partition dt_20280204 values less than ('2028-02-05 00:00:00'),
    partition dt_20280205 values less than ('2028-02-06 00:00:00'),
    partition dt_20280206 values less than ('2028-02-07 00:00:00'),
    partition dt_20280207 values less than ('2028-02-08 00:00:00'),
    partition dt_20280208 values less than ('2028-02-09 00:00:00'),
    partition dt_20280209 values less than ('2028-02-10 00:00:00'),
    partition dt_20280210 values less than ('2028-02-11 00:00:00'),
    partition dt_20280211 values less than ('2028-02-12 00:00:00'),
    partition dt_20280212 values less than ('2028-02-13 00:00:00'),
    partition dt_20280213 values less than ('2028-02-14 00:00:00'),
    partition dt_20280214 values less than ('2028-02-15 00:00:00'),
    partition dt_20280215 values less than ('2028-02-16 00:00:00'),
    partition dt_20280216 values less than ('2028-02-17 00:00:00'),
    partition dt_20280217 values less than ('2028-02-18 00:00:00'),
    partition dt_20280218 values less than ('2028-02-19 00:00:00'),
    partition dt_20280219 values less than ('2028-02-20 00:00:00'),
    partition dt_20280220 values less than ('2028-02-21 00:00:00'),
    partition dt_20280221 values less than ('2028-02-22 00:00:00'),
    partition dt_20280222 values less than ('2028-02-23 00:00:00'),
    partition dt_20280223 values less than ('2028-02-24 00:00:00'),
    partition dt_20280224 values less than ('2028-02-25 00:00:00'),
    partition dt_20280225 values less than ('2028-02-26 00:00:00'),
    partition dt_20280226 values less than ('2028-02-27 00:00:00'),
    partition dt_20280227 values less than ('2028-02-28 00:00:00'),
    partition dt_20280228 values less than ('2028-02-29 00:00:00'),
    partition dt_20280229 values less than ('2028-03-01 00:00:00'),
    partition dt_20280301 values less than ('2028-03-02 00:00:00'),
    partition dt_20280302 values less than ('2028-03-03 00:00:00'),
    partition dt_20280303 values less than ('2028-03-04 00:00:00'),
    partition dt_20280304 values less than ('2028-03-05 00:00:00'),
    partition dt_20280305 values less than ('2028-03-06 00:00:00'),
    partition dt_20280306 values less than ('2028-03-07 00:00:00'),
    partition dt_20280307 values less than ('2028-03-08 00:00:00'),
    partition dt_20280308 values less than ('2028-03-09 00:00:00'),
    partition dt_20280309 values less than ('2028-03-10 00:00:00'),
    partition dt_20280310 values less than ('2028-03-11 00:00:00'),
    partition dt_20280311 values less than ('2028-03-12 00:00:00'),
    partition dt_20280312 values less than ('2028-03-13 00:00:00'),
    partition dt_20280313 values less than ('2028-03-14 00:00:00'),
    partition dt_20280314 values less than ('2028-03-15 00:00:00'),
    partition dt_20280315 values less than ('2028-03-16 00:00:00'),
    partition dt_20280316 values less than ('2028-03-17 00:00:00'),
    partition dt_20280317 values less than ('2028-03-18 00:00:00'),
    partition dt_20280318 values less than ('2028-03-19 00:00:00'),
    partition dt_20280319 values less than ('2028-03-20 00:00:00'),
    partition dt_20280320 values less than ('2028-03-21 00:00:00'),
    partition dt_20280321 values less than ('2028-03-22 00:00:00'),
    partition dt_20280322 values less than ('2028-03-23 00:00:00'),
    partition dt_20280323 values less than ('2028-03-24 00:00:00'),
    partition dt_20280324 values less than ('2028-03-25 00:00:00'),
    partition dt_20280325 values less than ('2028-03-26 00:00:00'),
    partition dt_20280326 values less than ('2028-03-27 00:00:00'),
    partition dt_20280327 values less than ('2028-03-28 00:00:00'),
    partition dt_20280328 values less than ('2028-03-29 00:00:00'),
    partition dt_20280329 values less than ('2028-03-30 00:00:00'),
    partition dt_20280330 values less than ('2028-03-31 00:00:00'),
    partition dt_20280331 values less than ('2028-04-01 00:00:00'),
    partition dt_20280401 values less than ('2028-04-02 00:00:00'),
    partition dt_20280402 values less than ('2028-04-03 00:00:00'),
    partition dt_20280403 values less than ('2028-04-04 00:00:00'),
    partition dt_20280404 values less than ('2028-04-05 00:00:00'),
    partition dt_20280405 values less than ('2028-04-06 00:00:00'),
    partition dt_20280406 values less than ('2028-04-07 00:00:00'),
    partition dt_20280407 values less than ('2028-04-08 00:00:00'),
    partition dt_20280408 values less than ('2028-04-09 00:00:00'),
    partition dt_20280409 values less than ('2028-04-10 00:00:00'),
    partition dt_20280410 values less than ('2028-04-11 00:00:00'),
    partition dt_20280411 values less than ('2028-04-12 00:00:00'),
    partition dt_20280412 values less than ('2028-04-13 00:00:00'),
    partition dt_20280413 values less than ('2028-04-14 00:00:00'),
    partition dt_20280414 values less than ('2028-04-15 00:00:00'),
    partition dt_20280415 values less than ('2028-04-16 00:00:00'),
    partition dt_20280416 values less than ('2028-04-17 00:00:00'),
    partition dt_20280417 values less than ('2028-04-18 00:00:00'),
    partition dt_20280418 values less than ('2028-04-19 00:00:00'),
    partition dt_20280419 values less than ('2028-04-20 00:00:00'),
    partition dt_20280420 values less than ('2028-04-21 00:00:00'),
    partition dt_20280421 values less than ('2028-04-22 00:00:00'),
    partition dt_20280422 values less than ('2028-04-23 00:00:00'),
    partition dt_20280423 values less than ('2028-04-24 00:00:00'),
    partition dt_20280424 values less than ('2028-04-25 00:00:00'),
    partition dt_20280425 values less than ('2028-04-26 00:00:00'),
    partition dt_20280426 values less than ('2028-04-27 00:00:00'),
    partition dt_20280427 values less than ('2028-04-28 00:00:00'),
    partition dt_20280428 values less than ('2028-04-29 00:00:00'),
    partition dt_20280429 values less than ('2028-04-30 00:00:00'),
    partition dt_20280430 values less than ('2028-05-01 00:00:00'),
    partition dt_20280501 values less than ('2028-05-02 00:00:00'),
    partition dt_20280502 values less than ('2028-05-03 00:00:00'),
    partition dt_20280503 values less than ('2028-05-04 00:00:00'),
    partition dt_20280504 values less than ('2028-05-05 00:00:00'),
    partition dt_20280505 values less than ('2028-05-06 00:00:00'),
    partition dt_20280506 values less than ('2028-05-07 00:00:00'),
    partition dt_20280507 values less than ('2028-05-08 00:00:00'),
    partition dt_20280508 values less than ('2028-05-09 00:00:00'),
    partition dt_20280509 values less than ('2028-05-10 00:00:00'),
    partition dt_20280510 values less than ('2028-05-11 00:00:00'),
    partition dt_20280511 values less than ('2028-05-12 00:00:00'),
    partition dt_20280512 values less than ('2028-05-13 00:00:00'),
    partition dt_20280513 values less than ('2028-05-14 00:00:00'),
    partition dt_20280514 values less than ('2028-05-15 00:00:00'),
    partition dt_20280515 values less than ('2028-05-16 00:00:00'),
    partition dt_20280516 values less than ('2028-05-17 00:00:00'),
    partition dt_20280517 values less than ('2028-05-18 00:00:00'),
    partition dt_20280518 values less than ('2028-05-19 00:00:00'),
    partition dt_20280519 values less than ('2028-05-20 00:00:00'),
    partition dt_20280520 values less than ('2028-05-21 00:00:00'),
    partition dt_20280521 values less than ('2028-05-22 00:00:00'),
    partition dt_20280522 values less than ('2028-05-23 00:00:00'),
    partition dt_20280523 values less than ('2028-05-24 00:00:00'),
    partition dt_20280524 values less than ('2028-05-25 00:00:00'),
    partition dt_20280525 values less than ('2028-05-26 00:00:00'),
    partition dt_20280526 values less than ('2028-05-27 00:00:00'),
    partition dt_20280527 values less than ('2028-05-28 00:00:00'),
    partition dt_20280528 values less than ('2028-05-29 00:00:00'),
    partition dt_20280529 values less than ('2028-05-30 00:00:00'),
    partition dt_20280530 values less than ('2028-05-31 00:00:00'),
    partition dt_20280531 values less than ('2028-06-01 00:00:00'),
    partition dt_20280601 values less than ('2028-06-02 00:00:00'),
    partition dt_20280602 values less than ('2028-06-03 00:00:00'),
    partition dt_20280603 values less than ('2028-06-04 00:00:00'),
    partition dt_20280604 values less than ('2028-06-05 00:00:00'),
    partition dt_20280605 values less than ('2028-06-06 00:00:00'),
    partition dt_20280606 values less than ('2028-06-07 00:00:00'),
    partition dt_20280607 values less than ('2028-06-08 00:00:00'),
    partition dt_20280608 values less than ('2028-06-09 00:00:00'),
    partition dt_20280609 values less than ('2028-06-10 00:00:00'),
    partition dt_20280610 values less than ('2028-06-11 00:00:00'),
    partition dt_20280611 values less than ('2028-06-12 00:00:00'),
    partition dt_20280612 values less than ('2028-06-13 00:00:00'),
    partition dt_20280613 values less than ('2028-06-14 00:00:00'),
    partition dt_20280614 values less than ('2028-06-15 00:00:00'),
    partition dt_20280615 values less than ('2028-06-16 00:00:00'),
    partition dt_20280616 values less than ('2028-06-17 00:00:00'),
    partition dt_20280617 values less than ('2028-06-18 00:00:00'),
    partition dt_20280618 values less than ('2028-06-19 00:00:00'),
    partition dt_20280619 values less than ('2028-06-20 00:00:00'),
    partition dt_20280620 values less than ('2028-06-21 00:00:00'),
    partition dt_20280621 values less than ('2028-06-22 00:00:00'),
    partition dt_20280622 values less than ('2028-06-23 00:00:00'),
    partition dt_20280623 values less than ('2028-06-24 00:00:00'),
    partition dt_20280624 values less than ('2028-06-25 00:00:00'),
    partition dt_20280625 values less than ('2028-06-26 00:00:00'),
    partition dt_20280626 values less than ('2028-06-27 00:00:00'),
    partition dt_20280627 values less than ('2028-06-28 00:00:00'),
    partition dt_20280628 values less than ('2028-06-29 00:00:00'),
    partition dt_20280629 values less than ('2028-06-30 00:00:00'),
    partition dt_20280630 values less than ('2028-07-01 00:00:00'),
    partition dt_20280701 values less than ('2028-07-02 00:00:00'),
    partition dt_20280702 values less than ('2028-07-03 00:00:00'),
    partition dt_20280703 values less than ('2028-07-04 00:00:00'),
    partition dt_20280704 values less than ('2028-07-05 00:00:00'),
    partition dt_20280705 values less than ('2028-07-06 00:00:00'),
    partition dt_20280706 values less than ('2028-07-07 00:00:00'),
    partition dt_20280707 values less than ('2028-07-08 00:00:00'),
    partition dt_20280708 values less than ('2028-07-09 00:00:00'),
    partition dt_20280709 values less than ('2028-07-10 00:00:00'),
    partition dt_20280710 values less than ('2028-07-11 00:00:00'),
    partition dt_20280711 values less than ('2028-07-12 00:00:00'),
    partition dt_20280712 values less than ('2028-07-13 00:00:00'),
    partition dt_20280713 values less than ('2028-07-14 00:00:00'),
    partition dt_20280714 values less than ('2028-07-15 00:00:00'),
    partition dt_20280715 values less than ('2028-07-16 00:00:00'),
    partition dt_20280716 values less than ('2028-07-17 00:00:00'),
    partition dt_20280717 values less than ('2028-07-18 00:00:00'),
    partition dt_20280718 values less than ('2028-07-19 00:00:00'),
    partition dt_20280719 values less than ('2028-07-20 00:00:00'),
    partition dt_20280720 values less than ('2028-07-21 00:00:00'),
    partition dt_20280721 values less than ('2028-07-22 00:00:00'),
    partition dt_20280722 values less than ('2028-07-23 00:00:00'),
    partition dt_20280723 values less than ('2028-07-24 00:00:00'),
    partition dt_20280724 values less than ('2028-07-25 00:00:00'),
    partition dt_20280725 values less than ('2028-07-26 00:00:00'),
    partition dt_20280726 values less than ('2028-07-27 00:00:00'),
    partition dt_20280727 values less than ('2028-07-28 00:00:00'),
    partition dt_20280728 values less than ('2028-07-29 00:00:00'),
    partition dt_20280729 values less than ('2028-07-30 00:00:00'),
    partition dt_20280730 values less than ('2028-07-31 00:00:00'),
    partition dt_20280731 values less than ('2028-08-01 00:00:00'),
    partition dt_20280801 values less than ('2028-08-02 00:00:00'),
    partition dt_20280802 values less than ('2028-08-03 00:00:00'),
    partition dt_20280803 values less than ('2028-08-04 00:00:00'),
    partition dt_20280804 values less than ('2028-08-05 00:00:00'),
    partition dt_20280805 values less than ('2028-08-06 00:00:00'),
    partition dt_20280806 values less than ('2028-08-07 00:00:00'),
    partition dt_20280807 values less than ('2028-08-08 00:00:00'),
    partition dt_20280808 values less than ('2028-08-09 00:00:00'),
    partition dt_20280809 values less than ('2028-08-10 00:00:00'),
    partition dt_20280810 values less than ('2028-08-11 00:00:00'),
    partition dt_20280811 values less than ('2028-08-12 00:00:00'),
    partition dt_20280812 values less than ('2028-08-13 00:00:00'),
    partition dt_20280813 values less than ('2028-08-14 00:00:00'),
    partition dt_20280814 values less than ('2028-08-15 00:00:00'),
    partition dt_20280815 values less than ('2028-08-16 00:00:00'),
    partition dt_20280816 values less than ('2028-08-17 00:00:00'),
    partition dt_20280817 values less than ('2028-08-18 00:00:00'),
    partition dt_20280818 values less than ('2028-08-19 00:00:00'),
    partition dt_20280819 values less than ('2028-08-20 00:00:00'),
    partition dt_20280820 values less than ('2028-08-21 00:00:00'),
    partition dt_20280821 values less than ('2028-08-22 00:00:00'),
    partition dt_20280822 values less than ('2028-08-23 00:00:00'),
    partition dt_20280823 values less than ('2028-08-24 00:00:00'),
    partition dt_20280824 values less than ('2028-08-25 00:00:00'),
    partition dt_20280825 values less than ('2028-08-26 00:00:00'),
    partition dt_20280826 values less than ('2028-08-27 00:00:00'),
    partition dt_20280827 values less than ('2028-08-28 00:00:00'),
    partition dt_20280828 values less than ('2028-08-29 00:00:00'),
    partition dt_20280829 values less than ('2028-08-30 00:00:00'),
    partition dt_20280830 values less than ('2028-08-31 00:00:00'),
    partition dt_20280831 values less than ('2028-09-01 00:00:00'),
    partition dt_20280901 values less than ('2028-09-02 00:00:00'),
    partition dt_20280902 values less than ('2028-09-03 00:00:00'),
    partition dt_20280903 values less than ('2028-09-04 00:00:00'),
    partition dt_20280904 values less than ('2028-09-05 00:00:00'),
    partition dt_20280905 values less than ('2028-09-06 00:00:00'),
    partition dt_20280906 values less than ('2028-09-07 00:00:00'),
    partition dt_20280907 values less than ('2028-09-08 00:00:00'),
    partition dt_20280908 values less than ('2028-09-09 00:00:00'),
    partition dt_20280909 values less than ('2028-09-10 00:00:00'),
    partition dt_20280910 values less than ('2028-09-11 00:00:00'),
    partition dt_20280911 values less than ('2028-09-12 00:00:00'),
    partition dt_20280912 values less than ('2028-09-13 00:00:00'),
    partition dt_20280913 values less than ('2028-09-14 00:00:00'),
    partition dt_20280914 values less than ('2028-09-15 00:00:00'),
    partition dt_20280915 values less than ('2028-09-16 00:00:00'),
    partition dt_20280916 values less than ('2028-09-17 00:00:00'),
    partition dt_20280917 values less than ('2028-09-18 00:00:00'),
    partition dt_20280918 values less than ('2028-09-19 00:00:00'),
    partition dt_20280919 values less than ('2028-09-20 00:00:00'),
    partition dt_20280920 values less than ('2028-09-21 00:00:00'),
    partition dt_20280921 values less than ('2028-09-22 00:00:00'),
    partition dt_20280922 values less than ('2028-09-23 00:00:00'),
    partition dt_20280923 values less than ('2028-09-24 00:00:00'),
    partition dt_20280924 values less than ('2028-09-25 00:00:00'),
    partition dt_20280925 values less than ('2028-09-26 00:00:00'),
    partition dt_20280926 values less than ('2028-09-27 00:00:00'),
    partition dt_20280927 values less than ('2028-09-28 00:00:00'),
    partition dt_20280928 values less than ('2028-09-29 00:00:00'),
    partition dt_20280929 values less than ('2028-09-30 00:00:00'),
    partition dt_20280930 values less than ('2028-10-01 00:00:00'),
    partition dt_20281001 values less than ('2028-10-02 00:00:00'),
    partition dt_20281002 values less than ('2028-10-03 00:00:00'),
    partition dt_20281003 values less than ('2028-10-04 00:00:00'),
    partition dt_20281004 values less than ('2028-10-05 00:00:00'),
    partition dt_20281005 values less than ('2028-10-06 00:00:00'),
    partition dt_20281006 values less than ('2028-10-07 00:00:00'),
    partition dt_20281007 values less than ('2028-10-08 00:00:00'),
    partition dt_20281008 values less than ('2028-10-09 00:00:00'),
    partition dt_20281009 values less than ('2028-10-10 00:00:00'),
    partition dt_20281010 values less than ('2028-10-11 00:00:00'),
    partition dt_20281011 values less than ('2028-10-12 00:00:00'),
    partition dt_20281012 values less than ('2028-10-13 00:00:00'),
    partition dt_20281013 values less than ('2028-10-14 00:00:00'),
    partition dt_20281014 values less than ('2028-10-15 00:00:00'),
    partition dt_20281015 values less than ('2028-10-16 00:00:00'),
    partition dt_20281016 values less than ('2028-10-17 00:00:00'),
    partition dt_20281017 values less than ('2028-10-18 00:00:00'),
    partition dt_20281018 values less than ('2028-10-19 00:00:00'),
    partition dt_20281019 values less than ('2028-10-20 00:00:00'),
    partition dt_20281020 values less than ('2028-10-21 00:00:00'),
    partition dt_20281021 values less than ('2028-10-22 00:00:00'),
    partition dt_20281022 values less than ('2028-10-23 00:00:00'),
    partition dt_20281023 values less than ('2028-10-24 00:00:00'),
    partition dt_20281024 values less than ('2028-10-25 00:00:00'),
    partition dt_20281025 values less than ('2028-10-26 00:00:00'),
    partition dt_20281026 values less than ('2028-10-27 00:00:00'),
    partition dt_20281027 values less than ('2028-10-28 00:00:00'),
    partition dt_20281028 values less than ('2028-10-29 00:00:00'),
    partition dt_20281029 values less than ('2028-10-30 00:00:00'),
    partition dt_20281030 values less than ('2028-10-31 00:00:00'),
    partition dt_20281031 values less than ('2028-11-01 00:00:00'),
    partition dt_20281101 values less than ('2028-11-02 00:00:00'),
    partition dt_20281102 values less than ('2028-11-03 00:00:00'),
    partition dt_20281103 values less than ('2028-11-04 00:00:00'),
    partition dt_20281104 values less than ('2028-11-05 00:00:00'),
    partition dt_20281105 values less than ('2028-11-06 00:00:00'),
    partition dt_20281106 values less than ('2028-11-07 00:00:00'),
    partition dt_20281107 values less than ('2028-11-08 00:00:00'),
    partition dt_20281108 values less than ('2028-11-09 00:00:00'),
    partition dt_20281109 values less than ('2028-11-10 00:00:00'),
    partition dt_20281110 values less than ('2028-11-11 00:00:00'),
    partition dt_20281111 values less than ('2028-11-12 00:00:00'),
    partition dt_20281112 values less than ('2028-11-13 00:00:00'),
    partition dt_20281113 values less than ('2028-11-14 00:00:00'),
    partition dt_20281114 values less than ('2028-11-15 00:00:00'),
    partition dt_20281115 values less than ('2028-11-16 00:00:00'),
    partition dt_20281116 values less than ('2028-11-17 00:00:00'),
    partition dt_20281117 values less than ('2028-11-18 00:00:00'),
    partition dt_20281118 values less than ('2028-11-19 00:00:00'),
    partition dt_20281119 values less than ('2028-11-20 00:00:00'),
    partition dt_20281120 values less than ('2028-11-21 00:00:00'),
    partition dt_20281121 values less than ('2028-11-22 00:00:00'),
    partition dt_20281122 values less than ('2028-11-23 00:00:00'),
    partition dt_20281123 values less than ('2028-11-24 00:00:00'),
    partition dt_20281124 values less than ('2028-11-25 00:00:00'),
    partition dt_20281125 values less than ('2028-11-26 00:00:00'),
    partition dt_20281126 values less than ('2028-11-27 00:00:00'),
    partition dt_20281127 values less than ('2028-11-28 00:00:00'),
    partition dt_20281128 values less than ('2028-11-29 00:00:00'),
    partition dt_20281129 values less than ('2028-11-30 00:00:00'),
    partition dt_20281130 values less than ('2028-12-01 00:00:00'),
    partition dt_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_wtw_opc_data_mini_day                     is 'water treatment work tag poc data latest'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.id                  is 'id'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.i_code              is 'install code'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.tag_name            is 'tag name'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.tag_value           is 'tag value'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.quality             is 'tag value quality'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.tag_time            is 'tag time'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.dwd_update_time     is 'dm update time'
;comment on column coss_dwd.dwd_wtw_opc_data_mini_day.dwd_load_time       is 'dm load time'
```

### 2.select sql

1. tuenmun

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For tuenmun
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                   -- id
     ,i_code              -- install code
     ,tag_name            -- tag name
     ,tag_value           -- tag value
     ,quality             -- quality
     ,tag_time            -- tag time
     ,dwd_update_time     -- dwd update time
     ,dwd_load_time       -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW016'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

   

2. yaukomtau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For yaukomtau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW018'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

   

3. shatin

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For shatin
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW013'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

4. silverminebay

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For silverminebay
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW009'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

5. autau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For autau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW021'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

6. ngautammei

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For ngautammei
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW027'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

7. maonshan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For maonshan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW024'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

8. siuhowan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- target table
   -- coss_dwd.dwd_wtw_opc_data_mini_day
   -- ****************************************************************************************
   insert into coss_dwd.dwd_wtw_opc_data_mini_day
   select
     id                -- id
     ,i_code           -- install code
     ,tag_name         -- tag name
     ,tag_value        -- tag value
     ,quality          -- quality
     ,tag_time         -- tag time
     ,dwd_update_time  -- dwd update time
     ,dwd_load_time    -- dwd load tim
   from coss_dwd.dwd_wtw_opc_data_latest_minf t where i_code = 'TW025'
     and not exists
     (select
       1
     from coss_dwd.dwd_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

   

# dm

## coss_dm.dm_wtw_opc_data_latest_minf

### 1.create table

```sql

;drop table if exists coss_dm.dm_wtw_opc_data_latest_minf
;create table if not exists coss_dm.dm_wtw_opc_data_latest_minf (
	id bigserial not null,
	i_code varchar(50) not null,
    region_abbr varchar(50) ,
    wtw_name_en  varchar(128) null,
    wtw_name_cn  varchar(128) null,
    wtw_name_tc  varchar(128) null,
    tag_name_cn  varchar(128) null,
    tag_name_tc  varchar(128) null,
    units        varchar(128) null,
    tag_type     varchar(128) null,
	tag_name varchar(128) null,
	tag_value varchar(128) null,
    quality  int,
	tag_time timestamp not null,
	dm_update_time timestamp not null,
    dm_load_time timestamp(6) not null,
    primary key(i_code, tag_name, tag_time)
)
with (
	orientation=row,
	compression=no,
	storage_type=ustore,
	segment=off
)
;comment on table  coss_dm.dm_wtw_opc_data_latest_minf                     is 'water treatment work tag poc data latest'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.id                  is 'id'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.i_code              is 'install code'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.region_abbr         is 'region abbreviation'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.wtw_name_en         is 'water treatments work engliash name '
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.wtw_name_cn         is 'water treatments work chinses name '
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.wtw_name_tc         is 'water treatments work traditional chinses name '
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_name_cn         is 'tag chinses name '
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_name_tc         is 'tag traditional chinses name '
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.units               is 'tag units'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_type            is 'tag type'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_name            is 'tag name'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_value           is 'tag value'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.quality             is 'quality'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_time            is 'tag time'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.dm_update_time      is 'dm update time'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.dm_load_time        is 'dm load time'
```

### 2.select sql

1. tuenmun

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For tuenmun
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW016'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                            -- id
     ,t1.i_code                      -- install code
     ,t1.region_abbr                 -- region abbreviation
     ,t1.wtw_name_en                 -- water treatments work english name
     ,t1.wtw_name_cn                 -- water treatments work chinese name
     ,t1.wtw_name_tc                 -- water treatments work traditional chinese name
     ,t1.tag_name_cn                 -- tag chinese name
     ,t1.tag_name_tc                 -- tag traditional chinese name
     ,t1.units                       -- tag units
     ,t1.tag_type                    -- tag type
     ,t.tag_name                     -- tag name
     ,t.tag_value                    -- tag value
     ,t.quality                      -- quality
     ,t.tag_time                     -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW016'
   ```

   

2. yaukomtau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For yaukomtau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW018'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                             -- id
     ,t1.i_code                       -- install code
     ,t1.region_abbr                  -- region abbreviation
     ,t1.wtw_name_en                  -- water treatments work english name
     ,t1.wtw_name_cn                  -- water treatments work chinese name
     ,t1.wtw_name_tc                  -- water treatments work traditional chinese name
     ,t1.tag_name_cn                  -- tag chinese name
     ,t1.tag_name_tc                  -- tag traditional chinese name
     ,t1.units                        -- tag units
     ,t1.tag_type                     -- tag type
     ,t.tag_name                      -- tag name
     ,t.tag_value                     -- tag value
     ,t.quality                       -- quality
     ,t.tag_time                      -- tag time
     ,localtimestamp dm_update_time   -- dm update time
     ,localtimestamp dm_load_time     -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW018'
   ```

3. shatin

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For shatin
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW013'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                           -- id
     ,t1.i_code                     -- install code
     ,t1.region_abbr                -- region abbreviation
     ,t1.wtw_name_en                -- water treatments work english name
     ,t1.wtw_name_cn                -- water treatments work chinese name
     ,t1.wtw_name_tc                -- water treatments work traditional chinese name
     ,t1.tag_name_cn                -- tag chinese name
     ,t1.tag_name_tc                -- tag traditional chinese name
     ,t1.units                      -- tag units
     ,t1.tag_type                   -- tag type
     ,t.tag_name                    -- tag name
     ,t.tag_value                   -- tag value
     ,t.quality                     -- quality
     ,t.tag_time                    -- tag time
     ,localtimestamp dm_update_time -- dm update time
     ,localtimestamp dm_load_time   -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW013'
   
   ```

4. silverminebay

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For silverminebay
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW009'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                           -- id
     ,t1.i_code                     -- install code
     ,t1.region_abbr                -- region abbreviation
     ,t1.wtw_name_en                -- water treatments work english name
     ,t1.wtw_name_cn                -- water treatments work chinese name
     ,t1.wtw_name_tc                -- water treatments work traditional chinese name
     ,t1.tag_name_cn                -- tag chinese name
     ,t1.tag_name_tc                -- tag traditional chinese name
     ,t1.units                      -- tag units
     ,t1.tag_type                   -- tag type
     ,t.tag_name                    -- tag name
     ,t.tag_value                   -- tag value
     ,t.quality                     -- quality
     ,t.tag_time                    -- tag time
     ,localtimestamp dm_update_time -- dm update time
     ,localtimestamp dm_load_time   -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW009'
   
   ```

5. autau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For autau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW021'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                           -- id
     ,t1.i_code                     -- install code
     ,t1.region_abbr                -- region abbreviation
     ,t1.wtw_name_en                -- water treatments work english name
     ,t1.wtw_name_cn                -- water treatments work chinese name
     ,t1.wtw_name_tc                -- water treatments work traditional chinese name
     ,t1.tag_name_cn                -- tag chinese name
     ,t1.tag_name_tc                -- tag traditional chinese name
     ,t1.units                      -- tag units
     ,t1.tag_type                   -- tag type
     ,t.tag_name                    -- tag name
     ,t.tag_value                   -- tag value
     ,t.quality                     -- quality
     ,t.tag_time                    -- tag time
     ,localtimestamp dm_update_time -- dm update time
     ,localtimestamp dm_load_time   -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW021'
   
   ```

6. ngautammei

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For ngautammei
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW027'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                           -- id
     ,t1.i_code                     -- install code
     ,t1.region_abbr                -- region abbreviation
     ,t1.wtw_name_en                -- water treatments work english name
     ,t1.wtw_name_cn                -- water treatments work chinese name
     ,t1.wtw_name_tc                -- water treatments work traditional chinese name
     ,t1.tag_name_cn                -- tag chinese name
     ,t1.tag_name_tc                -- tag traditional chinese name
     ,t1.units                      -- tag units
     ,t1.tag_type                   -- tag type
     ,t.tag_name                    -- tag name
     ,t.tag_value                   -- tag value
     ,t.quality                     -- quality
     ,t.tag_time                    -- tag time
     ,localtimestamp dm_update_time -- dm update time
     ,localtimestamp dm_load_time   -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW027'
   
   ```

7. maonshan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For maonshan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW024'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                           -- id
     ,t1.i_code                     -- install code
     ,t1.region_abbr                -- region abbreviation
     ,t1.wtw_name_en                -- water treatments work english name
     ,t1.wtw_name_cn                -- water treatments work chinese name
     ,t1.wtw_name_tc                -- water treatments work traditional chinese name
     ,t1.tag_name_cn                -- tag chinese name
     ,t1.tag_name_tc                -- tag traditional chinese name
     ,t1.units                      -- tag units
     ,t1.tag_type                   -- tag type
     ,t.tag_name                    -- tag name
     ,t.tag_value                   -- tag value
     ,t.quality                     -- quality
     ,t.tag_time                    -- tag time
     ,localtimestamp dm_update_time -- dm update time
     ,localtimestamp dm_load_time   -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW024'
   
   ```

8. siuhowan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dwd.dwd_wtw_opc_data_latest_minf
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- ****************************************************************************************
   ;delete from coss_dm.dm_wtw_opc_data_latest_minf  where i_code = 'TW025'
   ;insert into coss_dm.dm_wtw_opc_data_latest_minf
   select 
     t.id                           -- id
     ,t1.i_code                     -- install code
     ,t1.region_abbr                -- region abbreviation
     ,t1.wtw_name_en                -- water treatments work english name
     ,t1.wtw_name_cn                -- water treatments work chinese name
     ,t1.wtw_name_tc                -- water treatments work traditional chinese name
     ,t1.tag_name_cn                -- tag chinese name
     ,t1.tag_name_tc                -- tag traditional chinese name
     ,t1.units                      -- tag units
     ,t1.tag_type                   -- tag type
     ,t.tag_name                    -- tag name
     ,t.tag_value                   -- tag value
     ,t.quality                     -- quality
     ,t.tag_time                    -- tag time
     ,localtimestamp dm_update_time -- dm update time
     ,localtimestamp dm_load_time   -- dm load time
   from coss_dwd.dwd_wtw_opc_data_latest_minf t
   inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW025'
   
   ```

   

## coss_dm.dm_wtw_opc_data_mini_day

### 1.create table

```sql
;drop table if exists coss_dm.dm_wtw_opc_data_mini_day
;create table if not exists coss_dm.dm_wtw_opc_data_mini_day (
	id bigserial not null,
	i_code varchar(50) not null,
    region_abbr varchar(50) ,
    wtw_name_en  varchar(128) null,
    wtw_name_cn  varchar(128) null,
    wtw_name_tc  varchar(128) null,
    tag_name_cn  varchar(128) null,
    tag_name_tc  varchar(128) null,
    units        varchar(128) null,
    tag_type     varchar(128) null,
	tag_name varchar(128) null,
	tag_value varchar(128) null,
    quality  int,
	tag_time timestamp not null,
	dm_update_time timestamp not null,
    dm_load_time timestamp(6) not null,
    primary key(i_code, tag_name, tag_time)
)
with (
	orientation=row,
	compression=no,
	storage_type=ustore,
	segment=off
)
partition by range (tag_time)
(
partition dt_20250101 values less than ('2025-01-02 00:00:00'),
    partition dt_20250102 values less than ('2025-01-03 00:00:00'),
    partition dt_20250103 values less than ('2025-01-04 00:00:00'),
    partition dt_20250104 values less than ('2025-01-05 00:00:00'),
    partition dt_20250105 values less than ('2025-01-06 00:00:00'),
    partition dt_20250106 values less than ('2025-01-07 00:00:00'),
    partition dt_20250107 values less than ('2025-01-08 00:00:00'),
    partition dt_20250108 values less than ('2025-01-09 00:00:00'),
    partition dt_20250109 values less than ('2025-01-10 00:00:00'),
    partition dt_20250110 values less than ('2025-01-11 00:00:00'),
    partition dt_20250111 values less than ('2025-01-12 00:00:00'),
    partition dt_20250112 values less than ('2025-01-13 00:00:00'),
    partition dt_20250113 values less than ('2025-01-14 00:00:00'),
    partition dt_20250114 values less than ('2025-01-15 00:00:00'),
    partition dt_20250115 values less than ('2025-01-16 00:00:00'),
    partition dt_20250116 values less than ('2025-01-17 00:00:00'),
    partition dt_20250117 values less than ('2025-01-18 00:00:00'),
    partition dt_20250118 values less than ('2025-01-19 00:00:00'),
    partition dt_20250119 values less than ('2025-01-20 00:00:00'),
    partition dt_20250120 values less than ('2025-01-21 00:00:00'),
    partition dt_20250121 values less than ('2025-01-22 00:00:00'),
    partition dt_20250122 values less than ('2025-01-23 00:00:00'),
    partition dt_20250123 values less than ('2025-01-24 00:00:00'),
    partition dt_20250124 values less than ('2025-01-25 00:00:00'),
    partition dt_20250125 values less than ('2025-01-26 00:00:00'),
    partition dt_20250126 values less than ('2025-01-27 00:00:00'),
    partition dt_20250127 values less than ('2025-01-28 00:00:00'),
    partition dt_20250128 values less than ('2025-01-29 00:00:00'),
    partition dt_20250129 values less than ('2025-01-30 00:00:00'),
    partition dt_20250130 values less than ('2025-01-31 00:00:00'),
    partition dt_20250131 values less than ('2025-02-01 00:00:00'),
    partition dt_20250201 values less than ('2025-02-02 00:00:00'),
    partition dt_20250202 values less than ('2025-02-03 00:00:00'),
    partition dt_20250203 values less than ('2025-02-04 00:00:00'),
    partition dt_20250204 values less than ('2025-02-05 00:00:00'),
    partition dt_20250205 values less than ('2025-02-06 00:00:00'),
    partition dt_20250206 values less than ('2025-02-07 00:00:00'),
    partition dt_20250207 values less than ('2025-02-08 00:00:00'),
    partition dt_20250208 values less than ('2025-02-09 00:00:00'),
    partition dt_20250209 values less than ('2025-02-10 00:00:00'),
    partition dt_20250210 values less than ('2025-02-11 00:00:00'),
    partition dt_20250211 values less than ('2025-02-12 00:00:00'),
    partition dt_20250212 values less than ('2025-02-13 00:00:00'),
    partition dt_20250213 values less than ('2025-02-14 00:00:00'),
    partition dt_20250214 values less than ('2025-02-15 00:00:00'),
    partition dt_20250215 values less than ('2025-02-16 00:00:00'),
    partition dt_20250216 values less than ('2025-02-17 00:00:00'),
    partition dt_20250217 values less than ('2025-02-18 00:00:00'),
    partition dt_20250218 values less than ('2025-02-19 00:00:00'),
    partition dt_20250219 values less than ('2025-02-20 00:00:00'),
    partition dt_20250220 values less than ('2025-02-21 00:00:00'),
    partition dt_20250221 values less than ('2025-02-22 00:00:00'),
    partition dt_20250222 values less than ('2025-02-23 00:00:00'),
    partition dt_20250223 values less than ('2025-02-24 00:00:00'),
    partition dt_20250224 values less than ('2025-02-25 00:00:00'),
    partition dt_20250225 values less than ('2025-02-26 00:00:00'),
    partition dt_20250226 values less than ('2025-02-27 00:00:00'),
    partition dt_20250227 values less than ('2025-02-28 00:00:00'),
    partition dt_20250228 values less than ('2025-03-01 00:00:00'),
    partition dt_20250301 values less than ('2025-03-02 00:00:00'),
    partition dt_20250302 values less than ('2025-03-03 00:00:00'),
    partition dt_20250303 values less than ('2025-03-04 00:00:00'),
    partition dt_20250304 values less than ('2025-03-05 00:00:00'),
    partition dt_20250305 values less than ('2025-03-06 00:00:00'),
    partition dt_20250306 values less than ('2025-03-07 00:00:00'),
    partition dt_20250307 values less than ('2025-03-08 00:00:00'),
    partition dt_20250308 values less than ('2025-03-09 00:00:00'),
    partition dt_20250309 values less than ('2025-03-10 00:00:00'),
    partition dt_20250310 values less than ('2025-03-11 00:00:00'),
    partition dt_20250311 values less than ('2025-03-12 00:00:00'),
    partition dt_20250312 values less than ('2025-03-13 00:00:00'),
    partition dt_20250313 values less than ('2025-03-14 00:00:00'),
    partition dt_20250314 values less than ('2025-03-15 00:00:00'),
    partition dt_20250315 values less than ('2025-03-16 00:00:00'),
    partition dt_20250316 values less than ('2025-03-17 00:00:00'),
    partition dt_20250317 values less than ('2025-03-18 00:00:00'),
    partition dt_20250318 values less than ('2025-03-19 00:00:00'),
    partition dt_20250319 values less than ('2025-03-20 00:00:00'),
    partition dt_20250320 values less than ('2025-03-21 00:00:00'),
    partition dt_20250321 values less than ('2025-03-22 00:00:00'),
    partition dt_20250322 values less than ('2025-03-23 00:00:00'),
    partition dt_20250323 values less than ('2025-03-24 00:00:00'),
    partition dt_20250324 values less than ('2025-03-25 00:00:00'),
    partition dt_20250325 values less than ('2025-03-26 00:00:00'),
    partition dt_20250326 values less than ('2025-03-27 00:00:00'),
    partition dt_20250327 values less than ('2025-03-28 00:00:00'),
    partition dt_20250328 values less than ('2025-03-29 00:00:00'),
    partition dt_20250329 values less than ('2025-03-30 00:00:00'),
    partition dt_20250330 values less than ('2025-03-31 00:00:00'),
    partition dt_20250331 values less than ('2025-04-01 00:00:00'),
    partition dt_20250401 values less than ('2025-04-02 00:00:00'),
    partition dt_20250402 values less than ('2025-04-03 00:00:00'),
    partition dt_20250403 values less than ('2025-04-04 00:00:00'),
    partition dt_20250404 values less than ('2025-04-05 00:00:00'),
    partition dt_20250405 values less than ('2025-04-06 00:00:00'),
    partition dt_20250406 values less than ('2025-04-07 00:00:00'),
    partition dt_20250407 values less than ('2025-04-08 00:00:00'),
    partition dt_20250408 values less than ('2025-04-09 00:00:00'),
    partition dt_20250409 values less than ('2025-04-10 00:00:00'),
    partition dt_20250410 values less than ('2025-04-11 00:00:00'),
    partition dt_20250411 values less than ('2025-04-12 00:00:00'),
    partition dt_20250412 values less than ('2025-04-13 00:00:00'),
    partition dt_20250413 values less than ('2025-04-14 00:00:00'),
    partition dt_20250414 values less than ('2025-04-15 00:00:00'),
    partition dt_20250415 values less than ('2025-04-16 00:00:00'),
    partition dt_20250416 values less than ('2025-04-17 00:00:00'),
    partition dt_20250417 values less than ('2025-04-18 00:00:00'),
    partition dt_20250418 values less than ('2025-04-19 00:00:00'),
    partition dt_20250419 values less than ('2025-04-20 00:00:00'),
    partition dt_20250420 values less than ('2025-04-21 00:00:00'),
    partition dt_20250421 values less than ('2025-04-22 00:00:00'),
    partition dt_20250422 values less than ('2025-04-23 00:00:00'),
    partition dt_20250423 values less than ('2025-04-24 00:00:00'),
    partition dt_20250424 values less than ('2025-04-25 00:00:00'),
    partition dt_20250425 values less than ('2025-04-26 00:00:00'),
    partition dt_20250426 values less than ('2025-04-27 00:00:00'),
    partition dt_20250427 values less than ('2025-04-28 00:00:00'),
    partition dt_20250428 values less than ('2025-04-29 00:00:00'),
    partition dt_20250429 values less than ('2025-04-30 00:00:00'),
    partition dt_20250430 values less than ('2025-05-01 00:00:00'),
    partition dt_20250501 values less than ('2025-05-02 00:00:00'),
    partition dt_20250502 values less than ('2025-05-03 00:00:00'),
    partition dt_20250503 values less than ('2025-05-04 00:00:00'),
    partition dt_20250504 values less than ('2025-05-05 00:00:00'),
    partition dt_20250505 values less than ('2025-05-06 00:00:00'),
    partition dt_20250506 values less than ('2025-05-07 00:00:00'),
    partition dt_20250507 values less than ('2025-05-08 00:00:00'),
    partition dt_20250508 values less than ('2025-05-09 00:00:00'),
    partition dt_20250509 values less than ('2025-05-10 00:00:00'),
    partition dt_20250510 values less than ('2025-05-11 00:00:00'),
    partition dt_20250511 values less than ('2025-05-12 00:00:00'),
    partition dt_20250512 values less than ('2025-05-13 00:00:00'),
    partition dt_20250513 values less than ('2025-05-14 00:00:00'),
    partition dt_20250514 values less than ('2025-05-15 00:00:00'),
    partition dt_20250515 values less than ('2025-05-16 00:00:00'),
    partition dt_20250516 values less than ('2025-05-17 00:00:00'),
    partition dt_20250517 values less than ('2025-05-18 00:00:00'),
    partition dt_20250518 values less than ('2025-05-19 00:00:00'),
    partition dt_20250519 values less than ('2025-05-20 00:00:00'),
    partition dt_20250520 values less than ('2025-05-21 00:00:00'),
    partition dt_20250521 values less than ('2025-05-22 00:00:00'),
    partition dt_20250522 values less than ('2025-05-23 00:00:00'),
    partition dt_20250523 values less than ('2025-05-24 00:00:00'),
    partition dt_20250524 values less than ('2025-05-25 00:00:00'),
    partition dt_20250525 values less than ('2025-05-26 00:00:00'),
    partition dt_20250526 values less than ('2025-05-27 00:00:00'),
    partition dt_20250527 values less than ('2025-05-28 00:00:00'),
    partition dt_20250528 values less than ('2025-05-29 00:00:00'),
    partition dt_20250529 values less than ('2025-05-30 00:00:00'),
    partition dt_20250530 values less than ('2025-05-31 00:00:00'),
    partition dt_20250531 values less than ('2025-06-01 00:00:00'),
    partition dt_20250601 values less than ('2025-06-02 00:00:00'),
    partition dt_20250602 values less than ('2025-06-03 00:00:00'),
    partition dt_20250603 values less than ('2025-06-04 00:00:00'),
    partition dt_20250604 values less than ('2025-06-05 00:00:00'),
    partition dt_20250605 values less than ('2025-06-06 00:00:00'),
    partition dt_20250606 values less than ('2025-06-07 00:00:00'),
    partition dt_20250607 values less than ('2025-06-08 00:00:00'),
    partition dt_20250608 values less than ('2025-06-09 00:00:00'),
    partition dt_20250609 values less than ('2025-06-10 00:00:00'),
    partition dt_20250610 values less than ('2025-06-11 00:00:00'),
    partition dt_20250611 values less than ('2025-06-12 00:00:00'),
    partition dt_20250612 values less than ('2025-06-13 00:00:00'),
    partition dt_20250613 values less than ('2025-06-14 00:00:00'),
    partition dt_20250614 values less than ('2025-06-15 00:00:00'),
    partition dt_20250615 values less than ('2025-06-16 00:00:00'),
    partition dt_20250616 values less than ('2025-06-17 00:00:00'),
    partition dt_20250617 values less than ('2025-06-18 00:00:00'),
    partition dt_20250618 values less than ('2025-06-19 00:00:00'),
    partition dt_20250619 values less than ('2025-06-20 00:00:00'),
    partition dt_20250620 values less than ('2025-06-21 00:00:00'),
    partition dt_20250621 values less than ('2025-06-22 00:00:00'),
    partition dt_20250622 values less than ('2025-06-23 00:00:00'),
    partition dt_20250623 values less than ('2025-06-24 00:00:00'),
    partition dt_20250624 values less than ('2025-06-25 00:00:00'),
    partition dt_20250625 values less than ('2025-06-26 00:00:00'),
    partition dt_20250626 values less than ('2025-06-27 00:00:00'),
    partition dt_20250627 values less than ('2025-06-28 00:00:00'),
    partition dt_20250628 values less than ('2025-06-29 00:00:00'),
    partition dt_20250629 values less than ('2025-06-30 00:00:00'),
    partition dt_20250630 values less than ('2025-07-01 00:00:00'),
    partition dt_20250701 values less than ('2025-07-02 00:00:00'),
    partition dt_20250702 values less than ('2025-07-03 00:00:00'),
    partition dt_20250703 values less than ('2025-07-04 00:00:00'),
    partition dt_20250704 values less than ('2025-07-05 00:00:00'),
    partition dt_20250705 values less than ('2025-07-06 00:00:00'),
    partition dt_20250706 values less than ('2025-07-07 00:00:00'),
    partition dt_20250707 values less than ('2025-07-08 00:00:00'),
    partition dt_20250708 values less than ('2025-07-09 00:00:00'),
    partition dt_20250709 values less than ('2025-07-10 00:00:00'),
    partition dt_20250710 values less than ('2025-07-11 00:00:00'),
    partition dt_20250711 values less than ('2025-07-12 00:00:00'),
    partition dt_20250712 values less than ('2025-07-13 00:00:00'),
    partition dt_20250713 values less than ('2025-07-14 00:00:00'),
    partition dt_20250714 values less than ('2025-07-15 00:00:00'),
    partition dt_20250715 values less than ('2025-07-16 00:00:00'),
    partition dt_20250716 values less than ('2025-07-17 00:00:00'),
    partition dt_20250717 values less than ('2025-07-18 00:00:00'),
    partition dt_20250718 values less than ('2025-07-19 00:00:00'),
    partition dt_20250719 values less than ('2025-07-20 00:00:00'),
    partition dt_20250720 values less than ('2025-07-21 00:00:00'),
    partition dt_20250721 values less than ('2025-07-22 00:00:00'),
    partition dt_20250722 values less than ('2025-07-23 00:00:00'),
    partition dt_20250723 values less than ('2025-07-24 00:00:00'),
    partition dt_20250724 values less than ('2025-07-25 00:00:00'),
    partition dt_20250725 values less than ('2025-07-26 00:00:00'),
    partition dt_20250726 values less than ('2025-07-27 00:00:00'),
    partition dt_20250727 values less than ('2025-07-28 00:00:00'),
    partition dt_20250728 values less than ('2025-07-29 00:00:00'),
    partition dt_20250729 values less than ('2025-07-30 00:00:00'),
    partition dt_20250730 values less than ('2025-07-31 00:00:00'),
    partition dt_20250731 values less than ('2025-08-01 00:00:00'),
    partition dt_20250801 values less than ('2025-08-02 00:00:00'),
    partition dt_20250802 values less than ('2025-08-03 00:00:00'),
    partition dt_20250803 values less than ('2025-08-04 00:00:00'),
    partition dt_20250804 values less than ('2025-08-05 00:00:00'),
    partition dt_20250805 values less than ('2025-08-06 00:00:00'),
    partition dt_20250806 values less than ('2025-08-07 00:00:00'),
    partition dt_20250807 values less than ('2025-08-08 00:00:00'),
    partition dt_20250808 values less than ('2025-08-09 00:00:00'),
    partition dt_20250809 values less than ('2025-08-10 00:00:00'),
    partition dt_20250810 values less than ('2025-08-11 00:00:00'),
    partition dt_20250811 values less than ('2025-08-12 00:00:00'),
    partition dt_20250812 values less than ('2025-08-13 00:00:00'),
    partition dt_20250813 values less than ('2025-08-14 00:00:00'),
    partition dt_20250814 values less than ('2025-08-15 00:00:00'),
    partition dt_20250815 values less than ('2025-08-16 00:00:00'),
    partition dt_20250816 values less than ('2025-08-17 00:00:00'),
    partition dt_20250817 values less than ('2025-08-18 00:00:00'),
    partition dt_20250818 values less than ('2025-08-19 00:00:00'),
    partition dt_20250819 values less than ('2025-08-20 00:00:00'),
    partition dt_20250820 values less than ('2025-08-21 00:00:00'),
    partition dt_20250821 values less than ('2025-08-22 00:00:00'),
    partition dt_20250822 values less than ('2025-08-23 00:00:00'),
    partition dt_20250823 values less than ('2025-08-24 00:00:00'),
    partition dt_20250824 values less than ('2025-08-25 00:00:00'),
    partition dt_20250825 values less than ('2025-08-26 00:00:00'),
    partition dt_20250826 values less than ('2025-08-27 00:00:00'),
    partition dt_20250827 values less than ('2025-08-28 00:00:00'),
    partition dt_20250828 values less than ('2025-08-29 00:00:00'),
    partition dt_20250829 values less than ('2025-08-30 00:00:00'),
    partition dt_20250830 values less than ('2025-08-31 00:00:00'),
    partition dt_20250831 values less than ('2025-09-01 00:00:00'),
    partition dt_20250901 values less than ('2025-09-02 00:00:00'),
    partition dt_20250902 values less than ('2025-09-03 00:00:00'),
    partition dt_20250903 values less than ('2025-09-04 00:00:00'),
    partition dt_20250904 values less than ('2025-09-05 00:00:00'),
    partition dt_20250905 values less than ('2025-09-06 00:00:00'),
    partition dt_20250906 values less than ('2025-09-07 00:00:00'),
    partition dt_20250907 values less than ('2025-09-08 00:00:00'),
    partition dt_20250908 values less than ('2025-09-09 00:00:00'),
    partition dt_20250909 values less than ('2025-09-10 00:00:00'),
    partition dt_20250910 values less than ('2025-09-11 00:00:00'),
    partition dt_20250911 values less than ('2025-09-12 00:00:00'),
    partition dt_20250912 values less than ('2025-09-13 00:00:00'),
    partition dt_20250913 values less than ('2025-09-14 00:00:00'),
    partition dt_20250914 values less than ('2025-09-15 00:00:00'),
    partition dt_20250915 values less than ('2025-09-16 00:00:00'),
    partition dt_20250916 values less than ('2025-09-17 00:00:00'),
    partition dt_20250917 values less than ('2025-09-18 00:00:00'),
    partition dt_20250918 values less than ('2025-09-19 00:00:00'),
    partition dt_20250919 values less than ('2025-09-20 00:00:00'),
    partition dt_20250920 values less than ('2025-09-21 00:00:00'),
    partition dt_20250921 values less than ('2025-09-22 00:00:00'),
    partition dt_20250922 values less than ('2025-09-23 00:00:00'),
    partition dt_20250923 values less than ('2025-09-24 00:00:00'),
    partition dt_20250924 values less than ('2025-09-25 00:00:00'),
    partition dt_20250925 values less than ('2025-09-26 00:00:00'),
    partition dt_20250926 values less than ('2025-09-27 00:00:00'),
    partition dt_20250927 values less than ('2025-09-28 00:00:00'),
    partition dt_20250928 values less than ('2025-09-29 00:00:00'),
    partition dt_20250929 values less than ('2025-09-30 00:00:00'),
    partition dt_20250930 values less than ('2025-10-01 00:00:00'),
    partition dt_20251001 values less than ('2025-10-02 00:00:00'),
    partition dt_20251002 values less than ('2025-10-03 00:00:00'),
    partition dt_20251003 values less than ('2025-10-04 00:00:00'),
    partition dt_20251004 values less than ('2025-10-05 00:00:00'),
    partition dt_20251005 values less than ('2025-10-06 00:00:00'),
    partition dt_20251006 values less than ('2025-10-07 00:00:00'),
    partition dt_20251007 values less than ('2025-10-08 00:00:00'),
    partition dt_20251008 values less than ('2025-10-09 00:00:00'),
    partition dt_20251009 values less than ('2025-10-10 00:00:00'),
    partition dt_20251010 values less than ('2025-10-11 00:00:00'),
    partition dt_20251011 values less than ('2025-10-12 00:00:00'),
    partition dt_20251012 values less than ('2025-10-13 00:00:00'),
    partition dt_20251013 values less than ('2025-10-14 00:00:00'),
    partition dt_20251014 values less than ('2025-10-15 00:00:00'),
    partition dt_20251015 values less than ('2025-10-16 00:00:00'),
    partition dt_20251016 values less than ('2025-10-17 00:00:00'),
    partition dt_20251017 values less than ('2025-10-18 00:00:00'),
    partition dt_20251018 values less than ('2025-10-19 00:00:00'),
    partition dt_20251019 values less than ('2025-10-20 00:00:00'),
    partition dt_20251020 values less than ('2025-10-21 00:00:00'),
    partition dt_20251021 values less than ('2025-10-22 00:00:00'),
    partition dt_20251022 values less than ('2025-10-23 00:00:00'),
    partition dt_20251023 values less than ('2025-10-24 00:00:00'),
    partition dt_20251024 values less than ('2025-10-25 00:00:00'),
    partition dt_20251025 values less than ('2025-10-26 00:00:00'),
    partition dt_20251026 values less than ('2025-10-27 00:00:00'),
    partition dt_20251027 values less than ('2025-10-28 00:00:00'),
    partition dt_20251028 values less than ('2025-10-29 00:00:00'),
    partition dt_20251029 values less than ('2025-10-30 00:00:00'),
    partition dt_20251030 values less than ('2025-10-31 00:00:00'),
    partition dt_20251031 values less than ('2025-11-01 00:00:00'),
    partition dt_20251101 values less than ('2025-11-02 00:00:00'),
    partition dt_20251102 values less than ('2025-11-03 00:00:00'),
    partition dt_20251103 values less than ('2025-11-04 00:00:00'),
    partition dt_20251104 values less than ('2025-11-05 00:00:00'),
    partition dt_20251105 values less than ('2025-11-06 00:00:00'),
    partition dt_20251106 values less than ('2025-11-07 00:00:00'),
    partition dt_20251107 values less than ('2025-11-08 00:00:00'),
    partition dt_20251108 values less than ('2025-11-09 00:00:00'),
    partition dt_20251109 values less than ('2025-11-10 00:00:00'),
    partition dt_20251110 values less than ('2025-11-11 00:00:00'),
    partition dt_20251111 values less than ('2025-11-12 00:00:00'),
    partition dt_20251112 values less than ('2025-11-13 00:00:00'),
    partition dt_20251113 values less than ('2025-11-14 00:00:00'),
    partition dt_20251114 values less than ('2025-11-15 00:00:00'),
    partition dt_20251115 values less than ('2025-11-16 00:00:00'),
    partition dt_20251116 values less than ('2025-11-17 00:00:00'),
    partition dt_20251117 values less than ('2025-11-18 00:00:00'),
    partition dt_20251118 values less than ('2025-11-19 00:00:00'),
    partition dt_20251119 values less than ('2025-11-20 00:00:00'),
    partition dt_20251120 values less than ('2025-11-21 00:00:00'),
    partition dt_20251121 values less than ('2025-11-22 00:00:00'),
    partition dt_20251122 values less than ('2025-11-23 00:00:00'),
    partition dt_20251123 values less than ('2025-11-24 00:00:00'),
    partition dt_20251124 values less than ('2025-11-25 00:00:00'),
    partition dt_20251125 values less than ('2025-11-26 00:00:00'),
    partition dt_20251126 values less than ('2025-11-27 00:00:00'),
    partition dt_20251127 values less than ('2025-11-28 00:00:00'),
    partition dt_20251128 values less than ('2025-11-29 00:00:00'),
    partition dt_20251129 values less than ('2025-11-30 00:00:00'),
    partition dt_20251130 values less than ('2025-12-01 00:00:00'),
    partition dt_20251201 values less than ('2025-12-02 00:00:00'),
    partition dt_20251202 values less than ('2025-12-03 00:00:00'),
    partition dt_20251203 values less than ('2025-12-04 00:00:00'),
    partition dt_20251204 values less than ('2025-12-05 00:00:00'),
    partition dt_20251205 values less than ('2025-12-06 00:00:00'),
    partition dt_20251206 values less than ('2025-12-07 00:00:00'),
    partition dt_20251207 values less than ('2025-12-08 00:00:00'),
    partition dt_20251208 values less than ('2025-12-09 00:00:00'),
    partition dt_20251209 values less than ('2025-12-10 00:00:00'),
    partition dt_20251210 values less than ('2025-12-11 00:00:00'),
    partition dt_20251211 values less than ('2025-12-12 00:00:00'),
    partition dt_20251212 values less than ('2025-12-13 00:00:00'),
    partition dt_20251213 values less than ('2025-12-14 00:00:00'),
    partition dt_20251214 values less than ('2025-12-15 00:00:00'),
    partition dt_20251215 values less than ('2025-12-16 00:00:00'),
    partition dt_20251216 values less than ('2025-12-17 00:00:00'),
    partition dt_20251217 values less than ('2025-12-18 00:00:00'),
    partition dt_20251218 values less than ('2025-12-19 00:00:00'),
    partition dt_20251219 values less than ('2025-12-20 00:00:00'),
    partition dt_20251220 values less than ('2025-12-21 00:00:00'),
    partition dt_20251221 values less than ('2025-12-22 00:00:00'),
    partition dt_20251222 values less than ('2025-12-23 00:00:00'),
    partition dt_20251223 values less than ('2025-12-24 00:00:00'),
    partition dt_20251224 values less than ('2025-12-25 00:00:00'),
    partition dt_20251225 values less than ('2025-12-26 00:00:00'),
    partition dt_20251226 values less than ('2025-12-27 00:00:00'),
    partition dt_20251227 values less than ('2025-12-28 00:00:00'),
    partition dt_20251228 values less than ('2025-12-29 00:00:00'),
    partition dt_20251229 values less than ('2025-12-30 00:00:00'),
    partition dt_20251230 values less than ('2025-12-31 00:00:00'),
    partition dt_20251231 values less than ('2026-01-01 00:00:00'),
    partition dt_20260101 values less than ('2026-01-02 00:00:00'),
    partition dt_20260102 values less than ('2026-01-03 00:00:00'),
    partition dt_20260103 values less than ('2026-01-04 00:00:00'),
    partition dt_20260104 values less than ('2026-01-05 00:00:00'),
    partition dt_20260105 values less than ('2026-01-06 00:00:00'),
    partition dt_20260106 values less than ('2026-01-07 00:00:00'),
    partition dt_20260107 values less than ('2026-01-08 00:00:00'),
    partition dt_20260108 values less than ('2026-01-09 00:00:00'),
    partition dt_20260109 values less than ('2026-01-10 00:00:00'),
    partition dt_20260110 values less than ('2026-01-11 00:00:00'),
    partition dt_20260111 values less than ('2026-01-12 00:00:00'),
    partition dt_20260112 values less than ('2026-01-13 00:00:00'),
    partition dt_20260113 values less than ('2026-01-14 00:00:00'),
    partition dt_20260114 values less than ('2026-01-15 00:00:00'),
    partition dt_20260115 values less than ('2026-01-16 00:00:00'),
    partition dt_20260116 values less than ('2026-01-17 00:00:00'),
    partition dt_20260117 values less than ('2026-01-18 00:00:00'),
    partition dt_20260118 values less than ('2026-01-19 00:00:00'),
    partition dt_20260119 values less than ('2026-01-20 00:00:00'),
    partition dt_20260120 values less than ('2026-01-21 00:00:00'),
    partition dt_20260121 values less than ('2026-01-22 00:00:00'),
    partition dt_20260122 values less than ('2026-01-23 00:00:00'),
    partition dt_20260123 values less than ('2026-01-24 00:00:00'),
    partition dt_20260124 values less than ('2026-01-25 00:00:00'),
    partition dt_20260125 values less than ('2026-01-26 00:00:00'),
    partition dt_20260126 values less than ('2026-01-27 00:00:00'),
    partition dt_20260127 values less than ('2026-01-28 00:00:00'),
    partition dt_20260128 values less than ('2026-01-29 00:00:00'),
    partition dt_20260129 values less than ('2026-01-30 00:00:00'),
    partition dt_20260130 values less than ('2026-01-31 00:00:00'),
    partition dt_20260131 values less than ('2026-02-01 00:00:00'),
    partition dt_20260201 values less than ('2026-02-02 00:00:00'),
    partition dt_20260202 values less than ('2026-02-03 00:00:00'),
    partition dt_20260203 values less than ('2026-02-04 00:00:00'),
    partition dt_20260204 values less than ('2026-02-05 00:00:00'),
    partition dt_20260205 values less than ('2026-02-06 00:00:00'),
    partition dt_20260206 values less than ('2026-02-07 00:00:00'),
    partition dt_20260207 values less than ('2026-02-08 00:00:00'),
    partition dt_20260208 values less than ('2026-02-09 00:00:00'),
    partition dt_20260209 values less than ('2026-02-10 00:00:00'),
    partition dt_20260210 values less than ('2026-02-11 00:00:00'),
    partition dt_20260211 values less than ('2026-02-12 00:00:00'),
    partition dt_20260212 values less than ('2026-02-13 00:00:00'),
    partition dt_20260213 values less than ('2026-02-14 00:00:00'),
    partition dt_20260214 values less than ('2026-02-15 00:00:00'),
    partition dt_20260215 values less than ('2026-02-16 00:00:00'),
    partition dt_20260216 values less than ('2026-02-17 00:00:00'),
    partition dt_20260217 values less than ('2026-02-18 00:00:00'),
    partition dt_20260218 values less than ('2026-02-19 00:00:00'),
    partition dt_20260219 values less than ('2026-02-20 00:00:00'),
    partition dt_20260220 values less than ('2026-02-21 00:00:00'),
    partition dt_20260221 values less than ('2026-02-22 00:00:00'),
    partition dt_20260222 values less than ('2026-02-23 00:00:00'),
    partition dt_20260223 values less than ('2026-02-24 00:00:00'),
    partition dt_20260224 values less than ('2026-02-25 00:00:00'),
    partition dt_20260225 values less than ('2026-02-26 00:00:00'),
    partition dt_20260226 values less than ('2026-02-27 00:00:00'),
    partition dt_20260227 values less than ('2026-02-28 00:00:00'),
    partition dt_20260228 values less than ('2026-03-01 00:00:00'),
    partition dt_20260301 values less than ('2026-03-02 00:00:00'),
    partition dt_20260302 values less than ('2026-03-03 00:00:00'),
    partition dt_20260303 values less than ('2026-03-04 00:00:00'),
    partition dt_20260304 values less than ('2026-03-05 00:00:00'),
    partition dt_20260305 values less than ('2026-03-06 00:00:00'),
    partition dt_20260306 values less than ('2026-03-07 00:00:00'),
    partition dt_20260307 values less than ('2026-03-08 00:00:00'),
    partition dt_20260308 values less than ('2026-03-09 00:00:00'),
    partition dt_20260309 values less than ('2026-03-10 00:00:00'),
    partition dt_20260310 values less than ('2026-03-11 00:00:00'),
    partition dt_20260311 values less than ('2026-03-12 00:00:00'),
    partition dt_20260312 values less than ('2026-03-13 00:00:00'),
    partition dt_20260313 values less than ('2026-03-14 00:00:00'),
    partition dt_20260314 values less than ('2026-03-15 00:00:00'),
    partition dt_20260315 values less than ('2026-03-16 00:00:00'),
    partition dt_20260316 values less than ('2026-03-17 00:00:00'),
    partition dt_20260317 values less than ('2026-03-18 00:00:00'),
    partition dt_20260318 values less than ('2026-03-19 00:00:00'),
    partition dt_20260319 values less than ('2026-03-20 00:00:00'),
    partition dt_20260320 values less than ('2026-03-21 00:00:00'),
    partition dt_20260321 values less than ('2026-03-22 00:00:00'),
    partition dt_20260322 values less than ('2026-03-23 00:00:00'),
    partition dt_20260323 values less than ('2026-03-24 00:00:00'),
    partition dt_20260324 values less than ('2026-03-25 00:00:00'),
    partition dt_20260325 values less than ('2026-03-26 00:00:00'),
    partition dt_20260326 values less than ('2026-03-27 00:00:00'),
    partition dt_20260327 values less than ('2026-03-28 00:00:00'),
    partition dt_20260328 values less than ('2026-03-29 00:00:00'),
    partition dt_20260329 values less than ('2026-03-30 00:00:00'),
    partition dt_20260330 values less than ('2026-03-31 00:00:00'),
    partition dt_20260331 values less than ('2026-04-01 00:00:00'),
    partition dt_20260401 values less than ('2026-04-02 00:00:00'),
    partition dt_20260402 values less than ('2026-04-03 00:00:00'),
    partition dt_20260403 values less than ('2026-04-04 00:00:00'),
    partition dt_20260404 values less than ('2026-04-05 00:00:00'),
    partition dt_20260405 values less than ('2026-04-06 00:00:00'),
    partition dt_20260406 values less than ('2026-04-07 00:00:00'),
    partition dt_20260407 values less than ('2026-04-08 00:00:00'),
    partition dt_20260408 values less than ('2026-04-09 00:00:00'),
    partition dt_20260409 values less than ('2026-04-10 00:00:00'),
    partition dt_20260410 values less than ('2026-04-11 00:00:00'),
    partition dt_20260411 values less than ('2026-04-12 00:00:00'),
    partition dt_20260412 values less than ('2026-04-13 00:00:00'),
    partition dt_20260413 values less than ('2026-04-14 00:00:00'),
    partition dt_20260414 values less than ('2026-04-15 00:00:00'),
    partition dt_20260415 values less than ('2026-04-16 00:00:00'),
    partition dt_20260416 values less than ('2026-04-17 00:00:00'),
    partition dt_20260417 values less than ('2026-04-18 00:00:00'),
    partition dt_20260418 values less than ('2026-04-19 00:00:00'),
    partition dt_20260419 values less than ('2026-04-20 00:00:00'),
    partition dt_20260420 values less than ('2026-04-21 00:00:00'),
    partition dt_20260421 values less than ('2026-04-22 00:00:00'),
    partition dt_20260422 values less than ('2026-04-23 00:00:00'),
    partition dt_20260423 values less than ('2026-04-24 00:00:00'),
    partition dt_20260424 values less than ('2026-04-25 00:00:00'),
    partition dt_20260425 values less than ('2026-04-26 00:00:00'),
    partition dt_20260426 values less than ('2026-04-27 00:00:00'),
    partition dt_20260427 values less than ('2026-04-28 00:00:00'),
    partition dt_20260428 values less than ('2026-04-29 00:00:00'),
    partition dt_20260429 values less than ('2026-04-30 00:00:00'),
    partition dt_20260430 values less than ('2026-05-01 00:00:00'),
    partition dt_20260501 values less than ('2026-05-02 00:00:00'),
    partition dt_20260502 values less than ('2026-05-03 00:00:00'),
    partition dt_20260503 values less than ('2026-05-04 00:00:00'),
    partition dt_20260504 values less than ('2026-05-05 00:00:00'),
    partition dt_20260505 values less than ('2026-05-06 00:00:00'),
    partition dt_20260506 values less than ('2026-05-07 00:00:00'),
    partition dt_20260507 values less than ('2026-05-08 00:00:00'),
    partition dt_20260508 values less than ('2026-05-09 00:00:00'),
    partition dt_20260509 values less than ('2026-05-10 00:00:00'),
    partition dt_20260510 values less than ('2026-05-11 00:00:00'),
    partition dt_20260511 values less than ('2026-05-12 00:00:00'),
    partition dt_20260512 values less than ('2026-05-13 00:00:00'),
    partition dt_20260513 values less than ('2026-05-14 00:00:00'),
    partition dt_20260514 values less than ('2026-05-15 00:00:00'),
    partition dt_20260515 values less than ('2026-05-16 00:00:00'),
    partition dt_20260516 values less than ('2026-05-17 00:00:00'),
    partition dt_20260517 values less than ('2026-05-18 00:00:00'),
    partition dt_20260518 values less than ('2026-05-19 00:00:00'),
    partition dt_20260519 values less than ('2026-05-20 00:00:00'),
    partition dt_20260520 values less than ('2026-05-21 00:00:00'),
    partition dt_20260521 values less than ('2026-05-22 00:00:00'),
    partition dt_20260522 values less than ('2026-05-23 00:00:00'),
    partition dt_20260523 values less than ('2026-05-24 00:00:00'),
    partition dt_20260524 values less than ('2026-05-25 00:00:00'),
    partition dt_20260525 values less than ('2026-05-26 00:00:00'),
    partition dt_20260526 values less than ('2026-05-27 00:00:00'),
    partition dt_20260527 values less than ('2026-05-28 00:00:00'),
    partition dt_20260528 values less than ('2026-05-29 00:00:00'),
    partition dt_20260529 values less than ('2026-05-30 00:00:00'),
    partition dt_20260530 values less than ('2026-05-31 00:00:00'),
    partition dt_20260531 values less than ('2026-06-01 00:00:00'),
    partition dt_20260601 values less than ('2026-06-02 00:00:00'),
    partition dt_20260602 values less than ('2026-06-03 00:00:00'),
    partition dt_20260603 values less than ('2026-06-04 00:00:00'),
    partition dt_20260604 values less than ('2026-06-05 00:00:00'),
    partition dt_20260605 values less than ('2026-06-06 00:00:00'),
    partition dt_20260606 values less than ('2026-06-07 00:00:00'),
    partition dt_20260607 values less than ('2026-06-08 00:00:00'),
    partition dt_20260608 values less than ('2026-06-09 00:00:00'),
    partition dt_20260609 values less than ('2026-06-10 00:00:00'),
    partition dt_20260610 values less than ('2026-06-11 00:00:00'),
    partition dt_20260611 values less than ('2026-06-12 00:00:00'),
    partition dt_20260612 values less than ('2026-06-13 00:00:00'),
    partition dt_20260613 values less than ('2026-06-14 00:00:00'),
    partition dt_20260614 values less than ('2026-06-15 00:00:00'),
    partition dt_20260615 values less than ('2026-06-16 00:00:00'),
    partition dt_20260616 values less than ('2026-06-17 00:00:00'),
    partition dt_20260617 values less than ('2026-06-18 00:00:00'),
    partition dt_20260618 values less than ('2026-06-19 00:00:00'),
    partition dt_20260619 values less than ('2026-06-20 00:00:00'),
    partition dt_20260620 values less than ('2026-06-21 00:00:00'),
    partition dt_20260621 values less than ('2026-06-22 00:00:00'),
    partition dt_20260622 values less than ('2026-06-23 00:00:00'),
    partition dt_20260623 values less than ('2026-06-24 00:00:00'),
    partition dt_20260624 values less than ('2026-06-25 00:00:00'),
    partition dt_20260625 values less than ('2026-06-26 00:00:00'),
    partition dt_20260626 values less than ('2026-06-27 00:00:00'),
    partition dt_20260627 values less than ('2026-06-28 00:00:00'),
    partition dt_20260628 values less than ('2026-06-29 00:00:00'),
    partition dt_20260629 values less than ('2026-06-30 00:00:00'),
    partition dt_20260630 values less than ('2026-07-01 00:00:00'),
    partition dt_20260701 values less than ('2026-07-02 00:00:00'),
    partition dt_20260702 values less than ('2026-07-03 00:00:00'),
    partition dt_20260703 values less than ('2026-07-04 00:00:00'),
    partition dt_20260704 values less than ('2026-07-05 00:00:00'),
    partition dt_20260705 values less than ('2026-07-06 00:00:00'),
    partition dt_20260706 values less than ('2026-07-07 00:00:00'),
    partition dt_20260707 values less than ('2026-07-08 00:00:00'),
    partition dt_20260708 values less than ('2026-07-09 00:00:00'),
    partition dt_20260709 values less than ('2026-07-10 00:00:00'),
    partition dt_20260710 values less than ('2026-07-11 00:00:00'),
    partition dt_20260711 values less than ('2026-07-12 00:00:00'),
    partition dt_20260712 values less than ('2026-07-13 00:00:00'),
    partition dt_20260713 values less than ('2026-07-14 00:00:00'),
    partition dt_20260714 values less than ('2026-07-15 00:00:00'),
    partition dt_20260715 values less than ('2026-07-16 00:00:00'),
    partition dt_20260716 values less than ('2026-07-17 00:00:00'),
    partition dt_20260717 values less than ('2026-07-18 00:00:00'),
    partition dt_20260718 values less than ('2026-07-19 00:00:00'),
    partition dt_20260719 values less than ('2026-07-20 00:00:00'),
    partition dt_20260720 values less than ('2026-07-21 00:00:00'),
    partition dt_20260721 values less than ('2026-07-22 00:00:00'),
    partition dt_20260722 values less than ('2026-07-23 00:00:00'),
    partition dt_20260723 values less than ('2026-07-24 00:00:00'),
    partition dt_20260724 values less than ('2026-07-25 00:00:00'),
    partition dt_20260725 values less than ('2026-07-26 00:00:00'),
    partition dt_20260726 values less than ('2026-07-27 00:00:00'),
    partition dt_20260727 values less than ('2026-07-28 00:00:00'),
    partition dt_20260728 values less than ('2026-07-29 00:00:00'),
    partition dt_20260729 values less than ('2026-07-30 00:00:00'),
    partition dt_20260730 values less than ('2026-07-31 00:00:00'),
    partition dt_20260731 values less than ('2026-08-01 00:00:00'),
    partition dt_20260801 values less than ('2026-08-02 00:00:00'),
    partition dt_20260802 values less than ('2026-08-03 00:00:00'),
    partition dt_20260803 values less than ('2026-08-04 00:00:00'),
    partition dt_20260804 values less than ('2026-08-05 00:00:00'),
    partition dt_20260805 values less than ('2026-08-06 00:00:00'),
    partition dt_20260806 values less than ('2026-08-07 00:00:00'),
    partition dt_20260807 values less than ('2026-08-08 00:00:00'),
    partition dt_20260808 values less than ('2026-08-09 00:00:00'),
    partition dt_20260809 values less than ('2026-08-10 00:00:00'),
    partition dt_20260810 values less than ('2026-08-11 00:00:00'),
    partition dt_20260811 values less than ('2026-08-12 00:00:00'),
    partition dt_20260812 values less than ('2026-08-13 00:00:00'),
    partition dt_20260813 values less than ('2026-08-14 00:00:00'),
    partition dt_20260814 values less than ('2026-08-15 00:00:00'),
    partition dt_20260815 values less than ('2026-08-16 00:00:00'),
    partition dt_20260816 values less than ('2026-08-17 00:00:00'),
    partition dt_20260817 values less than ('2026-08-18 00:00:00'),
    partition dt_20260818 values less than ('2026-08-19 00:00:00'),
    partition dt_20260819 values less than ('2026-08-20 00:00:00'),
    partition dt_20260820 values less than ('2026-08-21 00:00:00'),
    partition dt_20260821 values less than ('2026-08-22 00:00:00'),
    partition dt_20260822 values less than ('2026-08-23 00:00:00'),
    partition dt_20260823 values less than ('2026-08-24 00:00:00'),
    partition dt_20260824 values less than ('2026-08-25 00:00:00'),
    partition dt_20260825 values less than ('2026-08-26 00:00:00'),
    partition dt_20260826 values less than ('2026-08-27 00:00:00'),
    partition dt_20260827 values less than ('2026-08-28 00:00:00'),
    partition dt_20260828 values less than ('2026-08-29 00:00:00'),
    partition dt_20260829 values less than ('2026-08-30 00:00:00'),
    partition dt_20260830 values less than ('2026-08-31 00:00:00'),
    partition dt_20260831 values less than ('2026-09-01 00:00:00'),
    partition dt_20260901 values less than ('2026-09-02 00:00:00'),
    partition dt_20260902 values less than ('2026-09-03 00:00:00'),
    partition dt_20260903 values less than ('2026-09-04 00:00:00'),
    partition dt_20260904 values less than ('2026-09-05 00:00:00'),
    partition dt_20260905 values less than ('2026-09-06 00:00:00'),
    partition dt_20260906 values less than ('2026-09-07 00:00:00'),
    partition dt_20260907 values less than ('2026-09-08 00:00:00'),
    partition dt_20260908 values less than ('2026-09-09 00:00:00'),
    partition dt_20260909 values less than ('2026-09-10 00:00:00'),
    partition dt_20260910 values less than ('2026-09-11 00:00:00'),
    partition dt_20260911 values less than ('2026-09-12 00:00:00'),
    partition dt_20260912 values less than ('2026-09-13 00:00:00'),
    partition dt_20260913 values less than ('2026-09-14 00:00:00'),
    partition dt_20260914 values less than ('2026-09-15 00:00:00'),
    partition dt_20260915 values less than ('2026-09-16 00:00:00'),
    partition dt_20260916 values less than ('2026-09-17 00:00:00'),
    partition dt_20260917 values less than ('2026-09-18 00:00:00'),
    partition dt_20260918 values less than ('2026-09-19 00:00:00'),
    partition dt_20260919 values less than ('2026-09-20 00:00:00'),
    partition dt_20260920 values less than ('2026-09-21 00:00:00'),
    partition dt_20260921 values less than ('2026-09-22 00:00:00'),
    partition dt_20260922 values less than ('2026-09-23 00:00:00'),
    partition dt_20260923 values less than ('2026-09-24 00:00:00'),
    partition dt_20260924 values less than ('2026-09-25 00:00:00'),
    partition dt_20260925 values less than ('2026-09-26 00:00:00'),
    partition dt_20260926 values less than ('2026-09-27 00:00:00'),
    partition dt_20260927 values less than ('2026-09-28 00:00:00'),
    partition dt_20260928 values less than ('2026-09-29 00:00:00'),
    partition dt_20260929 values less than ('2026-09-30 00:00:00'),
    partition dt_20260930 values less than ('2026-10-01 00:00:00'),
    partition dt_20261001 values less than ('2026-10-02 00:00:00'),
    partition dt_20261002 values less than ('2026-10-03 00:00:00'),
    partition dt_20261003 values less than ('2026-10-04 00:00:00'),
    partition dt_20261004 values less than ('2026-10-05 00:00:00'),
    partition dt_20261005 values less than ('2026-10-06 00:00:00'),
    partition dt_20261006 values less than ('2026-10-07 00:00:00'),
    partition dt_20261007 values less than ('2026-10-08 00:00:00'),
    partition dt_20261008 values less than ('2026-10-09 00:00:00'),
    partition dt_20261009 values less than ('2026-10-10 00:00:00'),
    partition dt_20261010 values less than ('2026-10-11 00:00:00'),
    partition dt_20261011 values less than ('2026-10-12 00:00:00'),
    partition dt_20261012 values less than ('2026-10-13 00:00:00'),
    partition dt_20261013 values less than ('2026-10-14 00:00:00'),
    partition dt_20261014 values less than ('2026-10-15 00:00:00'),
    partition dt_20261015 values less than ('2026-10-16 00:00:00'),
    partition dt_20261016 values less than ('2026-10-17 00:00:00'),
    partition dt_20261017 values less than ('2026-10-18 00:00:00'),
    partition dt_20261018 values less than ('2026-10-19 00:00:00'),
    partition dt_20261019 values less than ('2026-10-20 00:00:00'),
    partition dt_20261020 values less than ('2026-10-21 00:00:00'),
    partition dt_20261021 values less than ('2026-10-22 00:00:00'),
    partition dt_20261022 values less than ('2026-10-23 00:00:00'),
    partition dt_20261023 values less than ('2026-10-24 00:00:00'),
    partition dt_20261024 values less than ('2026-10-25 00:00:00'),
    partition dt_20261025 values less than ('2026-10-26 00:00:00'),
    partition dt_20261026 values less than ('2026-10-27 00:00:00'),
    partition dt_20261027 values less than ('2026-10-28 00:00:00'),
    partition dt_20261028 values less than ('2026-10-29 00:00:00'),
    partition dt_20261029 values less than ('2026-10-30 00:00:00'),
    partition dt_20261030 values less than ('2026-10-31 00:00:00'),
    partition dt_20261031 values less than ('2026-11-01 00:00:00'),
    partition dt_20261101 values less than ('2026-11-02 00:00:00'),
    partition dt_20261102 values less than ('2026-11-03 00:00:00'),
    partition dt_20261103 values less than ('2026-11-04 00:00:00'),
    partition dt_20261104 values less than ('2026-11-05 00:00:00'),
    partition dt_20261105 values less than ('2026-11-06 00:00:00'),
    partition dt_20261106 values less than ('2026-11-07 00:00:00'),
    partition dt_20261107 values less than ('2026-11-08 00:00:00'),
    partition dt_20261108 values less than ('2026-11-09 00:00:00'),
    partition dt_20261109 values less than ('2026-11-10 00:00:00'),
    partition dt_20261110 values less than ('2026-11-11 00:00:00'),
    partition dt_20261111 values less than ('2026-11-12 00:00:00'),
    partition dt_20261112 values less than ('2026-11-13 00:00:00'),
    partition dt_20261113 values less than ('2026-11-14 00:00:00'),
    partition dt_20261114 values less than ('2026-11-15 00:00:00'),
    partition dt_20261115 values less than ('2026-11-16 00:00:00'),
    partition dt_20261116 values less than ('2026-11-17 00:00:00'),
    partition dt_20261117 values less than ('2026-11-18 00:00:00'),
    partition dt_20261118 values less than ('2026-11-19 00:00:00'),
    partition dt_20261119 values less than ('2026-11-20 00:00:00'),
    partition dt_20261120 values less than ('2026-11-21 00:00:00'),
    partition dt_20261121 values less than ('2026-11-22 00:00:00'),
    partition dt_20261122 values less than ('2026-11-23 00:00:00'),
    partition dt_20261123 values less than ('2026-11-24 00:00:00'),
    partition dt_20261124 values less than ('2026-11-25 00:00:00'),
    partition dt_20261125 values less than ('2026-11-26 00:00:00'),
    partition dt_20261126 values less than ('2026-11-27 00:00:00'),
    partition dt_20261127 values less than ('2026-11-28 00:00:00'),
    partition dt_20261128 values less than ('2026-11-29 00:00:00'),
    partition dt_20261129 values less than ('2026-11-30 00:00:00'),
    partition dt_20261130 values less than ('2026-12-01 00:00:00'),
    partition dt_20261201 values less than ('2026-12-02 00:00:00'),
    partition dt_20261202 values less than ('2026-12-03 00:00:00'),
    partition dt_20261203 values less than ('2026-12-04 00:00:00'),
    partition dt_20261204 values less than ('2026-12-05 00:00:00'),
    partition dt_20261205 values less than ('2026-12-06 00:00:00'),
    partition dt_20261206 values less than ('2026-12-07 00:00:00'),
    partition dt_20261207 values less than ('2026-12-08 00:00:00'),
    partition dt_20261208 values less than ('2026-12-09 00:00:00'),
    partition dt_20261209 values less than ('2026-12-10 00:00:00'),
    partition dt_20261210 values less than ('2026-12-11 00:00:00'),
    partition dt_20261211 values less than ('2026-12-12 00:00:00'),
    partition dt_20261212 values less than ('2026-12-13 00:00:00'),
    partition dt_20261213 values less than ('2026-12-14 00:00:00'),
    partition dt_20261214 values less than ('2026-12-15 00:00:00'),
    partition dt_20261215 values less than ('2026-12-16 00:00:00'),
    partition dt_20261216 values less than ('2026-12-17 00:00:00'),
    partition dt_20261217 values less than ('2026-12-18 00:00:00'),
    partition dt_20261218 values less than ('2026-12-19 00:00:00'),
    partition dt_20261219 values less than ('2026-12-20 00:00:00'),
    partition dt_20261220 values less than ('2026-12-21 00:00:00'),
    partition dt_20261221 values less than ('2026-12-22 00:00:00'),
    partition dt_20261222 values less than ('2026-12-23 00:00:00'),
    partition dt_20261223 values less than ('2026-12-24 00:00:00'),
    partition dt_20261224 values less than ('2026-12-25 00:00:00'),
    partition dt_20261225 values less than ('2026-12-26 00:00:00'),
    partition dt_20261226 values less than ('2026-12-27 00:00:00'),
    partition dt_20261227 values less than ('2026-12-28 00:00:00'),
    partition dt_20261228 values less than ('2026-12-29 00:00:00'),
    partition dt_20261229 values less than ('2026-12-30 00:00:00'),
    partition dt_20261230 values less than ('2026-12-31 00:00:00'),
    partition dt_20261231 values less than ('2027-01-01 00:00:00'),
    partition dt_20270101 values less than ('2027-01-02 00:00:00'),
    partition dt_20270102 values less than ('2027-01-03 00:00:00'),
    partition dt_20270103 values less than ('2027-01-04 00:00:00'),
    partition dt_20270104 values less than ('2027-01-05 00:00:00'),
    partition dt_20270105 values less than ('2027-01-06 00:00:00'),
    partition dt_20270106 values less than ('2027-01-07 00:00:00'),
    partition dt_20270107 values less than ('2027-01-08 00:00:00'),
    partition dt_20270108 values less than ('2027-01-09 00:00:00'),
    partition dt_20270109 values less than ('2027-01-10 00:00:00'),
    partition dt_20270110 values less than ('2027-01-11 00:00:00'),
    partition dt_20270111 values less than ('2027-01-12 00:00:00'),
    partition dt_20270112 values less than ('2027-01-13 00:00:00'),
    partition dt_20270113 values less than ('2027-01-14 00:00:00'),
    partition dt_20270114 values less than ('2027-01-15 00:00:00'),
    partition dt_20270115 values less than ('2027-01-16 00:00:00'),
    partition dt_20270116 values less than ('2027-01-17 00:00:00'),
    partition dt_20270117 values less than ('2027-01-18 00:00:00'),
    partition dt_20270118 values less than ('2027-01-19 00:00:00'),
    partition dt_20270119 values less than ('2027-01-20 00:00:00'),
    partition dt_20270120 values less than ('2027-01-21 00:00:00'),
    partition dt_20270121 values less than ('2027-01-22 00:00:00'),
    partition dt_20270122 values less than ('2027-01-23 00:00:00'),
    partition dt_20270123 values less than ('2027-01-24 00:00:00'),
    partition dt_20270124 values less than ('2027-01-25 00:00:00'),
    partition dt_20270125 values less than ('2027-01-26 00:00:00'),
    partition dt_20270126 values less than ('2027-01-27 00:00:00'),
    partition dt_20270127 values less than ('2027-01-28 00:00:00'),
    partition dt_20270128 values less than ('2027-01-29 00:00:00'),
    partition dt_20270129 values less than ('2027-01-30 00:00:00'),
    partition dt_20270130 values less than ('2027-01-31 00:00:00'),
    partition dt_20270131 values less than ('2027-02-01 00:00:00'),
    partition dt_20270201 values less than ('2027-02-02 00:00:00'),
    partition dt_20270202 values less than ('2027-02-03 00:00:00'),
    partition dt_20270203 values less than ('2027-02-04 00:00:00'),
    partition dt_20270204 values less than ('2027-02-05 00:00:00'),
    partition dt_20270205 values less than ('2027-02-06 00:00:00'),
    partition dt_20270206 values less than ('2027-02-07 00:00:00'),
    partition dt_20270207 values less than ('2027-02-08 00:00:00'),
    partition dt_20270208 values less than ('2027-02-09 00:00:00'),
    partition dt_20270209 values less than ('2027-02-10 00:00:00'),
    partition dt_20270210 values less than ('2027-02-11 00:00:00'),
    partition dt_20270211 values less than ('2027-02-12 00:00:00'),
    partition dt_20270212 values less than ('2027-02-13 00:00:00'),
    partition dt_20270213 values less than ('2027-02-14 00:00:00'),
    partition dt_20270214 values less than ('2027-02-15 00:00:00'),
    partition dt_20270215 values less than ('2027-02-16 00:00:00'),
    partition dt_20270216 values less than ('2027-02-17 00:00:00'),
    partition dt_20270217 values less than ('2027-02-18 00:00:00'),
    partition dt_20270218 values less than ('2027-02-19 00:00:00'),
    partition dt_20270219 values less than ('2027-02-20 00:00:00'),
    partition dt_20270220 values less than ('2027-02-21 00:00:00'),
    partition dt_20270221 values less than ('2027-02-22 00:00:00'),
    partition dt_20270222 values less than ('2027-02-23 00:00:00'),
    partition dt_20270223 values less than ('2027-02-24 00:00:00'),
    partition dt_20270224 values less than ('2027-02-25 00:00:00'),
    partition dt_20270225 values less than ('2027-02-26 00:00:00'),
    partition dt_20270226 values less than ('2027-02-27 00:00:00'),
    partition dt_20270227 values less than ('2027-02-28 00:00:00'),
    partition dt_20270228 values less than ('2027-03-01 00:00:00'),
    partition dt_20270301 values less than ('2027-03-02 00:00:00'),
    partition dt_20270302 values less than ('2027-03-03 00:00:00'),
    partition dt_20270303 values less than ('2027-03-04 00:00:00'),
    partition dt_20270304 values less than ('2027-03-05 00:00:00'),
    partition dt_20270305 values less than ('2027-03-06 00:00:00'),
    partition dt_20270306 values less than ('2027-03-07 00:00:00'),
    partition dt_20270307 values less than ('2027-03-08 00:00:00'),
    partition dt_20270308 values less than ('2027-03-09 00:00:00'),
    partition dt_20270309 values less than ('2027-03-10 00:00:00'),
    partition dt_20270310 values less than ('2027-03-11 00:00:00'),
    partition dt_20270311 values less than ('2027-03-12 00:00:00'),
    partition dt_20270312 values less than ('2027-03-13 00:00:00'),
    partition dt_20270313 values less than ('2027-03-14 00:00:00'),
    partition dt_20270314 values less than ('2027-03-15 00:00:00'),
    partition dt_20270315 values less than ('2027-03-16 00:00:00'),
    partition dt_20270316 values less than ('2027-03-17 00:00:00'),
    partition dt_20270317 values less than ('2027-03-18 00:00:00'),
    partition dt_20270318 values less than ('2027-03-19 00:00:00'),
    partition dt_20270319 values less than ('2027-03-20 00:00:00'),
    partition dt_20270320 values less than ('2027-03-21 00:00:00'),
    partition dt_20270321 values less than ('2027-03-22 00:00:00'),
    partition dt_20270322 values less than ('2027-03-23 00:00:00'),
    partition dt_20270323 values less than ('2027-03-24 00:00:00'),
    partition dt_20270324 values less than ('2027-03-25 00:00:00'),
    partition dt_20270325 values less than ('2027-03-26 00:00:00'),
    partition dt_20270326 values less than ('2027-03-27 00:00:00'),
    partition dt_20270327 values less than ('2027-03-28 00:00:00'),
    partition dt_20270328 values less than ('2027-03-29 00:00:00'),
    partition dt_20270329 values less than ('2027-03-30 00:00:00'),
    partition dt_20270330 values less than ('2027-03-31 00:00:00'),
    partition dt_20270331 values less than ('2027-04-01 00:00:00'),
    partition dt_20270401 values less than ('2027-04-02 00:00:00'),
    partition dt_20270402 values less than ('2027-04-03 00:00:00'),
    partition dt_20270403 values less than ('2027-04-04 00:00:00'),
    partition dt_20270404 values less than ('2027-04-05 00:00:00'),
    partition dt_20270405 values less than ('2027-04-06 00:00:00'),
    partition dt_20270406 values less than ('2027-04-07 00:00:00'),
    partition dt_20270407 values less than ('2027-04-08 00:00:00'),
    partition dt_20270408 values less than ('2027-04-09 00:00:00'),
    partition dt_20270409 values less than ('2027-04-10 00:00:00'),
    partition dt_20270410 values less than ('2027-04-11 00:00:00'),
    partition dt_20270411 values less than ('2027-04-12 00:00:00'),
    partition dt_20270412 values less than ('2027-04-13 00:00:00'),
    partition dt_20270413 values less than ('2027-04-14 00:00:00'),
    partition dt_20270414 values less than ('2027-04-15 00:00:00'),
    partition dt_20270415 values less than ('2027-04-16 00:00:00'),
    partition dt_20270416 values less than ('2027-04-17 00:00:00'),
    partition dt_20270417 values less than ('2027-04-18 00:00:00'),
    partition dt_20270418 values less than ('2027-04-19 00:00:00'),
    partition dt_20270419 values less than ('2027-04-20 00:00:00'),
    partition dt_20270420 values less than ('2027-04-21 00:00:00'),
    partition dt_20270421 values less than ('2027-04-22 00:00:00'),
    partition dt_20270422 values less than ('2027-04-23 00:00:00'),
    partition dt_20270423 values less than ('2027-04-24 00:00:00'),
    partition dt_20270424 values less than ('2027-04-25 00:00:00'),
    partition dt_20270425 values less than ('2027-04-26 00:00:00'),
    partition dt_20270426 values less than ('2027-04-27 00:00:00'),
    partition dt_20270427 values less than ('2027-04-28 00:00:00'),
    partition dt_20270428 values less than ('2027-04-29 00:00:00'),
    partition dt_20270429 values less than ('2027-04-30 00:00:00'),
    partition dt_20270430 values less than ('2027-05-01 00:00:00'),
    partition dt_20270501 values less than ('2027-05-02 00:00:00'),
    partition dt_20270502 values less than ('2027-05-03 00:00:00'),
    partition dt_20270503 values less than ('2027-05-04 00:00:00'),
    partition dt_20270504 values less than ('2027-05-05 00:00:00'),
    partition dt_20270505 values less than ('2027-05-06 00:00:00'),
    partition dt_20270506 values less than ('2027-05-07 00:00:00'),
    partition dt_20270507 values less than ('2027-05-08 00:00:00'),
    partition dt_20270508 values less than ('2027-05-09 00:00:00'),
    partition dt_20270509 values less than ('2027-05-10 00:00:00'),
    partition dt_20270510 values less than ('2027-05-11 00:00:00'),
    partition dt_20270511 values less than ('2027-05-12 00:00:00'),
    partition dt_20270512 values less than ('2027-05-13 00:00:00'),
    partition dt_20270513 values less than ('2027-05-14 00:00:00'),
    partition dt_20270514 values less than ('2027-05-15 00:00:00'),
    partition dt_20270515 values less than ('2027-05-16 00:00:00'),
    partition dt_20270516 values less than ('2027-05-17 00:00:00'),
    partition dt_20270517 values less than ('2027-05-18 00:00:00'),
    partition dt_20270518 values less than ('2027-05-19 00:00:00'),
    partition dt_20270519 values less than ('2027-05-20 00:00:00'),
    partition dt_20270520 values less than ('2027-05-21 00:00:00'),
    partition dt_20270521 values less than ('2027-05-22 00:00:00'),
    partition dt_20270522 values less than ('2027-05-23 00:00:00'),
    partition dt_20270523 values less than ('2027-05-24 00:00:00'),
    partition dt_20270524 values less than ('2027-05-25 00:00:00'),
    partition dt_20270525 values less than ('2027-05-26 00:00:00'),
    partition dt_20270526 values less than ('2027-05-27 00:00:00'),
    partition dt_20270527 values less than ('2027-05-28 00:00:00'),
    partition dt_20270528 values less than ('2027-05-29 00:00:00'),
    partition dt_20270529 values less than ('2027-05-30 00:00:00'),
    partition dt_20270530 values less than ('2027-05-31 00:00:00'),
    partition dt_20270531 values less than ('2027-06-01 00:00:00'),
    partition dt_20270601 values less than ('2027-06-02 00:00:00'),
    partition dt_20270602 values less than ('2027-06-03 00:00:00'),
    partition dt_20270603 values less than ('2027-06-04 00:00:00'),
    partition dt_20270604 values less than ('2027-06-05 00:00:00'),
    partition dt_20270605 values less than ('2027-06-06 00:00:00'),
    partition dt_20270606 values less than ('2027-06-07 00:00:00'),
    partition dt_20270607 values less than ('2027-06-08 00:00:00'),
    partition dt_20270608 values less than ('2027-06-09 00:00:00'),
    partition dt_20270609 values less than ('2027-06-10 00:00:00'),
    partition dt_20270610 values less than ('2027-06-11 00:00:00'),
    partition dt_20270611 values less than ('2027-06-12 00:00:00'),
    partition dt_20270612 values less than ('2027-06-13 00:00:00'),
    partition dt_20270613 values less than ('2027-06-14 00:00:00'),
    partition dt_20270614 values less than ('2027-06-15 00:00:00'),
    partition dt_20270615 values less than ('2027-06-16 00:00:00'),
    partition dt_20270616 values less than ('2027-06-17 00:00:00'),
    partition dt_20270617 values less than ('2027-06-18 00:00:00'),
    partition dt_20270618 values less than ('2027-06-19 00:00:00'),
    partition dt_20270619 values less than ('2027-06-20 00:00:00'),
    partition dt_20270620 values less than ('2027-06-21 00:00:00'),
    partition dt_20270621 values less than ('2027-06-22 00:00:00'),
    partition dt_20270622 values less than ('2027-06-23 00:00:00'),
    partition dt_20270623 values less than ('2027-06-24 00:00:00'),
    partition dt_20270624 values less than ('2027-06-25 00:00:00'),
    partition dt_20270625 values less than ('2027-06-26 00:00:00'),
    partition dt_20270626 values less than ('2027-06-27 00:00:00'),
    partition dt_20270627 values less than ('2027-06-28 00:00:00'),
    partition dt_20270628 values less than ('2027-06-29 00:00:00'),
    partition dt_20270629 values less than ('2027-06-30 00:00:00'),
    partition dt_20270630 values less than ('2027-07-01 00:00:00'),
    partition dt_20270701 values less than ('2027-07-02 00:00:00'),
    partition dt_20270702 values less than ('2027-07-03 00:00:00'),
    partition dt_20270703 values less than ('2027-07-04 00:00:00'),
    partition dt_20270704 values less than ('2027-07-05 00:00:00'),
    partition dt_20270705 values less than ('2027-07-06 00:00:00'),
    partition dt_20270706 values less than ('2027-07-07 00:00:00'),
    partition dt_20270707 values less than ('2027-07-08 00:00:00'),
    partition dt_20270708 values less than ('2027-07-09 00:00:00'),
    partition dt_20270709 values less than ('2027-07-10 00:00:00'),
    partition dt_20270710 values less than ('2027-07-11 00:00:00'),
    partition dt_20270711 values less than ('2027-07-12 00:00:00'),
    partition dt_20270712 values less than ('2027-07-13 00:00:00'),
    partition dt_20270713 values less than ('2027-07-14 00:00:00'),
    partition dt_20270714 values less than ('2027-07-15 00:00:00'),
    partition dt_20270715 values less than ('2027-07-16 00:00:00'),
    partition dt_20270716 values less than ('2027-07-17 00:00:00'),
    partition dt_20270717 values less than ('2027-07-18 00:00:00'),
    partition dt_20270718 values less than ('2027-07-19 00:00:00'),
    partition dt_20270719 values less than ('2027-07-20 00:00:00'),
    partition dt_20270720 values less than ('2027-07-21 00:00:00'),
    partition dt_20270721 values less than ('2027-07-22 00:00:00'),
    partition dt_20270722 values less than ('2027-07-23 00:00:00'),
    partition dt_20270723 values less than ('2027-07-24 00:00:00'),
    partition dt_20270724 values less than ('2027-07-25 00:00:00'),
    partition dt_20270725 values less than ('2027-07-26 00:00:00'),
    partition dt_20270726 values less than ('2027-07-27 00:00:00'),
    partition dt_20270727 values less than ('2027-07-28 00:00:00'),
    partition dt_20270728 values less than ('2027-07-29 00:00:00'),
    partition dt_20270729 values less than ('2027-07-30 00:00:00'),
    partition dt_20270730 values less than ('2027-07-31 00:00:00'),
    partition dt_20270731 values less than ('2027-08-01 00:00:00'),
    partition dt_20270801 values less than ('2027-08-02 00:00:00'),
    partition dt_20270802 values less than ('2027-08-03 00:00:00'),
    partition dt_20270803 values less than ('2027-08-04 00:00:00'),
    partition dt_20270804 values less than ('2027-08-05 00:00:00'),
    partition dt_20270805 values less than ('2027-08-06 00:00:00'),
    partition dt_20270806 values less than ('2027-08-07 00:00:00'),
    partition dt_20270807 values less than ('2027-08-08 00:00:00'),
    partition dt_20270808 values less than ('2027-08-09 00:00:00'),
    partition dt_20270809 values less than ('2027-08-10 00:00:00'),
    partition dt_20270810 values less than ('2027-08-11 00:00:00'),
    partition dt_20270811 values less than ('2027-08-12 00:00:00'),
    partition dt_20270812 values less than ('2027-08-13 00:00:00'),
    partition dt_20270813 values less than ('2027-08-14 00:00:00'),
    partition dt_20270814 values less than ('2027-08-15 00:00:00'),
    partition dt_20270815 values less than ('2027-08-16 00:00:00'),
    partition dt_20270816 values less than ('2027-08-17 00:00:00'),
    partition dt_20270817 values less than ('2027-08-18 00:00:00'),
    partition dt_20270818 values less than ('2027-08-19 00:00:00'),
    partition dt_20270819 values less than ('2027-08-20 00:00:00'),
    partition dt_20270820 values less than ('2027-08-21 00:00:00'),
    partition dt_20270821 values less than ('2027-08-22 00:00:00'),
    partition dt_20270822 values less than ('2027-08-23 00:00:00'),
    partition dt_20270823 values less than ('2027-08-24 00:00:00'),
    partition dt_20270824 values less than ('2027-08-25 00:00:00'),
    partition dt_20270825 values less than ('2027-08-26 00:00:00'),
    partition dt_20270826 values less than ('2027-08-27 00:00:00'),
    partition dt_20270827 values less than ('2027-08-28 00:00:00'),
    partition dt_20270828 values less than ('2027-08-29 00:00:00'),
    partition dt_20270829 values less than ('2027-08-30 00:00:00'),
    partition dt_20270830 values less than ('2027-08-31 00:00:00'),
    partition dt_20270831 values less than ('2027-09-01 00:00:00'),
    partition dt_20270901 values less than ('2027-09-02 00:00:00'),
    partition dt_20270902 values less than ('2027-09-03 00:00:00'),
    partition dt_20270903 values less than ('2027-09-04 00:00:00'),
    partition dt_20270904 values less than ('2027-09-05 00:00:00'),
    partition dt_20270905 values less than ('2027-09-06 00:00:00'),
    partition dt_20270906 values less than ('2027-09-07 00:00:00'),
    partition dt_20270907 values less than ('2027-09-08 00:00:00'),
    partition dt_20270908 values less than ('2027-09-09 00:00:00'),
    partition dt_20270909 values less than ('2027-09-10 00:00:00'),
    partition dt_20270910 values less than ('2027-09-11 00:00:00'),
    partition dt_20270911 values less than ('2027-09-12 00:00:00'),
    partition dt_20270912 values less than ('2027-09-13 00:00:00'),
    partition dt_20270913 values less than ('2027-09-14 00:00:00'),
    partition dt_20270914 values less than ('2027-09-15 00:00:00'),
    partition dt_20270915 values less than ('2027-09-16 00:00:00'),
    partition dt_20270916 values less than ('2027-09-17 00:00:00'),
    partition dt_20270917 values less than ('2027-09-18 00:00:00'),
    partition dt_20270918 values less than ('2027-09-19 00:00:00'),
    partition dt_20270919 values less than ('2027-09-20 00:00:00'),
    partition dt_20270920 values less than ('2027-09-21 00:00:00'),
    partition dt_20270921 values less than ('2027-09-22 00:00:00'),
    partition dt_20270922 values less than ('2027-09-23 00:00:00'),
    partition dt_20270923 values less than ('2027-09-24 00:00:00'),
    partition dt_20270924 values less than ('2027-09-25 00:00:00'),
    partition dt_20270925 values less than ('2027-09-26 00:00:00'),
    partition dt_20270926 values less than ('2027-09-27 00:00:00'),
    partition dt_20270927 values less than ('2027-09-28 00:00:00'),
    partition dt_20270928 values less than ('2027-09-29 00:00:00'),
    partition dt_20270929 values less than ('2027-09-30 00:00:00'),
    partition dt_20270930 values less than ('2027-10-01 00:00:00'),
    partition dt_20271001 values less than ('2027-10-02 00:00:00'),
    partition dt_20271002 values less than ('2027-10-03 00:00:00'),
    partition dt_20271003 values less than ('2027-10-04 00:00:00'),
    partition dt_20271004 values less than ('2027-10-05 00:00:00'),
    partition dt_20271005 values less than ('2027-10-06 00:00:00'),
    partition dt_20271006 values less than ('2027-10-07 00:00:00'),
    partition dt_20271007 values less than ('2027-10-08 00:00:00'),
    partition dt_20271008 values less than ('2027-10-09 00:00:00'),
    partition dt_20271009 values less than ('2027-10-10 00:00:00'),
    partition dt_20271010 values less than ('2027-10-11 00:00:00'),
    partition dt_20271011 values less than ('2027-10-12 00:00:00'),
    partition dt_20271012 values less than ('2027-10-13 00:00:00'),
    partition dt_20271013 values less than ('2027-10-14 00:00:00'),
    partition dt_20271014 values less than ('2027-10-15 00:00:00'),
    partition dt_20271015 values less than ('2027-10-16 00:00:00'),
    partition dt_20271016 values less than ('2027-10-17 00:00:00'),
    partition dt_20271017 values less than ('2027-10-18 00:00:00'),
    partition dt_20271018 values less than ('2027-10-19 00:00:00'),
    partition dt_20271019 values less than ('2027-10-20 00:00:00'),
    partition dt_20271020 values less than ('2027-10-21 00:00:00'),
    partition dt_20271021 values less than ('2027-10-22 00:00:00'),
    partition dt_20271022 values less than ('2027-10-23 00:00:00'),
    partition dt_20271023 values less than ('2027-10-24 00:00:00'),
    partition dt_20271024 values less than ('2027-10-25 00:00:00'),
    partition dt_20271025 values less than ('2027-10-26 00:00:00'),
    partition dt_20271026 values less than ('2027-10-27 00:00:00'),
    partition dt_20271027 values less than ('2027-10-28 00:00:00'),
    partition dt_20271028 values less than ('2027-10-29 00:00:00'),
    partition dt_20271029 values less than ('2027-10-30 00:00:00'),
    partition dt_20271030 values less than ('2027-10-31 00:00:00'),
    partition dt_20271031 values less than ('2027-11-01 00:00:00'),
    partition dt_20271101 values less than ('2027-11-02 00:00:00'),
    partition dt_20271102 values less than ('2027-11-03 00:00:00'),
    partition dt_20271103 values less than ('2027-11-04 00:00:00'),
    partition dt_20271104 values less than ('2027-11-05 00:00:00'),
    partition dt_20271105 values less than ('2027-11-06 00:00:00'),
    partition dt_20271106 values less than ('2027-11-07 00:00:00'),
    partition dt_20271107 values less than ('2027-11-08 00:00:00'),
    partition dt_20271108 values less than ('2027-11-09 00:00:00'),
    partition dt_20271109 values less than ('2027-11-10 00:00:00'),
    partition dt_20271110 values less than ('2027-11-11 00:00:00'),
    partition dt_20271111 values less than ('2027-11-12 00:00:00'),
    partition dt_20271112 values less than ('2027-11-13 00:00:00'),
    partition dt_20271113 values less than ('2027-11-14 00:00:00'),
    partition dt_20271114 values less than ('2027-11-15 00:00:00'),
    partition dt_20271115 values less than ('2027-11-16 00:00:00'),
    partition dt_20271116 values less than ('2027-11-17 00:00:00'),
    partition dt_20271117 values less than ('2027-11-18 00:00:00'),
    partition dt_20271118 values less than ('2027-11-19 00:00:00'),
    partition dt_20271119 values less than ('2027-11-20 00:00:00'),
    partition dt_20271120 values less than ('2027-11-21 00:00:00'),
    partition dt_20271121 values less than ('2027-11-22 00:00:00'),
    partition dt_20271122 values less than ('2027-11-23 00:00:00'),
    partition dt_20271123 values less than ('2027-11-24 00:00:00'),
    partition dt_20271124 values less than ('2027-11-25 00:00:00'),
    partition dt_20271125 values less than ('2027-11-26 00:00:00'),
    partition dt_20271126 values less than ('2027-11-27 00:00:00'),
    partition dt_20271127 values less than ('2027-11-28 00:00:00'),
    partition dt_20271128 values less than ('2027-11-29 00:00:00'),
    partition dt_20271129 values less than ('2027-11-30 00:00:00'),
    partition dt_20271130 values less than ('2027-12-01 00:00:00'),
    partition dt_20271201 values less than ('2027-12-02 00:00:00'),
    partition dt_20271202 values less than ('2027-12-03 00:00:00'),
    partition dt_20271203 values less than ('2027-12-04 00:00:00'),
    partition dt_20271204 values less than ('2027-12-05 00:00:00'),
    partition dt_20271205 values less than ('2027-12-06 00:00:00'),
    partition dt_20271206 values less than ('2027-12-07 00:00:00'),
    partition dt_20271207 values less than ('2027-12-08 00:00:00'),
    partition dt_20271208 values less than ('2027-12-09 00:00:00'),
    partition dt_20271209 values less than ('2027-12-10 00:00:00'),
    partition dt_20271210 values less than ('2027-12-11 00:00:00'),
    partition dt_20271211 values less than ('2027-12-12 00:00:00'),
    partition dt_20271212 values less than ('2027-12-13 00:00:00'),
    partition dt_20271213 values less than ('2027-12-14 00:00:00'),
    partition dt_20271214 values less than ('2027-12-15 00:00:00'),
    partition dt_20271215 values less than ('2027-12-16 00:00:00'),
    partition dt_20271216 values less than ('2027-12-17 00:00:00'),
    partition dt_20271217 values less than ('2027-12-18 00:00:00'),
    partition dt_20271218 values less than ('2027-12-19 00:00:00'),
    partition dt_20271219 values less than ('2027-12-20 00:00:00'),
    partition dt_20271220 values less than ('2027-12-21 00:00:00'),
    partition dt_20271221 values less than ('2027-12-22 00:00:00'),
    partition dt_20271222 values less than ('2027-12-23 00:00:00'),
    partition dt_20271223 values less than ('2027-12-24 00:00:00'),
    partition dt_20271224 values less than ('2027-12-25 00:00:00'),
    partition dt_20271225 values less than ('2027-12-26 00:00:00'),
    partition dt_20271226 values less than ('2027-12-27 00:00:00'),
    partition dt_20271227 values less than ('2027-12-28 00:00:00'),
    partition dt_20271228 values less than ('2027-12-29 00:00:00'),
    partition dt_20271229 values less than ('2027-12-30 00:00:00'),
    partition dt_20271230 values less than ('2027-12-31 00:00:00'),
    partition dt_20271231 values less than ('2028-01-01 00:00:00'),
    partition dt_20280101 values less than ('2028-01-02 00:00:00'),
    partition dt_20280102 values less than ('2028-01-03 00:00:00'),
    partition dt_20280103 values less than ('2028-01-04 00:00:00'),
    partition dt_20280104 values less than ('2028-01-05 00:00:00'),
    partition dt_20280105 values less than ('2028-01-06 00:00:00'),
    partition dt_20280106 values less than ('2028-01-07 00:00:00'),
    partition dt_20280107 values less than ('2028-01-08 00:00:00'),
    partition dt_20280108 values less than ('2028-01-09 00:00:00'),
    partition dt_20280109 values less than ('2028-01-10 00:00:00'),
    partition dt_20280110 values less than ('2028-01-11 00:00:00'),
    partition dt_20280111 values less than ('2028-01-12 00:00:00'),
    partition dt_20280112 values less than ('2028-01-13 00:00:00'),
    partition dt_20280113 values less than ('2028-01-14 00:00:00'),
    partition dt_20280114 values less than ('2028-01-15 00:00:00'),
    partition dt_20280115 values less than ('2028-01-16 00:00:00'),
    partition dt_20280116 values less than ('2028-01-17 00:00:00'),
    partition dt_20280117 values less than ('2028-01-18 00:00:00'),
    partition dt_20280118 values less than ('2028-01-19 00:00:00'),
    partition dt_20280119 values less than ('2028-01-20 00:00:00'),
    partition dt_20280120 values less than ('2028-01-21 00:00:00'),
    partition dt_20280121 values less than ('2028-01-22 00:00:00'),
    partition dt_20280122 values less than ('2028-01-23 00:00:00'),
    partition dt_20280123 values less than ('2028-01-24 00:00:00'),
    partition dt_20280124 values less than ('2028-01-25 00:00:00'),
    partition dt_20280125 values less than ('2028-01-26 00:00:00'),
    partition dt_20280126 values less than ('2028-01-27 00:00:00'),
    partition dt_20280127 values less than ('2028-01-28 00:00:00'),
    partition dt_20280128 values less than ('2028-01-29 00:00:00'),
    partition dt_20280129 values less than ('2028-01-30 00:00:00'),
    partition dt_20280130 values less than ('2028-01-31 00:00:00'),
    partition dt_20280131 values less than ('2028-02-01 00:00:00'),
    partition dt_20280201 values less than ('2028-02-02 00:00:00'),
    partition dt_20280202 values less than ('2028-02-03 00:00:00'),
    partition dt_20280203 values less than ('2028-02-04 00:00:00'),
    partition dt_20280204 values less than ('2028-02-05 00:00:00'),
    partition dt_20280205 values less than ('2028-02-06 00:00:00'),
    partition dt_20280206 values less than ('2028-02-07 00:00:00'),
    partition dt_20280207 values less than ('2028-02-08 00:00:00'),
    partition dt_20280208 values less than ('2028-02-09 00:00:00'),
    partition dt_20280209 values less than ('2028-02-10 00:00:00'),
    partition dt_20280210 values less than ('2028-02-11 00:00:00'),
    partition dt_20280211 values less than ('2028-02-12 00:00:00'),
    partition dt_20280212 values less than ('2028-02-13 00:00:00'),
    partition dt_20280213 values less than ('2028-02-14 00:00:00'),
    partition dt_20280214 values less than ('2028-02-15 00:00:00'),
    partition dt_20280215 values less than ('2028-02-16 00:00:00'),
    partition dt_20280216 values less than ('2028-02-17 00:00:00'),
    partition dt_20280217 values less than ('2028-02-18 00:00:00'),
    partition dt_20280218 values less than ('2028-02-19 00:00:00'),
    partition dt_20280219 values less than ('2028-02-20 00:00:00'),
    partition dt_20280220 values less than ('2028-02-21 00:00:00'),
    partition dt_20280221 values less than ('2028-02-22 00:00:00'),
    partition dt_20280222 values less than ('2028-02-23 00:00:00'),
    partition dt_20280223 values less than ('2028-02-24 00:00:00'),
    partition dt_20280224 values less than ('2028-02-25 00:00:00'),
    partition dt_20280225 values less than ('2028-02-26 00:00:00'),
    partition dt_20280226 values less than ('2028-02-27 00:00:00'),
    partition dt_20280227 values less than ('2028-02-28 00:00:00'),
    partition dt_20280228 values less than ('2028-02-29 00:00:00'),
    partition dt_20280229 values less than ('2028-03-01 00:00:00'),
    partition dt_20280301 values less than ('2028-03-02 00:00:00'),
    partition dt_20280302 values less than ('2028-03-03 00:00:00'),
    partition dt_20280303 values less than ('2028-03-04 00:00:00'),
    partition dt_20280304 values less than ('2028-03-05 00:00:00'),
    partition dt_20280305 values less than ('2028-03-06 00:00:00'),
    partition dt_20280306 values less than ('2028-03-07 00:00:00'),
    partition dt_20280307 values less than ('2028-03-08 00:00:00'),
    partition dt_20280308 values less than ('2028-03-09 00:00:00'),
    partition dt_20280309 values less than ('2028-03-10 00:00:00'),
    partition dt_20280310 values less than ('2028-03-11 00:00:00'),
    partition dt_20280311 values less than ('2028-03-12 00:00:00'),
    partition dt_20280312 values less than ('2028-03-13 00:00:00'),
    partition dt_20280313 values less than ('2028-03-14 00:00:00'),
    partition dt_20280314 values less than ('2028-03-15 00:00:00'),
    partition dt_20280315 values less than ('2028-03-16 00:00:00'),
    partition dt_20280316 values less than ('2028-03-17 00:00:00'),
    partition dt_20280317 values less than ('2028-03-18 00:00:00'),
    partition dt_20280318 values less than ('2028-03-19 00:00:00'),
    partition dt_20280319 values less than ('2028-03-20 00:00:00'),
    partition dt_20280320 values less than ('2028-03-21 00:00:00'),
    partition dt_20280321 values less than ('2028-03-22 00:00:00'),
    partition dt_20280322 values less than ('2028-03-23 00:00:00'),
    partition dt_20280323 values less than ('2028-03-24 00:00:00'),
    partition dt_20280324 values less than ('2028-03-25 00:00:00'),
    partition dt_20280325 values less than ('2028-03-26 00:00:00'),
    partition dt_20280326 values less than ('2028-03-27 00:00:00'),
    partition dt_20280327 values less than ('2028-03-28 00:00:00'),
    partition dt_20280328 values less than ('2028-03-29 00:00:00'),
    partition dt_20280329 values less than ('2028-03-30 00:00:00'),
    partition dt_20280330 values less than ('2028-03-31 00:00:00'),
    partition dt_20280331 values less than ('2028-04-01 00:00:00'),
    partition dt_20280401 values less than ('2028-04-02 00:00:00'),
    partition dt_20280402 values less than ('2028-04-03 00:00:00'),
    partition dt_20280403 values less than ('2028-04-04 00:00:00'),
    partition dt_20280404 values less than ('2028-04-05 00:00:00'),
    partition dt_20280405 values less than ('2028-04-06 00:00:00'),
    partition dt_20280406 values less than ('2028-04-07 00:00:00'),
    partition dt_20280407 values less than ('2028-04-08 00:00:00'),
    partition dt_20280408 values less than ('2028-04-09 00:00:00'),
    partition dt_20280409 values less than ('2028-04-10 00:00:00'),
    partition dt_20280410 values less than ('2028-04-11 00:00:00'),
    partition dt_20280411 values less than ('2028-04-12 00:00:00'),
    partition dt_20280412 values less than ('2028-04-13 00:00:00'),
    partition dt_20280413 values less than ('2028-04-14 00:00:00'),
    partition dt_20280414 values less than ('2028-04-15 00:00:00'),
    partition dt_20280415 values less than ('2028-04-16 00:00:00'),
    partition dt_20280416 values less than ('2028-04-17 00:00:00'),
    partition dt_20280417 values less than ('2028-04-18 00:00:00'),
    partition dt_20280418 values less than ('2028-04-19 00:00:00'),
    partition dt_20280419 values less than ('2028-04-20 00:00:00'),
    partition dt_20280420 values less than ('2028-04-21 00:00:00'),
    partition dt_20280421 values less than ('2028-04-22 00:00:00'),
    partition dt_20280422 values less than ('2028-04-23 00:00:00'),
    partition dt_20280423 values less than ('2028-04-24 00:00:00'),
    partition dt_20280424 values less than ('2028-04-25 00:00:00'),
    partition dt_20280425 values less than ('2028-04-26 00:00:00'),
    partition dt_20280426 values less than ('2028-04-27 00:00:00'),
    partition dt_20280427 values less than ('2028-04-28 00:00:00'),
    partition dt_20280428 values less than ('2028-04-29 00:00:00'),
    partition dt_20280429 values less than ('2028-04-30 00:00:00'),
    partition dt_20280430 values less than ('2028-05-01 00:00:00'),
    partition dt_20280501 values less than ('2028-05-02 00:00:00'),
    partition dt_20280502 values less than ('2028-05-03 00:00:00'),
    partition dt_20280503 values less than ('2028-05-04 00:00:00'),
    partition dt_20280504 values less than ('2028-05-05 00:00:00'),
    partition dt_20280505 values less than ('2028-05-06 00:00:00'),
    partition dt_20280506 values less than ('2028-05-07 00:00:00'),
    partition dt_20280507 values less than ('2028-05-08 00:00:00'),
    partition dt_20280508 values less than ('2028-05-09 00:00:00'),
    partition dt_20280509 values less than ('2028-05-10 00:00:00'),
    partition dt_20280510 values less than ('2028-05-11 00:00:00'),
    partition dt_20280511 values less than ('2028-05-12 00:00:00'),
    partition dt_20280512 values less than ('2028-05-13 00:00:00'),
    partition dt_20280513 values less than ('2028-05-14 00:00:00'),
    partition dt_20280514 values less than ('2028-05-15 00:00:00'),
    partition dt_20280515 values less than ('2028-05-16 00:00:00'),
    partition dt_20280516 values less than ('2028-05-17 00:00:00'),
    partition dt_20280517 values less than ('2028-05-18 00:00:00'),
    partition dt_20280518 values less than ('2028-05-19 00:00:00'),
    partition dt_20280519 values less than ('2028-05-20 00:00:00'),
    partition dt_20280520 values less than ('2028-05-21 00:00:00'),
    partition dt_20280521 values less than ('2028-05-22 00:00:00'),
    partition dt_20280522 values less than ('2028-05-23 00:00:00'),
    partition dt_20280523 values less than ('2028-05-24 00:00:00'),
    partition dt_20280524 values less than ('2028-05-25 00:00:00'),
    partition dt_20280525 values less than ('2028-05-26 00:00:00'),
    partition dt_20280526 values less than ('2028-05-27 00:00:00'),
    partition dt_20280527 values less than ('2028-05-28 00:00:00'),
    partition dt_20280528 values less than ('2028-05-29 00:00:00'),
    partition dt_20280529 values less than ('2028-05-30 00:00:00'),
    partition dt_20280530 values less than ('2028-05-31 00:00:00'),
    partition dt_20280531 values less than ('2028-06-01 00:00:00'),
    partition dt_20280601 values less than ('2028-06-02 00:00:00'),
    partition dt_20280602 values less than ('2028-06-03 00:00:00'),
    partition dt_20280603 values less than ('2028-06-04 00:00:00'),
    partition dt_20280604 values less than ('2028-06-05 00:00:00'),
    partition dt_20280605 values less than ('2028-06-06 00:00:00'),
    partition dt_20280606 values less than ('2028-06-07 00:00:00'),
    partition dt_20280607 values less than ('2028-06-08 00:00:00'),
    partition dt_20280608 values less than ('2028-06-09 00:00:00'),
    partition dt_20280609 values less than ('2028-06-10 00:00:00'),
    partition dt_20280610 values less than ('2028-06-11 00:00:00'),
    partition dt_20280611 values less than ('2028-06-12 00:00:00'),
    partition dt_20280612 values less than ('2028-06-13 00:00:00'),
    partition dt_20280613 values less than ('2028-06-14 00:00:00'),
    partition dt_20280614 values less than ('2028-06-15 00:00:00'),
    partition dt_20280615 values less than ('2028-06-16 00:00:00'),
    partition dt_20280616 values less than ('2028-06-17 00:00:00'),
    partition dt_20280617 values less than ('2028-06-18 00:00:00'),
    partition dt_20280618 values less than ('2028-06-19 00:00:00'),
    partition dt_20280619 values less than ('2028-06-20 00:00:00'),
    partition dt_20280620 values less than ('2028-06-21 00:00:00'),
    partition dt_20280621 values less than ('2028-06-22 00:00:00'),
    partition dt_20280622 values less than ('2028-06-23 00:00:00'),
    partition dt_20280623 values less than ('2028-06-24 00:00:00'),
    partition dt_20280624 values less than ('2028-06-25 00:00:00'),
    partition dt_20280625 values less than ('2028-06-26 00:00:00'),
    partition dt_20280626 values less than ('2028-06-27 00:00:00'),
    partition dt_20280627 values less than ('2028-06-28 00:00:00'),
    partition dt_20280628 values less than ('2028-06-29 00:00:00'),
    partition dt_20280629 values less than ('2028-06-30 00:00:00'),
    partition dt_20280630 values less than ('2028-07-01 00:00:00'),
    partition dt_20280701 values less than ('2028-07-02 00:00:00'),
    partition dt_20280702 values less than ('2028-07-03 00:00:00'),
    partition dt_20280703 values less than ('2028-07-04 00:00:00'),
    partition dt_20280704 values less than ('2028-07-05 00:00:00'),
    partition dt_20280705 values less than ('2028-07-06 00:00:00'),
    partition dt_20280706 values less than ('2028-07-07 00:00:00'),
    partition dt_20280707 values less than ('2028-07-08 00:00:00'),
    partition dt_20280708 values less than ('2028-07-09 00:00:00'),
    partition dt_20280709 values less than ('2028-07-10 00:00:00'),
    partition dt_20280710 values less than ('2028-07-11 00:00:00'),
    partition dt_20280711 values less than ('2028-07-12 00:00:00'),
    partition dt_20280712 values less than ('2028-07-13 00:00:00'),
    partition dt_20280713 values less than ('2028-07-14 00:00:00'),
    partition dt_20280714 values less than ('2028-07-15 00:00:00'),
    partition dt_20280715 values less than ('2028-07-16 00:00:00'),
    partition dt_20280716 values less than ('2028-07-17 00:00:00'),
    partition dt_20280717 values less than ('2028-07-18 00:00:00'),
    partition dt_20280718 values less than ('2028-07-19 00:00:00'),
    partition dt_20280719 values less than ('2028-07-20 00:00:00'),
    partition dt_20280720 values less than ('2028-07-21 00:00:00'),
    partition dt_20280721 values less than ('2028-07-22 00:00:00'),
    partition dt_20280722 values less than ('2028-07-23 00:00:00'),
    partition dt_20280723 values less than ('2028-07-24 00:00:00'),
    partition dt_20280724 values less than ('2028-07-25 00:00:00'),
    partition dt_20280725 values less than ('2028-07-26 00:00:00'),
    partition dt_20280726 values less than ('2028-07-27 00:00:00'),
    partition dt_20280727 values less than ('2028-07-28 00:00:00'),
    partition dt_20280728 values less than ('2028-07-29 00:00:00'),
    partition dt_20280729 values less than ('2028-07-30 00:00:00'),
    partition dt_20280730 values less than ('2028-07-31 00:00:00'),
    partition dt_20280731 values less than ('2028-08-01 00:00:00'),
    partition dt_20280801 values less than ('2028-08-02 00:00:00'),
    partition dt_20280802 values less than ('2028-08-03 00:00:00'),
    partition dt_20280803 values less than ('2028-08-04 00:00:00'),
    partition dt_20280804 values less than ('2028-08-05 00:00:00'),
    partition dt_20280805 values less than ('2028-08-06 00:00:00'),
    partition dt_20280806 values less than ('2028-08-07 00:00:00'),
    partition dt_20280807 values less than ('2028-08-08 00:00:00'),
    partition dt_20280808 values less than ('2028-08-09 00:00:00'),
    partition dt_20280809 values less than ('2028-08-10 00:00:00'),
    partition dt_20280810 values less than ('2028-08-11 00:00:00'),
    partition dt_20280811 values less than ('2028-08-12 00:00:00'),
    partition dt_20280812 values less than ('2028-08-13 00:00:00'),
    partition dt_20280813 values less than ('2028-08-14 00:00:00'),
    partition dt_20280814 values less than ('2028-08-15 00:00:00'),
    partition dt_20280815 values less than ('2028-08-16 00:00:00'),
    partition dt_20280816 values less than ('2028-08-17 00:00:00'),
    partition dt_20280817 values less than ('2028-08-18 00:00:00'),
    partition dt_20280818 values less than ('2028-08-19 00:00:00'),
    partition dt_20280819 values less than ('2028-08-20 00:00:00'),
    partition dt_20280820 values less than ('2028-08-21 00:00:00'),
    partition dt_20280821 values less than ('2028-08-22 00:00:00'),
    partition dt_20280822 values less than ('2028-08-23 00:00:00'),
    partition dt_20280823 values less than ('2028-08-24 00:00:00'),
    partition dt_20280824 values less than ('2028-08-25 00:00:00'),
    partition dt_20280825 values less than ('2028-08-26 00:00:00'),
    partition dt_20280826 values less than ('2028-08-27 00:00:00'),
    partition dt_20280827 values less than ('2028-08-28 00:00:00'),
    partition dt_20280828 values less than ('2028-08-29 00:00:00'),
    partition dt_20280829 values less than ('2028-08-30 00:00:00'),
    partition dt_20280830 values less than ('2028-08-31 00:00:00'),
    partition dt_20280831 values less than ('2028-09-01 00:00:00'),
    partition dt_20280901 values less than ('2028-09-02 00:00:00'),
    partition dt_20280902 values less than ('2028-09-03 00:00:00'),
    partition dt_20280903 values less than ('2028-09-04 00:00:00'),
    partition dt_20280904 values less than ('2028-09-05 00:00:00'),
    partition dt_20280905 values less than ('2028-09-06 00:00:00'),
    partition dt_20280906 values less than ('2028-09-07 00:00:00'),
    partition dt_20280907 values less than ('2028-09-08 00:00:00'),
    partition dt_20280908 values less than ('2028-09-09 00:00:00'),
    partition dt_20280909 values less than ('2028-09-10 00:00:00'),
    partition dt_20280910 values less than ('2028-09-11 00:00:00'),
    partition dt_20280911 values less than ('2028-09-12 00:00:00'),
    partition dt_20280912 values less than ('2028-09-13 00:00:00'),
    partition dt_20280913 values less than ('2028-09-14 00:00:00'),
    partition dt_20280914 values less than ('2028-09-15 00:00:00'),
    partition dt_20280915 values less than ('2028-09-16 00:00:00'),
    partition dt_20280916 values less than ('2028-09-17 00:00:00'),
    partition dt_20280917 values less than ('2028-09-18 00:00:00'),
    partition dt_20280918 values less than ('2028-09-19 00:00:00'),
    partition dt_20280919 values less than ('2028-09-20 00:00:00'),
    partition dt_20280920 values less than ('2028-09-21 00:00:00'),
    partition dt_20280921 values less than ('2028-09-22 00:00:00'),
    partition dt_20280922 values less than ('2028-09-23 00:00:00'),
    partition dt_20280923 values less than ('2028-09-24 00:00:00'),
    partition dt_20280924 values less than ('2028-09-25 00:00:00'),
    partition dt_20280925 values less than ('2028-09-26 00:00:00'),
    partition dt_20280926 values less than ('2028-09-27 00:00:00'),
    partition dt_20280927 values less than ('2028-09-28 00:00:00'),
    partition dt_20280928 values less than ('2028-09-29 00:00:00'),
    partition dt_20280929 values less than ('2028-09-30 00:00:00'),
    partition dt_20280930 values less than ('2028-10-01 00:00:00'),
    partition dt_20281001 values less than ('2028-10-02 00:00:00'),
    partition dt_20281002 values less than ('2028-10-03 00:00:00'),
    partition dt_20281003 values less than ('2028-10-04 00:00:00'),
    partition dt_20281004 values less than ('2028-10-05 00:00:00'),
    partition dt_20281005 values less than ('2028-10-06 00:00:00'),
    partition dt_20281006 values less than ('2028-10-07 00:00:00'),
    partition dt_20281007 values less than ('2028-10-08 00:00:00'),
    partition dt_20281008 values less than ('2028-10-09 00:00:00'),
    partition dt_20281009 values less than ('2028-10-10 00:00:00'),
    partition dt_20281010 values less than ('2028-10-11 00:00:00'),
    partition dt_20281011 values less than ('2028-10-12 00:00:00'),
    partition dt_20281012 values less than ('2028-10-13 00:00:00'),
    partition dt_20281013 values less than ('2028-10-14 00:00:00'),
    partition dt_20281014 values less than ('2028-10-15 00:00:00'),
    partition dt_20281015 values less than ('2028-10-16 00:00:00'),
    partition dt_20281016 values less than ('2028-10-17 00:00:00'),
    partition dt_20281017 values less than ('2028-10-18 00:00:00'),
    partition dt_20281018 values less than ('2028-10-19 00:00:00'),
    partition dt_20281019 values less than ('2028-10-20 00:00:00'),
    partition dt_20281020 values less than ('2028-10-21 00:00:00'),
    partition dt_20281021 values less than ('2028-10-22 00:00:00'),
    partition dt_20281022 values less than ('2028-10-23 00:00:00'),
    partition dt_20281023 values less than ('2028-10-24 00:00:00'),
    partition dt_20281024 values less than ('2028-10-25 00:00:00'),
    partition dt_20281025 values less than ('2028-10-26 00:00:00'),
    partition dt_20281026 values less than ('2028-10-27 00:00:00'),
    partition dt_20281027 values less than ('2028-10-28 00:00:00'),
    partition dt_20281028 values less than ('2028-10-29 00:00:00'),
    partition dt_20281029 values less than ('2028-10-30 00:00:00'),
    partition dt_20281030 values less than ('2028-10-31 00:00:00'),
    partition dt_20281031 values less than ('2028-11-01 00:00:00'),
    partition dt_20281101 values less than ('2028-11-02 00:00:00'),
    partition dt_20281102 values less than ('2028-11-03 00:00:00'),
    partition dt_20281103 values less than ('2028-11-04 00:00:00'),
    partition dt_20281104 values less than ('2028-11-05 00:00:00'),
    partition dt_20281105 values less than ('2028-11-06 00:00:00'),
    partition dt_20281106 values less than ('2028-11-07 00:00:00'),
    partition dt_20281107 values less than ('2028-11-08 00:00:00'),
    partition dt_20281108 values less than ('2028-11-09 00:00:00'),
    partition dt_20281109 values less than ('2028-11-10 00:00:00'),
    partition dt_20281110 values less than ('2028-11-11 00:00:00'),
    partition dt_20281111 values less than ('2028-11-12 00:00:00'),
    partition dt_20281112 values less than ('2028-11-13 00:00:00'),
    partition dt_20281113 values less than ('2028-11-14 00:00:00'),
    partition dt_20281114 values less than ('2028-11-15 00:00:00'),
    partition dt_20281115 values less than ('2028-11-16 00:00:00'),
    partition dt_20281116 values less than ('2028-11-17 00:00:00'),
    partition dt_20281117 values less than ('2028-11-18 00:00:00'),
    partition dt_20281118 values less than ('2028-11-19 00:00:00'),
    partition dt_20281119 values less than ('2028-11-20 00:00:00'),
    partition dt_20281120 values less than ('2028-11-21 00:00:00'),
    partition dt_20281121 values less than ('2028-11-22 00:00:00'),
    partition dt_20281122 values less than ('2028-11-23 00:00:00'),
    partition dt_20281123 values less than ('2028-11-24 00:00:00'),
    partition dt_20281124 values less than ('2028-11-25 00:00:00'),
    partition dt_20281125 values less than ('2028-11-26 00:00:00'),
    partition dt_20281126 values less than ('2028-11-27 00:00:00'),
    partition dt_20281127 values less than ('2028-11-28 00:00:00'),
    partition dt_20281128 values less than ('2028-11-29 00:00:00'),
    partition dt_20281129 values less than ('2028-11-30 00:00:00'),
    partition dt_20281130 values less than ('2028-12-01 00:00:00'),
    partition dt_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dm.dm_wtw_opc_data_mini_day                     is 'water treatment work tag poc data latest'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.id                  is 'id'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.i_code              is 'install code'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.region_abbr         is 'region abbreviation'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.wtw_name_en         is 'water treatments work engliash name '
;comment on column coss_dm.dm_wtw_opc_data_mini_day.wtw_name_cn         is 'water treatments work chinses name '
;comment on column coss_dm.dm_wtw_opc_data_mini_day.wtw_name_tc         is 'water treatments work traditional chinses name '
;comment on column coss_dm.dm_wtw_opc_data_mini_day.tag_name_cn         is 'tag chinses name '
;comment on column coss_dm.dm_wtw_opc_data_mini_day.tag_name_tc         is 'tag traditional chinses name '
;comment on column coss_dm.dm_wtw_opc_data_mini_day.units               is 'tag units'
;comment on column coss_dm.dm_wtw_opc_data_latest_minf.tag_type            is 'tag type'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.tag_name            is 'tag name'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.tag_value           is 'tag value'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.quality             is 'quality'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.tag_time            is 'tag time'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.dm_update_time      is 'dm update time'
;comment on column coss_dm.dm_wtw_opc_data_mini_day.dm_load_time        is 'dm load time'
```

### 2.select sql 

1. tuenmun

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works 
   -- function describe: Water Treatment Works Monitoring For tuenmun
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                                -- id
     ,i_code                           -- install code
     ,region_abbr                      -- region abbreviation
     ,wtw_name_en                      -- water treatments work english name
     ,wtw_name_cn                      -- water treatments work chinese name
     ,wtw_name_tc                      -- water treatments work traditional chinese name
     ,tag_name_cn                      -- tag chinese name
     ,tag_name_tc                      -- tag traditional chinese name
     ,units                            -- tag units
     ,tag_type                         -- tag type
     ,tag_name                         -- tag name
     ,tag_value                        -- tag value
     ,quality                          -- quality
     ,tag_time                         -- tag time
     ,localtimestamp dm_update_time    -- dm update time
     ,localtimestamp dm_load_time      -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW016'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

   

2. yaukomtau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For yaukomtau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                                   -- id
     ,i_code                              -- install code
     ,region_abbr                         -- region abbreviation
     ,wtw_name_en                         -- water treatments work english name
     ,wtw_name_cn                         -- water treatments work chinese name
     ,wtw_name_tc                         -- water treatments work traditional chinese name
     ,tag_name_cn                         -- tag chinese name
     ,tag_name_tc                         -- tag traditional chinese name
     ,units                               -- tag units
     ,tag_type                            -- tag type
     ,tag_name                            -- tag name
     ,tag_value                           -- tag value
     ,quality                             -- quality
     ,tag_time                            -- tag time
     ,localtimestamp dm_update_time       -- dm update time
     ,localtimestamp dm_load_time         -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW018'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

   

3. shatin

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For shatin
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                              -- id
     ,i_code                         -- install code
     ,region_abbr                    -- region abbreviation
     ,wtw_name_en                    -- water treatments work english name
     ,wtw_name_cn                    -- water treatments work chinese name
     ,wtw_name_tc                    -- water treatments work traditional chinese name
     ,tag_name_cn                    -- tag chinese name
     ,tag_name_tc                    -- tag traditional chinese name
     ,units                          -- tag units
     ,tag_type                       -- tag type
     ,tag_name                       -- tag name
     ,tag_value                      -- tag value
     ,quality                        -- quality
     ,tag_time                       -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW013'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

4. silverminebay

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For silverminebay
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                              -- id
     ,i_code                         -- install code
     ,region_abbr                    -- region abbreviation
     ,wtw_name_en                    -- water treatments work english name
     ,wtw_name_cn                    -- water treatments work chinese name
     ,wtw_name_tc                    -- water treatments work traditional chinese name
     ,tag_name_cn                    -- tag chinese name
     ,tag_name_tc                    -- tag traditional chinese name
     ,units                          -- tag units
     ,tag_type                       -- tag type
     ,tag_name                       -- tag name
     ,tag_value                      -- tag value
     ,quality                        -- quality
     ,tag_time                       -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW009'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

5. autau

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For autau
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                              -- id
     ,i_code                         -- install code
     ,region_abbr                    -- region abbreviation
     ,wtw_name_en                    -- water treatments work english name
     ,wtw_name_cn                    -- water treatments work chinese name
     ,wtw_name_tc                    -- water treatments work traditional chinese name
     ,tag_name_cn                    -- tag chinese name
     ,tag_name_tc                    -- tag traditional chinese name
     ,units                          -- tag units
     ,tag_type                       -- tag type
     ,tag_name                       -- tag name
     ,tag_value                      -- tag value
     ,quality                        -- quality
     ,tag_time                       -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW021'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

6. ngautammei

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For ngautammei
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                              -- id
     ,i_code                         -- install code
     ,region_abbr                    -- region abbreviation
     ,wtw_name_en                    -- water treatments work english name
     ,wtw_name_cn                    -- water treatments work chinese name
     ,wtw_name_tc                    -- water treatments work traditional chinese name
     ,tag_name_cn                    -- tag chinese name
     ,tag_name_tc                    -- tag traditional chinese name
     ,units                          -- tag units
     ,tag_type                       -- tag type
     ,tag_name                       -- tag name
     ,tag_value                      -- tag value
     ,quality                        -- quality
     ,tag_time                       -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW027'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

7. maonshan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For maonshan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                              -- id
     ,i_code                         -- install code
     ,region_abbr                    -- region abbreviation
     ,wtw_name_en                    -- water treatments work english name
     ,wtw_name_cn                    -- water treatments work chinese name
     ,wtw_name_tc                    -- water treatments work traditional chinese name
     ,tag_name_cn                    -- tag chinese name
     ,tag_name_tc                    -- tag traditional chinese name
     ,units                          -- tag units
     ,tag_type                       -- tag type
     ,tag_name                       -- tag name
     ,tag_value                      -- tag value
     ,quality                        -- quality
     ,tag_time                       -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW024'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

8. siuhowan

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dm.dm_wtw_opc_data_latest_minf
   -- target table
   -- coss_dm.dm_wtw_opc_data_mini_day
   -- ****************************************************************************************
   ;insert into coss_dm.dm_wtw_opc_data_mini_day
   select
     id                              -- id
     ,i_code                         -- install code
     ,region_abbr                    -- region abbreviation
     ,wtw_name_en                    -- water treatments work english name
     ,wtw_name_cn                    -- water treatments work chinese name
     ,wtw_name_tc                    -- water treatments work traditional chinese name
     ,tag_name_cn                    -- tag chinese name
     ,tag_name_tc                    -- tag traditional chinese name
     ,units                          -- tag units
     ,tag_type                       -- tag type
     ,tag_name                       -- tag name
     ,tag_value                      -- tag value
     ,quality                        -- quality
     ,tag_time                       -- tag time
     ,localtimestamp dm_update_time  -- dm update time
     ,localtimestamp dm_load_time    -- dm load time
   from coss_dm.dm_wtw_opc_data_latest_minf t where i_code = 'TW025'
     and not exists
     (select
       1
     from coss_dm.dm_wtw_opc_data_mini_day as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name
       and t.tag_time = t1.tag_time)
   ```

   

# dim

```sql
;drop table if exists coss_dim.dim_wtw_tag_info
;create table if not exists coss_dim.dim_wtw_tag_info(
  i_code          varchar(50)
  ,region_abbr    varchar(50)
  ,wtw_name_en    varchar(200)
  ,wtw_name_cn    varchar(200)
  ,wtw_name_tc    varchar(200)
  ,tag_name_en    varchar(200)
  ,tag_name_cn    varchar(200)
  ,tag_name_tc    varchar(200)
  ,units          varchar(200)
  ,tag_type       varchar(200)
  ,dm_update_time timestamp(6)
  ,dm_load_time   timestamp(6)
  ,primary key(i_code, tag_name_en)
)
;comment on table  coss_dim.dim_wtw_tag_info                is 'water treatment work tag information'
;comment on column coss_dim.dim_wtw_tag_info.i_code         is 'install code'
;comment on column coss_dim.dim_wtw_tag_info.region_abbr    is 'region abbreviation'
;comment on column coss_dim.dim_wtw_tag_info.wtw_name_en    is 'water treatments work engliash name '
;comment on column coss_dim.dim_wtw_tag_info.wtw_name_cn    is 'water treatments work chinses name '
;comment on column coss_dim.dim_wtw_tag_info.wtw_name_tc    is 'water treatments work traditional chinses name '
;comment on column coss_dim.dim_wtw_tag_info.tag_name_en    is 'tag engliash name '
;comment on column coss_dim.dim_wtw_tag_info.tag_name_cn    is 'tag chinses name '
;comment on column coss_dim.dim_wtw_tag_info.tag_name_tc    is 'tag traditional chinses name '
;comment on column coss_dim.dim_wtw_tag_info.units          is 'tag units'
;comment on column coss_dim.dim_wtw_tag_info.tag_type       is 'tag type'
;comment on column coss_dim.dim_wtw_tag_info.dm_update_time is 'update time'
;comment on column coss_dim.dim_wtw_tag_info.dm_load_time   is 'load time'
```





## data verify



```sql
select distinct tag_time  from coss_dm.dm_wtw_opc_data_mini_day where i_code = 'TW013' order by tag_time
select distinct tag_time  from coss_dm.dm_wtw_opc_data_latest_minf dwodlm where i_code = 'TW013' order by tag_time

select distinct tag_time  from coss_dwd.dwd_wtw_opc_data_mini_day dwodmd  where i_code = 'TW013' order by tag_time
select distinct tag_time  from coss_dwd.dwd_wtw_opc_data_latest_minf dwodlm  where i_code = 'TW013' order by tag_time

select distinct tag_time  from coss_ods.ods_dcs_opc_data_shatin_minf order by tag_time
select distinct tag_time  from coss_ods.ods_dcs_opc_data_full_shatin_mini_month order by tag_time

```





# tmp

```sql

```



## 1.coss_ods.ods_dcs_opc_data_di

```sql
;drop table if exists coss_ods.ods_dcs_opc_data_di
;create table if not exists coss_ods.ods_dcs_opc_data_di (
	id bigserial not null,
	tag_name varchar(128) null,
	tag_value varchar(128) null,
	tag_time timestamp not null,
	ms_sql_time timestamp not null,
    ods_load_time timestamp(6) not null
)
with (
	orientation=row,
	compression=no,
	storage_type=ustore,
	segment=off
)
partition by range (tag_time)
(
	partition yr_20250718 values less than ('2025-07-19 00:00:00'),
	partition yr_20250719 values less than ('2025-07-20 00:00:00'),
	partition yr_20250720 values less than ('2025-07-21 00:00:00'),
	partition yr_20250721 values less than ('2025-07-22 00:00:00'),
	partition yr_20250722 values less than ('2025-07-23 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
    )
;insert into coss_ods.ods_dcs_opc_data_di
select
  id
  ,tag_name
  ,tag_value
  ,tag_time
  ,ms_sql_time
  ,localtimestamp ods_load_time
from coss_dcs.opc_data 
```

## 2.coss_ods.ods_dcs_opc_data_latest_mini

```sql
;drop table if exists coss_ods.ods_dcs_opc_data_latest_mini
;create table coss_ods.ods_dcs_opc_data_latest_mini (
	id bigserial not null,
	tag_name varchar(128) not null,
	tag_value varchar(128) not null,
	tag_time timestamp not null,
	ms_sql_time timestamp not null,
    ods_load_time timestamp(6) not null
)
with (
	orientation=row,
	compression=no,
	storage_type=ustore,
	segment=off
)
;insert into coss_ods.ods_dcs_opc_data_latest_mini
select 
  id
  ,tag_name
  ,tag_value
  ,tag_time
  ,ms_sql_time
  ,localtimestamp ods_load_time
from coss_dcs.opc_data_latest 
```



