## 7.ods_dcs_opc_wtw_data_siuhowan

### 1.create table 

1. ods_dcs_opc_wtw_data_siuhowan_minf

   ```sql
   
   ```

2. ods_dcs_opc_wtw_data_full_siuhowan_mini_month

   ```sql
   ;drop table if exists coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
   ;create table if not exists coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month (
   	id bigserial not null,
   	tag_name varchar(128) not null,
   	tag_value varchar(128) null,
   	quality int4 not null,
   	tag_time timestamp not null,
   	ms_sql_time timestamp not null default pg_systimestamp(),
   	ods_update_time timestamp(6) default current_timestamp,
       ods_load_time   timestamp(6) default current_timestamp,
   	constraint opc_data_full_siuhowan_pk primary key (tag_name, tag_time)
   )
   with (
   	orientation=row,
   	compression=no,
   	storage_type=ustore,
   	segment=off
   )
   partition by range (tag_time)
   (
       partition mh_202501 values less than ('2025-02-01 00:00:00'),
       partition mh_202502 values less than ('2025-03-01 00:00:00'),
       partition mh_202503 values less than ('2025-04-01 00:00:00'),
       partition mh_202504 values less than ('2025-05-01 00:00:00'),
       partition mh_202505 values less than ('2025-06-01 00:00:00'),
       partition mh_202506 values less than ('2025-07-01 00:00:00'),
       partition mh_202507 values less than ('2025-08-01 00:00:00'),
       partition mh_202508 values less than ('2025-09-01 00:00:00'),
       partition mh_202509 values less than ('2025-10-01 00:00:00'),
       partition mh_202510 values less than ('2025-11-01 00:00:00'),
       partition mh_202511 values less than ('2025-12-01 00:00:00'),
       partition mh_202512 values less than ('2026-01-01 00:00:00'),
       partition mh_202601 values less than ('2026-02-01 00:00:00'),
       partition mh_202602 values less than ('2026-03-01 00:00:00'),
       partition mh_202603 values less than ('2026-04-01 00:00:00'),
       partition mh_202604 values less than ('2026-05-01 00:00:00'),
       partition mh_202605 values less than ('2026-06-01 00:00:00'),
       partition mh_202606 values less than ('2026-07-01 00:00:00'),
       partition mh_202607 values less than ('2026-08-01 00:00:00'),
       partition mh_202608 values less than ('2026-09-01 00:00:00'),
       partition mh_202609 values less than ('2026-10-01 00:00:00'),
       partition mh_202610 values less than ('2026-11-01 00:00:00'),
       partition mh_202611 values less than ('2026-12-01 00:00:00'),
       partition mh_202612 values less than ('2027-01-01 00:00:00'),
       partition mh_202701 values less than ('2027-02-01 00:00:00'),
       partition mh_202702 values less than ('2027-03-01 00:00:00'),
       partition mh_202703 values less than ('2027-04-01 00:00:00'),
       partition mh_202704 values less than ('2027-05-01 00:00:00'),
       partition mh_202705 values less than ('2027-06-01 00:00:00'),
       partition mh_202706 values less than ('2027-07-01 00:00:00'),
       partition mh_202707 values less than ('2027-08-01 00:00:00'),
       partition mh_202708 values less than ('2027-09-01 00:00:00'),
       partition mh_202709 values less than ('2027-10-01 00:00:00'),
       partition mh_202710 values less than ('2027-11-01 00:00:00'),
       partition mh_202711 values less than ('2027-12-01 00:00:00'),
       partition mh_202712 values less than ('2028-01-01 00:00:00'),
       partition mh_202801 values less than ('2028-02-01 00:00:00'),
       partition mh_202802 values less than ('2028-03-01 00:00:00'),
       partition mh_202803 values less than ('2028-04-01 00:00:00'),
       partition mh_202804 values less than ('2028-05-01 00:00:00'),
       partition mh_202805 values less than ('2028-06-01 00:00:00'),
       partition mh_202806 values less than ('2028-07-01 00:00:00'),
       partition mh_202807 values less than ('2028-08-01 00:00:00'),
       partition mh_202808 values less than ('2028-09-01 00:00:00'),
       partition mh_202809 values less than ('2028-10-01 00:00:00'),
       partition mh_202810 values less than ('2028-11-01 00:00:00'),
       partition mh_future values less than ('9999-01-01 00:00:00')
   )
   ;comment on table  coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month                   is 'water treatment work tag poc data history'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.id                is 'id'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.tag_name          is 'tag name'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.tag_value         is 'tag value'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.quality           is 'quality'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.tag_time          is 'tag time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.ms_sql_time       is 'ms sql time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.ods_update_time   is 'ods update time'
   ;comment on column coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month.ods_load_time     is 'ods load time'
   ```


### 2.select sql

1. full update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_dcs.opc_data_siuhowan
   -- coss_dim.dim_wtw_tag_info
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
   -- ****************************************************************************************
   select
   	t.id                                -- id
   	,t.tag_name                         -- tag name
   	,t.tag_value                        -- tag value
   	,t.quality                          -- quality
   	,t.tag_time                         -- tag time
   	,t.ms_sql_time                      -- ms sql time
   	,localtimestamp ods_update_time     -- ods update time
       ,localtimestamp ods_load_time       -- ods load time
   from coss_dcs.opc_data_siuhowan t
     inner join coss_dim.dim_wtw_tag_info t1 on t.tag_name = t1.tag_name_en where t1.i_code = 'TW025'
   ```

2. incremental update select sql

   ```sql
   -- ****************************************************************************************
   -- subject     areas: Water Treatment Works
   -- function describe: Water Treatment Works Monitoring For siuhowan
   -- create         by: dongmaochen
   -- create       date: 2025-10-14
   -- modify date                modify by                    modify content
   -- None                       None                         None
   -- source table
   -- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
   -- target table
   -- coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
   -- ****************************************************************************************
   insert into coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
   select
   	t.id                              -- id
   	,t.tag_name                       -- tag name
   	,t.tag_value                      -- tag value
   	,t.quality                        -- quality
   	,t.tag_time                       -- tag time
   	,t.ms_sql_time                    -- ms sql time
   	,localtimestamp ods_update_time   -- ods update time
       ,localtimestamp ods_load_time     -- ods load time
   from coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf t where
     not exists
     (select
       1
     from coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month as t1
     WHERE t.id = t1.id
       and t.tag_name = t1.tag_name 
       and t.tag_time = t1.tag_time)
   ```

## 



