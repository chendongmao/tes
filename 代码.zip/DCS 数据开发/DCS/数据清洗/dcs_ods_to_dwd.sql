-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For tuenmun
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW016';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW016' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf;

-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For yaukomtau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW018';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW018' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf;


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For shatin
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_shatin_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW013';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW013' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_shatin_minf;


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For silverminebay
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW009';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW009' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf;



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For autau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_autau_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW021';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW021' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_autau_minf;


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For ngautammei
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW027';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW027' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf;


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For maonshan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_maonshan_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW024';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW024' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_maonshan_minf;


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For siuhowan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW025';

INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW025' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf;


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For sheungshui
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf 
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dwd.dwd_wtw_opc_data_latest_minf
WHERE i_code = 'TW017';
INSERT INTO coss_dwd.dwd_wtw_opc_data_latest_minf (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                              -- id
    'TW017' AS i_code,               -- install code
    tag_name,                        -- tag name
    tag_value,                       -- tag value
    quality,                         -- quality
    tag_time,                        -- tag time
    LOCALTIMESTAMP AS dwd_update_time,  -- dwd update time
    LOCALTIMESTAMP AS dwd_load_time     -- dwd load time
FROM coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf;

-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For tuenmun
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                   -- id
    i_code,              -- install code
    tag_name,            -- tag name
    tag_value,           -- tag value
    quality,             -- quality
    tag_time,            -- tag time
    dwd_update_time,     -- dwd update time
    dwd_load_time        -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW016'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day AS t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For yaukomtau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW018'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For shatin
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW013'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For silverminebay
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW009'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For autau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW021'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );

-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For ngautammei
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW027'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For maonshan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW024'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For siuhowan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                -- id
    i_code,           -- install code
    tag_name,         -- tag name
    tag_value,        -- tag value
    quality,          -- quality
    tag_time,         -- tag time
    dwd_update_time,  -- dwd update time
    dwd_load_time     -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW025'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For sheungshui
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- target table
-- coss_dwd.dwd_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dwd.dwd_wtw_opc_data_mini_day (
    id,
    i_code,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dwd_update_time,
    dwd_load_time
)
SELECT
    id,                   -- id
    i_code,              -- install code
    tag_name,            -- tag name
    tag_value,           -- tag value
    quality,             -- quality
    tag_time,            -- tag time
    dwd_update_time,     -- dwd update time
    dwd_load_time        -- dwd load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
WHERE i_code = 'TW017'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dwd.dwd_wtw_opc_data_mini_day AS t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );




