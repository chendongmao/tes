-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For tuenmun
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_tuenmun
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_tuenmun t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW016';


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For tuenmun
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_tuenmun_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For yaukomtau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_yaukomtau
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_yaukomtau t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW018';

-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For yaukomtau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_yaukomtau_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For shatin
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_shatin
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_shatin_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_shatin t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW013';

-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For shatin
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_shatin_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_shatin_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_shatin_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For silverminebay
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_silverminebay
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_silverminebay t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW009';


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For silverminebay
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_silverminebay_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);

-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For autau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_autau
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_autau_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_autau t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW021';


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For autau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_autau_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_autau_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_autau_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);

-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For ngautammei
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_ngautammei
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_ngautammei t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW027';




-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For ngautammei
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_ngautammei_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);





-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For maonshan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_maonshan
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_maonshan_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_maonshan t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW024';



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For maonshan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_maonshan_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_maonshan_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_maonshan_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For siuhowan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_siuhowan
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_siuhowan t
INNER JOIN coss_dim.dim_wtw_tag_info t1
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW025';



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For siuhowan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_siuhowan_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);

-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For sheungshui
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dcs.opc_data_sheungshui
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf
-- ****************************************************************************************
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_dcs.opc_data_sheungshui t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en
WHERE t1.i_code = 'TW017';

-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For sheungshui
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf
-- target table
-- coss_ods.ods_dcs_wtw_opc_data_full_sheungshui_mini_month
-- ****************************************************************************************
INSERT INTO coss_ods.ods_dcs_wtw_opc_data_full_sheungshui_mini_month (
    id,
    tag_name,
    tag_value,
    quality,
    tag_time,
    ms_sql_time,
    ods_update_time,
    ods_load_time
)
SELECT
    t.id,                              -- id
    t.tag_name,                        -- tag name
    t.tag_value,                       -- tag value
    t.quality,                         -- quality
    t.tag_time,                        -- tag time
    t.ms_sql_time,                     -- ms sql time
    LOCALTIMESTAMP AS ods_update_time,  -- ods update time
    LOCALTIMESTAMP AS ods_load_time     -- ods load time
FROM coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf t
WHERE NOT EXISTS (
    SELECT 1
    FROM coss_ods.ods_dcs_wtw_opc_data_full_sheungshui_mini_month t1
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
);



