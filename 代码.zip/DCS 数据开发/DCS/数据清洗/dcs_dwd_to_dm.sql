-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For tuenmun
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW016';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                            -- id
    t1.i_code,                      -- install code
    t1.region_abbr,                 -- region abbreviation
    t1.wtw_name_en,                 -- water treatments work english name
    t1.wtw_name_cn,                 -- water treatments work chinese name
    t1.wtw_name_tc,                 -- water treatments work traditional chinese name
    t1.tag_name_cn,                 -- tag chinese name
    t1.tag_name_tc,                 -- tag traditional chinese name
    t1.units,                       -- tag units
    t1.tag_type,                    -- tag type
    t.tag_name,                     -- tag name
    t.tag_value,                    -- tag value
    t.quality,                      -- quality
    t.tag_time,                     -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time     -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW016';




-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For yaukomtau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW018';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                             -- id
    t1.i_code,                       -- install code
    t1.region_abbr,                  -- region abbreviation
    t1.wtw_name_en,                  -- water treatments work english name
    t1.wtw_name_cn,                  -- water treatments work chinese name
    t1.wtw_name_tc,                  -- water treatments work traditional chinese name
    t1.tag_name_cn,                  -- tag chinese name
    t1.tag_name_tc,                  -- tag traditional chinese name
    t1.units,                        -- tag units
    t1.tag_type,                     -- tag type
    t.tag_name,                      -- tag name
    t.tag_value,                     -- tag value
    t.quality,                       -- quality
    t.tag_time,                      -- tag time
    LOCALTIMESTAMP AS dm_update_time,   -- dm update time
    LOCALTIMESTAMP AS dm_load_time     -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW018';



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For shatin
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW013';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                           -- id
    t1.i_code,                     -- install code
    t1.region_abbr,                -- region abbreviation
    t1.wtw_name_en,                -- water treatments work english name
    t1.wtw_name_cn,                -- water treatments work chinese name
    t1.wtw_name_tc,                -- water treatments work traditional chinese name
    t1.tag_name_cn,                -- tag chinese name
    t1.tag_name_tc,                -- tag traditional chinese name
    t1.units,                      -- tag units
    t1.tag_type,                   -- tag type
    t.tag_name,                    -- tag name
    t.tag_value,                   -- tag value
    t.quality,                     -- quality
    t.tag_time,                    -- tag time
    LOCALTIMESTAMP AS dm_update_time, -- dm update time
    LOCALTIMESTAMP AS dm_load_time   -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW013';



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For silverminebay
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW009';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                           -- id
    t1.i_code,                     -- install code
    t1.region_abbr,                -- region abbreviation
    t1.wtw_name_en,                -- water treatments work english name
    t1.wtw_name_cn,                -- water treatments work chinese name
    t1.wtw_name_tc,                -- water treatments work traditional chinese name
    t1.tag_name_cn,                -- tag chinese name
    t1.tag_name_tc,                -- tag traditional chinese name
    t1.units,                      -- tag units
    t1.tag_type,                   -- tag type
    t.tag_name,                    -- tag name
    t.tag_value,                   -- tag value
    t.quality,                     -- quality
    t.tag_time,                    -- tag time
    LOCALTIMESTAMP AS dm_update_time, -- dm update time
    LOCALTIMESTAMP AS dm_load_time   -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW009';


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For autau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW021';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                           -- id
    t1.i_code,                     -- install code
    t1.region_abbr,                -- region abbreviation
    t1.wtw_name_en,                -- water treatments work english name
    t1.wtw_name_cn,                -- water treatments work chinese name
    t1.wtw_name_tc,                -- water treatments work traditional chinese name
    t1.tag_name_cn,                -- tag chinese name
    t1.tag_name_tc,                -- tag traditional chinese name
    t1.units,                      -- tag units
    t1.tag_type,                   -- tag type
    t.tag_name,                    -- tag name
    t.tag_value,                   -- tag value
    t.quality,                     -- quality
    t.tag_time,                    -- tag time
    LOCALTIMESTAMP AS dm_update_time, -- dm update time
    LOCALTIMESTAMP AS dm_load_time   -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW021';


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For ngautammei
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW027';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                           -- id
    t1.i_code,                     -- install code
    t1.region_abbr,                -- region abbreviation
    t1.wtw_name_en,                -- water treatments work english name
    t1.wtw_name_cn,                -- water treatments work chinese name
    t1.wtw_name_tc,                -- water treatments work traditional chinese name
    t1.tag_name_cn,                -- tag chinese name
    t1.tag_name_tc,                -- tag traditional chinese name
    t1.units,                      -- tag units
    t1.tag_type,                   -- tag type
    t.tag_name,                    -- tag name
    t.tag_value,                   -- tag value
    t.quality,                     -- quality
    t.tag_time,                    -- tag time
    LOCALTIMESTAMP AS dm_update_time, -- dm update time
    LOCALTIMESTAMP AS dm_load_time   -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW027';


-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For maonshan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW024';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                           -- id
    t1.i_code,                     -- install code
    t1.region_abbr,                -- region abbreviation
    t1.wtw_name_en,                -- water treatments work english name
    t1.wtw_name_cn,                -- water treatments work chinese name
    t1.wtw_name_tc,                -- water treatments work traditional chinese name
    t1.tag_name_cn,                -- tag chinese name
    t1.tag_name_tc,                -- tag traditional chinese name
    t1.units,                      -- tag units
    t1.tag_type,                   -- tag type
    t.tag_name,                    -- tag name
    t.tag_value,                   -- tag value
    t.quality,                     -- quality
    t.tag_time,                    -- tag time
    LOCALTIMESTAMP AS dm_update_time, -- dm update time
    LOCALTIMESTAMP AS dm_load_time   -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW024';

-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For siuhowan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW025';

INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                           -- id
    t1.i_code,                     -- install code
    t1.region_abbr,                -- region abbreviation
    t1.wtw_name_en,                -- water treatments work english name
    t1.wtw_name_cn,                -- water treatments work chinese name
    t1.wtw_name_tc,                -- water treatments work traditional chinese name
    t1.tag_name_cn,                -- tag chinese name
    t1.tag_name_tc,                -- tag traditional chinese name
    t1.units,                      -- tag units
    t1.tag_type,                   -- tag type
    t.tag_name,                    -- tag name
    t.tag_value,                   -- tag value
    t.quality,                     -- quality
    t.tag_time,                    -- tag time
    LOCALTIMESTAMP AS dm_update_time, -- dm update time
    LOCALTIMESTAMP AS dm_load_time   -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW025';



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For sheungshui
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dwd.dwd_wtw_opc_data_latest_minf
-- coss_dim.dim_wtw_tag_info
-- target table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- ****************************************************************************************
DELETE FROM coss_dm.dm_wtw_opc_data_latest_minf
WHERE i_code = 'TW017';
INSERT INTO coss_dm.dm_wtw_opc_data_latest_minf (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    t.id,                            -- id
    t1.i_code,                      -- install code
    t1.region_abbr,                 -- region abbreviation
    t1.wtw_name_en,                 -- water treatments work english name
    t1.wtw_name_cn,                 -- water treatments work chinese name
    t1.wtw_name_tc,                 -- water treatments work traditional chinese name
    t1.tag_name_cn,                 -- tag chinese name
    t1.tag_name_tc,                 -- tag traditional chinese name
    t1.units,                       -- tag units
    t1.tag_type,                    -- tag type
    t.tag_name,                     -- tag name
    t.tag_value,                    -- tag value
    t.quality,                      -- quality
    t.tag_time,                     -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time     -- dm load time
FROM coss_dwd.dwd_wtw_opc_data_latest_minf t
INNER JOIN coss_dim.dim_wtw_tag_info t1 
    ON t.tag_name = t1.tag_name_en  
WHERE t1.i_code = 'TW017';



-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For tuenmun
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                                -- id
    i_code,                           -- install code
    region_abbr,                      -- region abbreviation
    wtw_name_en,                      -- water treatments work english name
    wtw_name_cn,                      -- water treatments work chinese name
    wtw_name_tc,                      -- water treatments work traditional chinese name
    tag_name_cn,                      -- tag chinese name
    tag_name_tc,                      -- tag traditional chinese name
    units,                            -- tag units
    tag_type,                         -- tag type
    tag_name,                         -- tag name
    tag_value,                        -- tag value
    quality,                          -- quality
    tag_time,                         -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time     -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW016'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For yaukomtau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                                   -- id
    i_code,                              -- install code
    region_abbr,                         -- region abbreviation
    wtw_name_en,                         -- water treatments work english name
    wtw_name_cn,                         -- water treatments work chinese name
    wtw_name_tc,                         -- water treatments work traditional chinese name
    tag_name_cn,                         -- tag chinese name
    tag_name_tc,                         -- tag traditional chinese name
    units,                               -- tag units
    tag_type,                            -- tag type
    tag_name,                            -- tag name
    tag_value,                           -- tag value
    quality,                             -- quality
    tag_time,                            -- tag time
    LOCALTIMESTAMP AS dm_update_time,     -- dm update time
    LOCALTIMESTAMP AS dm_load_time       -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW018'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For shatin
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                              -- id
    i_code,                         -- install code
    region_abbr,                    -- region abbreviation
    wtw_name_en,                    -- water treatments work english name
    wtw_name_cn,                    -- water treatments work chinese name
    wtw_name_tc,                    -- water treatments work traditional chinese name
    tag_name_cn,                    -- tag chinese name
    tag_name_tc,                    -- tag traditional chinese name
    units,                          -- tag units
    tag_type,                       -- tag type
    tag_name,                       -- tag name
    tag_value,                      -- tag value
    quality,                        -- quality
    tag_time,                       -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time    -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW013'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For silverminebay
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                              -- id
    i_code,                         -- install code
    region_abbr,                    -- region abbreviation
    wtw_name_en,                    -- water treatments work english name
    wtw_name_cn,                    -- water treatments work chinese name
    wtw_name_tc,                    -- water treatments work traditional chinese name
    tag_name_cn,                    -- tag chinese name
    tag_name_tc,                    -- tag traditional chinese name
    units,                          -- tag units
    tag_type,                       -- tag type
    tag_name,                       -- tag name
    tag_value,                      -- tag value
    quality,                        -- quality
    tag_time,                       -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time    -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW009'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For autau
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                              -- id
    i_code,                         -- install code
    region_abbr,                    -- region abbreviation
    wtw_name_en,                    -- water treatments work english name
    wtw_name_cn,                    -- water treatments work chinese name
    wtw_name_tc,                    -- water treatments work traditional chinese name
    tag_name_cn,                    -- tag chinese name
    tag_name_tc,                    -- tag traditional chinese name
    units,                          -- tag units
    tag_type,                       -- tag type
    tag_name,                       -- tag name
    tag_value,                      -- tag value
    quality,                        -- quality
    tag_time,                       -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time    -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW021'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For ngautammei
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                              -- id
    i_code,                         -- install code
    region_abbr,                    -- region abbreviation
    wtw_name_en,                    -- water treatments work english name
    wtw_name_cn,                    -- water treatments work chinese name
    wtw_name_tc,                    -- water treatments work traditional chinese name
    tag_name_cn,                    -- tag chinese name
    tag_name_tc,                    -- tag traditional chinese name
    units,                          -- tag units
    tag_type,                       -- tag type
    tag_name,                       -- tag name
    tag_value,                      -- tag value
    quality,                        -- quality
    tag_time,                       -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time    -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW027'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );


-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For maonshan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                              -- id
    i_code,                         -- install code
    region_abbr,                    -- region abbreviation
    wtw_name_en,                    -- water treatments work english name
    wtw_name_cn,                    -- water treatments work chinese name
    wtw_name_tc,                    -- water treatments work traditional chinese name
    tag_name_cn,                    -- tag chinese name
    tag_name_tc,                    -- tag traditional chinese name
    units,                          -- tag units
    tag_type,                       -- tag type
    tag_name,                       -- tag name
    tag_value,                      -- tag value
    quality,                        -- quality
    tag_time,                       -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time    -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW024'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );



-- ****************************************************************************************
-- subject     areas: Water Treatment Works
-- function describe: Water Treatment Works Monitoring For siuhowan
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                              -- id
    i_code,                         -- install code
    region_abbr,                    -- region abbreviation
    wtw_name_en,                    -- water treatments work english name
    wtw_name_cn,                    -- water treatments work chinese name
    wtw_name_tc,                    -- water treatments work traditional chinese name
    tag_name_cn,                    -- tag chinese name
    tag_name_tc,                    -- tag traditional chinese name
    units,                          -- tag units
    tag_type,                       -- tag type
    tag_name,                       -- tag name
    tag_value,                      -- tag value
    quality,                        -- quality
    tag_time,                       -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time    -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW025'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );









-- ****************************************************************************************
-- subject     areas: Water Treatment Works 
-- function describe: Water Treatment Works Monitoring For sheungshui
-- create         by: dongmaochen
-- create       date: 2025-10-14
-- modify date                modify by                    modify content
-- None                       None                         None
-- source table
-- coss_dm.dm_wtw_opc_data_latest_minf
-- target table
-- coss_dm.dm_wtw_opc_data_mini_day
-- ****************************************************************************************
INSERT INTO coss_dm.dm_wtw_opc_data_mini_day (
    id,
    i_code,
    region_abbr,
    wtw_name_en,
    wtw_name_cn,
    wtw_name_tc,
    tag_name_cn,
    tag_name_tc,
    units,
    tag_type,
    tag_name,
    tag_value,
    quality,
    tag_time,
    dm_update_time,
    dm_load_time
)
SELECT
    id,                                -- id
    i_code,                           -- install code
    region_abbr,                      -- region abbreviation
    wtw_name_en,                      -- water treatments work english name
    wtw_name_cn,                      -- water treatments work chinese name
    wtw_name_tc,                      -- water treatments work traditional chinese name
    tag_name_cn,                      -- tag chinese name
    tag_name_tc,                      -- tag traditional chinese name
    units,                            -- tag units
    tag_type,                         -- tag type
    tag_name,                         -- tag name
    tag_value,                        -- tag value
    quality,                          -- quality
    tag_time,                         -- tag time
    LOCALTIMESTAMP AS dm_update_time,  -- dm update time
    LOCALTIMESTAMP AS dm_load_time     -- dm load time
FROM coss_dm.dm_wtw_opc_data_latest_minf t
WHERE i_code = 'TW017'
  AND NOT EXISTS (
    SELECT 1
    FROM coss_dm.dm_wtw_opc_data_mini_day t1  
    WHERE t.id = t1.id
      AND t.tag_name = t1.tag_name
      AND t.tag_time = t1.tag_time
  );


