-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Tuen Mun Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_tuenmun_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_tuenmun_minf.ods_load_time     IS 'ods load time';


-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Yau Kom Tau Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_yaukomtau_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_yaukomtau_minf.ods_load_time     IS 'ods load time';


-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Shatin Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_shatin_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_shatin_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_shatin_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_shatin_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_shatin_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_shatin_minf.ods_load_time     IS 'ods load time';

-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Silvermine Bay Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_silverminebay_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_silverminebay_minf.ods_load_time     IS 'ods load time';


-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Au Tau Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_autau_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_autau_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_autau_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_autau_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_autau_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_autau_minf.ods_load_time     IS 'ods load time';



-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Ngau Tam Mei Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_ngautammei_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_ngautammei_minf.ods_load_time     IS 'ods load time';



-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Ma On Shan Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_maonshan_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_maonshan_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_maonshan_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_maonshan_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_maonshan_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_maonshan_minf.ods_load_time     IS 'ods load time';



-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Siu Ho Wan Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf;

CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_siuhowan_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);

-- Table and Column Comments (all in English)
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_siuhowan_minf.ods_load_time     IS 'ods load time';

-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create ODS table for Sheung Shui Water Treatment Works DCS OPC latest data
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf;
CREATE TABLE IF NOT EXISTS coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf (
    id              BIGSERIAL NOT NULL,
    tag_name        VARCHAR(128) NULL,
    tag_value       VARCHAR(128) NULL,
    quality         INT4 NOT NULL,
    tag_time        TIMESTAMP NOT NULL,
    ms_sql_time     TIMESTAMP NOT NULL DEFAULT pg_systimestamp(),
    ods_update_time TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    ods_load_time   TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT opc_data_sheungshui_unique UNIQUE (tag_name)
) WITH (
    orientation=row,
    compression=no,
    storage_type=ustore,
    segment=off
);
COMMENT ON TABLE coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf                   IS 'water treatment work tag poc data latest';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.id                IS 'id';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.tag_name          IS 'tag name';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.tag_value         IS 'tag value';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.quality           IS 'quality';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.tag_time          IS 'tag time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.ms_sql_time       IS 'ms sql time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.ods_update_time   IS 'ods update time';
COMMENT ON COLUMN coss_ods.ods_dcs_wtw_opc_data_sheungshui_minf.ods_load_time     IS 'ods load time';

