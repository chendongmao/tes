-- ****************************************************************************************
-- Subject Areas: Water Treatment Works
-- Function Description: Create dimension table for water treatment work tag information
-- Create By: dongmaochen
-- Create Date: 2025-10-14
-- Modify Date | Modify By | Modify Content
-- None       | None      | None
-- Target Table: coss_dim.dim_wtw_tag_info
-- ****************************************************************************************
DROP TABLE IF EXISTS coss_dim.dim_wtw_tag_info;

CREATE TABLE IF NOT EXISTS coss_dim.dim_wtw_tag_info (
    i_code          VARCHAR(50) NOT NULL,
    region_abbr     VARCHAR(50),
    wtw_name_en     VARCHAR(200),
    wtw_name_cn     VARCHAR(200),
    wtw_name_tc     VARCHAR(200),
    tag_name_en     VARCHAR(200) NOT NULL,
    tag_name_cn     VARCHAR(200),
    tag_name_tc     VARCHAR(200),
    units           VARCHAR(200),
    tag_type        VARCHAR(200),
    dm_update_time  TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP(6),
    dm_load_time    TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (i_code, tag_name_en)
);

COMMENT ON TABLE coss_dim.dim_wtw_tag_info IS 'water treatment work tag information';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.i_code         IS 'install code';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.region_abbr    IS 'region abbreviation';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.wtw_name_en    IS 'water treatments work english name';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.wtw_name_cn    IS 'water treatments work chinese name';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.wtw_name_tc    IS 'water treatments work traditional chinese name';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.tag_name_en    IS 'tag english name';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.tag_name_cn    IS 'tag chinese name';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.tag_name_tc    IS 'tag traditional chinese name';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.units          IS 'tag units';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.tag_type       IS 'tag type';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.dm_update_time IS 'update time';
COMMENT ON COLUMN coss_dim.dim_wtw_tag_info.dm_load_time   IS 'load time';