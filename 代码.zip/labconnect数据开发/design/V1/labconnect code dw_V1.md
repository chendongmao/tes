version desc

```tex
1.没有数据字典参考下开发
```

# ods

## 1.ods_labconnect_labcon_hki_wqmm_acceptable_diff_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_acceptable_diff_df;
CREATE table if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_acceptable_diff_df (
	acceptable_diff_id serial4 NOT NULL,
	config_id int4 NOT NULL,
	loc_id int4 NOT NULL,
	ph_abs_diff numeric(8, 3) NULL,
	ph_percent_diff numeric(8, 3) NULL,
	turb_abs_diff numeric(8, 3) NULL,
	turb_percent_diff numeric(8, 3) NULL,
	rcl2_abs_diff numeric(8, 3) NULL,
	rcl2_percent_diff numeric(8, 3) NULL,
	fluoride_abs_diff numeric(8, 3) NULL,
	fluoride_percent_diff numeric(8, 3) NULL,
	mn_abs_diff numeric(8, 3) NULL,
	mn_percent_diff numeric(8, 3) NULL,
	nh3_abs_diff numeric(8, 3) NULL,
	nh3_percent_diff numeric(8, 3) NULL,
	uv_abs_diff numeric(8, 3) NULL,
	uv_percent_diff numeric(8, 3) NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_acceptable_diff_pkey PRIMARY KEY (acceptable_diff_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);

```

```
extract 
select 
  acceptable_diff_id
  ,config_id
  ,loc_id
  ,ph_abs_diff
  ,ph_percent_diff
  ,turb_abs_diff
  ,turb_percent_diff
  ,rcl2_abs_diff
  ,rcl2_percent_diff
  ,fluoride_abs_diff
  ,fluoride_percent_diff
  ,mn_abs_diff
  ,mn_percent_diff
  ,nh3_abs_diff
  ,nh3_percent_diff
  ,uv_abs_diff
  ,uv_percent_diff
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from 
labcon_hki.wqmm_acceptable_diff
```



## 2.ods_labconnect_labcon_hki_wqmm_analyzer_verification_di_year

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_analyzer_verification_di_year;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_analyzer_verification_di_year (
	verification_id serial4 NOT NULL,
	wtw_id int4 NOT NULL,
	status int2 NULL,
	last_updated_date timestamp NULL,
	sample_date timestamp NULL,
	reported_by int4 NULL,
	reported_role int4 NULL,
	reported_date timestamp NULL,
	no_record_reason text NULL,
	approved_by int4 NULL,
	approved_role int4 NULL,
	approved_remarks text NULL,
	approved_date timestamp NULL,
	require_acknowledgement bool NULL,
	acknowledged_by int4 NULL,
	acknowledged_role int4 NULL,
	acknowledged_remarks text NULL,
	acknowledged_date timestamp NULL,
	reviewed_by int4 NULL,
	reviewed_role int4 NULL,
	reviewed_remarks text NULL,
	reviewed_date timestamp NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_analyzer_verification_pkey PRIMARY KEY (verification_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  verification_id
  ,wtw_id
  ,status
  ,last_updated_date
  ,sample_date
  ,reported_by
  ,reported_role
  ,reported_date
  ,no_record_reason
  ,approved_by
  ,approved_role
  ,approved_remarks
  ,approved_date
  ,require_acknowledgement
  ,acknowledged_by
  ,acknowledged_role
  ,acknowledged_remarks
  ,acknowledged_date
  ,reviewed_by
  ,reviewed_role
  ,reviewed_remarks
  ,reviewed_date
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_analyzer_verification
```



## 3.ods_labconnect_labcon_hki_wqmm_analyzer_verification_item_df

```
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_analyzer_verification_item_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_analyzer_verification_item_df (
	verification_item_id int4 NOT NULL,
	verification_id int4 NOT NULL,
	loc_id int4 NOT NULL,
	ph_manual numeric(8, 3) NULL,
	ph_analyzer numeric(8, 3) NULL,
	ph_remarks text NULL,
	turb_manual numeric(8, 3) NULL,
	turb_analyzer numeric(8, 3) NULL,
	turb_remarks text NULL,
	rcl2_manual numeric(8, 3) NULL,
	rcl2_analyzer numeric(8, 3) NULL,
	rcl2_remarks text NULL,
	fluoride_manual numeric(8, 3) NULL,
	fluoride_analyzer numeric(8, 3) NULL,
	fluoride_remarks text NULL,
	mn_manual numeric(8, 3) NULL,
	mn_analyzer numeric(8, 3) NULL,
	mn_remarks text NULL,
	nh3_manual numeric(8, 3) NULL,
	nh3_analyzer int4 NULL,
	nh3_remarks text NULL,
	uv_manual numeric(8, 3) NULL,
	uv_analyzer int4 NULL,
	uv_remarks text NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_analyzer_verification_item_pkey PRIMARY KEY (verification_item_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);

```

```
select
  verification_item_id
  ,verification_id
  ,loc_id
  ,ph_manual
  ,ph_analyzer
  ,ph_remarks
  ,turb_manual
  ,turb_analyzer
  ,turb_remarks
  ,rcl2_manual
  ,rcl2_analyzer
  ,rcl2_remarks
  ,fluoride_manual
  ,fluoride_analyzer
  ,fluoride_remarks
  ,mn_manual
  ,mn_analyzer
  ,mn_remarks
  ,nh3_manual
  ,nh3_analyzer
  ,nh3_remarks
  ,uv_manual
  ,uv_analyzer
  ,uv_remarks
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_analyzer_verification_item
```

## 4.ods_labconnect_labcon_hki_wqmm_chem_parameter_df

```sql
DROP TABLE if  exists coss_ods.ods_labconnect_labcon_hki_wqmm_chem_parameter_df;
CREATE table if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_chem_parameter_df (
	ch_para text NOT NULL,
	ch_para_unit text NULL,
	ch_para_order int2 NULL,
	ch_round_dp int2 NULL,
	ch_name_chi text NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_chem_parameter_pkey PRIMARY KEY (ch_para)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  ch_para
  ,ch_para_unit
  ,ch_para_order
  ,ch_round_dp
  ,ch_name_chi
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_chem_parameter
```



## 5.ods_labconnect_labcon_hki_wqmm_config_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_config_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_config_df (
	config_id serial4 NOT NULL,
	wtw_id int4 NOT NULL,
	config_type int2 NULL,
	created_date timestamp NULL,
	created_by int4 NULL,
	created_role int4 NULL,
	effective_date timestamp NULL,
	verification_interval_hr int2 NULL,
	jar_test_interval_hr int2 NULL,
	jar_measure_type int2 NULL,
	require_to_test bool NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_config_pkey PRIMARY KEY (config_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  config_id
  ,wtw_id
  ,config_type
  ,created_date
  ,created_by
  ,created_role
  ,effective_date
  ,verification_interval_hr
  ,jar_test_interval_hr
  ,jar_measure_type
  ,require_to_test
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_config
```



## 6.ods_labconnect_labcon_hki_wqmm_frequency_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_frequency_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_frequency_df (
	parameter_item_id serial4 NOT NULL,
	config_id int4 NOT NULL,
	loc_id int4 NOT NULL,
	ph_frequency int2 NULL,
	turb_frequency int2 NULL,
	rcl2_frequency int2 NULL,
	fluoride_frequency int2 NULL,
	mn_frequency int2 NULL,
	nh3_frequency int2 NULL,
	uv_frequency int2 NULL,
	taste_frequency int2 NULL,
	odour_frequency int2 NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_frequency_pkey PRIMARY KEY (parameter_item_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  parameter_item_id
  ,config_id
  ,loc_id
  ,ph_frequency
  ,turb_frequency
  ,rcl2_frequency
  ,mn_frequency
  ,nh3_frequency
  ,uv_frequency
  ,taste_frequency
  ,odour_frequency
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_frequency
```



## 7.ods_labconnect_labcon_hki_wqmm_jar_test_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_jar_test_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_jar_test_df (
	jar_test_id serial4 NOT NULL,
	wtw_id int4 NOT NULL,
	status int2 NULL,
	last_updated_date timestamp NULL,
	sample_date timestamp NULL,
	reported_by int4 NULL,
	reported_role int4 NULL,
	reported_date timestamp NULL,
	reported_remarks text NULL,
	no_record_reason text NULL,
	approved_by int4 NULL,
	approved_role int4 NULL,
	approved_remarks text NULL,
	approved_date timestamp NULL,
	reviewed_by int4 NULL,
	reviewed_role int4 NULL,
	reviewed_remarks text NULL,
	reviewed_date timestamp NULL,
	raw_water_turb numeric(8, 3) NULL,
	raw_water_ph numeric(8, 3) NULL,
	current_dosage_alum numeric(8, 3) NULL,
	current_dosage_hlime numeric(8, 3) NULL,
	best_dosage_alum numeric(8, 3) NULL,
	best_dosage_hlime numeric(8, 3) NULL,
	need_adjust bool NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_jar_test_pkey PRIMARY KEY (jar_test_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  jar_test_id
  ,wtw_id
  ,status
  ,last_updated_date
  ,sample_date
  ,reported_by
  ,reported_role
  ,reported_date
  ,reported_remarks
  ,no_record_reason
  ,approved_by
  ,approved_role
  ,approved_remarks
  ,approved_date
  ,reviewed_by
  ,reviewed_role
  ,reviewed_remarks
  ,reviewed_date
  ,raw_water_turb
  ,raw_water_ph
  ,current_dosage_alum
  ,current_dosage_hlime
  ,best_dosage_alum
  ,best_dosage_hlime
  ,need_adjust
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_jar_test
```



## 8.ods_labconnect_labcon_hki_wqmm_jar_test_item_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_jar_test_item_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_jar_test_item_df (
	jar_test_item_id serial4 NOT NULL,
	jar_test_id int4 NOT NULL,
	jar_id int4 NOT NULL,
	test_dosage_alum numeric(8, 3) NULL,
	test_dosage_hlime numeric(8, 3) NULL,
	precipitation int2 NULL,
	result_turb numeric(8, 3) NULL,
	result_ph numeric(8, 3) NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_jar_test_item_pkey PRIMARY KEY (jar_test_item_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  jar_test_item_id
  ,jar_test_id
  ,jar_id
  ,test_dosage_alum
  ,test_dosage_hlime
  ,precipitation
  ,result_turb
  ,result_ph
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_jar_test_item
```

## 9.ods_labconnect_labcon_hki_wqmm_location_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_location_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_location_df (
	loc_id serial4 NOT NULL,
	loc_full_name text NULL,
	loc_name text NULL,
	loc_suffix text NULL,
	loc_name_chi text NULL,
	loc_color_pri text NULL,
	loc_color_sec text NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_location_pkey PRIMARY KEY (loc_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  loc_id
  ,loc_full_name
  ,loc_name
  ,loc_suffix
  ,loc_name_chi
  ,loc_color_pri
  ,loc_color_sec
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_location
```



## 10.ods_labconnect_labcon_hki_wqmm_parameter_limit_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_parameter_limit_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_parameter_limit_df (
	parameter_limit_id serial4 NOT NULL,
	config_id int4 NOT NULL,
	loc_id int4 NOT NULL,
	target_type int2 NULL,
	ph_compare text NULL,
	ph_min_value numeric(8, 3) NULL,
	ph_max_value numeric(8, 3) NULL,
	turb_compare text NULL,
	turb_min_value numeric(8, 3) NULL,
	turb_max_value numeric(8, 3) NULL,
	rcl2_compare text NULL,
	rcl2_min_value numeric(8, 3) NULL,
	rcl2_max_value numeric(8, 3) NULL,
	uv_compare text NULL,
	uv_min_value numeric(8, 3) NULL,
	uv_max_value numeric(8, 3) NULL,
	fluoride_compare text NULL,
	fluoride_min_value numeric(8, 3) NULL,
	fluoride_max_value numeric(8, 3) NULL,
	mn_compare text NULL,
	mn_min_value numeric(8, 3) NULL,
	mn_max_value numeric(8, 3) NULL,
	nh3_compare text NULL,
	nh3_min_value numeric(8, 3) NULL,
	nh3_max_value numeric(8, 3) NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_parameter_limit_pkey PRIMARY KEY (parameter_limit_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  parameter_limit_id
  ,config_id
  ,loc_id
  ,target_type
  ,ph_compare
  ,ph_min_value
  ,ph_max_value
  ,turb_compare
  ,turb_min_value
  ,turb_max_value
  ,rcl2_compare
  ,rcl2_min_value
  ,rcl2_max_value
  ,uv_compare
  ,uv_min_value
  ,uv_max_value
  ,fluoride_compare
  ,fluoride_min_value
  ,fluoride_max_value
  ,mn_compare
  ,mn_min_value
  ,mn_max_value
  ,nh3_compare
  ,nh3_min_value
  ,nh3_max_value
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_parameter_limit
```



## 11.ods_labconnect_labcon_hki_wqmm_process_handling_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_process_handling_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_process_handling_df (
	process text NOT NULL,
	status int2 NOT NULL,
	user_group_id int4 NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_process_handling_pkey PRIMARY KEY (process, status)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  process
  ,status
  ,user_group_id
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_process_handling
```



## 12.ods_labconnect_labcon_hki_wqmm_reminder_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_reminder_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_reminder_df (
	reminder_id serial4 NOT NULL,
	wtw_id int4 NOT NULL,
	status int2 NULL,
	created_date timestamp NULL,
	completed_date timestamp NULL,
	completed_by int4 NULL,
	process text NULL,
	loc_id int4 NULL,
	"parameter" text NULL,
	next_sample_time timestamp NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_reminder_pkey PRIMARY KEY (reminder_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  reminder_id
  ,wtw_id
  ,status
  ,created_date
  ,completed_date
  ,completed_by
  ,process
  ,loc_id
  ,parameter
  ,next_sample_time
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_reminder
```



## 13.ods_labconnect_labcon_hki_wqmm_taste_odour_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_taste_odour_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_taste_odour_df (
	to_test_id serial4 NOT NULL,
	wtw_id int4 NOT NULL,
	status int2 NULL,
	last_updated_date timestamp NULL,
	sample_date timestamp NULL,
	reported_by int4 NULL,
	reported_role int4 NULL,
	reported_date timestamp NULL,
	reported_remarks text NULL,
	no_record_reason text NULL,
	approved_by int4 NULL,
	approved_role int4 NULL,
	approved_remarks text NULL,
	approved_date timestamp NULL,
	raw_water_odour bool NULL,
	final_water_odour bool NULL,
	final_water_taste bool NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_taste_odour_pkey PRIMARY KEY (to_test_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  to_test_id
  ,wtw_id
  ,status
  ,last_updated_date
  ,sample_date
  ,reported_by
  ,reported_role
  ,reported_date
  ,reported_remarks
  ,no_record_reason
  ,approved_by
  ,approved_role
  ,approved_remarks
  ,approved_date
  ,raw_water_odour
  ,final_water_odour
  ,final_water_taste
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_taste_odour
```



## 14.ods_labconnect_labcon_hki_wqmm_water_quality_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_water_quality_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_water_quality_df (
	water_quality_id serial4 NOT NULL,
	wtw_id int4 NOT NULL,
	status int2 NULL,
	last_updated_date timestamp NULL,
	sample_date timestamp NULL,
	visual_inspect_status bool NULL,
	abnormal_observed_at timestamp NULL,
	abnormal_reported_to int4 NULL,
	abnormal_reported_to_role int4 NULL,
	abnormal_reported_date timestamp NULL,
	reported_by int4 NULL,
	reported_role int4 NULL,
	reported_date timestamp NULL,
	no_record_reason text NULL,
	approved_by int4 NULL,
	approved_role int4 NULL,
	approved_remarks text NULL,
	approved_date timestamp NULL,
	reviewed_by int4 NULL,
	reviewed_role int4 NULL,
	reviewed_remarks text NULL,
	reviewed_date timestamp NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_water_quality_pkey PRIMARY KEY (water_quality_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  water_quality_id
  ,wtw_id
  ,status
  ,last_updated_date
  ,sample_date
  ,visual_inspect_status
  ,abnormal_observed_at
  ,abnormal_reported_to
  ,abnormal_reported_to_role
  ,abnormal_reported_date
  ,reported_by
  ,reported_role
  ,reported_date
  ,no_record_reason
  ,approved_by
  ,approved_role
  ,approved_remarks
  ,approved_date
  ,reviewed_by
  ,reviewed_role
  ,reviewed_remarks
  ,reviewed_date
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_water_quality
```



## 15.ods_labconnect_labcon_hki_wqmm_water_quality_item_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wqmm_water_quality_item_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wqmm_water_quality_item_df (
	water_quality_item_id serial4 NOT NULL,
	water_quality_id int4 NOT NULL,
	loc_id int4 NOT NULL,
	ph numeric(8, 3) NULL,
	ph_src int2 NULL,
	ph_remarks text NULL,
	turb numeric(8, 3) NULL,
	turb_src int2 NULL,
	turb_remarks text NULL,
	rcl2 numeric(8, 3) NULL,
	rcl2_src int2 NULL,
	rcl2_remarks text NULL,
	fluoride numeric(8, 3) NULL,
	fluoride_src int2 NULL,
	fluoride_remarks text NULL,
	mn numeric(8, 3) NULL,
	mn_src int2 NULL,
	mn_remarks text NULL,
	nh3 numeric(8, 3) NULL,
	nh3_src int2 NULL,
	nh3_remarks text NULL,
	uv numeric(8, 3) NULL,
	uv_src int2 NULL,
	uv_remarks text NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wqmm_water_quality_item_pkey PRIMARY KEY (water_quality_item_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);

```

```
select
  water_quality_item_id
  ,water_quality_id
  ,loc_id
  ,ph
  ,ph_src
  ,ph_remarks
  ,turb
  ,turb_src
  ,turb_remarks
  ,rcl2
  ,rcl2_src
  ,rcl2_remarks
  ,fluoride
  ,fluoride_src
  ,fluoride_remarks
  ,mn
  ,mn_src
  ,mn_remarks
  ,nh3
  ,nh3_src
  ,nh3_remarks
  ,uv
  ,uv_src
  ,uv_remarks
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wqmm_water_quality_item
```



## 16.ods_labconnect_labcon_hki_wtw_unit_df

```sql
DROP TABLE if exists coss_ods.ods_labconnect_labcon_hki_wtw_unit_df;
CREATE TABLE if not exists coss_ods.ods_labconnect_labcon_hki_wtw_unit_df (
	wtw_id serial4 NOT NULL,
	wtw_code text NOT NULL,
	wtw_name text NOT NULL,
	wtw_name_chi text NOT NULL,
	phase_1 bool NOT NULL,
	phase_2 bool NOT NULL,
	phase_3 bool NOT NULL,
    ods_update_time timestamp(6) default current_timestamp,
    ods_load_time timestamp(6) default current_timestamp,
	CONSTRAINT wtw_unit_pkey PRIMARY KEY (wtw_id)
)
WITH (
	orientation=row,
	compression=no,
	storage_type=USTORE,
	segment=off
);
```

```
select
  wtw_id
  ,wtw_code
  ,wtw_name
  ,wtw_name_chi
  ,phase_1
  ,phase_2
  ,phase_3
  ,localtimestamp ods_update_time
  ,localtimestamp ods_load_time
from
labcon_hki.wtw_unit
```





# dwd

## 1.coss_dwd.dwd_wtw_verification_di_year

```sql
;delete from  coss_dwd.dwd_wtw_verification_di_year
;insert into coss_dwd.dwd_wtw_verification_di_year
select 
    t.verification_id
    ,t.wtw_id
    ,t.status
    ,t.last_updated_date
    ,t.sample_date
    ,t.reviewed_date
    ,t1.wtw_code
    ,t1.wtw_name
    ,t1.wtw_name_chi
    ,t1.phase_1
    ,t1.phase_2
    ,t1.phase_3
    ,now() as dwd_update_time
    ,now() as dwd_load_time
from 
    coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_analyzer_verification_di_year t
    inner join coss_ods.ods_labconnect_labcon_hki_wtw_wtw_unit_df   t1 on t.wtw_id = t1.wtw_id 
```



## 2.coss_dwd.dwd_wtw_verification_item_di_year

```sql
;delete from coss_dwd.dwd_wtw_verification_item_di_year
;insert into coss_dwd.dwd_wtw_verification_item_di_year
select 
    t1.verification_item_id
    ,t1.verification_id
    ,t1.loc_id
    ,t2.loc_full_name
    ,t2.loc_name
    ,t2.loc_suffix
    ,t2.loc_name_chi
    ,t.sample_date
    ,t1.ph_manual
    ,t1.ph_analyzer
    ,t1.ph_remarks
    ,t1.turb_manual
    ,t1.turb_analyzer
    ,t1.turb_remarks
    ,t1.rcl2_manual
    ,t1.rcl2_analyzer
    ,t1.rcl2_remarks
    ,t1.fluoride_manual
    ,t1.fluoride_analyzer
    ,t1.fluoride_remarks
    ,t1.mn_manual
    ,t1.mn_analyzer
    ,t1.mn_remarks
    ,t1.nh3_manual
    ,t1.nh3_analyzer
    ,t1.nh3_remarks
    ,t1.uv_manual
    ,t1.uv_analyzer
    ,t1.uv_remarks
    ,now() as dwd_update_time
    ,now() as dwd_load_time
from 
    coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_analyzer_verification_di_year  t
    inner join coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_analyzer_verification_item_df  t1 on t.verification_id = t1.verification_id
    inner join coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_location_df t2 on t1.loc_id = t2.loc_id 
```

# dws

## 1.coss_dws.dws_wtw_verification_item_di_year

```sql
;delete from coss_dws.dws_wtw_verification_item_di_year
;insert into coss_dws.dws_wtw_verification_item_di_year
select
    t.verification_id
    ,t.wtw_id
    ,t.status
    ,t.last_updated_date
    ,t.sample_date
    ,t.reviewed_date
    ,t.wtw_code
    ,t.wtw_name
    ,t.wtw_name_chi
    ,t.phase_1
    ,t.phase_2
    ,t.phase_3
    ,t1.verification_item_id
    ,t1.loc_id
    ,t1.loc_full_name
    ,t1.loc_name
    ,t1.loc_suffix
    ,t1.loc_name_chi
    ,t1.ph_manual
    ,t1.ph_analyzer
    ,t1.ph_remarks
    ,t1.turb_manual
    ,t1.turb_analyzer
    ,t1.turb_remarks
    ,t1.rcl2_manual
    ,t1.rcl2_analyzer
    ,t1.rcl2_remarks
    ,t1.fluoride_manual
    ,t1.fluoride_analyzer
    ,t1.fluoride_remarks
    ,t1.mn_manual
    ,t1.mn_analyzer
    ,t1.mn_remarks
    ,t1.nh3_manual
    ,t1.nh3_analyzer
    ,t1.nh3_remarks
    ,t1.uv_manual
    ,t1.uv_analyzer
    ,t1.uv_remarks
    ,now() as dim_update_time
    ,now() as dim_load_time
from 
    coss_dwd.dwd_wtw_verification_di_year t
    inner join coss_dwd.dwd_wtw_verification_item_di_year t1 on t.verification_id = t1.verification_id
```



# dim

## coss_dim.dim_wtw_water_quality_paramaters

```sql
;delete from coss_dim.dim_wtw_water_quality_paramaters
;insert into coss_dim.dim_wtw_water_quality_paramaters
select 
    t.config_id
    ,t.wtw_id
    ,case 
        when wtw_id = 1 then 'TW025'
        when wtw_id = 2 then 'TW009'
        when wtw_id = 3 then 'TW015'
        when wtw_id = 4 then 'TW019'
        when wtw_id = 5 then 'TW011'
	      else '10000'
    end as i_code 
    ,t.config_type
    ,t.effective_date
    ,t.verification_interval_hr
    ,t.jar_test_interval_hr
    ,t.jar_measure_type
    ,t.require_to_test
    ,t1.parameter_limit_id
    ,t1.loc_id
    ,t1.target_type
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value
    ,t1.uv_compare
    ,t1.uv_min_value
    ,t1.uv_max_value
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value
    ,t1.nh3_compare
    ,t1.nh3_min_value
    ,t1.nh3_max_value
    ,t2.loc_full_name
    ,t2.loc_name
    ,t2.loc_suffix
    ,t2.loc_name_chi
    ,now() as dim_update_time
    ,now() as dim_load_time
from 
    coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_config_df t
    inner join coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_parameter_limit_df t1 on t.config_id  = t1.config_id 
    inner join coss_ods.ods_labconnect_labcon_hki_wtw_wqmm_location_df t2 on t1.loc_id = t2.loc_id 
    

```

## coss_dim.dim_ass_wtw_info

```sql
DROP TABLE if exists  coss_dim.dim_ass_wtw_info;
CREATE TABLE if not exists  coss_dim.dim_ass_wtw_info (
	tw_id varchar(20) NOT NULL, -- Water Treatment Woks ID with format TWNNNNNNNN
	i_code varchar(10) NULL, -- Installation Code of Water Treatment Works
	tw_name_en varchar(200) NULL, -- Water Treatment Works Name
	tw_name_tc varchar(300) NULL, -- Water Treatment Works Chinese Name
	tw_name_cn varchar(300) NULL, -- Water Treatment Works Traditional Chinese Name
	rpt_label varchar(400) NULL, -- Labels used in reports
	region_code varchar NULL, -- Region
	region_ind varchar(2) NULL, -- Possible Values: {"I" - HK Island, "M" - Mainland}
	capacity numeric(12, 4) NULL, -- Capacity of WTW.  Unit is in Mld
	dim_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Update Time
	dim_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Loading Time
	CONSTRAINT dim_ass_wtw_info_pkey PRIMARY KEY (tw_id)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dim.dim_ass_wtw_info IS 'Water Treatment Works Information';

-- Column comments

COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.tw_id IS 'Water Treatment Woks ID with format TWNNNNNNNN';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.i_code IS 'Installation Code of Water Treatment Works';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.tw_name_en IS 'Water Treatment Works Name';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.tw_name_tc IS 'Water Treatment Works Chinese Name';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.tw_name_cn IS 'Water Treatment Works Traditional Chinese Name';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.rpt_label IS 'Labels used in reports';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.region_code IS 'Region';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.region_ind IS 'Possible Values: {"I" - HK Island, "M" - Mainland}';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.capacity IS 'Capacity of WTW.  Unit is in Mld';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.dim_update_time IS 'Data Update Time';
COMMENT ON COLUMN coss_dim.dim_ass_wtw_info.dim_load_time IS 'Data Loading Time';


```



# dm

## 原水水质

### wtw_id = 1

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1 and loc_id =0
    and parameter_limit_id = 19
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id=2

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2 
    and loc_id =0
    and parameter_limit_id = 35
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

```

### wtw_id=3

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3 
    and loc_id =0
    and parameter_limit_id = 9
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

```

### wtw_id=4

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4 
    and loc_id =0
    and parameter_limit_id = 1
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id


```

### wtw_id=5

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,0 as loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =5
    and loc_id in(1,2)
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 5
    and loc_id  = 0
    and parameter_limit_id = 45
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### coss_dm.dm_wtw_raw_water_quality_di

```sql
;delete from coss_dm.dm_wtw_raw_water_quality_di
;insert into coss_dm.dm_wtw_raw_water_quality_di
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1 and loc_id =0
    and parameter_limit_id = 19
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2 
    and loc_id =0
    and parameter_limit_id = 35
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3 
    and loc_id =0
    and parameter_limit_id = 9
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 0
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4 
    and loc_id =0
    and parameter_limit_id = 1
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,if((if(t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0))=2, 1, 0) raw_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,0 as loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =5
    and loc_id in(1,2)
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 5
    and loc_id  = 0
    and parameter_limit_id = 45
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

```



## 投药水质

### wtw_id=1

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(true ,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(true ,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code  
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1
    and loc_id =20
    and parameter_limit_id = 21
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### wtw_id=2

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(true ,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(true ,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2
    and loc_id =20
    and parameter_limit_id = 37
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### wtw_id=3

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3
    and loc_id =20
    and parameter_limit_id = 11
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

```

### wtw_id=4

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4
    and loc_id =20
    and parameter_limit_id = 3
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### wtw_id=5

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(true ,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(true ,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =5
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 5
    and loc_id =20
    and parameter_limit_id = 47
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### coss_dm.dm_wtw_dosed_water_quality_di

```sql
;delete from coss_dm.dm_wtw_dosed_water_quality_di
;insert into coss_dm.dm_wtw_dosed_water_quality_di
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(true ,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(true ,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code  
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1
    and loc_id =20
    and parameter_limit_id = 21
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(true ,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(true ,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2
    and loc_id =20
    and parameter_limit_id = 37
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3
    and loc_id =20
    and parameter_limit_id = 11
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4
    and loc_id =20
    and parameter_limit_id = 3
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(true ,1,0) rcl2_is_pass
    ,if((if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0))+if(true ,1,0)=2, 1, 0) dosed_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =5
    and loc_id = 20
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 5
    and loc_id =20
    and parameter_limit_id = 47
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



## 过滤水水质

### wtw_id = 1

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 40
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1
    and loc_id =40
    and parameter_limit_id = 27
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 2

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 40
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2
    and loc_id =40
    and parameter_limit_id = 41
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 3

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id in (44, 45)
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3
    and loc_id in (44, 45)
    and parameter_limit_id in(13, 15)
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 4

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 40
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4
    and loc_id =40
    and parameter_limit_id = 5
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 5

```sql
no data
```

### coss_dm.dm_wtw_filtered_water_quality_di

```sql
;delete from coss_dm.dm_wtw_filtered_water_quality_di 
;insert into coss_dm.dm_wtw_filtered_water_quality_di 
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 40
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1
    and loc_id =40
    and parameter_limit_id = 27
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 	
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 40
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2
    and loc_id =40
    and parameter_limit_id = 41
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id in (44, 45)
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3
    and loc_id in (44, 45)
    and parameter_limit_id in(13, 15)
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,if(if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)=2, 1, 0) filtered_is_pass
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 40
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4
    and loc_id =40
    and parameter_limit_id = 5
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id


```



##   出厂水质

### wtw_id = 1

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1
    and loc_id = 100
    and parameter_limit_id = 34
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### wtw_id = 2

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2
    and loc_id = 100
    and parameter_limit_id = 43
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 3

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3
    and loc_id = 100
    and parameter_limit_id = 17
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 4

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4
    and loc_id = 100
    and parameter_limit_id = 7
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```



### wtw_id = 5

```sql
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =5
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 5
    and loc_id = 100
    and parameter_limit_id = 51
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### coss_dm.dm_wtw_final_water_quality_di

```sql
;delete from coss_dm.dm_wtw_final_water_quality_di
;insert into coss_dm.dm_wtw_final_water_quality_di
select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =1
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 1
    and loc_id = 100
    and parameter_limit_id = 34
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
 
union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =2
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 2
    and loc_id = 100
    and parameter_limit_id = 43
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =3
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 3
    and loc_id = 100
    and parameter_limit_id = 17
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =4
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 4
    and loc_id = 100
    and parameter_limit_id = 7
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id

union all 

select 
    t.wtw_id
    ,t.loc_id
    ,t1.i_code
    ,t.sample_date
    ,t.ph_manual
    ,t.ph_analyzer
    ,if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0) ph_is_pass
    ,t.turb_manual
    ,t.turb_analyzer
    ,if(t.turb_manual<= t1.turb_max_value,1,0) turb_is_pass
    ,t.rcl2_manual
    ,t.rcl2_analyzer
    ,if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0) rcl2_is_pass
    ,t.fluoride_manual
    ,t.fluoride_analyzer
    ,if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0) fluoride_is_pass
    ,t.mn_manual
    ,t.mn_analyzer
    ,1 as mn_is_pass
    ,if(if(t.ph_manual>= t1.ph_min_value and t.ph_manual<= t1.ph_max_value,1,0)+if(t.turb_manual<= t1.turb_max_value,1,0)+if(t.rcl2_manual>= t1.rcl2_min_value and t.rcl2_manual<= t1.rcl2_max_value,1,0)+if(t.fluoride_manual>= t1.fluoride_min_value and t.fluoride_manual<= t1.fluoride_max_value,1,0)+ 1=5, 1, 0) final_is_pass
    ,t1.ph_compare
    ,t1.ph_min_value
    ,t1.ph_max_value
    ,t1.turb_compare
    ,t1.turb_min_value
    ,t1.turb_max_value
    ,t1.rcl2_compare
    ,t1.rcl2_min_value
    ,t1.rcl2_max_value 
    ,t1.fluoride_compare
    ,t1.fluoride_min_value
    ,t1.fluoride_max_value 
    ,t1.mn_compare
    ,t1.mn_min_value
    ,t1.mn_max_value 
    ,now() as dm_update_time
    ,now() as dm_load_time
from 
(
select 
    wtw_id
    ,loc_id
    ,sample_date
    ,ph_manual
    ,ph_analyzer
    ,turb_manual
    ,turb_analyzer
    ,rcl2_manual
    ,rcl2_analyzer 
    ,fluoride_manual
    ,fluoride_analyzer 
    ,mn_manual
    ,mn_analyzer 
from 
    coss_dws.dws_wtw_verification_item_di_year 
	where wtw_id =5
    and loc_id = 100
)t 
	inner join 
(
select 
    wtw_id
    ,loc_id
    ,i_code
    ,ph_compare
    ,ph_min_value
    ,ph_max_value
    ,turb_compare
    ,turb_min_value
    ,turb_max_value
    ,rcl2_compare
    ,rcl2_min_value
    ,rcl2_max_value 
    ,fluoride_compare
    ,fluoride_min_value
    ,fluoride_max_value 
    ,mn_compare
    ,mn_min_value
    ,mn_max_value 
from coss_dim.dim_wtw_water_quality_paramaters 
    where wtw_id = 5
    and loc_id = 100
    and parameter_limit_id = 51
)t1 on t.wtw_id = t1.wtw_id and t.loc_id = t1.loc_id
```

### coss_dm.dm_wtw_water_quality_verification_item_di

```sql
DROP TABLE if exists  coss_dm.dm_wtw_water_quality_verification_item_di;
CREATE TABLE if not exists coss_dm.dm_wtw_water_quality_verification_item_di (
	verification_id numeric(15) NULL, -- verification item id
	i_code varchar(255) NULL, -- local id
	sample_date timestamp(6) NULL, -- sample date
	verification_item_id numeric(15) NOT NULL, -- verification item id
	loc_id numeric(15) NULL, -- loc id
	loc_full_name varchar(255) NULL, -- local full name
	water_type_code varchar(255) NULL, -- water type code
	water_type_en varchar(255) NULL, -- water type en
	water_type_tc varchar(255) NULL, -- water type tc
	water_type_cn varchar(255) NULL, -- water type cn
	ph_manual numeric(15, 5) NULL, -- ph manual
	turb_manual numeric(15, 5) NULL, -- Turbidity manual
	rcl2_manual numeric(15, 5) NULL, -- Residual chlorine manual
	fluoride_manual numeric(15, 5) NULL, -- fluoride manual
	mn_manual numeric(15, 5) NULL, -- Manganese ions manual
	nh3_manual numeric(15, 5) NULL, -- NH₃ manual
	uv_manual numeric(15, 5) NULL, -- organic matter manual
	dm_update_time timestamp(6) NULL, -- dm update time
	dm_load_time timestamp(6) NULL, -- dm load time
	CONSTRAINT dm_wtw_water_quality_verification_item_di_pkey PRIMARY KEY (verification_item_id)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_wtw_water_quality_verification_item_di IS 'water treatment works of water quality verification item';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.verification_id IS 'verification item id';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.i_code IS 'local id';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.sample_date IS 'sample date';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.verification_item_id IS 'verification item id';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.loc_id IS 'loc id';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.loc_full_name IS 'local full name';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.water_type_code IS 'water type code';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.water_type_en IS 'water type en';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.water_type_tc IS 'water type tc';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.water_type_cn IS 'water type cn';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.ph_manual IS 'ph manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.turb_manual IS 'Turbidity manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.rcl2_manual IS 'Residual chlorine manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.fluoride_manual IS 'fluoride manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.mn_manual IS 'Manganese ions manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.nh3_manual IS 'NH₃ manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.uv_manual IS 'organic matter manual';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.dm_update_time IS 'dm update time';
COMMENT ON COLUMN coss_dm.dm_wtw_water_quality_verification_item_di.dm_load_time IS 'dm load time';

```





# 水厂水质参数

| 指标     | 核心检测对象                     | 对水厂的关键作用                               | 国标（GB 5749-2022）控制目标                |
| -------- | -------------------------------- | ---------------------------------------------- | ------------------------------------------- |
| ABS      | 有机污染物总量                   | 评估污染、监控有机物去除、预警消毒副产物       | 出厂水（254nm）＜0.05                       |
| pH       | 水体酸碱度                       | 防管网腐蚀 / 结垢、保障混凝 / 消毒效率         | 6.5~8.5                                     |
| Turb     | 悬浮 / 胶体颗粒                  | 保障感官合规、消除微生物包裹风险、监控过滤效果 | 出厂水≤1 NTU，末梢水≤2 NTU                  |
| UV       | 有机物（UV254）/ 消毒（UV 工艺） | 快速测有机物、无氯消毒控微生物                 | UV254＜0.03 cm⁻¹；消毒后微生物达标          |
| RCl₂     | 余氯                             | 管网持续杀菌、验证消毒效果                     | 出厂水≥0.3 mg/L，末梢水≥0.05 mg/L           |
| Mn       | 锰离子                           | 防感官污染（染色、水垢）、保护管网设备         | ≤0.1 mg/L                                   |
| NH₃      | 氨氮                             | 避免消耗余氯、防藻类滋生、减少管网腐蚀         | ≤0.5 mg/L（以 N 计）                        |
| Fluoride | 氟离子                           | 平衡防龋齿与氟中毒风险（分区控制）             | 0.5~1.0 mg/L（低氟区）；≤1.0 mg/L（高氟区） |
| Taste    | 味觉特性                         | 保障用户接受度、排查金属 / 氯污染              | 无异臭、异味                                |
| Odour    | 嗅觉特性                         | 快速发现藻类 / 微生物污染、响应用户反馈        | 无异臭、异味                                |











