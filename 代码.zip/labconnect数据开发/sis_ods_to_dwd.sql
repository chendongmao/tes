-- subject     areas: pipe network areas
-- function describe: filter the real-time monitoring data with quality of 1 to table coss_dwd.dwd_pnw_pipe_tag_monitored_rt_mini
-- create       date: 2025/10/13
-- modify date     modify by      modify content 
-- 
-- source table
-- coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini                 the sis system monitors data in real time
-- coss_dim.dim_sis_tag_list_info                                  sis system tag list
-- target table
-- coss_dwd.dwd_pnw_pipe_tag_monitored_rt_mini                     the sis system monitors data in real time
insert into coss_dwd.dwd_pnw_pipe_tag_monitored_rt_mini (
    scada_tag,            -- scada tag
    time,                 -- monitoring time
    value,                -- monitoring value
    unit,                 -- monitoring value unit
    comment,              -- tag comment
    region_abbr,          -- regional abbreviation
    sub_region_code,      -- sub-region code
    name_cn,              -- simplified chinese name of the monitoring point
    name_tc,              -- the traditional chinese name of the monitoring point
    name_en,              -- the english name of the monitoring point
    water_type_code,      -- water type code
    water_biz_type,       -- monitoring type
    installation_id,      -- installation id
    tag_device_type_code, -- the code of equipment type
    tag_device_type_cn,   -- simplified chinese name of the device type
    tag_device_type_tc,   -- traditional chinese name of the equipment type
    tag_device_type_en,   -- the english name of the equipment type
    tag_signal_code,      -- the code of tag signal
    tag_signal_cn,        -- the chinese name of tag signal
    context_text          -- alarm value text
)
select 
    b.scada_tag,
    a.time,
    case when b.water_biz_type = 'ALARM' then a.value
	     when b.water_biz_type = 'FLOW' and upper(b.unit) = 'MLD' then a.value * b.scale * 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L'   then a.value * b.scale / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/H' then a.value * b.scale * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/S' then a.value * b.scale * 3600 * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'M3'  then a.value * b.scale
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'KPA' then a.value * b.scale / 9.80665
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'M' then a.value * b.scale
		 when b.water_biz_type = 'LEVEL' then a.value * b.scale
		 when b.water_biz_type = 'PH' then a.value * b.scale
		 when b.water_biz_type = 'TURBIDITY' then a.value * b.scale
		 when b.water_biz_type = 'CHLORINE' then a.value * b.scale
		 when b.water_biz_type = 'FLUORIDE' then a.value * b.scale                  -- monitoring value * scale = true value
    end as value,
    case when b.water_biz_type = 'FLOW' then 'm3'
	     when b.water_biz_type = 'PRESSURE' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'M' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'MPD' then 'mPD'
		 when b.water_biz_type = 'PH' then ''
		 when b.water_biz_type = 'TURBIDITY' then 'NTU'
		 when b.water_biz_type = 'CHLORINE' then 'mg/L'
		 when b.water_biz_type = 'FLUORIDE' then 'mg/L'
	end as unit,
    b.comment,
    b.region_abbr,
    b.sub_region_code,
    b.name_cn,
    b.name_tc,
    b.name_en,
	b.water_type_code,
    b.water_biz_type,
    b.installation_id,
    b.tag_device_type_code,
    b.tag_device_type_cn,
    b.tag_device_type_tc,
    b.tag_device_type_en,
    b.tag_signal_code,
    b.tag_signal_cn,
    case when b.water_biz_type = 'ALARM' and a.value = 0 then b.text_1
         when b.water_biz_type = 'ALARM' and a.value = 1 then b.text_2
         when b.water_biz_type = 'ALARM' and a.value = 2 then b.text_3
         when b.water_biz_type = 'ALARM' and a.value = 3 then b.text_4
         else null
    end as context_text                                     -- obtain the alarm status information based on the alarm status code
from (
    -- obtain monitoring data
    select
        time,
        value,
        path
    from coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini
    where quality = 1                                       -- filter the data with quality of 1
) a
inner join (
    -- get detailed information about the tag
    select 
        scada_tag,
        comment,
        unit,
        scale,
        region_abbr,
		sub_region_code,
        name_cn,
        name_tc,
        name_en,
        water_type_code,
        water_biz_type,
        installation_id,
        tag_device_type_code,
        tag_signal_code,
        tag_device_type_cn,
        tag_device_type_tc,
        tag_device_type_en,
        tag_signal_cn,
        text_1,
        text_2,
        text_3,
        text_4
    from 
        coss_dim.dim_sis_tag_list_info
) b 
on a.path = b.scada_tag
on duplicate key 
update
    time = values(time),
    value = values(value),
	context_text = values(context_text),
	dwd_update_time = current_timestamp;
	
-- subject     areas: pipe network areas
-- function describe: filter the raw water real-time monitoring data with quality of 1 to table coss_dwd.dwd_pnw_raw_water_tag_monitored_hst_mini_month
-- create       date: 2025/10/13
-- modify date     modify by      modify content 
-- 
-- source table
-- coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini                 the sis system monitors data in real time
-- coss_dim.dim_sis_tag_list_info                                  sis system tag list
-- target table
-- coss_dwd.dwd_pnw_raw_water_tag_monitored_hst_mini_month         historical monitoring data of raw water in the sis system
insert into coss_dwd.dwd_pnw_raw_water_tag_monitored_hst_mini_month (
    scada_tag,            -- scada tag
    time,                 -- monitoring time
    value,                -- monitoring value
    unit,                 -- monitoring value unit
    comment,              -- tag comment
    region_abbr,          -- regional abbreviation
    sub_region_code,      -- sub-region code
    name_cn,              -- simplified chinese name of the monitoring point
    name_tc,              -- the traditional chinese name of the monitoring point
    name_en,              -- the english name of the monitoring point
    water_biz_type,       -- monitoring type
    installation_id,      -- installation id
    tag_device_type_code, -- the code of equipment type
    tag_device_type_cn,   -- simplified chinese name of the device type
    tag_device_type_tc,   -- traditional chinese name of the equipment type
    tag_device_type_en,   -- the english name of the equipment type
    tag_signal_code,      -- the code of tag signal
    tag_signal_cn,        -- the chinese name of tag signal
    context_text          -- alarm value text
)
select 
    b.scada_tag,
    a.time,
    case when b.water_biz_type = 'ALARM' then a.value
	     when b.water_biz_type = 'FLOW' and upper(b.unit) = 'MLD' then a.value * b.scale * 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L'   then a.value * b.scale / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/H' then a.value * b.scale * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/S' then a.value * b.scale * 3600 * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'M3'  then a.value * b.scale
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'KPA' then a.value * b.scale / 9.80665
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'M' then a.value * b.scale
		 when b.water_biz_type = 'LEVEL' then a.value * b.scale
		 when b.water_biz_type = 'PH' then a.value * b.scale
		 when b.water_biz_type = 'TURBIDITY' then a.value * b.scale
		 when b.water_biz_type = 'CHLORINE' then a.value * b.scale
		 when b.water_biz_type = 'FLUORIDE' then a.value * b.scale                  -- monitoring value * scale = true value
    end as value,
    case when b.water_biz_type = 'FLOW' then 'm3'
	     when b.water_biz_type = 'PRESSURE' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'M' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'MPD' then 'mPD'
		 when b.water_biz_type = 'PH' then ''
		 when b.water_biz_type = 'TURBIDITY' then 'NTU'
		 when b.water_biz_type = 'CHLORINE' then 'mg/L'
		 when b.water_biz_type = 'FLUORIDE' then 'mg/L'
	end as unit,
    b.comment,
    b.region_abbr,
    b.sub_region_code,
    b.name_cn,
    b.name_tc,
    b.name_en,
    b.water_biz_type,
    b.installation_id,
    b.tag_device_type_code,
    b.tag_device_type_cn,
    b.tag_device_type_tc,
    b.tag_device_type_en,
    b.tag_signal_code,
    b.tag_signal_cn,
    case when b.water_biz_type = 'ALARM' and a.value = 0 then b.text_1
         when b.water_biz_type = 'ALARM' and a.value = 1 then b.text_2
         when b.water_biz_type = 'ALARM' and a.value = 2 then b.text_3
         when b.water_biz_type = 'ALARM' and a.value = 3 then b.text_4
         else null
    end as context_text                                  -- obtain the alarm status information based on the alarm status code
from (
    -- obtain monitoring data
    select
        time,
        value,
        path
    from coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini
    where 
	    quality = 1                                    -- filter the data with quality of 1
		and ods_update_time > ${dwd_update_time}
) a
inner join (
    -- get detailed information about the tag
    select 
        scada_tag,
        comment,
        unit,
        scale,
        region_abbr,
		sub_region_code,
        name_cn,
        name_tc,
        name_en,
        water_type_code,
        water_biz_type,
        installation_id,
        tag_device_type_code,
        tag_signal_code,
        tag_device_type_cn,
        tag_device_type_tc,
        tag_device_type_en,
        tag_signal_cn,
        text_1,
        text_2,
        text_3,
        text_4
    from 
        coss_dim.dim_sis_tag_list_info
	where water_type_code in (
	    'WT_RW_000002',    -- raw water pumping station
		'WT_WP_000001',    -- reservoir
		'WT_RW_000008',    -- raw water pumping house
		'WT_PE_000005'     -- raw&fresh water pumping station
	)
) b 
on a.path = b.scada_tag;

-- subject     areas: pipe network areas
-- function describe: filter the pumping station real-time monitoring data with quality of 1 to table coss_dwd.dwd_pnw_pump_station_tag_monitored_hst_mini_month
-- create       date: 2025/10/13
-- modify date     modify by      modify content 
-- 
-- source table
-- coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini                    the sis system monitors data in real time
-- coss_dim.dim_sis_tag_list_info                                     sis system tag list
-- target table
-- coss_dwd.dwd_pnw_pump_station_tag_monitored_hst_mini_month         historical monitoring data of pumping station in the sis system
insert into coss_dwd.dwd_pnw_pump_station_tag_monitored_hst_mini_month (
    scada_tag,            -- scada tag
    time,                 -- monitoring time
    value,                -- monitoring value
    unit,                 -- monitoring value unit
    comment,              -- tag comment
    region_abbr,          -- regional abbreviation
    sub_region_code,      -- sub-region code
    name_cn,              -- simplified chinese name of the monitoring point
    name_tc,              -- the traditional chinese name of the monitoring point
    name_en,              -- the english name of the monitoring point
    water_biz_type,       -- monitoring type
    installation_id,      -- installation id
    tag_device_type_code, -- the code of equipment type
    tag_device_type_cn,   -- simplified chinese name of the device type
    tag_device_type_tc,   -- traditional chinese name of the equipment type
    tag_device_type_en,   -- the english name of the equipment type
    tag_signal_code,      -- the code of tag signal
    tag_signal_cn,        -- the chinese name of tag signal
    context_text          -- alarm value text
)
select 
    b.scada_tag,
    a.time,
    case when b.water_biz_type = 'ALARM' then a.value
	     when b.water_biz_type = 'FLOW' and upper(b.unit) = 'MLD' then a.value * b.scale * 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L'   then a.value * b.scale / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/H' then a.value * b.scale * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/S' then a.value * b.scale * 3600 * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'M3'  then a.value * b.scale
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'KPA' then a.value * b.scale / 9.80665
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'M' then a.value * b.scale
		 when b.water_biz_type = 'LEVEL' then a.value * b.scale
		 when b.water_biz_type = 'PH' then a.value * b.scale
		 when b.water_biz_type = 'TURBIDITY' then a.value * b.scale
		 when b.water_biz_type = 'CHLORINE' then a.value * b.scale
		 when b.water_biz_type = 'FLUORIDE' then a.value * b.scale                  -- monitoring value * scale = true value
    end as value,
    case when b.water_biz_type = 'FLOW' then 'm3'
	     when b.water_biz_type = 'PRESSURE' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'M' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'MPD' then 'mPD'
		 when b.water_biz_type = 'PH' then ''
		 when b.water_biz_type = 'TURBIDITY' then 'NTU'
		 when b.water_biz_type = 'CHLORINE' then 'mg/L'
		 when b.water_biz_type = 'FLUORIDE' then 'mg/L'
	end as unit,
    b.comment,
    b.region_abbr,
    b.sub_region_code,
    b.name_cn,
    b.name_tc,
    b.name_en,
    b.water_biz_type,
    b.installation_id,
    b.tag_device_type_code,
    b.tag_device_type_cn,
    b.tag_device_type_tc,
    b.tag_device_type_en,
    b.tag_signal_code,
    b.tag_signal_cn,
    case when b.water_biz_type = 'ALARM' and a.value = 0 then b.text_1
         when b.water_biz_type = 'ALARM' and a.value = 1 then b.text_2
         when b.water_biz_type = 'ALARM' and a.value = 2 then b.text_3
         when b.water_biz_type = 'ALARM' and a.value = 3 then b.text_4
         else null
    end as context_text                                    -- obtain the alarm status information based on the alarm status code
from (
    -- obtain monitoring data
    select
        time,
        value,
        path
    from coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini
    where 
	    quality = 1                                      -- filter the data with quality of 1
		and ods_update_time > ${dwd_update_time}
) a
inner join (
    -- get detailed information about the tag
    select 
        scada_tag,
        comment,
        unit,
        scale,
        region_abbr,
		sub_region_code,
        name_cn,
        name_tc,
        name_en,
        water_type_code,
        water_biz_type,
        installation_id,
        tag_device_type_code,
        tag_signal_code,
        tag_device_type_cn,
        tag_device_type_tc,
        tag_device_type_en,
        tag_signal_cn,
        text_1,
        text_2,
        text_3,
        text_4
    from 
        coss_dim.dim_sis_tag_list_info
	where water_type_code in (
	    'WT_FC_000007',   -- fresh water pumping house
		'WT_FC_000008',   -- fresh water pumping station
		'WT_PE_000004',   -- salt&fresh water pumping station
		'WT_PE_000005',   -- raw&fresh water pumping station
		'WT_RW_000002',   -- raw water pumping station
		'WT_RW_000008',   -- raw water pumping house
		'WT_SC_000003'    -- salt water pumping house
	)
) b 
on a.path = b.scada_tag;

-- subject     areas: pipe network areas
-- function describe: filter the service reservoir real-time monitoring data with quality of 1 to table coss_dwd.dwd_pnw_service_reservoir_tag_monitored_hst_mini_month
-- create       date: 2025/10/13
-- modify date     modify by      modify content 
-- 
-- source table
-- coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini                         the sis system monitors data in real time
-- coss_dim.dim_sis_tag_list_info                                          sis system tag list
-- target table
-- coss_dwd.dwd_pnw_service_reservoir_tag_monitored_hst_mini_month         historical monitoring data of service reservoir in the sis system
insert into coss_dwd.dwd_pnw_service_reservoir_tag_monitored_hst_mini_month (
    scada_tag,            -- scada tag
    time,                 -- monitoring time
    value,                -- monitoring value
    unit,                 -- monitoring value unit
    comment,              -- tag comment
    region_abbr,          -- regional abbreviation
    sub_region_code,      -- sub-region code
    name_cn,              -- simplified chinese name of the monitoring point
    name_tc,              -- the traditional chinese name of the monitoring point
    name_en,              -- the english name of the monitoring point
    water_biz_type,       -- monitoring type
    installation_id,      -- installation id
    tag_device_type_code, -- the code of equipment type
    tag_device_type_cn,   -- simplified chinese name of the device type
    tag_device_type_tc,   -- traditional chinese name of the equipment type
    tag_device_type_en,   -- the english name of the equipment type
    tag_signal_code,      -- the code of tag signal
    tag_signal_cn,        -- the chinese name of tag signal
    context_text          -- alarm value text
)
select 
    b.scada_tag,
    a.time,
    case when b.water_biz_type = 'ALARM' then a.value
	     when b.water_biz_type = 'FLOW' and upper(b.unit) = 'MLD' then a.value * b.scale * 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L'   then a.value * b.scale / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/H' then a.value * b.scale * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'L/S' then a.value * b.scale * 3600 * 24 / 1000
		 when b.water_biz_type = 'FLOW' and upper(b.unit) = 'M3'  then a.value * b.scale
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'KPA' then a.value * b.scale / 9.80665
		 when b.water_biz_type = 'PRESSURE' and upper(b.unit) = 'M' then a.value * b.scale
		 when b.water_biz_type = 'LEVEL' then a.value * b.scale
		 when b.water_biz_type = 'PH' then a.value * b.scale
		 when b.water_biz_type = 'TURBIDITY' then a.value * b.scale
		 when b.water_biz_type = 'CHLORINE' then a.value * b.scale
		 when b.water_biz_type = 'FLUORIDE' then a.value * b.scale                  -- monitoring value * scale = true value
    end as value,
    case when b.water_biz_type = 'FLOW' then 'm3'
	     when b.water_biz_type = 'PRESSURE' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'M' then 'm'
		 when b.water_biz_type = 'LEVEL' and upper(b.unit) = 'MPD' then 'mPD'
		 when b.water_biz_type = 'PH' then ''
		 when b.water_biz_type = 'TURBIDITY' then 'NTU'
		 when b.water_biz_type = 'CHLORINE' then 'mg/L'
		 when b.water_biz_type = 'FLUORIDE' then 'mg/L'
	end as unit,
    b.comment,
    b.region_abbr,
    b.sub_region_code,
    b.name_cn,
    b.name_tc,
    b.name_en,
    b.water_biz_type,
    b.installation_id,
    b.tag_device_type_code,
    b.tag_device_type_cn,
    b.tag_device_type_tc,
    b.tag_device_type_en,
    b.tag_signal_code,
    b.tag_signal_cn,
    case when b.water_biz_type = 'ALARM' and a.value = 0 then b.text_1
         when b.water_biz_type = 'ALARM' and a.value = 1 then b.text_2
         when b.water_biz_type = 'ALARM' and a.value = 2 then b.text_3
         when b.water_biz_type = 'ALARM' and a.value = 3 then b.text_4
         else null
    end as context_text                                -- obtain the alarm status information based on the alarm status code
from (
    -- obtain monitoring data
    select
        time,
        value,
        path
    from coss_ods.ods_sis_pnw_pipe_tag_monitored_rt_mini
    where 
	    quality = 1                                  -- filter the data with quality of 1
	    and ods_update_time > ${dwd_update_time}
) a
inner join (
    -- get detailed information about the tag
    select 
        scada_tag,
        comment,
        unit,
        scale,
        region_abbr,
		sub_region_code,
        name_cn,
        name_tc,
        name_en,
        water_type_code,
        water_biz_type,
        installation_id,
        tag_device_type_code,
        tag_signal_code,
        tag_device_type_cn,
        tag_device_type_tc,
        tag_device_type_en,
        tag_signal_cn,
        text_1,
        text_2,
        text_3,
        text_4
    from 
        coss_dim.dim_sis_tag_list_info
	where water_type_code in (
	    'WT_FC_000002',    -- fresh water service reservoir
		'WT_SC_000004'     -- salt water service reservoir
	)
) b 
on a.path = b.scada_tag;