## version manage

```remark
==================================================================================
表结构修改情况:
1.coss_dm.dm_wtw_eng_cons_billing_hist_dip 表结构更新为：coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di
2.coss_dm.dm_psr_daily_ps_running_item_di  表结构更新为：coss_dm.dm_psr_monthly_ps_running_item_di
3.coss_dim.dim_ps_installation_info        该表未新增维度表
==================================================================================
数据更新情况:
1.公司opengaussdb 已经更新
2.HK DEV 已经更新
==================================================================================
指标更新情况：
1.抽水站、滤水厂二级页面的 kwh/cum 修改未 kwh/ML  指标数据还已修改
==================================================================================
双周会修改新增表：
1.coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di
2.coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di
3.coss_dim.dim_wtw_installation_info
```



---

## dm

### 1.Create Table

#### 1.coss_dm.dm_wtw_eng_cons_billing_hist_dip

```sql
;drop table if exists coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di
;create table if not exists coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di(
  id                     varchar(50)
  ,asset_id               decimal(11)
  ,asset_name            varchar(120)
  ,asset_desc            varchar(120)
  ,i_type_code           varchar(150)
  ,i_type_desc           varchar(150)
  ,region_rpt            varchar(150)
  ,bill_id               decimal(20)
  ,bill_date             timestamp(6)
  ,tariff_name           varchar(150)
  ,tariff_desc           varchar(300)
  ,utility_name          varchar(150)
  ,utility_desc          varchar(800)
  ,kwh_on_peak           decimal(10,0)
  ,kwh_off_peak          decimal(10,0)
  ,payout                decimal(10,0)
  ,total_kwh             decimal(10,0)
  ,pump_qty              decimal(20,5)
  ,dm_update_time        timestamp(6) default current_timestamp
  ,dm_load_time          timestamp(6) default current_timestamp
  ,statistical_month     decimal(10)
  ,primary key (id)
  ,constraint uk_eng_cons_billing_bill_id unique (bill_id)

)
with (orientation = row, compression = no)
-- distribute by hash (bill_id)
;comment on table  coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di                    is 'pump station running billing history'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.asset_id           is  'asset id'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.asset_name         is  'asset name'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.asset_desc         is  'asset description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.i_type_code        is  'installation type code'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.i_type_desc        is  'installation type  description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.region_rpt         is  'region report'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.bill_id            is  'bill_id'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.bill_date          is  'bill date'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.tariff_name        is  'tariff name'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.tariff_desc        is  'tariff description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.utility_name       is  'utility name'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.utility_desc       is  'utility description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.payout             is  'pay out'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.total_kwh          is  'power consumption of total (kwh), the calculation logic is (kwh_on_peak + kwh_off_peak)'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.pump_qty           is  'water pumped this month'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.dm_update_time     is  'dm update time'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.dm_load_time       is  'dm load time'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.statistical_month  is  'statistical month'
```



#### 2.coss_dm.dm_psr_annual_pump_station_item_di

```sql
;drop table if exists coss_dm.dm_psr_annual_pump_station_item_di
;create table if not exists coss_dm.dm_psr_annual_pump_station_item_di(
  id                           varchar(50)
  ,statistical_year            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_item_year_region_code unique (statistical_year,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_year,region_abbr)
;comment on table  coss_dm.dm_psr_annual_pump_station_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.statistical_year     is 'Statistical Year'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.dm_load_time         is 'Data Loading Time'
```

#### 3.coss_dm.dm_psr_monthly_pump_station_item_di

```sql
;drop table if exists coss_dm.dm_psr_monthly_pump_station_item_di
;create table if not exists coss_dm.dm_psr_monthly_pump_station_item_di(
  id                           varchar(50)
  ,statistical_month            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_item_month_region_code unique (statistical_month,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_month,region_abbr)
;comment on table  coss_dm.dm_psr_monthly_pump_station_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.statistical_month     is 'Statistical month'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.dm_load_time         is 'Data Loading Time'
```

#### 4.coss_dm.dm_psr_daily_pump_station_item_di

```sql
;drop table if exists coss_dm.dm_psr_daily_pump_station_item_di
;create table if not exists coss_dm.dm_psr_daily_pump_station_item_di(
  id                           varchar(50)
  ,statistical_day            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_item_day_region_code unique (statistical_day,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_day,region_abbr)
;comment on table  coss_dm.dm_psr_daily_pump_station_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.statistical_day     is 'Statistical day'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_psr_daily_pump_station_item_di.dm_load_time         is 'Data Loading Time'
```

#### 5.coss_dm.dm_wtw_annual_water_treatment_works_item_di

```sql
;drop table if exists coss_dm.dm_wtw_annual_water_treatment_works_item_di
;create table if not exists coss_dm.dm_wtw_annual_water_treatment_works_item_di(
  id                           varchar(50)
  ,statistical_year            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_year_region_code unique (statistical_year,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_year,region_abbr)
;comment on table  coss_dm.dm_wtw_annual_water_treatment_works_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.statistical_year     is 'Statistical Year'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.dm_load_time         is 'Data Loading Time'
```

#### 6.coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di

```sql
;drop table if exists coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di
;create table if not exists coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di(
  id                           varchar(50)
  ,statistical_year            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,asset_id                    int
  ,wtw_name_en                 varchar(250)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_year_wtw_code unique (statistical_year,region_abbr,wtw_name_en,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_year,region_abbr)
;comment on table  coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di                      is 'The Water Treatment Works items'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.statistical_year     is 'Statistical Year'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.asset_id             is 'asset id'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.wtw_name_en          is 'Water Treatment Work English Name'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.dm_load_time         is 'Data Loading Time'
```

#### 7.coss_dm.dm_wtw_monthly_water_treatment_works_item_di

```sql
;drop table if exists coss_dm.dm_wtw_monthly_water_treatment_works_item_di
;create table if not exists coss_dm.dm_wtw_monthly_water_treatment_works_item_di(
  id                           varchar(50)
  ,statistical_month            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_month_region_code unique (statistical_month,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_month,region_abbr)
;comment on table  coss_dm.dm_wtw_monthly_water_treatment_works_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.statistical_month     is 'Statistical month'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.dm_load_time         is 'Data Loading Time'

```

#### 8.coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di

```sql
;drop table if exists coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di
;create table if not exists coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di(
  id                           varchar(50)
  ,statistical_month            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,asset_id                    int
  ,wtw_name_en                 varchar(250)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_month_wtw_code unique (statistical_month, wtw_name_en, inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_month,region_abbr)
;comment on table  coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di                      is 'The Annual Pump Station items'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.statistical_month    is 'Statistical month'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.asset_id             is 'asset_id'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.wtw_name_en          is 'Water Treatmemt Works'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.dm_load_time         is 'Data Loading Time'
```



#### 9.coss_dm.dm_wtw_daily_water_treatment_works_item_di

```sql
;drop table if exists coss_dm.dm_wtw_daily_water_treatment_works_item_di
;create table if not exists coss_dm.dm_wtw_daily_water_treatment_works_item_di(
  id                           varchar(50)
  ,statistical_day            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_day_region_code unique (statistical_day,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_day,region_abbr)
;comment on table  coss_dm.dm_wtw_daily_water_treatment_works_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.statistical_day     is 'Statistical day'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_daily_water_treatment_works_item_di.dm_load_time         is 'Data Loading Time'
```

#### 10.coss_dm.dm_psr_monthly_ps_running_item_di

```sql
;drop table if exists coss_dm.dm_psr_monthly_ps_running_item_di
;create table if not exists coss_dm.dm_psr_monthly_ps_running_item_di(
  id                  varchar(50)
  ,asset_id           decimal(10)
  ,region_abbr        varchar(50)
  ,sub_region         varchar(50)
  ,installation_no    varchar(50)
  ,ps_en              varchar(100)
  ,ps_cn              varchar(100)
  ,address_en         varchar(100)
  ,address_cn         varchar(100)
  ,kwh_ml             decimal(20,5)
  ,running_pumps      decimal(20,5)
  ,total_pumps        decimal(20,5)
  ,statistical_month  decimal(10,0)
  ,dm_update_time     timestamp(6) default current_timestamp
  ,dm_load_time       timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_running_item_month_region_code unique (statistical_month,region_abbr,asset_id)
)
with (orientation = row, compression = no)
-- distribute by hash (statistical_month, region_abbr)
;comment on table  coss_dm.dm_psr_monthly_ps_running_item_di                       is 'The Monthly Pump Station Running items'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.id                    is 'Primary Key'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.asset_id              is 'asset id'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.region_abbr           is 'region abbr'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.sub_region            is 'sub region'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.installation_no       is 'installation_no'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.ps_en                 is 'pump station en name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.ps_cn                 is 'pump station cn name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.address_en            is 'address en name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.address_cn            is 'address cn name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.kwh_ml                is 'kwh/ml'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.running_pumps         is 'running pump number'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.total_pumps           is 'total pump number'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.statistical_month     is 'statistical month'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.dm_update_time        is  'dm update time'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.dm_load_time          is  'dm load time'
```

#### 11.coss_dim.dim_ps_installation_info

```sql
;drop table if exists coss_dim.dim_ps_installation_info
;create table if not exists coss_dim.dim_ps_installation_info(
  asset_id           decimal(10)
  ,region_abbr        varchar(50)
  ,sub_region         varchar(50)
  ,installation_no    varchar(50)
  ,ps_en              varchar(100)
  ,ps_cn              varchar(100)
  ,address_en         varchar(100)
  ,address_cn         varchar(100)
  ,dim_update_time     timestamp(6) default current_timestamp
  ,dim_load_time       timestamp(6) default current_timestamp
  ,primary key (asset_id)
)
with (orientation = row, compression = no)
-- distribute by hash (statistical_month, region_abbr)
;comment on table  coss_dim.dim_ps_installation_info                       is 'The Monthly Pump Station Running items'
;comment on column coss_dim.dim_ps_installation_info.asset_id              is 'asset id'
;comment on column coss_dim.dim_ps_installation_info.region_abbr           is 'region abbr'
;comment on column coss_dim.dim_ps_installation_info.sub_region            is 'sub region'
;comment on column coss_dim.dim_ps_installation_info.installation_no       is 'installation_no'
;comment on column coss_dim.dim_ps_installation_info.ps_en                 is 'pump station en name'
;comment on column coss_dim.dim_ps_installation_info.ps_cn                 is 'pump station cn name'
;comment on column coss_dim.dim_ps_installation_info.address_en            is 'address en name'
;comment on column coss_dim.dim_ps_installation_info.address_cn            is 'address cn name'
;comment on column coss_dim.dim_ps_installation_info.dim_update_time        is  'dm update time'
;comment on column coss_dim.dim_ps_installation_info.dim_load_time          is  'dm load time'
```

#### 12.coss_dim.dim_wtw_installation_info

```sql
;drop table if exists coss_dim.dim_wtw_installation_info
;create table if not exists coss_dim.dim_wtw_installation_info(
  asset_id             numeric(11)
  ,asset_name          varchar(120)
  ,asset_desc          varchar(120)
  ,loca_code           varchar(15)
  ,region_abbr         varchar(150)
  ,i_type_id           numeric(11)
  ,i_type_code         varchar(150)
  ,i_type_desc         varchar(150)
  ,dim_update_time     timestamp(6) default current_timestamp
  ,dim_load_time       timestamp(6) default current_timestamp
  ,primary key (asset_id)
)
with (orientation = row, compression = no)
-- distribute by hash (asset_id)
;comment on table  coss_dim.dim_wtw_installation_info                       is 'The Water Treatment Works items'
;comment on column coss_dim.dim_wtw_installation_info.asset_id              is 'asset id '
;comment on column coss_dim.dim_wtw_installation_info.asset_name            is 'asset name'
;comment on column coss_dim.dim_wtw_installation_info.asset_desc            is 'asset descrip'
;comment on column coss_dim.dim_wtw_installation_info.loca_code             is 'local code'
;comment on column coss_dim.dim_wtw_installation_info.region_abbr           is 'region'
;comment on column coss_dim.dim_wtw_installation_info.i_type_id             is 'installation type id '
;comment on column coss_dim.dim_wtw_installation_info.i_type_code           is 'installation code '
;comment on column coss_dim.dim_wtw_installation_info.i_type_desc           is 'installation type descrip'
;comment on column coss_dim.dim_wtw_installation_info.dim_update_time       is 'dm update time'
;comment on column coss_dim.dim_wtw_installation_info.dim_load_time         is 'dm load time'
;insert into coss_dim.dim_wtw_installation_info
select 
  asset_id
  ,asset_name
  ,asset_desc
  ,loca_code
  ,region_rpt as region_abbr
  ,i_type_id
  ,i_type_code
  ,i_type_desc
  ,localtimestamp
  ,localtimestamp
from coss_dwd.dim_ass_energy_cons_installation_dfp 
where asset_name like '%WTW%' 
and asset_name not like '%Ceased%'
and  asset_name not like '%decommissioned%'

```



## metric calculated

#### 1.Fresh&Salt water pump station energy consumption&water pumped&station number

```sql
;delete 
from 
coss_dm.dm_psr_annual_pump_station_item_di
where 
inter_item_code in(
 'IT_PS_000001'
,'IT_PS_000002'
,'IT_PS_000003'
,'IT_PS_000005'
,'IT_PS_000007'
,'IT_PS_000008'
,'IT_PS_000009'
,'IT_PS_000011'
,'IT_PS_000029'
,'IT_PS_000030'
,'IT_PS_000031'
)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'FW'
group by 
  yr
  ,region_rpt
), t_ar as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'RW'
group by 
  yr
  ,region_rpt
),t_as as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
group by 
  yr
  ,region_rpt
),t_afs as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
group by 
  yr
  ,region_rpt
),
t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'FW'
group by 
  yr
),
t_br as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'RW'
group by 
  yr
),
t_bs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
group by 
  yr
),t_bfs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
group by 
  yr
)
insert into coss_dm.dm_psr_annual_pump_station_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000001'                        as item_code
  ,'食水抽水站电耗量' as item_name_cn
  ,'食水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Fresh Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000001'                        as item_code
  ,'食水抽水站电耗量' as item_name_cn
  ,'食水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Fresh Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000002'                        as item_code
  ,'原水抽水站电耗量' as item_name_cn
  ,'原水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Raw Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_br t
union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000002'                        as item_code
  ,'原水站电耗量' as item_name_cn
  ,'原水食水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Raw Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_ar t
union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000003'                        as item_code
  ,'海水抽水站电耗量' as item_name_cn
  ,'海水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Salt Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000003'                        as item_code
  ,'海水抽水站电耗量' as item_name_cn
  ,'海水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Salt Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000005'                        as item_code
  ,'其他(combine)抽水站电耗量' as item_name_cn
  ,'其他(combine)抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of combine Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000005'                        as item_code
  ,'其他(combine)抽水站电耗量' as item_name_cn
  ,'其他(combine)抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of combine Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_afs t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000007'                        as item_code
  ,'食水抽水站抽水量' as item_name_cn
  ,'食水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000007'                        as item_code
  ,'食水抽水站抽水量' as item_name_cn
  ,'食水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000008'                        as item_code
  ,'原水抽水站抽水量' as item_name_cn
  ,'原水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Raw Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000008'                        as item_code
  ,'原水抽水站抽水量' as item_name_cn
  ,'原水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Raw Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000009'                        as item_code
  ,'海水抽水站抽水量' as item_name_cn
  ,'海水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Salt Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000009'                        as item_code
  ,'海水抽水站抽水量' as item_name_cn
  ,'海水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Salt Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000011'                        as item_code
  ,'其他(combine)抽水站抽水量' as item_name_cn
  ,'其他(combine)抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of combine Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000011'                        as item_code
  ,'其他(combine)抽水站抽水量' as item_name_cn
  ,'其他(combine)抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of combine Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_afs t
union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000029'                        as item_code
  ,'食水抽水站kwh/Ml' as item_name_cn
  ,'食水抽水站kwh/Ml' as item_name_tc  
  ,'Power Consumption kwh/Ml Of Fresh Water Pumping Stations' as item_name_en  
  ,t.total_kwh/(t.pump_qty*1000)                       as item_value  -- convert pump_qty mcm to Ml
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
where pump_qty is not null and pump_qty !=0 

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000029'                        as item_code
  ,'食水抽水站kwh/Ml' as item_name_cn
  ,'食水抽水站kwh/Ml' as item_name_tc  
  ,'Power Consumption kwh/Ml Of Fresh Water Pumping Stations' as item_name_en  
  ,t.total_kwh/(t.pump_qty*1000)                       as item_value  -- convert pump_qty mcm to Ml
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
where pump_qty is not null and pump_qty !=0 

union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000030'                        as item_code
  ,'食水抽水站kwh/Ml同比整张率' as item_name_cn
  ,'食水抽水站kwh/Ml年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Power Consumption kwh/Ml Of Fresh Water Pumping Stations' as item_name_en  
  ,((t.total_kwh/(t.pump_qty*1000)) - (t1.total_kwh/(t1.pump_qty*1000)))/(t1.total_kwh/(t1.pump_qty*1000)) * 100   as item_value  -- convert pump_qty mcm to Ml
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
  left join t_bf t1 on t.region = t1.region and t.yr = t1.yr+1
where t.pump_qty is not null 
  and t.pump_qty !=0 
  and t1.pump_qty is not null 
  and t1.pump_qty !=0 

union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000030'                        as item_code
  ,'食水抽水站kwh/Ml同比整张率' as item_name_cn
  ,'食水抽水站kwh/Ml年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Power Consumption kwh/Ml Of Fresh Water Pumping Stations' as item_name_en  
  ,((t.total_kwh/(t.pump_qty*1000)) - (t1.total_kwh/(t1.pump_qty*1000)))/(t1.total_kwh/(t1.pump_qty*1000)) * 100   as item_value  -- convert pump_qty mcm to Ml
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
  left join t_af t1 on t.region = t1.region and t.yr = t1.yr+1
where t.pump_qty is not null 
  and t.pump_qty !=0 
  and t1.pump_qty is not null 
  and t1.pump_qty !=0 
    
union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000031'                        as item_code
  ,'食水抽水站抽水量同比增长率' as item_name_cn
  ,'食水抽水站抽水量年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,(t.pump_qty - t1.pump_qty)/t1.pump_qty * 100                       as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
left join t_bf t1 on t.region = t1.region and t.yr = t1.yr+1
where t1.pump_qty is not null 
  and t1.pump_qty != 0

union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000031'                        as item_code
  ,'食水抽水站抽水量同比增长率' as item_name_cn
  ,'食水抽水站抽水量年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,(t.pump_qty - t1.pump_qty)/t1.pump_qty * 100                       as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
left join t_af t1 on t.region = t1.region and t.yr = t1.yr+1
where t1.pump_qty is not null 
  and t1.pump_qty != 0
)
```



#### 2.Fresh&Salt water pump station electricity consumption per unit 

#### 2.1Yearly

```sql
;delete from coss_dm.dm_psr_annual_pump_station_item_di
where 
inter_item_code in( 
'IT_PS_000019'
,'IT_PS_000020'
,'IT_PS_000021'
,'IT_PS_000023'
)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'FW')
  and pump_qty is not null and pump_qty !=0
group by 
  yr
  ,region_rpt
),t_ar as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'RW')
  and pump_qty is not null and pump_qty !=0
group by 
  yr
  ,region_rpt
),t_as as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
group by 
  yr
  ,region_rpt
),t_afs as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
group by 
  yr
  ,region_rpt
),
t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'FW'
  or i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
group by 
  yr
),
t_br as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
group by 
  yr
)
,t_bs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
group by 
  yr
),t_bfs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
group by 
  yr
)
insert into coss_dm.dm_psr_annual_pump_station_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'食水海水抽水站单位电耗' as item_name_cn
  ,'食水海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit  Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'食水海水抽水站单位电耗' as item_name_cn
  ,'食水海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_afs t
)
```



#### 2.2Monthly

```sql
;delete from coss_dm.dm_psr_monthly_pump_station_item_di
where 
inter_item_code in( 
'IT_PS_000019'
,'IT_PS_000020'
,'IT_PS_000021'
,'IT_PS_000023'
)

;with t_af as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty   
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'FW')
  and pump_qty is not null and pump_qty !=0
group by 
  mh
  ,region_rpt
),
t_ar as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty    
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'RW')
  and pump_qty is not null and pump_qty !=0
group by 
  mh
  ,region_rpt
),t_as as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty   
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
group by 
  mh
  ,region_rpt
),t_afs as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty  
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
group by 
  mh
  ,region_rpt
),
t_bf as(
select 
  mh as mh
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty  
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'FW')
  and pump_qty is not null  and pump_qty !=0
group by 
  mh
)
,t_br as(
select 
  mh as mh
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty  
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
group by 
  mh
)
,t_bs as(
select 
  mh as mh
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty 
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
group by 
  mh
),t_bfs as(
select 
  mh as mh
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty   
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
group by 
  mh
)
insert into coss_dm.dm_psr_monthly_pump_station_item_di
select 
id
,mh statistical_month
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'其他（Combine）抽水站单位电耗' as item_name_cn
  ,'其他（Combine）抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit  Of Combine Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'其他（Combine）抽水站单位电耗' as item_name_cn
  ,'其他（Combine）抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Combine Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_afs t
)
```



#### 2.3Daily

```sql
;delete from coss_dm.dm_psr_daily_pump_station_item_di
where 
inter_item_code in( 
'IT_PS_000019'
,'IT_PS_000020'
,'IT_PS_000021'
,'IT_PS_000023'
)

;with t_af as(
select 
  mh*100+1 as dt
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'FW')
  and pump_qty is not null and pump_qty !=0
group by 
  dt
  ,region_rpt
),t_ar as(
select 
  mh*100+1 as dt
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'RW')
  and pump_qty is not null and pump_qty !=0
group by 
  dt
  ,region_rpt
),t_as as(
select 
  mh*100+1 as dt
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
group by 
  dt
  ,region_rpt
),t_afs as(
select 
  mh*100+1 as dt
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
group by 
  dt
  ,region_rpt
),
t_bf as(
select 
  mh*100+1 as dt
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'FW')
  and pump_qty is not null  and pump_qty !=0
group by 
  dt
),
t_br as(
select 
  mh*100+1 as dt
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where (i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
group by 
  dt
),t_bs as(
select 
  mh*100+1 as dt
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
group by 
  dt
),t_bfs as(
select 
  mh*100+1 as dt
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty*1000) kwh_qty    -- convert Ml to cum
from coss_dws.dws_psr_eng_cons_billing_details_dip 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
group by 
  dt
)
insert into coss_dm.dm_psr_daily_pump_station_item_di
select 
id
,dt statistical_day
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'其他（Combine）抽水站单位电耗' as item_name_cn
  ,'其他（Combine）抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit  Of Combine Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'其他（Combine）抽水站单位电耗' as item_name_cn
  ,'其他（Combine）抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Combine Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_afs t)

```



### 4.water treatment works metircs

#### 4.1Yearly region

```sql
;delete from coss_dm.dm_wtw_annual_water_treatment_works_item_di
where inter_item_code in (
'IT_TW_000025'
,'IT_TW_000027'
)
;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where  pump_qty is not null and pump_qty !=0
group by 
  yr
  ,region_rpt
),t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where pump_qty is not null  and pump_qty !=0
group by 
  yr
)
insert into coss_dm.dm_wtw_annual_water_treatment_works_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t

union all 
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_TW_000027'                        as item_code
  ,'滤水厂单位电耗同比增长率' as item_name_cn
  ,'濾水廠單位電耗同比增長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Electricity Consumption Per Unit In Water Treatment Works' as item_name_en  
  ,case when t1.kwh_qty is null or t1.kwh_qty = 0 then 0
  else  (t.kwh_qty - t1.kwh_qty)/t1.kwh_qty * 100 end   as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
  left join t_bf t1 on t.yr = t1.yr+1 and t.region = t1.region
  
union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_TW_000027'                        as item_code
  ,'滤水厂单位电耗同比增长率' as item_name_cn
  ,'濾水廠水站單位電耗同比增長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Electricity Consumption Per Unit In Water Treatment Works' as item_name_en  
  ,case when t1.kwh_qty is null or t1.kwh_qty = 0 then 0
  else  (t.kwh_qty - t1.kwh_qty)/t1.kwh_qty * 100 end   as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
  left join t_af t1 on t.yr = t1.yr+1 and t.region = t1.region)
```

#### 4.2Yealy wtw

```sql
;delete from coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di
where inter_item_code in (
'IT_TW_000025'
,'IT_TW_000027'
)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,asset_id 
  ,asset_name wtw_name_en
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where  pump_qty is not null and pump_qty !=0
group by 
  yr
  ,region_rpt
  ,wtw_name_en 
  ,asset_id 
)
insert into coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di
select 
id
,yr statistical_year
,region region_abbr
,asset_id 
,wtw_name_en
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                           as id
  ,region                          as region
  ,asset_id 
  ,wtw_name_en                     as wtw_name_en
  ,'IT_TW_000025'                  as item_code
  ,'滤水厂单位电耗'                     as item_name_cn
  ,'濾水廠水站單位電耗'                   as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
  
union all
select
  uuid()                             as id
  ,t.region                           as region
  ,t.asset_id 
  ,t.wtw_name_en                     as wtw_name_en
  ,'IT_TW_000027'                        as item_code
  ,'滤水厂单位电耗同比增长率' as item_name_cn
  ,'濾水廠水站單位電耗同比增長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Electricity Consumption Per Unit In Water Treatment Works' as item_name_en  
  ,case when t1.kwh_qty is null or t1.kwh_qty = 0 then 0
  else  (t.kwh_qty - t1.kwh_qty)/t1.kwh_qty * 100 end   as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
  left join t_af t1 on t.yr = t1.yr+1 and t.region = t1.region and t.wtw_name_en = t1.wtw_name_en )
  
```



#### 4.3Monthly region

```sql
;delete from coss_dm.dm_wtw_monthly_water_treatment_works_item_di
where 
inter_item_code in( 
'IT_TW_000025'
)

;with t_af as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty ) kwh_qty   
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where  pump_qty is not null and pump_qty !=0
group by 
  mh
  ,region_rpt
),t_bf as(
select 
  mh as mh
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty ) kwh_qty   
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where pump_qty is not null  and pump_qty !=0
group by 
  mh
)
insert into coss_dm.dm_wtw_monthly_water_treatment_works_item_di
select 
id
,mh statistical_month
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_af t)

```

#### 4.4Monthly wtw

```sql
;delete from coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di
where 
inter_item_code in( 
'IT_TW_000025'
)

;with t_af as(
select 
  mh as mh
  ,region_rpt region
  ,asset_id 
  ,asset_name wtw_name_en
  ,sum(total_kwh)/sum(pump_qty ) kwh_qty   
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where  pump_qty is not null and pump_qty !=0
group by 
  mh
  ,region_rpt
  ,wtw_name_en
  ,asset_id 
)
-- insert into coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di
select 
id
,mh statistical_month
,region region_abbr
,asset_id 
,wtw_name_en
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,asset_id 
  ,wtw_name_en                      as wtw_name_en                                                                 
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_af t)
```



#### 4.3Daily

```sql
;delete from coss_dm.dm_wtw_daily_water_treatment_works_item_di
where 
inter_item_code in( 
'IT_TW_000025'
)

;with t_af as(
select 
  mh * 100 + 1 as dt
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty * 1000) kwh_qty    --convert Ml to cum
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where  pump_qty is not null and pump_qty !=0
group by 
  dt
  ,region_rpt
),t_bf as(
select 
  mh * 100 + 1 as dt
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty * 1000) kwh_qty    --convert Ml to cum
from coss_dws.dws_wtw_eng_cons_billing_details_dip 
where pump_qty is not null  and pump_qty !=0
group by 
  dt
)
insert into coss_dm.dm_wtw_daily_water_treatment_works_item_di
select 
id
,dt statistical_day
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from (
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/cum'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.dt                              as dt
from t_af t)
```

### 5.add kwh_ml&running_pumps

```sql
;with t_a as (
select 
"INSTALLATION_ID" "Installation_No" 
,split_part(split_part("REGION",'(',2), ')', 1) as sub_region
from(
select "INSTALLATION_ID", "REGION", "SYSTEM" from coss_ods.ods_dms_f_pumpstn_dfn where char_length("INSTALLATION_ID") !=0
union all 
select "INSTALLATION_ID", "REGION", "SYSTEM" from coss_ods.ods_dms_r_pumpstn_dfn where char_length("INSTALLATION_ID") !=0
union all
select "INSTALLATION_ID", "REGION", "SYSTEM" from coss_ods.ods_dms_s_pumpstn_dfn where char_length("INSTALLATION_ID") !=0
) t
group by 
"INSTALLATION_ID", "REGION"
), t_b as(
select 
t.asset_id
,t.kwh_ml
,t1.running_pumps
,t1.total_pumps
,t.mh
from 
(select 
asset_id
,total_kwh/pump_qty  kwh_ml
,mh 
from coss_dm.dm_psr_eng_cons_billing_hist_dip  
where pump_qty !=0 and pump_qty is not null )t
left join 
(select
mh
,asset_id
,sum(if(run_hours>0,1,0)) running_pumps
,count(pump_num) total_pumps 
from coss_dwd.dwd_psr_pump_running_details_dip 
group by 
mh
,asset_id)t1 on t.mh = t1.mh and t.asset_id = t1.asset_id
)
insert into coss_dm.dm_psr_daily_ps_running_item_di
select 
t.asset_id
,t1."Region" region 
,t2.sub_region 
,t1."Installation_No"
,t1."Offical_Eng_Name"
,t1."Offical_Chi_Name"
,t1."Address_Eng"
,t1."Address_Chi"
,t.kwh_ml
,t.running_pumps
,t.total_pumps
,t.mh
from t_b t
left join coss_ods.ods_wsdems_asset_offical_dfn t1 on t.asset_id = t1.asset_id 
left join t_a t2 on t1."Installation_No" = t2."Installation_No"
```

dim load data

```sql
insert into coss_dim.dim_ps_installation_info
select 
  asset_id        
  ,region_abbr    
  ,sub_region  
  ,installation_no
  ,ps_en          
  ,ps_cn          
  ,address_en     
  ,address_cn     
  ,now() dim_update_time
  ,now() dim_load_time  
from 
coss_dm.dm_psr_monthly_ps_running_item_di
group by 
  asset_id        
  ,region_abbr    
  ,sub_region  
  ,installation_no
  ,ps_en          
  ,ps_cn          
  ,address_en     
  ,address_cn     
```



