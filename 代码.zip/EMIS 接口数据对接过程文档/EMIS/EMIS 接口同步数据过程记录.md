## 1.asset

> 读取report 数据，并将数据报错到txt文件
>
> 注：代码文件在10.66.169.236机器中的pycharm环境

```python
import requests
import funtion
import json
asset_list = funtion.get_asset_id()

res = []
for ast in asset_list:
    url = 'https://wiki.sis2.wsd.gov/ems/webresources/reports?loc_id='+ast+'&from=2023-01-01&to=2026-01-01'
    re = funtion.get_pump_report(url,ast)
    res.append(re)
    print(ast)
res = json.dumps(res)
with open('output.txt', 'w', encoding='utf-8') as f:
    f.write(res)
```

## 2.funtion

> 功能函数，其中包括读取接口函数和读取资产列表函数
>
> 注：代码文件在10.66.169.236机器中的pycharm环境

```python
import requests
def get_asset_id():
    with open('asset_id.txt', 'r', encoding='utf-8') as file:
        content = file.read()  # 读取全部内容为字符串
    return content.split('\n')
def get_pump_report(url, asset_id):
    re = []
    headers = {'Content-Type': 'application/json'}
    data = requests.get(url, headers=headers, verify=False)
    # print(data.json())
    # print(data.json()['location']['id'])
    rpt_id = 'null'
    asset_id = data.json()['location']['id']
    report = data.json()['reports']
    for i in range(len(report)):
        # print(report[i]['per_destination'])
        per_destination = report[i]['per_destination']
        mh = report[i]['date'].replace('-', '')
        for j in range(len(per_destination)):
            pump_num = per_destination[j]['Pump_Number']
            cat_id = 'null'
            cat_name = per_destination[j]['category']
            drive_id = 'null'
            drive_name = per_destination[j]['drive']
            del_id = 'null'
            del_name = per_destination[j]['destination']
            del_asset_id = per_destination[j]['dest_id']
            design_flow = 'null'
            run_hours = per_destination[j]['Hours_Run_This_Month']
            pump_qty = per_destination[j]['Water_Pumped_This_Month']
            avg_suct = per_destination[j]['Average_Head_Suct']
            avg_del = per_destination[j]['Average_Head_Del']
            design_flow_flag = 'null'
            run_hours_flag = 'null'
            pump_qty_flag = 'null'
            avg_suct_flag = 'null'
            avg_del_flag = 'null'
            dw_etl_time = 'null'
            # print(report[i]['per_equipment'])
            re.append([rpt_id, asset_id, pump_num, cat_id, cat_name, drive_id, drive_name, del_id, del_name, del_asset_id,
                  design_flow, run_hours, pump_qty, avg_suct, avg_del, design_flow_flag, run_hours_flag, pump_qty_flag,
                  avg_suct_flag, avg_del_flag, dw_etl_time, mh])
    return re

```

## 3.result

> 将读取report 接口数据导入到dev gaussdb 

```python
import pandas as pd
import json
# 文件转化为数组
with open('data/output.txt', 'r', encoding='utf-8') as f:
    content = f.read()
arr = json.loads(content)
# 将不规则的数组转化为标准的二维数组
re = []
for ase in arr:
    for i in ase:
        re.append(i)
# 把标准的二维数组转化成 pd.data_frame
col = ["rpt_id","asset_id","pump_num","cat_id","cat_name","drive_id","drive_name","del_id","del_name","del__asset_id","design_flow","run_hours","pump_qty","avg_suct","avg_del","design_flow_flag","run_hours_flag","pump_qty_flag","avg_suct_flag","avg_del_flag","dw_etl_time","mh"]
pdf = pd.DataFrame(re,columns=col)
# pandas 转化为spark
sdf = spark.createDataFrame(pdf)
# 将spark df 数据写出到dev书库
writeToPostgresql_dev(sdf,'coss_tmp.dwd_psr_pump_running_details_dip_arch')
```

