## python tool code

```python
# generating monthly partitions
def get_month_partitions(st, en, tb):
    data_list = pd.date_range(st, en, freq='M')
    for i in range(len(data_list)-1) :
        a = str(data_list[i])[:7].replace('-','')
        b = str(data_list[i+1])[:7].replace('-','')
        if i ==0:
            print(";alter table "+tb+"         add partition mh_100000 start(100000) end("+a+")")
        print(";alter table "+tb+"         add partition mh_"+a+" start("+a+") end("+b+")")
# get_month_partitions('1996-01', '2023-12', 'coss_ods.ods_emis_wsdems_billing_dip')
```

gaussdb 存储过程

```sql
https://doc.hcs.huawei.com/db/zh-cn/gaussdb/24.7.30.10/devg-dist/gaussdb-12-0557.html#ZH-CN_TOPIC_0000002008636548
```

gaussdb 存储过程

## ods code

### 1.coss_ods.ods_emis_wsdems_asset_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_asset_dfp
;create table if not exists coss_ods.ods_emis_wsdems_asset_dfp(
  id                                           decimal(11)
  ,name                                        varchar(120)
  ,description                                 varchar(120)
  ,loca_code                                   varchar(15)
  ,acc_no                                      varchar(120)
  ,region_id                                   decimal(11)
  ,installation_type_id                        decimal(11)
  ,fw_portion                                  decimal(20,5)
  ,sw_portion                                  decimal(20,5)
  ,rw_portion                                  decimal(20,5)
  ,tw_portion                                  decimal(20,5)
  ,remarks                                     varchar(120)
  ,active                                      decimal(5)
  ,offical_name                                varchar(120)
  ,station_code                                varchar(120)
  ,billing_active                              decimal(5)
  ,ps_active                                   decimal(5)
  ,ecw_active                                  decimal(5)
  ,region_report                               varchar(150)
  ,hkp_active                                  decimal(5)
  ,fy_active                                   decimal(5)
  ,"1035_active"                               decimal(5)
  ,waterefficiency_active                      decimal(5)
  ,installation_type_id_for_waterefficiency    decimal(11)
  ,installation_number                         varchar(30)
  ,"dw_etl_time"                               timestamp(6)
  ,"dt"                                        decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_asset_dfp                                             is 'asset of energy consumption'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."id"                                        is 'Asset id'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."name"                                      is 'Asset Name'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."description"                               is 'Description'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."location_code"                             is 'Location Code'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."account_no"                                is 'Account No'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."region_id"                                 is 'Region Id'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."installation_type_id"                      is 'Installation Type Id'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."fw_portion"                                is 'FW Portion'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."sw_portion"                                is 'SW Portion'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."rw_portion"                                is 'RW Portion'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."tw_portion"                                is 'TW Portion'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."remarks"                                   is 'Remarks'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."active"                                    is 'Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."offical_name"                              is 'Offical Name'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."station_code"                              is 'Station Code'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."billing_active"                            is 'Billing Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."ps_active"                                 is 'PS Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."ecw_active"                                is 'ECW Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."region_report"                             is 'Region report'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."hkp_active"                                is 'HKP Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."fy_active"                                 is 'FY Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."1035_active"                               is '1035 Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."waterefficiency_active"                    is 'WaterEfficiency Active'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."installation_type_id_for_waterefficiency"  is 'Installation Type Id for WaterEfficiency'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."installation_number"                       is 'Installation number'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."dw_etl_time"                               is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_asset_dfp."dt"                                        is 'Daily Partitions'


;alter table coss_ods.ods_emis_wsdems_asset_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_asset_dfp add partition dt_20250314 START(20250314) END(20250315)
```

#### 2.Asset Data Integration

```python
# asset data integration to gaussdb
sql = """
select
  id
  ,name
  ,description
  ,location_code
  ,account_no
  ,region_id
  ,installation_type_id
  ,fw_portion
  ,sw_portion
  ,rw_portion
  ,tw_portion
  ,remarks
  ,active
  ,offical_name
  ,station_code
  ,billing_active
  ,ps_active
  ,ecw_active
  ,region_report
  ,hkp_active
  ,fy_active
  ,waterefficiency_active
  ,installation_type_id_for_waterefficiency
  ,installation_number
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from asset
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("asset")
df.createOrReplaceTempView("asset")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_asset_dfp')
```

### 2.coss_ods.ods_emis_wsdems_billing_dip

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_billing_dip
;create table if not exists coss_ods.ods_emis_wsdems_billing_dip(
  id                     decimal(20)
  ,date                  timestamp(6)
  ,location_code_id      decimal(11)
  ,tariff_id             decimal(11)
  ,kwh_on_peak           decimal(10,0)
  ,kwh_off_peak          decimal(10,0)
  ,kva_on_peak           decimal(10,0)
  ,kva_off_peak          decimal(10,0)
  ,flow_volume           decimal(20,5)
  ,average_pressure      decimal(20,5)
  ,payout                decimal(10,0)
  ,billingcol            varchar(150)
  ,payout_isvalid        decimal(5)
  ,"dw_etl_time"         timestamp(6)
  ,"mh"                  decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(mh)
(partition  mh_000000 start(0) end(100000))
;comment on table  coss_ods.ods_emis_wsdems_billing_dip                            is   'bills of energy consumption'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."id"                       is  'Bills ID'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."date"                     is  'Date'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."location_code_id"         is  'Location Code Id'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."tariff_id"                is  'Tariff Id'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."kwh_on_peak"              is  'kWh On Peak'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."kwh_off_peak"             is  'kWh Off Peak'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."kva_on_peak"              is  'kVA On Peak'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."kva_off_peak"             is  'kVA Off Peak'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."flow_volume"              is  'Flow Volume'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."average_pressure"         is  'Average Pressure'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."payout"                   is  'Payout'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."billingcol"               is  'billingcol'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."payout_isvalid"           is  'Payout IsValid'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."dw_etl_time"              is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_billing_dip."mh"                       is 'Monthly Partitions'
```

#### 2.Add Partitions

```sql
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_100000 start(100000) end(199601)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199601 start(199601) end(199602)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199602 start(199602) end(199603)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199603 start(199603) end(199604)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199604 start(199604) end(199605)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199605 start(199605) end(199606)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199606 start(199606) end(199607)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199607 start(199607) end(199608)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199608 start(199608) end(199609)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199609 start(199609) end(199610)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199610 start(199610) end(199611)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199611 start(199611) end(199612)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199612 start(199612) end(199701)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199701 start(199701) end(199702)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199702 start(199702) end(199703)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199703 start(199703) end(199704)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199704 start(199704) end(199705)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199705 start(199705) end(199706)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199706 start(199706) end(199707)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199707 start(199707) end(199708)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199708 start(199708) end(199709)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199709 start(199709) end(199710)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199710 start(199710) end(199711)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199711 start(199711) end(199712)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199712 start(199712) end(199801)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199801 start(199801) end(199802)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199802 start(199802) end(199803)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199803 start(199803) end(199804)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199804 start(199804) end(199805)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199805 start(199805) end(199806)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199806 start(199806) end(199807)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199807 start(199807) end(199808)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199808 start(199808) end(199809)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199809 start(199809) end(199810)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199810 start(199810) end(199811)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199811 start(199811) end(199812)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199812 start(199812) end(199901)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199901 start(199901) end(199902)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199902 start(199902) end(199903)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199903 start(199903) end(199904)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199904 start(199904) end(199905)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199905 start(199905) end(199906)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199906 start(199906) end(199907)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199907 start(199907) end(199908)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199908 start(199908) end(199909)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199909 start(199909) end(199910)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199910 start(199910) end(199911)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199911 start(199911) end(199912)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_199912 start(199912) end(200001)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200001 start(200001) end(200002)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200002 start(200002) end(200003)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200003 start(200003) end(200004)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200004 start(200004) end(200005)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200005 start(200005) end(200006)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200006 start(200006) end(200007)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200007 start(200007) end(200008)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200008 start(200008) end(200009)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200009 start(200009) end(200010)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200010 start(200010) end(200011)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200011 start(200011) end(200012)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200012 start(200012) end(200101)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200101 start(200101) end(200102)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200102 start(200102) end(200103)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200103 start(200103) end(200104)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200104 start(200104) end(200105)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200105 start(200105) end(200106)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200106 start(200106) end(200107)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200107 start(200107) end(200108)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200108 start(200108) end(200109)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200109 start(200109) end(200110)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200110 start(200110) end(200111)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200111 start(200111) end(200112)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200112 start(200112) end(200201)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200201 start(200201) end(200202)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200202 start(200202) end(200203)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200203 start(200203) end(200204)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200204 start(200204) end(200205)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200205 start(200205) end(200206)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200206 start(200206) end(200207)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200207 start(200207) end(200208)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200208 start(200208) end(200209)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200209 start(200209) end(200210)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200210 start(200210) end(200211)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200211 start(200211) end(200212)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200212 start(200212) end(200301)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200301 start(200301) end(200302)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200302 start(200302) end(200303)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200303 start(200303) end(200304)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200304 start(200304) end(200305)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200305 start(200305) end(200306)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200306 start(200306) end(200307)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200307 start(200307) end(200308)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200308 start(200308) end(200309)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200309 start(200309) end(200310)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200310 start(200310) end(200311)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200311 start(200311) end(200312)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200312 start(200312) end(200401)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200401 start(200401) end(200402)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200402 start(200402) end(200403)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200403 start(200403) end(200404)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200404 start(200404) end(200405)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200405 start(200405) end(200406)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200406 start(200406) end(200407)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200407 start(200407) end(200408)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200408 start(200408) end(200409)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200409 start(200409) end(200410)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200410 start(200410) end(200411)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200411 start(200411) end(200412)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200412 start(200412) end(200501)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200501 start(200501) end(200502)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200502 start(200502) end(200503)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200503 start(200503) end(200504)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200504 start(200504) end(200505)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200505 start(200505) end(200506)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200506 start(200506) end(200507)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200507 start(200507) end(200508)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200508 start(200508) end(200509)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200509 start(200509) end(200510)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200510 start(200510) end(200511)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200511 start(200511) end(200512)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200512 start(200512) end(200601)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200601 start(200601) end(200602)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200602 start(200602) end(200603)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200603 start(200603) end(200604)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200604 start(200604) end(200605)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200605 start(200605) end(200606)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200606 start(200606) end(200607)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200607 start(200607) end(200608)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200608 start(200608) end(200609)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200609 start(200609) end(200610)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200610 start(200610) end(200611)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200611 start(200611) end(200612)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200612 start(200612) end(200701)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200701 start(200701) end(200702)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200702 start(200702) end(200703)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200703 start(200703) end(200704)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200704 start(200704) end(200705)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200705 start(200705) end(200706)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200706 start(200706) end(200707)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200707 start(200707) end(200708)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200708 start(200708) end(200709)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200709 start(200709) end(200710)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200710 start(200710) end(200711)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200711 start(200711) end(200712)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200712 start(200712) end(200801)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200801 start(200801) end(200802)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200802 start(200802) end(200803)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200803 start(200803) end(200804)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200804 start(200804) end(200805)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200805 start(200805) end(200806)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200806 start(200806) end(200807)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200807 start(200807) end(200808)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200808 start(200808) end(200809)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200809 start(200809) end(200810)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200810 start(200810) end(200811)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200811 start(200811) end(200812)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200812 start(200812) end(200901)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200901 start(200901) end(200902)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200902 start(200902) end(200903)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200903 start(200903) end(200904)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200904 start(200904) end(200905)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200905 start(200905) end(200906)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200906 start(200906) end(200907)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200907 start(200907) end(200908)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200908 start(200908) end(200909)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200909 start(200909) end(200910)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200910 start(200910) end(200911)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200911 start(200911) end(200912)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_200912 start(200912) end(201001)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201001 start(201001) end(201002)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201002 start(201002) end(201003)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201003 start(201003) end(201004)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201004 start(201004) end(201005)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201005 start(201005) end(201006)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201006 start(201006) end(201007)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201007 start(201007) end(201008)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201008 start(201008) end(201009)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201009 start(201009) end(201010)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201010 start(201010) end(201011)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201011 start(201011) end(201012)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201012 start(201012) end(201101)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201101 start(201101) end(201102)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201102 start(201102) end(201103)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201103 start(201103) end(201104)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201104 start(201104) end(201105)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201105 start(201105) end(201106)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201106 start(201106) end(201107)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201107 start(201107) end(201108)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201108 start(201108) end(201109)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201109 start(201109) end(201110)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201110 start(201110) end(201111)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201111 start(201111) end(201112)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201112 start(201112) end(201201)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201201 start(201201) end(201202)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201202 start(201202) end(201203)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201203 start(201203) end(201204)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201204 start(201204) end(201205)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201205 start(201205) end(201206)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201206 start(201206) end(201207)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201207 start(201207) end(201208)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201208 start(201208) end(201209)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201209 start(201209) end(201210)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201210 start(201210) end(201211)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201211 start(201211) end(201212)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201212 start(201212) end(201301)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201301 start(201301) end(201302)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201302 start(201302) end(201303)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201303 start(201303) end(201304)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201304 start(201304) end(201305)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201305 start(201305) end(201306)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201306 start(201306) end(201307)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201307 start(201307) end(201308)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201308 start(201308) end(201309)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201309 start(201309) end(201310)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201310 start(201310) end(201311)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201311 start(201311) end(201312)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201312 start(201312) end(201401)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201401 start(201401) end(201402)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201402 start(201402) end(201403)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201403 start(201403) end(201404)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201404 start(201404) end(201405)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201405 start(201405) end(201406)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201406 start(201406) end(201407)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201407 start(201407) end(201408)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201408 start(201408) end(201409)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201409 start(201409) end(201410)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201410 start(201410) end(201411)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201411 start(201411) end(201412)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201412 start(201412) end(201501)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201501 start(201501) end(201502)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201502 start(201502) end(201503)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201503 start(201503) end(201504)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201504 start(201504) end(201505)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201505 start(201505) end(201506)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201506 start(201506) end(201507)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201507 start(201507) end(201508)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201508 start(201508) end(201509)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201509 start(201509) end(201510)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201510 start(201510) end(201511)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201511 start(201511) end(201512)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201512 start(201512) end(201601)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201601 start(201601) end(201602)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201602 start(201602) end(201603)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201603 start(201603) end(201604)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201604 start(201604) end(201605)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201605 start(201605) end(201606)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201606 start(201606) end(201607)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201607 start(201607) end(201608)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201608 start(201608) end(201609)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201609 start(201609) end(201610)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201610 start(201610) end(201611)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201611 start(201611) end(201612)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201612 start(201612) end(201701)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201701 start(201701) end(201702)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201702 start(201702) end(201703)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201703 start(201703) end(201704)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201704 start(201704) end(201705)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201705 start(201705) end(201706)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201706 start(201706) end(201707)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201707 start(201707) end(201708)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201708 start(201708) end(201709)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201709 start(201709) end(201710)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201710 start(201710) end(201711)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201711 start(201711) end(201712)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201712 start(201712) end(201801)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201801 start(201801) end(201802)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201802 start(201802) end(201803)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201803 start(201803) end(201804)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201804 start(201804) end(201805)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201805 start(201805) end(201806)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201806 start(201806) end(201807)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201807 start(201807) end(201808)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201808 start(201808) end(201809)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201809 start(201809) end(201810)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201810 start(201810) end(201811)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201811 start(201811) end(201812)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201812 start(201812) end(201901)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201901 start(201901) end(201902)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201902 start(201902) end(201903)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201903 start(201903) end(201904)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201904 start(201904) end(201905)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201905 start(201905) end(201906)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201906 start(201906) end(201907)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201907 start(201907) end(201908)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201908 start(201908) end(201909)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201909 start(201909) end(201910)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201910 start(201910) end(201911)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201911 start(201911) end(201912)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_201912 start(201912) end(202001)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202001 start(202001) end(202002)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202002 start(202002) end(202003)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202003 start(202003) end(202004)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202004 start(202004) end(202005)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202005 start(202005) end(202006)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202006 start(202006) end(202007)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202007 start(202007) end(202008)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202008 start(202008) end(202009)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202009 start(202009) end(202010)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202010 start(202010) end(202011)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202011 start(202011) end(202012)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202012 start(202012) end(202101)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202101 start(202101) end(202102)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202102 start(202102) end(202103)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202103 start(202103) end(202104)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202104 start(202104) end(202105)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202105 start(202105) end(202106)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202106 start(202106) end(202107)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202107 start(202107) end(202108)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202108 start(202108) end(202109)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202109 start(202109) end(202110)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202110 start(202110) end(202111)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202111 start(202111) end(202112)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202112 start(202112) end(202201)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202201 start(202201) end(202202)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202202 start(202202) end(202203)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202203 start(202203) end(202204)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202204 start(202204) end(202205)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202205 start(202205) end(202206)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202206 start(202206) end(202207)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202207 start(202207) end(202208)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202208 start(202208) end(202209)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202209 start(202209) end(202210)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202210 start(202210) end(202211)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202211 start(202211) end(202212)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202212 start(202212) end(202301)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202301 start(202301) end(202302)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202302 start(202302) end(202303)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202303 start(202303) end(202304)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202304 start(202304) end(202305)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202305 start(202305) end(202306)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202306 start(202306) end(202307)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202307 start(202307) end(202308)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202308 start(202308) end(202309)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202309 start(202309) end(202310)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202310 start(202310) end(202311)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202311 start(202311) end(202312)
;alter table coss_ods.ods_emis_wsdems_billing_dip   add partition mh_202312 start(202312) end(202401)
            
```

#### 3.Billing Date Integration

```python
# billing data integration to gaussdb
for i in pd.date_range('1996-01-02', '2023-12-27', freq='D'):
    bill_date = str(i).split(' ')[0]
    df = read_mysql_emis_tbls("(select * from billing where date='"+bill_date+"')aa")
    df.createOrReplaceTempView("billing")
    sql = """
    select
      id
      ,date
      ,location_code_id
      ,tariff_id
      ,kwh_on_peak
      ,kwh_off_peak
      ,kva_on_peak
      ,kva_off_peak
      ,flow_volume
      ,average_pressure
      ,payout
      ,billingcol
      ,payout_isvalid
      ,current_timestamp()           as dw_etl_time
      ,date_format(date,'yyyyMM')    as mh
    from billing 
    where date ='"""+bill_date+"""'
    """
    print(bill_date,)
    spark.sql(sql).show()
    writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_billing_dip')
```

### 3.coss_ods.ods_emis_wsdems_installation_type_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_installation_type_dfp
;create table if not exists coss_ods.ods_emis_wsdems_installation_type_dfp(
  id                decimal(11)
  ,name             varchar(150)
  ,description      varchar(150)
  ,"dw_etl_time"    timestamp(6)
  ,"dt"             decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_installation_type_dfp                  is   'installation type'
;comment on column coss_ods.ods_emis_wsdems_installation_type_dfp."id"             is   'ID'
;comment on column coss_ods.ods_emis_wsdems_installation_type_dfp."name"           is   'Name'
;comment on column coss_ods.ods_emis_wsdems_installation_type_dfp."description"    is   'Description'
;comment on column coss_ods.ods_emis_wsdems_installation_type_dfp."dw_etl_time"    is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_installation_type_dfp."dt"             is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_installation_type_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_installation_type_dfp add partition dt_20250314 START(20250314) END(20250315)

```

#### 2.Installation Type Data Integration

```python
# installation type data integration to gaussdb
sql = """
select
  id
  ,name
  ,description
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from installation_type
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("installation_type")
df.createOrReplaceTempView("installation_type")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_installation_type_dfp')
```

### 4.coss_ods.ods_emis_wsdems_pump_category_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_pump_category_dfp
;create table if not exists coss_ods.ods_emis_wsdems_pump_category_dfp(
  id               decimal(11)
  ,name            varchar(150)
  ,"dw_etl_time"   timestamp(6)
  ,"dt"            decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_pump_category_dfp                  is 'pump category'
;comment on column coss_ods.ods_emis_wsdems_pump_category_dfp."id"             is 'id'
;comment on column coss_ods.ods_emis_wsdems_pump_category_dfp."name"           is 'name'
;comment on column coss_ods.ods_emis_wsdems_pump_category_dfp."dw_etl_time"    is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_pump_category_dfp."dt"             is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_pump_category_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_pump_category_dfp add partition dt_20250314 START(20250314) END(20250315)
```

2.Pump Category Data Integration

```python
# pump category data integration to gaussdb
sql = """
select
  id
  ,name
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from pump_category
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("pump_category")
df.createOrReplaceTempView("pump_category")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_pump_category_dfp')
```

### 5.coss_ods.ods_emis_wsdems_pump_delivery_to_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_pump_delivery_to_dfp
;create table if not exists coss_ods.ods_emis_wsdems_pump_delivery_to_dfp(
  id                decimal(11)
  ,name             varchar(600)
  ,asset_id         decimal(11)
  ,shortname        varchar(600)
  ,"dw_etl_time"    timestamp(6)
  ,"dt"             decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_pump_delivery_to_dfp                  is 'pump delivery to other asset'
;comment on column coss_ods.ods_emis_wsdems_pump_delivery_to_dfp."id"             is 'id'
;comment on column coss_ods.ods_emis_wsdems_pump_delivery_to_dfp."name"           is 'name'
;comment on column coss_ods.ods_emis_wsdems_pump_delivery_to_dfp."asset_id"       is 'asset id'
;comment on column coss_ods.ods_emis_wsdems_pump_delivery_to_dfp."shortname"      is 'shortname'
;comment on column coss_ods.ods_emis_wsdems_pump_delivery_to_dfp."dw_etl_time"    is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_pump_delivery_to_dfp."dt"             is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_pump_delivery_to_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_pump_delivery_to_dfp add partition dt_20250314 START(20250314) END(20250315)
```

#### 2.Pump Delivery To Data Integration

```python
# pump_delivery_to data integration to gaussdb
sql = """
select
  id
  ,name
  ,asset_id
  ,shortname
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from pump_delivery_to
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("pump_delivery_to")
df.createOrReplaceTempView("pump_delivery_to")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_pump_delivery_to_dfp')
```

### 6.coss_ods.ods_emis_wsdems_pump_drive_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_pump_drive_dfp
;create table if not exists coss_ods.ods_emis_wsdems_pump_drive_dfp(
  id                decimal(11)
  ,name             varchar(150)
  ,"dw_etl_time"    timestamp(6)
  ,"dt"             decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_pump_drive_dfp                  is 'pump drive'
;comment on column coss_ods.ods_emis_wsdems_pump_drive_dfp."id"             is 'id'
;comment on column coss_ods.ods_emis_wsdems_pump_drive_dfp."name"           is 'name'
;comment on column coss_ods.ods_emis_wsdems_pump_drive_dfp."dw_etl_time"    is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_pump_drive_dfp."dt"             is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_pump_drive_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_pump_drive_dfp add partition dt_20250314 START(20250314) END(20250315)

```

#### 2.Pump Drive Data Integration

```python 
# pump drive data integration to gaussdb
sql = """
select
  id
  ,name
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from pump_drive
""".replace('${dt}','20250314')
df = read_mysql_emis_tbls("pump_drive")
df.createOrReplaceTempView("pump_drive")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_pump_drive_dfp')
```

### 7.coss_ods.ods_emis_wsdems_region_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_region_dfp
;create table if not exists coss_ods.ods_emis_wsdems_region_dfp(
  id               decimal(11)
  ,name            varchar(150)
  ,description     varchar(800)
  ,remarks         varchar(150)
  ,"dw_etl_time"   timestamp(6)
  ,"dt"            decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_region_dfp                  is 'region'
;comment on column coss_ods.ods_emis_wsdems_region_dfp."id"             is 'id'
;comment on column coss_ods.ods_emis_wsdems_region_dfp."name"           is 'Name'
;comment on column coss_ods.ods_emis_wsdems_region_dfp."description"    is 'Description'
;comment on column coss_ods.ods_emis_wsdems_region_dfp."remarks"        is 'Remarks'
;comment on column coss_ods.ods_emis_wsdems_region_dfp."dw_etl_time"    is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_region_dfp."dt"             is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_region_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_region_dfp add partition dt_20250314 START(20250314) END(20250315)
```

#### 2.Region Data Integration

```python
# region data integration to gaussdb
sql = """
select
  id
  ,name
  ,description
  ,remarks
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from region
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("region")
df.createOrReplaceTempView("region")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_region_dfp')
```

### 8.coss_ods.ods_emis_wsdems_report_pump_dip

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_report_pump_dip
;create table if not exists coss_ods.ods_emis_wsdems_report_pump_dip(
  id                              decimal(20)
  ,report_id                      decimal(11)
  ,pump_number                    decimal(11)
  ,category_id                    decimal(11)
  ,drive_id                       decimal(11)
  ,flow_rate_design               decimal(20,5)
  ,delivery_to_id                 decimal(11)
  ,hours_run_this_month           decimal(20,5)
  ,water_pumped_this_month        decimal(20,5)
  ,average_head_suct              decimal(20,5)
  ,average_head_del               decimal(20,5)
  ,flow_rate_design_flag          decimal(11)
  ,hours_run_this_month_flag      decimal(11)
  ,water_pumped_this_month_flag   decimal(11)
  ,average_head_suct_flag         decimal(11)
  ,average_head_del_flag          decimal(11)
  ,"dw_etl_time"                  timestamp(6)
  ,"mh"                           decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(mh)
(partition  mh_000000 start(0) end(100000))
;comment on table  coss_ods.ods_emis_wsdems_report_pump_dip                                   is 'bills of energy consumption'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."id"                              is 'ID'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."report_id"                       is 'Report Id'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."pump_number"                     is 'Pump Number'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."category_id"                     is 'Category Id'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."drive_id"                        is 'Drive Id'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."flow_rate_design"                is 'Flow Rate Design'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."delivery_to_id"                  is 'Delivery To Id'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."hours_run_this_month"            is 'Hours Run This Month'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."water_pumped_this_month"         is 'Water Pumped This Month'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."average_head_suct"               is 'Average Head Suct'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."average_head_del"                is 'Average Head Del'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."flow_rate_design_flag"           is 'Flow Rate Design Flag'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."hours_run_this_month_flag"       is 'Hours Run This Month Flag'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."water_pumped_this_month_flag"    is 'Water Pumped This Month Flag'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."average_head_suct_flag"          is 'Average Head Suct Flag'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."average_head_del_flag"           is 'Average Head Del Flag'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."dw_etl_time"                     is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_report_pump_dip."mh"                              is 'Monthly Partitions'
```

#### 2.Add Partitions

```sql
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_100000 start(100000) end(200801)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200801 start(200801) end(200802)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200802 start(200802) end(200803)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200803 start(200803) end(200804)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200804 start(200804) end(200805)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200805 start(200805) end(200806)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200806 start(200806) end(200807)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200807 start(200807) end(200808)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200808 start(200808) end(200809)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200809 start(200809) end(200810)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200810 start(200810) end(200811)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200811 start(200811) end(200812)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200812 start(200812) end(200901)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200901 start(200901) end(200902)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200902 start(200902) end(200903)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200903 start(200903) end(200904)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200904 start(200904) end(200905)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200905 start(200905) end(200906)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200906 start(200906) end(200907)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200907 start(200907) end(200908)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200908 start(200908) end(200909)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200909 start(200909) end(200910)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200910 start(200910) end(200911)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200911 start(200911) end(200912)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_200912 start(200912) end(201001)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201001 start(201001) end(201002)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201002 start(201002) end(201003)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201003 start(201003) end(201004)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201004 start(201004) end(201005)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201005 start(201005) end(201006)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201006 start(201006) end(201007)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201007 start(201007) end(201008)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201008 start(201008) end(201009)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201009 start(201009) end(201010)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201010 start(201010) end(201011)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201011 start(201011) end(201012)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201012 start(201012) end(201101)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201101 start(201101) end(201102)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201102 start(201102) end(201103)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201103 start(201103) end(201104)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201104 start(201104) end(201105)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201105 start(201105) end(201106)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201106 start(201106) end(201107)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201107 start(201107) end(201108)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201108 start(201108) end(201109)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201109 start(201109) end(201110)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201110 start(201110) end(201111)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201111 start(201111) end(201112)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201112 start(201112) end(201201)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201201 start(201201) end(201202)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201202 start(201202) end(201203)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201203 start(201203) end(201204)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201204 start(201204) end(201205)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201205 start(201205) end(201206)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201206 start(201206) end(201207)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201207 start(201207) end(201208)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201208 start(201208) end(201209)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201209 start(201209) end(201210)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201210 start(201210) end(201211)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201211 start(201211) end(201212)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201212 start(201212) end(201301)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201301 start(201301) end(201302)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201302 start(201302) end(201303)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201303 start(201303) end(201304)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201304 start(201304) end(201305)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201305 start(201305) end(201306)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201306 start(201306) end(201307)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201307 start(201307) end(201308)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201308 start(201308) end(201309)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201309 start(201309) end(201310)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201310 start(201310) end(201311)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201311 start(201311) end(201312)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201312 start(201312) end(201401)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201401 start(201401) end(201402)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201402 start(201402) end(201403)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201403 start(201403) end(201404)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201404 start(201404) end(201405)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201405 start(201405) end(201406)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201406 start(201406) end(201407)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201407 start(201407) end(201408)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201408 start(201408) end(201409)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201409 start(201409) end(201410)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201410 start(201410) end(201411)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201411 start(201411) end(201412)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201412 start(201412) end(201501)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201501 start(201501) end(201502)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201502 start(201502) end(201503)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201503 start(201503) end(201504)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201504 start(201504) end(201505)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201505 start(201505) end(201506)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201506 start(201506) end(201507)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201507 start(201507) end(201508)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201508 start(201508) end(201509)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201509 start(201509) end(201510)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201510 start(201510) end(201511)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201511 start(201511) end(201512)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201512 start(201512) end(201601)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201601 start(201601) end(201602)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201602 start(201602) end(201603)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201603 start(201603) end(201604)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201604 start(201604) end(201605)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201605 start(201605) end(201606)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201606 start(201606) end(201607)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201607 start(201607) end(201608)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201608 start(201608) end(201609)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201609 start(201609) end(201610)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201610 start(201610) end(201611)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201611 start(201611) end(201612)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201612 start(201612) end(201701)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201701 start(201701) end(201702)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201702 start(201702) end(201703)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201703 start(201703) end(201704)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201704 start(201704) end(201705)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201705 start(201705) end(201706)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201706 start(201706) end(201707)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201707 start(201707) end(201708)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201708 start(201708) end(201709)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201709 start(201709) end(201710)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201710 start(201710) end(201711)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201711 start(201711) end(201712)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201712 start(201712) end(201801)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201801 start(201801) end(201802)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201802 start(201802) end(201803)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201803 start(201803) end(201804)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201804 start(201804) end(201805)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201805 start(201805) end(201806)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201806 start(201806) end(201807)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201807 start(201807) end(201808)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201808 start(201808) end(201809)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201809 start(201809) end(201810)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201810 start(201810) end(201811)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201811 start(201811) end(201812)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201812 start(201812) end(201901)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201901 start(201901) end(201902)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201902 start(201902) end(201903)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201903 start(201903) end(201904)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201904 start(201904) end(201905)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201905 start(201905) end(201906)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201906 start(201906) end(201907)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201907 start(201907) end(201908)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201908 start(201908) end(201909)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201909 start(201909) end(201910)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201910 start(201910) end(201911)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201911 start(201911) end(201912)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_201912 start(201912) end(202001)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202001 start(202001) end(202002)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202002 start(202002) end(202003)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202003 start(202003) end(202004)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202004 start(202004) end(202005)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202005 start(202005) end(202006)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202006 start(202006) end(202007)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202007 start(202007) end(202008)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202008 start(202008) end(202009)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202009 start(202009) end(202010)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202010 start(202010) end(202011)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202011 start(202011) end(202012)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202012 start(202012) end(202101)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202101 start(202101) end(202102)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202102 start(202102) end(202103)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202103 start(202103) end(202104)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202104 start(202104) end(202105)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202105 start(202105) end(202106)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202106 start(202106) end(202107)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202107 start(202107) end(202108)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202108 start(202108) end(202109)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202109 start(202109) end(202110)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202110 start(202110) end(202111)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202111 start(202111) end(202112)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202112 start(202112) end(202201)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202201 start(202201) end(202202)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202202 start(202202) end(202203)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202203 start(202203) end(202204)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202204 start(202204) end(202205)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202205 start(202205) end(202206)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202206 start(202206) end(202207)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202207 start(202207) end(202208)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202208 start(202208) end(202209)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202209 start(202209) end(202210)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202210 start(202210) end(202211)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202211 start(202211) end(202212)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202212 start(202212) end(202301)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202301 start(202301) end(202302)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202302 start(202302) end(202303)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202303 start(202303) end(202304)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202304 start(202304) end(202305)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202305 start(202305) end(202306)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202306 start(202306) end(202307)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202307 start(202307) end(202308)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202308 start(202308) end(202309)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202309 start(202309) end(202310)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202310 start(202310) end(202311)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202311 start(202311) end(202312)
;alter table ods_emis_wsdems_report_pump_dip         add partition mh_202312 start(202312) end(202401)
```

#### 3.Report Pump Data Integration

```python
# report pump data integration to gaussdb
for i in pd.date_range('2023-12-01', '2024-01-02', freq='M'):
    bill_date = str(i).split(' ')[0][:7].replace('-','')
    df = read_mysql_emis_tbls("(select * from report_pump where report_id % 1000000 = "+bill_date+")aa")
    df.createOrReplaceTempView("report_pump")
    sql = """
    select
      id
      ,report_id
      ,pump_number
      ,category_id
      ,drive_id
      ,flow_rate_design
      ,delivery_to_id
      ,hours_run_this_month
      ,water_pumped_this_month
      ,average_head_suct
      ,average_head_del
      ,flow_rate_design_flag
      ,hours_run_this_month_flag
      ,water_pumped_this_month_flag
      ,average_head_suct_flag
      ,average_head_del_flag
      ,current_timestamp()     as dw_etl_time
      ,report_id % 1000000     as mh
    from report_pump 
    """
    print(bill_date)
    writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_report_pump_dip')
```

### 9.coss_ods.ods_emis_wsdems_tariff_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_tariff_dfp
;create table if not exists coss_ods.ods_emis_wsdems_tariff_dfp(
  id                   decimal(11)
  ,name                varchar(150)
  ,description         varchar(300)
  ,utility_id          decimal(11)
  ,market_id           decimal(11)
  ,min_kw              decimal(20,5)
  ,max_kw              decimal(20,5)
  ,min_kwh             decimal(20,5)
  ,max_kwh             decimal(20,5)
  ,logic               varchar(30)
  ,service_volt        varchar(60)
  ,min_volt            decimal(20,5)
  ,max_volt            decimal(20,5)
  ,tou                 decimal(5)
  ,status              decimal(11)
  ,last_update         timestamp(6)
  ,date_effective      timestamp(6)
  ,date_expired        timestamp(6)
  ,doc_date_effective  timestamp(6)
  ,doc_date_expired    timestamp(6)
  ,remarks             varchar(800)
  ,publish_note        varchar(800)
  ,create_user         varchar(150)
  ,create_date         timestamp(6)
  ,update_user         varchar(150)
  ,update_date         timestamp(6)
  ,suspend             decimal(11)
  ,"dw_etl_time"       timestamp(6)
  ,"dt"                decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_tariff_dfp                      is 'tariff'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."id"                 is 'id'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."name"               is 'Name'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."description"        is 'Description'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."utility_id"         is 'Utility Id'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."market_id"          is 'Market Id'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."min_kw"             is 'Min kW'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."max_kw"             is 'Max kW'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."min_kwh"            is 'Min kWh'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."max_kwh"            is 'Max kWh'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."logic"              is 'Logic'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."service_volt"       is 'Service Volt'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."min_volt"           is 'Min Volt'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."max_volt"           is 'Max Volt'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."tou"                is 'TOU'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."status"             is 'Status'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."last_update"        is 'Last Update'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."date_effective"     is 'Date Effective'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."date_expired"       is 'Date Expired'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."doc_date_effective" is 'Doc Date Effective'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."doc_date_expired"   is 'Doc Date Expired'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."remarks"            is 'Remarks'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."publish_note"       is 'Publish Note'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."create_user"        is 'Create User'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."create_date"        is 'Create Date'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."update_user"        is 'Update User'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."update_date"        is 'Update Date'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."suspend"            is 'Suspend'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."dw_etl_time"        is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_tariff_dfp."dt"                 is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_tariff_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_tariff_dfp add partition dt_20250314 START(20250314) END(20250315)

```

#### 2.Tariff Data Integration

```python
# tariff data integration to gaussdb
sql = """
select
  id
  ,name
  ,description
  ,utility_id
  ,market_id
  ,min_kw
  ,max_kw
  ,min_kwh
  ,max_kwh
  ,logic
  ,service_volt
  ,min_volt
  ,max_volt
  ,tou
  ,status
  ,last_update
  ,date_effective
  ,date_expired
  ,doc_date_effective
  ,doc_date_expired
  ,remarks
  ,publish_note
  ,create_user
  ,create_date
  ,update_user
  ,update_date
  ,suspend
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from tariff
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("tariff")
df.createOrReplaceTempView("tariff")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_tariff_dfp')
```

### 10.coss_ods.ods_emis_wsdems_utility_dfp

#### 1.Create Table Sql

```sql
;drop table if exists coss_ods.ods_emis_wsdems_utility_dfp
;create table if not exists coss_ods.ods_emis_wsdems_utility_dfp(
  id                     decimal(11)
  ,name                  varchar(150)
  ,description           varchar(800)
  ,date_effective        timestamp(6)
  ,date_expired          timestamp(6)
  ,last_update           timestamp(6)
  ,ownership             varchar(90)
  ,website               varchar(300)
  ,create_user           varchar(150)
  ,create_date           timestamp(6)
  ,update_user           varchar(150)
  ,update_date           timestamp(6)
  ,"dw_etl_time"    timestamp(6)
  ,"dt"             decimal(10)
)
with (orientation = column, compression = high)
distribute by hash("id")
partition by range(dt)
(partition  dt_00000000 start(0) end(10000000))
;comment on table  coss_ods.ods_emis_wsdems_utility_dfp                  is 'utility'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."id"             is 'id'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."name"           is 'Name'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."description"    is 'Description'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."date_effective" is 'Date Effective'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."date_expired"   is 'Date Expired'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."last_update"    is 'Last Update'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."ownership"      is 'Ownership'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."website"        is 'WebSite'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."create_user"    is 'Create User'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."create_date"    is 'Create Date'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."update_user"    is 'Update User'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."update_date"    is 'Update Date'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."dw_etl_time"    is 'Data Warehouse ETL Time'
;comment on column coss_ods.ods_emis_wsdems_utility_dfp."dt"             is 'Daily Partitions'
;alter table coss_ods.ods_emis_wsdems_utility_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_ods.ods_emis_wsdems_utility_dfp add partition dt_20250314 START(20250314) END(20250315)
```

#### 2.Utility Data Integration

```python 
# utility data integration to gaussdb
sql = """
select
  id
  ,name
  ,description
  ,date_effective
  ,date_expired
  ,last_update
  ,ownership
  ,website
  ,create_user
  ,create_date
  ,update_user
  ,update_date
  ,current_timestamp()     as dw_etl_time
  ,${dt}                   as dt
from utility
""".replace('${dt}','20250314')

df = read_mysql_emis_tbls("utility")
df.createOrReplaceTempView("utility")
writeToPostgresql(spark.sql(sql), 'coss_ods.ods_emis_wsdems_utility_dfp')
```

## dwd code

### 1.coss_dwd.dim_ass_energy_cons_installation_dfp

#### 1.Create Table

```sql
create table if not exists coss_dwd.dim_ass_energy_cons_installation_dfp(
  asset_id                    decimal(11)         -- asset id
  ,asset_name                 varchar(120)        -- asset name
  ,asset_desc                 varchar(120)        -- asset description
  ,loca_code              varchar(15)         -- location code
  ,acc_no                 varchar(120)        -- account no
  ,region_id                  decimal(11)         -- region id
  ,region_code                varchar(150)        -- region code
  ,region_desc                varchar(800)        -- region description
  ,i_type_id                  decimal(11)         -- installation type id
  ,i_type_code                varchar(150)        -- installation type code
  ,i_type_desc                varchar(150)        -- installation type  description
  ,fw_portion                 decimal(20,5)       -- fresh portion
  ,sw_portion                 decimal(20,5)       -- salt water portion
  ,rw_portion                 decimal(20,5)       -- raw water portion
  ,tw_portion                 decimal(20,5)       -- treatment works portion
  ,remarks                    varchar(120)        -- remarks
  ,is_active                  decimal(5)          -- is active
  ,official_name              varchar(120)        -- official name
  ,station_code               varchar(120)        -- station code
  ,is_billing                 decimal(5)          -- billing is active
  ,is_ps                      decimal(5)          -- pump station is active
  ,is_ecw                     decimal(5)          -- ecw is active
  ,region_rpt                 varchar(150)        -- region report
  ,is_hkp                     decimal(5)          -- hkp is active
  ,is_fy                      decimal(5)          -- fy is active
  ,is_water_eff               decimal(5)          -- waterefficiency is active
  ,water_eff_type_id          decimal(11)         -- installation type id for waterefficiency
  ,i_num                      varchar(30)         -- installation number
  ,dw_etl_time                timestamp(6)        -- data warehouse etl time
  ,dt                         decimal(10)         -- daily partitions
)

with (orientation = column, compression = middle)
distribute by hash("asset_id")
partition by range(dt)
(partition dt_00000000 start(0) end(10000000))

;comment on table  coss_dwd.dim_ass_energy_cons_installation_dfp                   is  'energy consumption installations'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.asset_id          is 'asset id'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.asset_name        is 'asset name'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.asset_desc        is 'asset description'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.location_code     is 'location code'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.account_no        is 'account no'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.region_id         is 'region id'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.region_code       is 'region code'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.region_desc       is 'region description'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.i_type_id         is 'installation type id'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.i_type_code       is 'installation type code'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.i_type_desc       is 'installation type  description'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.fw_portion        is 'fresh portion'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.sw_portion        is 'salt water portion'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.rw_portion        is 'raw water portion'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.tw_portion        is 'treatment works portion'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.remarks           is 'remarks'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_active         is 'is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.official_name     is 'official name'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.station_code      is 'station code'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_billing        is 'billing is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_ps             is 'pump station is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_ecw            is 'ecw is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.region_rpt        is 'region report'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_hkp            is 'hkp is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_fy             is 'fy is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.is_water_eff      is 'water efficiency is active'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.water_eff_type_id is 'installation type id for water efficiency'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.i_num             is 'installation number'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.dw_etl_time       is 'data warehouse etl time'
;comment on column coss_dwd.dim_ass_energy_cons_installation_dfp.dt                is 'daily partitions'
```

#### 2.Add Partition

```sql
;alter table coss_dwd.dim_ass_energy_cons_installation_dfp add partition dt_10000000 START(10000000) END(20250314)
;alter table coss_dwd.dim_ass_energy_cons_installation_dfp add partition dt_20250314 START(20250314) END(20250315)
```

#### 3.Load Data

```sql
insert into coss_dwd.dim_ass_energy_cons_installation_dfp
select
  t.id                                           as asset_id             -- asset id
  ,t.name                                        as asset_name           -- asset name
  ,t.description                                 as asset_desc           -- asset description
  ,t.location_code                               as location_code        -- location code
  ,t.account_no                                  as account_no           -- account no
  ,t.region_id                                   as region_id            -- region id
  ,t1.name                                       as region_code          -- region code
  ,t1.description                                as region_desc          -- region description
  ,t.installation_type_id                        as i_type_id            -- installation type id
  ,t2.name                                       as i_type_code          -- installation type code
  ,t2.description                                as i_type_desc          -- installation type  description
  ,t.fw_portion                                  as fw_portion           -- fresh portion
  ,t.sw_portion                                  as sw_portion           -- salt water portion
  ,t.rw_portion                                  as rw_portion           -- raw water portion
  ,t.tw_portion                                  as tw_portion           -- treatment works portion
  ,ifnull(t.remarks, 'undefined')                as remarks              -- remarks
  ,t.active                                      as is_active            -- is active
  ,ifnull(t.offical_name, 'undefined')           as official_name        -- official name
  ,ifnull(t.station_code, 'undefined')           as station_code         -- station code
  ,t.billing_active                              as is_billing           -- billing is active
  ,t.ps_active                                   as is_ps                -- pump station is active
  ,t.ecw_active                                  as is_ecw               -- ecw is active
  ,t.region_report                               as region_rpt           -- region report
  ,t.hkp_active                                  as is_hkp               -- hkp is active
  ,t.fy_active                                   as is_fy                -- fy is active
  ,t.waterefficiency_active                      as is_water_eff         -- waterefficiency is active
  ,t.installation_type_id_for_waterefficiency    as water_eff_type_id    -- installation type id for waterefficiency
  ,ifnull(t.installation_number, 'undefined')    as i_num                -- installation number
  ,localtimestamp                                as dw_etl_time          -- data warehouse etl time
  ,${dt}                                         as dt                   -- daily partitions
from coss_ods.ods_emis_wsdems_asset_dfp t
left join coss_ods.ods_emis_wsdems_region_dfp t1 on t.region_id = t1.id
left join coss_ods.ods_emis_wsdems_installation_type_dfp    t2 on t.installation_type_id = t2.id
where ps_active =1
```

### 2.coss_dwd.dwd_psr_billing_details_dip

#### 1.Create Table

```sql

create table if not exists coss_dwd.dwd_psr_billing_details_dip(
  bill_id            decimal(20)      -- bill_id
  ,bill_date         timestamp(6)     -- bill date
  ,asset_id          decimal(11)      -- asset id
  ,tariff_id         decimal(11)      -- tariff id
  ,tariff_name       varchar(150)     -- tariff name
  ,tariff_desc       varchar(300)     -- tariff description
  ,utility_id        decimal(11)      -- utility id
  ,utility_name      varchar(150)     -- utility name
  ,utility_desc      varchar(800)     -- utility description
  ,kwh_on_peak       decimal(10,0)    -- power consumption of on peak (kwh)
  ,kwh_off_peak      decimal(10,0)    -- power consumption of off peak (kwh)
  ,kva_on_peak       decimal(10,0)    -- capacity of on peak (kva)
  ,kva_off_peak      decimal(10,0)    -- capacity of off peak (kva)
  ,flow_volume       decimal(20,5)    -- flow volume
  ,avg_pressure      decimal(20,5)    -- average pressure
  ,payout            decimal(10,0)    -- pay out
  ,dw_etl_time       timestamp(6)     -- dw etl time
  ,mh                decimal(10)      -- partitions for billing month
)
with (orientation = column, compression = middle)
distribute by hash("bill_id")
partition by range(mh)
(partition  dt_000000 start(0) end(100000))
;comment on table  coss_dwd.dwd_psr_billing_details_dip                    is 'pump station billing details'
;comment on column coss_dwd.dwd_psr_billing_details_dip.bill_id            is 'bill_id'
;comment on column coss_dwd.dwd_psr_billing_details_dip.bill_date          is 'bill date'
;comment on column coss_dwd.dwd_psr_billing_details_dip.asset_id           is 'asset id'
;comment on column coss_dwd.dwd_psr_billing_details_dip.tariff_id          is 'tariff id'
;comment on column coss_dwd.dwd_psr_billing_details_dip.tariff_name        is 'tariff name'
;comment on column coss_dwd.dwd_psr_billing_details_dip.tariff_desc        is 'tariff description'
;comment on column coss_dwd.dwd_psr_billing_details_dip.utility_id         is 'utility id'
;comment on column coss_dwd.dwd_psr_billing_details_dip.utility_name       is 'utility name'
;comment on column coss_dwd.dwd_psr_billing_details_dip.utility_desc       is 'utility description'
;comment on column coss_dwd.dwd_psr_billing_details_dip.kwh_on_peak        is 'power consumption of on peak (kwh)'
;comment on column coss_dwd.dwd_psr_billing_details_dip.kwh_off_peak       is 'power consumption of off peak (kwh)'
;comment on column coss_dwd.dwd_psr_billing_details_dip.kva_on_peak        is 'capacity of on peak (kva)'
;comment on column coss_dwd.dwd_psr_billing_details_dip.kva_off_peak       is 'capacity of off peak (kva)'
;comment on column coss_dwd.dwd_psr_billing_details_dip.flow_volume        is 'flow volume'
;comment on column coss_dwd.dwd_psr_billing_details_dip.avg_pressure       is 'average pressure'
;comment on column coss_dwd.dwd_psr_billing_details_dip.payout             is 'pay out'
;comment on column coss_dwd.dwd_psr_billing_details_dip.dw_etl_time        is 'dw etl time'
;comment on column coss_dwd.dwd_psr_billing_details_dip.mh                 is 'partitions for billing month'
```

#### 2.Add Partitions

```                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             [
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_100000 start(100000) end(199601)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199601 start(199601) end(199602)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199602 start(199602) end(199603)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199603 start(199603) end(199604)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199604 start(199604) end(199605)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199605 start(199605) end(199606)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199606 start(199606) end(199607)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199607 start(199607) end(199608)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199608 start(199608) end(199609)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199609 start(199609) end(199610)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199610 start(199610) end(199611)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199611 start(199611) end(199612)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199612 start(199612) end(199701)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199701 start(199701) end(199702)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199702 start(199702) end(199703)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199703 start(199703) end(199704)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199704 start(199704) end(199705)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199705 start(199705) end(199706)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199706 start(199706) end(199707)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199707 start(199707) end(199708)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199708 start(199708) end(199709)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199709 start(199709) end(199710)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199710 start(199710) end(199711)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199711 start(199711) end(199712)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199712 start(199712) end(199801)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199801 start(199801) end(199802)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199802 start(199802) end(199803)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199803 start(199803) end(199804)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199804 start(199804) end(199805)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199805 start(199805) end(199806)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199806 start(199806) end(199807)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199807 start(199807) end(199808)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199808 start(199808) end(199809)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199809 start(199809) end(199810)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199810 start(199810) end(199811)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199811 start(199811) end(199812)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199812 start(199812) end(199901)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199901 start(199901) end(199902)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199902 start(199902) end(199903)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199903 start(199903) end(199904)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199904 start(199904) end(199905)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199905 start(199905) end(199906)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199906 start(199906) end(199907)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199907 start(199907) end(199908)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199908 start(199908) end(199909)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199909 start(199909) end(199910)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199910 start(199910) end(199911)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199911 start(199911) end(199912)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_199912 start(199912) end(200001)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200001 start(200001) end(200002)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200002 start(200002) end(200003)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200003 start(200003) end(200004)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200004 start(200004) end(200005)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200005 start(200005) end(200006)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200006 start(200006) end(200007)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200007 start(200007) end(200008)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200008 start(200008) end(200009)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200009 start(200009) end(200010)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200010 start(200010) end(200011)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200011 start(200011) end(200012)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200012 start(200012) end(200101)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200101 start(200101) end(200102)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200102 start(200102) end(200103)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200103 start(200103) end(200104)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200104 start(200104) end(200105)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200105 start(200105) end(200106)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200106 start(200106) end(200107)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200107 start(200107) end(200108)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200108 start(200108) end(200109)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200109 start(200109) end(200110)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200110 start(200110) end(200111)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200111 start(200111) end(200112)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200112 start(200112) end(200201)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200201 start(200201) end(200202)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200202 start(200202) end(200203)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200203 start(200203) end(200204)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200204 start(200204) end(200205)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200205 start(200205) end(200206)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200206 start(200206) end(200207)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200207 start(200207) end(200208)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200208 start(200208) end(200209)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200209 start(200209) end(200210)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200210 start(200210) end(200211)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200211 start(200211) end(200212)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200212 start(200212) end(200301)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200301 start(200301) end(200302)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200302 start(200302) end(200303)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200303 start(200303) end(200304)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200304 start(200304) end(200305)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200305 start(200305) end(200306)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200306 start(200306) end(200307)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200307 start(200307) end(200308)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200308 start(200308) end(200309)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200309 start(200309) end(200310)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200310 start(200310) end(200311)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200311 start(200311) end(200312)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200312 start(200312) end(200401)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200401 start(200401) end(200402)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200402 start(200402) end(200403)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200403 start(200403) end(200404)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200404 start(200404) end(200405)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200405 start(200405) end(200406)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200406 start(200406) end(200407)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200407 start(200407) end(200408)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200408 start(200408) end(200409)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200409 start(200409) end(200410)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200410 start(200410) end(200411)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200411 start(200411) end(200412)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200412 start(200412) end(200501)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200501 start(200501) end(200502)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200502 start(200502) end(200503)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200503 start(200503) end(200504)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200504 start(200504) end(200505)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200505 start(200505) end(200506)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200506 start(200506) end(200507)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200507 start(200507) end(200508)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200508 start(200508) end(200509)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200509 start(200509) end(200510)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200510 start(200510) end(200511)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200511 start(200511) end(200512)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200512 start(200512) end(200601)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200601 start(200601) end(200602)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200602 start(200602) end(200603)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200603 start(200603) end(200604)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200604 start(200604) end(200605)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200605 start(200605) end(200606)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200606 start(200606) end(200607)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200607 start(200607) end(200608)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200608 start(200608) end(200609)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200609 start(200609) end(200610)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200610 start(200610) end(200611)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200611 start(200611) end(200612)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200612 start(200612) end(200701)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200701 start(200701) end(200702)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200702 start(200702) end(200703)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200703 start(200703) end(200704)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200704 start(200704) end(200705)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200705 start(200705) end(200706)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200706 start(200706) end(200707)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200707 start(200707) end(200708)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200708 start(200708) end(200709)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200709 start(200709) end(200710)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200710 start(200710) end(200711)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200711 start(200711) end(200712)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200712 start(200712) end(200801)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200801 start(200801) end(200802)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200802 start(200802) end(200803)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200803 start(200803) end(200804)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200804 start(200804) end(200805)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200805 start(200805) end(200806)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200806 start(200806) end(200807)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200807 start(200807) end(200808)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200808 start(200808) end(200809)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200809 start(200809) end(200810)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200810 start(200810) end(200811)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200811 start(200811) end(200812)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200812 start(200812) end(200901)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200901 start(200901) end(200902)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200902 start(200902) end(200903)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200903 start(200903) end(200904)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200904 start(200904) end(200905)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200905 start(200905) end(200906)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200906 start(200906) end(200907)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200907 start(200907) end(200908)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200908 start(200908) end(200909)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200909 start(200909) end(200910)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200910 start(200910) end(200911)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200911 start(200911) end(200912)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_200912 start(200912) end(201001)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201001 start(201001) end(201002)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201002 start(201002) end(201003)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201003 start(201003) end(201004)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201004 start(201004) end(201005)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201005 start(201005) end(201006)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201006 start(201006) end(201007)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201007 start(201007) end(201008)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201008 start(201008) end(201009)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201009 start(201009) end(201010)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201010 start(201010) end(201011)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201011 start(201011) end(201012)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201012 start(201012) end(201101)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201101 start(201101) end(201102)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201102 start(201102) end(201103)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201103 start(201103) end(201104)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201104 start(201104) end(201105)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201105 start(201105) end(201106)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201106 start(201106) end(201107)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201107 start(201107) end(201108)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201108 start(201108) end(201109)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201109 start(201109) end(201110)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201110 start(201110) end(201111)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201111 start(201111) end(201112)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201112 start(201112) end(201201)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201201 start(201201) end(201202)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201202 start(201202) end(201203)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201203 start(201203) end(201204)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201204 start(201204) end(201205)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201205 start(201205) end(201206)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201206 start(201206) end(201207)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201207 start(201207) end(201208)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201208 start(201208) end(201209)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201209 start(201209) end(201210)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201210 start(201210) end(201211)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201211 start(201211) end(201212)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201212 start(201212) end(201301)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201301 start(201301) end(201302)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201302 start(201302) end(201303)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201303 start(201303) end(201304)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201304 start(201304) end(201305)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201305 start(201305) end(201306)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201306 start(201306) end(201307)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201307 start(201307) end(201308)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201308 start(201308) end(201309)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201309 start(201309) end(201310)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201310 start(201310) end(201311)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201311 start(201311) end(201312)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201312 start(201312) end(201401)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201401 start(201401) end(201402)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201402 start(201402) end(201403)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201403 start(201403) end(201404)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201404 start(201404) end(201405)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201405 start(201405) end(201406)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201406 start(201406) end(201407)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201407 start(201407) end(201408)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201408 start(201408) end(201409)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201409 start(201409) end(201410)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201410 start(201410) end(201411)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201411 start(201411) end(201412)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201412 start(201412) end(201501)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201501 start(201501) end(201502)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201502 start(201502) end(201503)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201503 start(201503) end(201504)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201504 start(201504) end(201505)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201505 start(201505) end(201506)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201506 start(201506) end(201507)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201507 start(201507) end(201508)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201508 start(201508) end(201509)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201509 start(201509) end(201510)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201510 start(201510) end(201511)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201511 start(201511) end(201512)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201512 start(201512) end(201601)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201601 start(201601) end(201602)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201602 start(201602) end(201603)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201603 start(201603) end(201604)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201604 start(201604) end(201605)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201605 start(201605) end(201606)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201606 start(201606) end(201607)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201607 start(201607) end(201608)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201608 start(201608) end(201609)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201609 start(201609) end(201610)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201610 start(201610) end(201611)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201611 start(201611) end(201612)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201612 start(201612) end(201701)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201701 start(201701) end(201702)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201702 start(201702) end(201703)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201703 start(201703) end(201704)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201704 start(201704) end(201705)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201705 start(201705) end(201706)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201706 start(201706) end(201707)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201707 start(201707) end(201708)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201708 start(201708) end(201709)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201709 start(201709) end(201710)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201710 start(201710) end(201711)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201711 start(201711) end(201712)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201712 start(201712) end(201801)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201801 start(201801) end(201802)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201802 start(201802) end(201803)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201803 start(201803) end(201804)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201804 start(201804) end(201805)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201805 start(201805) end(201806)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201806 start(201806) end(201807)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201807 start(201807) end(201808)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201808 start(201808) end(201809)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201809 start(201809) end(201810)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201810 start(201810) end(201811)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201811 start(201811) end(201812)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201812 start(201812) end(201901)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201901 start(201901) end(201902)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201902 start(201902) end(201903)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201903 start(201903) end(201904)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201904 start(201904) end(201905)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201905 start(201905) end(201906)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201906 start(201906) end(201907)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201907 start(201907) end(201908)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201908 start(201908) end(201909)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201909 start(201909) end(201910)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201910 start(201910) end(201911)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201911 start(201911) end(201912)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_201912 start(201912) end(202001)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202001 start(202001) end(202002)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202002 start(202002) end(202003)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202003 start(202003) end(202004)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202004 start(202004) end(202005)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202005 start(202005) end(202006)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202006 start(202006) end(202007)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202007 start(202007) end(202008)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202008 start(202008) end(202009)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202009 start(202009) end(202010)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202010 start(202010) end(202011)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202011 start(202011) end(202012)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202012 start(202012) end(202101)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202101 start(202101) end(202102)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202102 start(202102) end(202103)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202103 start(202103) end(202104)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202104 start(202104) end(202105)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202105 start(202105) end(202106)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202106 start(202106) end(202107)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202107 start(202107) end(202108)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202108 start(202108) end(202109)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202109 start(202109) end(202110)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202110 start(202110) end(202111)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202111 start(202111) end(202112)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202112 start(202112) end(202201)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202201 start(202201) end(202202)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202202 start(202202) end(202203)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202203 start(202203) end(202204)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202204 start(202204) end(202205)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202205 start(202205) end(202206)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202206 start(202206) end(202207)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202207 start(202207) end(202208)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202208 start(202208) end(202209)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202209 start(202209) end(202210)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202210 start(202210) end(202211)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202211 start(202211) end(202212)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202212 start(202212) end(202301)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202301 start(202301) end(202302)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202302 start(202302) end(202303)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202303 start(202303) end(202304)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202304 start(202304) end(202305)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202305 start(202305) end(202306)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202306 start(202306) end(202307)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202307 start(202307) end(202308)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202308 start(202308) end(202309)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202309 start(202309) end(202310)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202310 start(202310) end(202311)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202311 start(202311) end(202312)
;alter table coss_dwd.dwd_psr_billing_details_dip         add partition mh_202312 start(202312) end(202401)
            
```

#### 3.Load Data

```sql
insert into coss_dwd.dwd_psr_billing_details_dip
select
  t.id                          as bill_id         -- bill_id
  ,t.date                       as bill_date       -- bill date
  ,t.location_code_id           as asset_id        -- asset id
  ,t.tariff_id                  as tariff_id       -- tariff id
  ,t1.name                      as tariff_name     -- tariff name
  ,t1.description               as tariff_desc     -- tariff description
  ,t1.utility_id                as utility_id      -- utility id
  ,t2.name                      as utility_name    -- utility name
  ,t2.description               as utility_desc    -- utility description
  ,t.kwh_on_peak                as kwh_on_peak     -- power consumption of on peak (kwh)
  ,t.kwh_off_peak               as kwh_off_peak    -- power consumption of off peak (kwh)
  ,t.kva_on_peak                as kva_on_peak     -- capacity of on peak (kva)
  ,t.kva_off_peak               as kva_off_peak    -- capacity of off peak (kva)
  ,t.flow_volume                as flow_volume     -- flow volume
  ,t.average_pressure           as avg_pressure    -- average pressure
  ,t.payout                     as payout          -- pay out
  ,localtimestamp               as dw_etl_time     -- dw etl time
  ,to_char(t.date,'yyyymm')     as mh              -- partitions for billing month
from coss_ods.ods_emis_wsdems_billing_dip t
left join coss_ods.ods_emis_wsdems_tariff_dfp t1 on t.tariff_id = t1.id
left join coss_ods.ods_emis_wsdems_utility_dfp t2 on t1.utility_id = t2.id
```

### 3.coss_dwd.dwd_psr_pump_running_details_dip

#### 1.Create Table

```sql
create table if not exists coss_dwd.dwd_psr_pump_running_details_dip(
  rpt_id              decimal(20)       -- report pump id
  ,asset_id           decimal(11)       -- assert id
  ,pump_num           decimal(11)       -- pump number
  ,cat_id             decimal(11)       -- category id
  ,cat_name           varchar(150)      -- category name
  ,drive_id           decimal(11)       -- drive id
  ,drive_name         varchar(150)      -- drive name
  ,del_id             decimal(11)       -- delivery to id
  ,del_name           varchar(600)      -- delivery to name
  ,del__asset_id      decimal(11)       -- delivery to asset id
  ,design_flow        decimal(20,5)     -- flow rate design
  ,run_hours          decimal(20,5)     -- hours run this month
  ,pump_qty           decimal(20,5)     -- water pumped this month
  ,avg_suct           decimal(20,5)     -- average head suction
  ,avg_del            decimal(20,5)     -- average head delivery
  ,design_flow_flag   decimal(11)       -- flow rate design flag
  ,run_hours_flag     decimal(11)       -- hours run this month flag
  ,pump_qty_flag      decimal(11)       -- water pumped this month flag
  ,avg_suct_flag      decimal(11)       -- average head suction flag
  ,avg_del_flag       decimal(11)       -- average head delivery flag
  ,dw_etl_time        timestamp(6)      -- dw etl time
  ,mh                 decimal(10)       -- partitions for report month
)
with (orientation = column, compression = middle)
distribute by hash("rpt_id")
partition by range(mh)
(partition  dt_000000 start(0) end(100000))
;comment on table  coss_dwd.dwd_psr_pump_running_details_dip                    is 'pump station billing details'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.rpt_id             is 'report pump id'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.asset_id           is 'assert id'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.pump_num           is 'pump number'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.cat_id             is 'category id'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.cat_name           is 'category name'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.drive_id           is 'drive id'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.drive_name         is 'drive name'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.del_id             is 'delivery to id'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.del_name           is 'delivery to name'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.del__asset_id      is 'delivery to asset id'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.design_flow        is 'flow rate design'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.run_hours          is 'hours run this month'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.pump_qty           is 'water pumped this month'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.avg_suct           is 'average head suction'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.avg_del            is 'average head delivery'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.design_flow_flag   is 'flow rate design flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.run_hours_flag     is 'hours run this month flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.pump_qty_flag      is 'water pumped this month flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.avg_suct_flag      is 'average head suction flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.avg_del_flag       is 'average head delivery flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.dw_etl_time        is 'dw etl time'
;comment on column coss_dwd.dwd_psr_pump_running_details_dip.mh                 is 'partitions for report month'
```

#### 2.Add Partitions

```sql
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_100000 start(100000) end(200801)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200801 start(200801) end(200802)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200802 start(200802) end(200803)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200803 start(200803) end(200804)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200804 start(200804) end(200805)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200805 start(200805) end(200806)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200806 start(200806) end(200807)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200807 start(200807) end(200808)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200808 start(200808) end(200809)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200809 start(200809) end(200810)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200810 start(200810) end(200811)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200811 start(200811) end(200812)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200812 start(200812) end(200901)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200901 start(200901) end(200902)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200902 start(200902) end(200903)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200903 start(200903) end(200904)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200904 start(200904) end(200905)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200905 start(200905) end(200906)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200906 start(200906) end(200907)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200907 start(200907) end(200908)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200908 start(200908) end(200909)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200909 start(200909) end(200910)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200910 start(200910) end(200911)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200911 start(200911) end(200912)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_200912 start(200912) end(201001)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201001 start(201001) end(201002)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201002 start(201002) end(201003)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201003 start(201003) end(201004)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201004 start(201004) end(201005)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201005 start(201005) end(201006)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201006 start(201006) end(201007)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201007 start(201007) end(201008)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201008 start(201008) end(201009)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201009 start(201009) end(201010)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201010 start(201010) end(201011)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201011 start(201011) end(201012)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201012 start(201012) end(201101)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201101 start(201101) end(201102)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201102 start(201102) end(201103)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201103 start(201103) end(201104)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201104 start(201104) end(201105)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201105 start(201105) end(201106)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201106 start(201106) end(201107)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201107 start(201107) end(201108)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201108 start(201108) end(201109)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201109 start(201109) end(201110)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201110 start(201110) end(201111)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201111 start(201111) end(201112)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201112 start(201112) end(201201)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201201 start(201201) end(201202)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201202 start(201202) end(201203)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201203 start(201203) end(201204)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201204 start(201204) end(201205)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201205 start(201205) end(201206)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201206 start(201206) end(201207)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201207 start(201207) end(201208)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201208 start(201208) end(201209)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201209 start(201209) end(201210)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201210 start(201210) end(201211)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201211 start(201211) end(201212)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201212 start(201212) end(201301)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201301 start(201301) end(201302)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201302 start(201302) end(201303)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201303 start(201303) end(201304)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201304 start(201304) end(201305)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201305 start(201305) end(201306)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201306 start(201306) end(201307)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201307 start(201307) end(201308)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201308 start(201308) end(201309)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201309 start(201309) end(201310)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201310 start(201310) end(201311)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201311 start(201311) end(201312)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201312 start(201312) end(201401)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201401 start(201401) end(201402)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201402 start(201402) end(201403)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201403 start(201403) end(201404)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201404 start(201404) end(201405)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201405 start(201405) end(201406)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201406 start(201406) end(201407)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201407 start(201407) end(201408)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201408 start(201408) end(201409)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201409 start(201409) end(201410)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201410 start(201410) end(201411)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201411 start(201411) end(201412)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201412 start(201412) end(201501)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201501 start(201501) end(201502)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201502 start(201502) end(201503)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201503 start(201503) end(201504)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201504 start(201504) end(201505)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201505 start(201505) end(201506)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201506 start(201506) end(201507)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201507 start(201507) end(201508)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201508 start(201508) end(201509)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201509 start(201509) end(201510)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201510 start(201510) end(201511)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201511 start(201511) end(201512)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201512 start(201512) end(201601)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201601 start(201601) end(201602)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201602 start(201602) end(201603)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201603 start(201603) end(201604)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201604 start(201604) end(201605)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201605 start(201605) end(201606)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201606 start(201606) end(201607)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201607 start(201607) end(201608)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201608 start(201608) end(201609)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201609 start(201609) end(201610)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201610 start(201610) end(201611)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201611 start(201611) end(201612)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201612 start(201612) end(201701)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201701 start(201701) end(201702)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201702 start(201702) end(201703)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201703 start(201703) end(201704)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201704 start(201704) end(201705)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201705 start(201705) end(201706)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201706 start(201706) end(201707)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201707 start(201707) end(201708)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201708 start(201708) end(201709)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201709 start(201709) end(201710)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201710 start(201710) end(201711)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201711 start(201711) end(201712)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201712 start(201712) end(201801)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201801 start(201801) end(201802)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201802 start(201802) end(201803)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201803 start(201803) end(201804)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201804 start(201804) end(201805)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201805 start(201805) end(201806)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201806 start(201806) end(201807)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201807 start(201807) end(201808)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201808 start(201808) end(201809)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201809 start(201809) end(201810)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201810 start(201810) end(201811)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201811 start(201811) end(201812)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201812 start(201812) end(201901)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201901 start(201901) end(201902)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201902 start(201902) end(201903)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201903 start(201903) end(201904)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201904 start(201904) end(201905)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201905 start(201905) end(201906)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201906 start(201906) end(201907)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201907 start(201907) end(201908)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201908 start(201908) end(201909)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201909 start(201909) end(201910)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201910 start(201910) end(201911)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201911 start(201911) end(201912)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_201912 start(201912) end(202001)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202001 start(202001) end(202002)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202002 start(202002) end(202003)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202003 start(202003) end(202004)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202004 start(202004) end(202005)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202005 start(202005) end(202006)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202006 start(202006) end(202007)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202007 start(202007) end(202008)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202008 start(202008) end(202009)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202009 start(202009) end(202010)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202010 start(202010) end(202011)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202011 start(202011) end(202012)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202012 start(202012) end(202101)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202101 start(202101) end(202102)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202102 start(202102) end(202103)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202103 start(202103) end(202104)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202104 start(202104) end(202105)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202105 start(202105) end(202106)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202106 start(202106) end(202107)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202107 start(202107) end(202108)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202108 start(202108) end(202109)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202109 start(202109) end(202110)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202110 start(202110) end(202111)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202111 start(202111) end(202112)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202112 start(202112) end(202201)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202201 start(202201) end(202202)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202202 start(202202) end(202203)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202203 start(202203) end(202204)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202204 start(202204) end(202205)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202205 start(202205) end(202206)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202206 start(202206) end(202207)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202207 start(202207) end(202208)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202208 start(202208) end(202209)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202209 start(202209) end(202210)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202210 start(202210) end(202211)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202211 start(202211) end(202212)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202212 start(202212) end(202301)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202301 start(202301) end(202302)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202302 start(202302) end(202303)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202303 start(202303) end(202304)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202304 start(202304) end(202305)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202305 start(202305) end(202306)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202306 start(202306) end(202307)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202307 start(202307) end(202308)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202308 start(202308) end(202309)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202309 start(202309) end(202310)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202310 start(202310) end(202311)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202311 start(202311) end(202312)
;alter table coss_dwd.dwd_psr_pump_running_details_dip  add partition mh_202312 start(202312) end(202401)
```

#### 3.Load Data

```sql
insert into coss_dwd.dwd_psr_pump_running_details_dip
select
  t.id                                     as rpt_id              -- report pump id
  ,cast(t.report_id/1000000 as int)        as asset_id            -- assert id
  ,t.pump_number                           as pump_num            -- pump number
  ,t.category_id                           as cat_id              -- category id
  ,t1.name                                 as cat_name            -- category name
  ,t.drive_id                              as drive_id            -- drive id
  ,t2.name                                 as drive_name          -- drive name
  ,t.delivery_to_id                        as del_id              -- delivery to id
  ,t3.name                                 as del_name            -- delivery to name
  ,t3.asset_id                             as del__asset_id       -- delivery to asset id
  ,t.flow_rate_design                      as design_flow         -- flow rate design
  ,t.hours_run_this_month                  as run_hours           -- hours run this month
  ,t.water_pumped_this_month               as pump_qty            -- water pumped this month
  ,t.average_head_suct                     as avg_suct            -- average head suct
  ,t.average_head_del                      as avg_del             -- average head del
  ,t.flow_rate_design_flag                 as design_flow_flag    -- flow rate design flag
  ,t.hours_run_this_month_flag             as run_hours_flag      -- hours run this month flag
  ,t.water_pumped_this_month_flag          as pump_qty_flag       -- water pumped this month flag
  ,t.average_head_suct_flag                as avg_suct_flag       -- average head suct flag
  ,t.average_head_del_flag                 as avg_del_flag        -- average head del flag
  ,localtimestamp                          as dw_etl_time         -- dw etl time
  ,t.report_id%1000000                                            -- partitions for report month
from coss_ods.ods_emis_wsdems_report_pump_dip t
left join coss_ods.ods_emis_wsdems_pump_category_dfp	t1 on t.category_id = t1.id
left join coss_ods.ods_emis_wsdems_pump_drive_dfp t2 on t.drive_id = t2.id
left join coss_ods.ods_emis_wsdems_pump_delivery_to_dfp t3 on t.delivery_to_id = t3.id
```

## dws

### coss_dws.dws_psr_eng_cons_billing_details_dip

#### Create Table

```sql
create table if not exists coss_dws.dws_psr_eng_cons_billing_details_dip(
  asset_id            decimal(11)          -- asset id
  ,asset_name         varchar(120)         -- asset name
  ,asset_desc         varchar(120)         -- asset description
  ,loca_code          varchar(15)          -- location code
  ,acc_no             varchar(120)         -- account no
  ,region_id          decimal(11)          -- region id
  ,region_code        varchar(150)         -- region code
  ,region_desc        varchar(800)         -- region description
  ,i_type_id          decimal(11)          -- installation type id
  ,i_type_code        varchar(150)         -- installation type code
  ,i_type_desc        varchar(150)         -- installation type  description
  ,fw_portion         decimal(20,5)        -- fresh portion
  ,sw_portion         decimal(20,5)        -- salt water portion
  ,rw_portion         decimal(20,5)        -- raw water portion
  ,tw_portion         decimal(20,5)        -- treatment works portion
  ,remarks            varchar(120)         -- remarks
  ,is_active          decimal(5)           -- is active
  ,official_name      varchar(120)         -- official name
  ,station_code       varchar(120)         -- station code
  ,is_billing         decimal(5)           -- billing is active
  ,is_ps              decimal(5)           -- pump station is active
  ,is_ecw             decimal(5)           -- ecw is active
  ,region_rpt         varchar(150)         -- region report
  ,is_hkp             decimal(5)           -- hkp is active
  ,is_fy              decimal(5)           -- fy is active
  ,is_water_eff       decimal(5)           -- water efficiency is active
  ,water_eff_type_id  decimal(11)          -- installation type id for water efficiency
  ,i_num              varchar(30)          -- installation number
  ,bill_id            decimal(20)          -- bill_id
  ,bill_date          timestamp(6)         -- bill date
  ,tariff_id          decimal(11)          -- tariff id
  ,tariff_name        varchar(150)         -- tariff name
  ,tariff_desc        varchar(300)         -- tariff description
  ,utility_id         decimal(11)          -- utility id
  ,utility_name       varchar(150)         -- utility name
  ,utility_desc       varchar(800)         -- utility description
  ,kwh_on_peak        decimal(10,0)        -- power consumption of on peak (kwh)
  ,kwh_off_peak       decimal(10,0)        -- power consumption of off peak (kwh)
  ,kva_on_peak        decimal(10,0)        -- capacity of on peak (kva)
  ,kva_off_peak       decimal(10,0)        -- capacity of off peak (kva)
  ,flow_volume        decimal(20,5)        -- flow volume
  ,avg_pressure       decimal(20,5)        -- average pressure
  ,payout             decimal(10,0)        -- pay out
  ,total_kwh          decimal(10,0)        -- power consumption of on peak (kwh)
  ,pump_qty           decimal(20,5)        -- water pumped this month
  ,dw_etl_time        timestamp(6)         -- dw etl time
  ,mh                 decimal(10)          -- partitions for billing date
)
with (orientation = column, compression = middle)
distribute by hash("bill_id")
partition by range(mh)
(partition  dt_000000 start(0) end(100000))
;comment on table  coss_dws.dws_psr_eng_cons_billing_details_dip                    is 'pump station running billing details'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.asset_id           is  'asset id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.asset_name         is  'asset name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.asset_desc         is  'asset description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.loca_code          is  'location code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.acc_no             is  'account no'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.region_id          is  'region id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.region_code        is  'region code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.region_desc        is  'region description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.i_type_id          is  'installation type id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.i_type_code        is  'installation type code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.i_type_desc        is  'installation type  description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.fw_portion         is  'fresh portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.sw_portion         is  'salt water portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.rw_portion         is  'raw water portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.tw_portion         is  'treatment works portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.remarks            is  'remarks'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_active          is  'is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.official_name      is  'official name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.station_code       is  'station code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_billing         is  'billing is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_ps              is  'pump station is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_ecw             is  'ecw is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.region_rpt         is  'region report'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_hkp             is  'hkp is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_fy              is  'fy is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.is_water_eff       is  'water efficiency is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.water_eff_type_id  is  'installation type id for water efficiency'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.i_num              is  'installation number'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.bill_id            is  'bill_id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.bill_date          is  'bill date'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.tariff_id          is  'tariff id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.tariff_name        is  'tariff name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.tariff_desc        is  'tariff description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.utility_id         is  'utility id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.utility_name       is  'utility name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.utility_desc       is  'utility description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.kva_on_peak        is  'capacity of on peak (kva)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.kva_off_peak       is  'capacity of off peak (kva)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.flow_volume        is  'flow volume'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.avg_pressure       is  'average pressure'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.payout             is  'pay out'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.total_kwh          is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.pump_qty           is  'water pumped this month'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.dw_etl_time        is  'dw etl time'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_dip.mh                 is  'partitions for billing date'
```

#### Add Partition

```sql
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_100000 start(100000) end(199601)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199601 start(199601) end(199602)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199602 start(199602) end(199603)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199603 start(199603) end(199604)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199604 start(199604) end(199605)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199605 start(199605) end(199606)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199606 start(199606) end(199607)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199607 start(199607) end(199608)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199608 start(199608) end(199609)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199609 start(199609) end(199610)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199610 start(199610) end(199611)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199611 start(199611) end(199612)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199612 start(199612) end(199701)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199701 start(199701) end(199702)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199702 start(199702) end(199703)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199703 start(199703) end(199704)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199704 start(199704) end(199705)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199705 start(199705) end(199706)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199706 start(199706) end(199707)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199707 start(199707) end(199708)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199708 start(199708) end(199709)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199709 start(199709) end(199710)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199710 start(199710) end(199711)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199711 start(199711) end(199712)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199712 start(199712) end(199801)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199801 start(199801) end(199802)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199802 start(199802) end(199803)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199803 start(199803) end(199804)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199804 start(199804) end(199805)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199805 start(199805) end(199806)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199806 start(199806) end(199807)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199807 start(199807) end(199808)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199808 start(199808) end(199809)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199809 start(199809) end(199810)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199810 start(199810) end(199811)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199811 start(199811) end(199812)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199812 start(199812) end(199901)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199901 start(199901) end(199902)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199902 start(199902) end(199903)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199903 start(199903) end(199904)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199904 start(199904) end(199905)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199905 start(199905) end(199906)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199906 start(199906) end(199907)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199907 start(199907) end(199908)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199908 start(199908) end(199909)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199909 start(199909) end(199910)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199910 start(199910) end(199911)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199911 start(199911) end(199912)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_199912 start(199912) end(200001)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200001 start(200001) end(200002)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200002 start(200002) end(200003)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200003 start(200003) end(200004)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200004 start(200004) end(200005)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200005 start(200005) end(200006)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200006 start(200006) end(200007)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200007 start(200007) end(200008)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200008 start(200008) end(200009)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200009 start(200009) end(200010)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200010 start(200010) end(200011)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200011 start(200011) end(200012)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200012 start(200012) end(200101)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200101 start(200101) end(200102)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200102 start(200102) end(200103)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200103 start(200103) end(200104)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200104 start(200104) end(200105)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200105 start(200105) end(200106)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200106 start(200106) end(200107)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200107 start(200107) end(200108)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200108 start(200108) end(200109)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200109 start(200109) end(200110)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200110 start(200110) end(200111)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200111 start(200111) end(200112)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200112 start(200112) end(200201)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200201 start(200201) end(200202)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200202 start(200202) end(200203)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200203 start(200203) end(200204)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200204 start(200204) end(200205)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200205 start(200205) end(200206)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200206 start(200206) end(200207)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200207 start(200207) end(200208)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200208 start(200208) end(200209)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200209 start(200209) end(200210)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200210 start(200210) end(200211)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200211 start(200211) end(200212)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200212 start(200212) end(200301)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200301 start(200301) end(200302)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200302 start(200302) end(200303)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200303 start(200303) end(200304)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200304 start(200304) end(200305)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200305 start(200305) end(200306)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200306 start(200306) end(200307)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200307 start(200307) end(200308)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200308 start(200308) end(200309)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200309 start(200309) end(200310)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200310 start(200310) end(200311)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200311 start(200311) end(200312)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200312 start(200312) end(200401)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200401 start(200401) end(200402)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200402 start(200402) end(200403)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200403 start(200403) end(200404)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200404 start(200404) end(200405)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200405 start(200405) end(200406)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200406 start(200406) end(200407)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200407 start(200407) end(200408)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200408 start(200408) end(200409)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200409 start(200409) end(200410)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200410 start(200410) end(200411)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200411 start(200411) end(200412)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200412 start(200412) end(200501)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200501 start(200501) end(200502)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200502 start(200502) end(200503)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200503 start(200503) end(200504)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200504 start(200504) end(200505)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200505 start(200505) end(200506)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200506 start(200506) end(200507)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200507 start(200507) end(200508)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200508 start(200508) end(200509)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200509 start(200509) end(200510)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200510 start(200510) end(200511)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200511 start(200511) end(200512)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200512 start(200512) end(200601)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200601 start(200601) end(200602)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200602 start(200602) end(200603)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200603 start(200603) end(200604)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200604 start(200604) end(200605)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200605 start(200605) end(200606)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200606 start(200606) end(200607)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200607 start(200607) end(200608)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200608 start(200608) end(200609)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200609 start(200609) end(200610)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200610 start(200610) end(200611)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200611 start(200611) end(200612)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200612 start(200612) end(200701)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200701 start(200701) end(200702)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200702 start(200702) end(200703)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200703 start(200703) end(200704)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200704 start(200704) end(200705)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200705 start(200705) end(200706)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200706 start(200706) end(200707)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200707 start(200707) end(200708)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200708 start(200708) end(200709)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200709 start(200709) end(200710)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200710 start(200710) end(200711)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200711 start(200711) end(200712)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200712 start(200712) end(200801)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200801 start(200801) end(200802)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200802 start(200802) end(200803)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200803 start(200803) end(200804)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200804 start(200804) end(200805)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200805 start(200805) end(200806)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200806 start(200806) end(200807)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200807 start(200807) end(200808)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200808 start(200808) end(200809)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200809 start(200809) end(200810)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200810 start(200810) end(200811)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200811 start(200811) end(200812)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200812 start(200812) end(200901)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200901 start(200901) end(200902)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200902 start(200902) end(200903)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200903 start(200903) end(200904)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200904 start(200904) end(200905)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200905 start(200905) end(200906)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200906 start(200906) end(200907)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200907 start(200907) end(200908)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200908 start(200908) end(200909)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200909 start(200909) end(200910)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200910 start(200910) end(200911)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200911 start(200911) end(200912)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_200912 start(200912) end(201001)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201001 start(201001) end(201002)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201002 start(201002) end(201003)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201003 start(201003) end(201004)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201004 start(201004) end(201005)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201005 start(201005) end(201006)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201006 start(201006) end(201007)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201007 start(201007) end(201008)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201008 start(201008) end(201009)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201009 start(201009) end(201010)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201010 start(201010) end(201011)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201011 start(201011) end(201012)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201012 start(201012) end(201101)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201101 start(201101) end(201102)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201102 start(201102) end(201103)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201103 start(201103) end(201104)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201104 start(201104) end(201105)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201105 start(201105) end(201106)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201106 start(201106) end(201107)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201107 start(201107) end(201108)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201108 start(201108) end(201109)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201109 start(201109) end(201110)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201110 start(201110) end(201111)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201111 start(201111) end(201112)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201112 start(201112) end(201201)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201201 start(201201) end(201202)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201202 start(201202) end(201203)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201203 start(201203) end(201204)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201204 start(201204) end(201205)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201205 start(201205) end(201206)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201206 start(201206) end(201207)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201207 start(201207) end(201208)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201208 start(201208) end(201209)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201209 start(201209) end(201210)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201210 start(201210) end(201211)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201211 start(201211) end(201212)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201212 start(201212) end(201301)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201301 start(201301) end(201302)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201302 start(201302) end(201303)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201303 start(201303) end(201304)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201304 start(201304) end(201305)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201305 start(201305) end(201306)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201306 start(201306) end(201307)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201307 start(201307) end(201308)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201308 start(201308) end(201309)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201309 start(201309) end(201310)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201310 start(201310) end(201311)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201311 start(201311) end(201312)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201312 start(201312) end(201401)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201401 start(201401) end(201402)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201402 start(201402) end(201403)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201403 start(201403) end(201404)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201404 start(201404) end(201405)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201405 start(201405) end(201406)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201406 start(201406) end(201407)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201407 start(201407) end(201408)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201408 start(201408) end(201409)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201409 start(201409) end(201410)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201410 start(201410) end(201411)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201411 start(201411) end(201412)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201412 start(201412) end(201501)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201501 start(201501) end(201502)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201502 start(201502) end(201503)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201503 start(201503) end(201504)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201504 start(201504) end(201505)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201505 start(201505) end(201506)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201506 start(201506) end(201507)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201507 start(201507) end(201508)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201508 start(201508) end(201509)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201509 start(201509) end(201510)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201510 start(201510) end(201511)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201511 start(201511) end(201512)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201512 start(201512) end(201601)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201601 start(201601) end(201602)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201602 start(201602) end(201603)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201603 start(201603) end(201604)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201604 start(201604) end(201605)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201605 start(201605) end(201606)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201606 start(201606) end(201607)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201607 start(201607) end(201608)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201608 start(201608) end(201609)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201609 start(201609) end(201610)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201610 start(201610) end(201611)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201611 start(201611) end(201612)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201612 start(201612) end(201701)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201701 start(201701) end(201702)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201702 start(201702) end(201703)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201703 start(201703) end(201704)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201704 start(201704) end(201705)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201705 start(201705) end(201706)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201706 start(201706) end(201707)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201707 start(201707) end(201708)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201708 start(201708) end(201709)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201709 start(201709) end(201710)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201710 start(201710) end(201711)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201711 start(201711) end(201712)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201712 start(201712) end(201801)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201801 start(201801) end(201802)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201802 start(201802) end(201803)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201803 start(201803) end(201804)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201804 start(201804) end(201805)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201805 start(201805) end(201806)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201806 start(201806) end(201807)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201807 start(201807) end(201808)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201808 start(201808) end(201809)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201809 start(201809) end(201810)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201810 start(201810) end(201811)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201811 start(201811) end(201812)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201812 start(201812) end(201901)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201901 start(201901) end(201902)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201902 start(201902) end(201903)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201903 start(201903) end(201904)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201904 start(201904) end(201905)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201905 start(201905) end(201906)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201906 start(201906) end(201907)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201907 start(201907) end(201908)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201908 start(201908) end(201909)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201909 start(201909) end(201910)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201910 start(201910) end(201911)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201911 start(201911) end(201912)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_201912 start(201912) end(202001)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202001 start(202001) end(202002)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202002 start(202002) end(202003)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202003 start(202003) end(202004)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202004 start(202004) end(202005)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202005 start(202005) end(202006)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202006 start(202006) end(202007)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202007 start(202007) end(202008)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202008 start(202008) end(202009)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202009 start(202009) end(202010)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202010 start(202010) end(202011)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202011 start(202011) end(202012)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202012 start(202012) end(202101)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202101 start(202101) end(202102)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202102 start(202102) end(202103)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202103 start(202103) end(202104)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202104 start(202104) end(202105)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202105 start(202105) end(202106)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202106 start(202106) end(202107)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202107 start(202107) end(202108)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202108 start(202108) end(202109)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202109 start(202109) end(202110)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202110 start(202110) end(202111)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202111 start(202111) end(202112)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202112 start(202112) end(202201)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202201 start(202201) end(202202)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202202 start(202202) end(202203)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202203 start(202203) end(202204)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202204 start(202204) end(202205)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202205 start(202205) end(202206)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202206 start(202206) end(202207)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202207 start(202207) end(202208)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202208 start(202208) end(202209)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202209 start(202209) end(202210)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202210 start(202210) end(202211)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202211 start(202211) end(202212)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202212 start(202212) end(202301)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202301 start(202301) end(202302)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202302 start(202302) end(202303)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202303 start(202303) end(202304)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202304 start(202304) end(202305)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202305 start(202305) end(202306)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202306 start(202306) end(202307)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202307 start(202307) end(202308)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202308 start(202308) end(202309)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202309 start(202309) end(202310)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202310 start(202310) end(202311)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202311 start(202311) end(202312)
;alter table coss_dws.dws_psr_eng_cons_billing_details_dip         add partition mh_202312 start(202312) end(202401)

```

#### Load Data

```sql
insert into coss_dws.dws_psr_eng_cons_billing_details_dip
select 
  t1.asset_id
  ,t1.asset_name
  ,t1.asset_desc
  ,t1.loca_code
  ,t1.acc_no
  ,t1.region_id
  ,t1.region_code
  ,t1.region_desc
  ,t1.i_type_id
  ,t1.i_type_code
  ,t1.i_type_desc
  ,t1.fw_portion
  ,t1.sw_portion
  ,t1.rw_portion
  ,t1.tw_portion
  ,t1.remarks
  ,t1.is_active
  ,t1.official_name
  ,t1.station_code
  ,t1.is_billing
  ,t1.is_ps
  ,t1.is_ecw
  ,t1.region_rpt
  ,t1.is_hkp
  ,t1.is_fy
  ,t1.is_water_eff
  ,t1.water_eff_type_id
  ,t1.i_num
  ,t.bill_id
  ,t.bill_date
  ,t.tariff_id
  ,t.tariff_name
  ,t.tariff_desc
  ,t.utility_id
  ,t.utility_name
  ,t.utility_desc
  ,t.kwh_on_peak
  ,t.kwh_off_peak
  ,t.kva_on_peak
  ,t.kva_off_peak
  ,t.flow_volume
  ,t.avg_pressure
  ,t.payout
  ,t.kwh_on_peak+t.kwh_off_peak
  ,t2.pump_qty
  ,localtimestamp
  ,t.mh
from coss_dwd.dwd_psr_billing_details_dip t
inner join coss_dwd.dim_ass_energy_cons_installation_dfp t1 on t.asset_id = t1.asset_id 
left join (select mh,asset_id,sum(pump_qty) pump_qty from coss_dwd.dwd_psr_pump_running_details_dip group by mh,asset_id ) t2 on t.asset_id  = t2.asset_id and t.mh = t2.mh 
where t1.asset_name like '%PS%' 
  and lower(t1.asset_name) not like '%ceased%' 
  and lower(t1.asset_name) not like '%decommissi%'
  and lower(t1.asset_name) not like '%TW%'
--  and t.mh = '${mh}' 
--  and t1.dt = '${dt}' 
--  and t2.mh = '${mh}' 
```

### coss_dws.dws_psr_eng_cons_billing_details_dip

#### Create Table

```sql
create table if not exists coss_dws.dws_wtw_eng_cons_billing_details_dip(
  asset_id            decimal(11)          -- asset id
  ,asset_name         varchar(120)         -- asset name
  ,asset_desc         varchar(120)         -- asset description
  ,loca_code          varchar(15)          -- location code
  ,acc_no             varchar(120)         -- account no
  ,region_id          decimal(11)          -- region id
  ,region_code        varchar(150)         -- region code
  ,region_desc        varchar(800)         -- region description
  ,i_type_id          decimal(11)          -- installation type id
  ,i_type_code        varchar(150)         -- installation type code
  ,i_type_desc        varchar(150)         -- installation type  description
  ,fw_portion         decimal(20,5)        -- fresh portion
  ,sw_portion         decimal(20,5)        -- salt water portion
  ,rw_portion         decimal(20,5)        -- raw water portion
  ,tw_portion         decimal(20,5)        -- treatment works portion
  ,remarks            varchar(120)         -- remarks
  ,is_active          decimal(5)           -- is active
  ,official_name      varchar(120)         -- official name
  ,station_code       varchar(120)         -- station code
  ,is_billing         decimal(5)           -- billing is active
  ,is_ps              decimal(5)           -- pump station is active
  ,is_ecw             decimal(5)           -- ecw is active
  ,region_rpt         varchar(150)         -- region report
  ,is_hkp             decimal(5)           -- hkp is active
  ,is_fy              decimal(5)           -- fy is active
  ,is_water_eff       decimal(5)           -- water efficiency is active
  ,water_eff_type_id  decimal(11)          -- installation type id for water efficiency
  ,i_num              varchar(30)          -- installation number
  ,bill_id            decimal(20)          -- bill_id
  ,bill_date          timestamp(6)         -- bill date
  ,tariff_id          decimal(11)          -- tariff id
  ,tariff_name        varchar(150)         -- tariff name
  ,tariff_desc        varchar(300)         -- tariff description
  ,utility_id         decimal(11)          -- utility id
  ,utility_name       varchar(150)         -- utility name
  ,utility_desc       varchar(800)         -- utility description
  ,kwh_on_peak        decimal(10,0)        -- power consumption of on peak (kwh)
  ,kwh_off_peak       decimal(10,0)        -- power consumption of off peak (kwh)
  ,kva_on_peak        decimal(10,0)        -- capacity of on peak (kva)
  ,kva_off_peak       decimal(10,0)        -- capacity of off peak (kva)
  ,flow_volume        decimal(20,5)        -- flow volume
  ,avg_pressure       decimal(20,5)        -- average pressure
  ,payout             decimal(10,0)        -- pay out
  ,total_kwh          decimal(10,0)        -- power consumption of on peak (kwh)
  ,pump_qty           decimal(20,5)        -- water pumped this month
  ,dw_etl_time        timestamp(6)         -- dw etl time
  ,mh                 decimal(10)          -- partitions for billing date
)
with (orientation = column, compression = middle)
distribute by hash("bill_id")
partition by range(mh)
(partition  dt_000000 start(0) end(100000))
;comment on table  coss_dws.dws_wtw_eng_cons_billing_details_dip                    is 'pump station running billing details'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.asset_id           is  'asset id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.asset_name         is  'asset name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.asset_desc         is  'asset description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.loca_code          is  'location code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.acc_no             is  'account no'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.region_id          is  'region id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.region_code        is  'region code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.region_desc        is  'region description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.i_type_id          is  'installation type id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.i_type_code        is  'installation type code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.i_type_desc        is  'installation type  description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.fw_portion         is  'fresh portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.sw_portion         is  'salt water portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.rw_portion         is  'raw water portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.tw_portion         is  'treatment works portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.remarks            is  'remarks'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_active          is  'is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.official_name      is  'official name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.station_code       is  'station code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_billing         is  'billing is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_ps              is  'pump station is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_ecw             is  'ecw is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.region_rpt         is  'region report'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_hkp             is  'hkp is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_fy              is  'fy is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.is_water_eff       is  'water efficiency is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.water_eff_type_id  is  'installation type id for water efficiency'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.i_num              is  'installation number'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.bill_id            is  'bill_id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.bill_date          is  'bill date'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.tariff_id          is  'tariff id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.tariff_name        is  'tariff name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.tariff_desc        is  'tariff description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.utility_id         is  'utility id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.utility_name       is  'utility name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.utility_desc       is  'utility description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.kva_on_peak        is  'capacity of on peak (kva)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.kva_off_peak       is  'capacity of off peak (kva)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.flow_volume        is  'flow volume'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.avg_pressure       is  'average pressure'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.payout             is  'pay out'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.total_kwh          is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.pump_qty           is  'water pumped this month'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.dw_etl_time        is  'dw etl time'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_dip.mh                 is  'partitions for billing date'
```

#### Add Partition

```sql
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_100000 start(100000) end(199601)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199601 start(199601) end(199602)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199602 start(199602) end(199603)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199603 start(199603) end(199604)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199604 start(199604) end(199605)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199605 start(199605) end(199606)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199606 start(199606) end(199607)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199607 start(199607) end(199608)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199608 start(199608) end(199609)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199609 start(199609) end(199610)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199610 start(199610) end(199611)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199611 start(199611) end(199612)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199612 start(199612) end(199701)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199701 start(199701) end(199702)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199702 start(199702) end(199703)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199703 start(199703) end(199704)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199704 start(199704) end(199705)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199705 start(199705) end(199706)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199706 start(199706) end(199707)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199707 start(199707) end(199708)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199708 start(199708) end(199709)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199709 start(199709) end(199710)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199710 start(199710) end(199711)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199711 start(199711) end(199712)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199712 start(199712) end(199801)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199801 start(199801) end(199802)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199802 start(199802) end(199803)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199803 start(199803) end(199804)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199804 start(199804) end(199805)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199805 start(199805) end(199806)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199806 start(199806) end(199807)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199807 start(199807) end(199808)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199808 start(199808) end(199809)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199809 start(199809) end(199810)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199810 start(199810) end(199811)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199811 start(199811) end(199812)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199812 start(199812) end(199901)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199901 start(199901) end(199902)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199902 start(199902) end(199903)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199903 start(199903) end(199904)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199904 start(199904) end(199905)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199905 start(199905) end(199906)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199906 start(199906) end(199907)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199907 start(199907) end(199908)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199908 start(199908) end(199909)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199909 start(199909) end(199910)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199910 start(199910) end(199911)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199911 start(199911) end(199912)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_199912 start(199912) end(200001)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200001 start(200001) end(200002)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200002 start(200002) end(200003)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200003 start(200003) end(200004)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200004 start(200004) end(200005)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200005 start(200005) end(200006)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200006 start(200006) end(200007)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200007 start(200007) end(200008)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200008 start(200008) end(200009)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200009 start(200009) end(200010)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200010 start(200010) end(200011)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200011 start(200011) end(200012)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200012 start(200012) end(200101)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200101 start(200101) end(200102)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200102 start(200102) end(200103)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200103 start(200103) end(200104)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200104 start(200104) end(200105)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200105 start(200105) end(200106)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200106 start(200106) end(200107)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200107 start(200107) end(200108)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200108 start(200108) end(200109)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200109 start(200109) end(200110)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200110 start(200110) end(200111)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200111 start(200111) end(200112)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200112 start(200112) end(200201)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200201 start(200201) end(200202)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200202 start(200202) end(200203)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200203 start(200203) end(200204)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200204 start(200204) end(200205)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200205 start(200205) end(200206)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200206 start(200206) end(200207)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200207 start(200207) end(200208)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200208 start(200208) end(200209)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200209 start(200209) end(200210)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200210 start(200210) end(200211)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200211 start(200211) end(200212)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200212 start(200212) end(200301)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200301 start(200301) end(200302)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200302 start(200302) end(200303)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200303 start(200303) end(200304)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200304 start(200304) end(200305)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200305 start(200305) end(200306)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200306 start(200306) end(200307)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200307 start(200307) end(200308)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200308 start(200308) end(200309)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200309 start(200309) end(200310)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200310 start(200310) end(200311)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200311 start(200311) end(200312)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200312 start(200312) end(200401)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200401 start(200401) end(200402)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200402 start(200402) end(200403)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200403 start(200403) end(200404)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200404 start(200404) end(200405)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200405 start(200405) end(200406)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200406 start(200406) end(200407)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200407 start(200407) end(200408)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200408 start(200408) end(200409)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200409 start(200409) end(200410)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200410 start(200410) end(200411)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200411 start(200411) end(200412)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200412 start(200412) end(200501)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200501 start(200501) end(200502)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200502 start(200502) end(200503)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200503 start(200503) end(200504)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200504 start(200504) end(200505)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200505 start(200505) end(200506)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200506 start(200506) end(200507)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200507 start(200507) end(200508)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200508 start(200508) end(200509)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200509 start(200509) end(200510)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200510 start(200510) end(200511)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200511 start(200511) end(200512)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200512 start(200512) end(200601)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200601 start(200601) end(200602)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200602 start(200602) end(200603)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200603 start(200603) end(200604)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200604 start(200604) end(200605)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200605 start(200605) end(200606)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200606 start(200606) end(200607)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200607 start(200607) end(200608)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200608 start(200608) end(200609)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200609 start(200609) end(200610)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200610 start(200610) end(200611)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200611 start(200611) end(200612)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200612 start(200612) end(200701)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200701 start(200701) end(200702)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200702 start(200702) end(200703)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200703 start(200703) end(200704)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200704 start(200704) end(200705)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200705 start(200705) end(200706)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200706 start(200706) end(200707)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200707 start(200707) end(200708)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200708 start(200708) end(200709)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200709 start(200709) end(200710)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200710 start(200710) end(200711)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200711 start(200711) end(200712)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200712 start(200712) end(200801)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200801 start(200801) end(200802)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200802 start(200802) end(200803)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200803 start(200803) end(200804)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200804 start(200804) end(200805)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200805 start(200805) end(200806)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200806 start(200806) end(200807)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200807 start(200807) end(200808)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200808 start(200808) end(200809)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200809 start(200809) end(200810)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200810 start(200810) end(200811)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200811 start(200811) end(200812)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200812 start(200812) end(200901)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200901 start(200901) end(200902)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200902 start(200902) end(200903)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200903 start(200903) end(200904)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200904 start(200904) end(200905)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200905 start(200905) end(200906)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200906 start(200906) end(200907)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200907 start(200907) end(200908)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200908 start(200908) end(200909)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200909 start(200909) end(200910)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200910 start(200910) end(200911)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200911 start(200911) end(200912)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_200912 start(200912) end(201001)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201001 start(201001) end(201002)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201002 start(201002) end(201003)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201003 start(201003) end(201004)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201004 start(201004) end(201005)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201005 start(201005) end(201006)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201006 start(201006) end(201007)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201007 start(201007) end(201008)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201008 start(201008) end(201009)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201009 start(201009) end(201010)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201010 start(201010) end(201011)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201011 start(201011) end(201012)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201012 start(201012) end(201101)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201101 start(201101) end(201102)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201102 start(201102) end(201103)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201103 start(201103) end(201104)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201104 start(201104) end(201105)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201105 start(201105) end(201106)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201106 start(201106) end(201107)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201107 start(201107) end(201108)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201108 start(201108) end(201109)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201109 start(201109) end(201110)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201110 start(201110) end(201111)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201111 start(201111) end(201112)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201112 start(201112) end(201201)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201201 start(201201) end(201202)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201202 start(201202) end(201203)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201203 start(201203) end(201204)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201204 start(201204) end(201205)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201205 start(201205) end(201206)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201206 start(201206) end(201207)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201207 start(201207) end(201208)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201208 start(201208) end(201209)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201209 start(201209) end(201210)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201210 start(201210) end(201211)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201211 start(201211) end(201212)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201212 start(201212) end(201301)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201301 start(201301) end(201302)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201302 start(201302) end(201303)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201303 start(201303) end(201304)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201304 start(201304) end(201305)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201305 start(201305) end(201306)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201306 start(201306) end(201307)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201307 start(201307) end(201308)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201308 start(201308) end(201309)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201309 start(201309) end(201310)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201310 start(201310) end(201311)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201311 start(201311) end(201312)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201312 start(201312) end(201401)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201401 start(201401) end(201402)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201402 start(201402) end(201403)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201403 start(201403) end(201404)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201404 start(201404) end(201405)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201405 start(201405) end(201406)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201406 start(201406) end(201407)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201407 start(201407) end(201408)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201408 start(201408) end(201409)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201409 start(201409) end(201410)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201410 start(201410) end(201411)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201411 start(201411) end(201412)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201412 start(201412) end(201501)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201501 start(201501) end(201502)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201502 start(201502) end(201503)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201503 start(201503) end(201504)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201504 start(201504) end(201505)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201505 start(201505) end(201506)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201506 start(201506) end(201507)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201507 start(201507) end(201508)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201508 start(201508) end(201509)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201509 start(201509) end(201510)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201510 start(201510) end(201511)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201511 start(201511) end(201512)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201512 start(201512) end(201601)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201601 start(201601) end(201602)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201602 start(201602) end(201603)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201603 start(201603) end(201604)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201604 start(201604) end(201605)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201605 start(201605) end(201606)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201606 start(201606) end(201607)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201607 start(201607) end(201608)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201608 start(201608) end(201609)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201609 start(201609) end(201610)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201610 start(201610) end(201611)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201611 start(201611) end(201612)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201612 start(201612) end(201701)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201701 start(201701) end(201702)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201702 start(201702) end(201703)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201703 start(201703) end(201704)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201704 start(201704) end(201705)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201705 start(201705) end(201706)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201706 start(201706) end(201707)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201707 start(201707) end(201708)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201708 start(201708) end(201709)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201709 start(201709) end(201710)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201710 start(201710) end(201711)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201711 start(201711) end(201712)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201712 start(201712) end(201801)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201801 start(201801) end(201802)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201802 start(201802) end(201803)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201803 start(201803) end(201804)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201804 start(201804) end(201805)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201805 start(201805) end(201806)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201806 start(201806) end(201807)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201807 start(201807) end(201808)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201808 start(201808) end(201809)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201809 start(201809) end(201810)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201810 start(201810) end(201811)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201811 start(201811) end(201812)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201812 start(201812) end(201901)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201901 start(201901) end(201902)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201902 start(201902) end(201903)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201903 start(201903) end(201904)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201904 start(201904) end(201905)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201905 start(201905) end(201906)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201906 start(201906) end(201907)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201907 start(201907) end(201908)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201908 start(201908) end(201909)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201909 start(201909) end(201910)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201910 start(201910) end(201911)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201911 start(201911) end(201912)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_201912 start(201912) end(202001)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202001 start(202001) end(202002)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202002 start(202002) end(202003)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202003 start(202003) end(202004)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202004 start(202004) end(202005)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202005 start(202005) end(202006)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202006 start(202006) end(202007)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202007 start(202007) end(202008)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202008 start(202008) end(202009)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202009 start(202009) end(202010)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202010 start(202010) end(202011)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202011 start(202011) end(202012)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202012 start(202012) end(202101)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202101 start(202101) end(202102)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202102 start(202102) end(202103)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202103 start(202103) end(202104)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202104 start(202104) end(202105)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202105 start(202105) end(202106)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202106 start(202106) end(202107)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202107 start(202107) end(202108)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202108 start(202108) end(202109)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202109 start(202109) end(202110)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202110 start(202110) end(202111)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202111 start(202111) end(202112)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202112 start(202112) end(202201)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202201 start(202201) end(202202)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202202 start(202202) end(202203)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202203 start(202203) end(202204)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202204 start(202204) end(202205)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202205 start(202205) end(202206)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202206 start(202206) end(202207)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202207 start(202207) end(202208)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202208 start(202208) end(202209)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202209 start(202209) end(202210)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202210 start(202210) end(202211)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202211 start(202211) end(202212)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202212 start(202212) end(202301)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202301 start(202301) end(202302)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202302 start(202302) end(202303)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202303 start(202303) end(202304)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202304 start(202304) end(202305)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202305 start(202305) end(202306)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202306 start(202306) end(202307)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202307 start(202307) end(202308)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202308 start(202308) end(202309)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202309 start(202309) end(202310)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202310 start(202310) end(202311)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202311 start(202311) end(202312)
;alter table coss_dws.dws_wtw_eng_cons_billing_details_dip         add partition mh_202312 start(202312) end(202401)

```

#### Load Data

```sql
insert into coss_dws.dws_wtw_eng_cons_billing_details_dip
select 
  t1.asset_id
  ,t1.asset_name
  ,t1.asset_desc
  ,t1.loca_code
  ,t1.acc_no
  ,t1.region_id
  ,t1.region_code
  ,t1.region_desc
  ,t1.i_type_id
  ,t1.i_type_code
  ,t1.i_type_desc
  ,t1.fw_portion
  ,t1.sw_portion
  ,t1.rw_portion
  ,t1.tw_portion
  ,t1.remarks
  ,t1.is_active
  ,t1.official_name
  ,t1.station_code
  ,t1.is_billing
  ,t1.is_ps
  ,t1.is_ecw
  ,t1.region_rpt
  ,t1.is_hkp
  ,t1.is_fy
  ,t1.is_water_eff
  ,t1.water_eff_type_id
  ,t1.i_num
  ,t.bill_id
  ,t.bill_date
  ,t.tariff_id
  ,t.tariff_name
  ,t.tariff_desc
  ,t.utility_id
  ,t.utility_name
  ,t.utility_desc
  ,t.kwh_on_peak
  ,t.kwh_off_peak
  ,t.kva_on_peak
  ,t.kva_off_peak
  ,t.flow_volume
  ,t.avg_pressure
  ,t.payout
  ,t.kwh_on_peak+t.kwh_off_peak
  ,t2.pump_qty
  ,localtimestamp
  ,t.mh
from coss_dwd.dwd_psr_billing_details_dip t
inner join coss_dwd.dim_ass_energy_cons_installation_dfp t1 on t.asset_id = t1.asset_id 
left join (select mh,asset_id,sum(pump_qty) pump_qty from coss_dwd.dwd_psr_pump_running_details_dip group by mh,asset_id ) t2 on t.asset_id  = t2.asset_id and t.mh = t2.mh 
where t1.asset_name like '%WTW%' 
  and lower(t1.asset_name) not like '%ceased%' 
  and lower(t1.asset_name) not like '%decommissi%'
--  and t.mh = '${mh}' 
--  and t1.dt = '${dt}' 
--  and t2.mh = '${mh}' 
```

## dm

### 1.coss_dm.dm_psr_eng_cons_billing_hist_dip

#### Create Table

```sql
create table coss_dm.dm_psr_eng_cons_billing_hist_dip(
  asset_id         decimal(11)
  ,asset_name      varchar(120)
  ,asset_desc      varchar(120)
  ,i_type_code     varchar(150)
  ,i_type_desc     varchar(150)
  ,region_rpt      varchar(150)
  ,bill_id         decimal(20)
  ,bill_date       timestamp(6)
  ,tariff_name     varchar(150)
  ,tariff_desc     varchar(300)
  ,utility_name    varchar(150)
  ,utility_desc    varchar(800)
  ,kwh_on_peak     decimal(10,0)
  ,kwh_off_peak    decimal(10,0)
  ,payout          decimal(10,0)
  ,total_kwh       decimal(10,0)
  ,pump_qty        decimal(20,5)
  ,avg_flow_rate   decimal(20,5)
  ,dw_etl_time     timestamp(6)
  ,mh              decimal(10)
)
with (orientation = column, compression = middle)
distribute by hash("bill_id")
partition by range(mh)
(partition  dt_000000 start(0) end(100000))
;comment on table  coss_dm.dm_psr_eng_cons_billing_hist_dip                    is 'pump station running billing history'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.asset_id           is  'asset id'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.asset_name         is  'asset name'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.asset_desc         is  'asset description'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.i_type_code        is  'installation type code'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.i_type_desc        is  'installation type  description'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.region_rpt         is  'region report'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.bill_id            is  'bill_id'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.bill_date          is  'bill date'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.tariff_name        is  'tariff name'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.tariff_desc        is  'tariff description'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.utility_name       is  'utility name'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.utility_desc       is  'utility description'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.payout             is  'pay out'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.total_kwh          is  'power consumption of total (kwh), the calculation logic is (kwh_on_peak + kwh_off_peak)'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.pump_qty           is  'water pumped this month'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.avg_flow_rate      is  'average rate of flow.(Unit is MLD)'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.dw_etl_time        is  'dw etl time'
;comment on column coss_dm.dm_psr_eng_cons_billing_hist_dip.mh                 is  'partitions for billing date'
```

#### Add Partition

```sql
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_100000 start(100000) end(199601)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199601 start(199601) end(199602)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199602 start(199602) end(199603)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199603 start(199603) end(199604)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199604 start(199604) end(199605)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199605 start(199605) end(199606)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199606 start(199606) end(199607)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199607 start(199607) end(199608)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199608 start(199608) end(199609)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199609 start(199609) end(199610)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199610 start(199610) end(199611)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199611 start(199611) end(199612)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199612 start(199612) end(199701)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199701 start(199701) end(199702)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199702 start(199702) end(199703)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199703 start(199703) end(199704)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199704 start(199704) end(199705)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199705 start(199705) end(199706)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199706 start(199706) end(199707)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199707 start(199707) end(199708)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199708 start(199708) end(199709)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199709 start(199709) end(199710)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199710 start(199710) end(199711)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199711 start(199711) end(199712)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199712 start(199712) end(199801)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199801 start(199801) end(199802)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199802 start(199802) end(199803)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199803 start(199803) end(199804)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199804 start(199804) end(199805)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199805 start(199805) end(199806)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199806 start(199806) end(199807)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199807 start(199807) end(199808)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199808 start(199808) end(199809)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199809 start(199809) end(199810)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199810 start(199810) end(199811)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199811 start(199811) end(199812)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199812 start(199812) end(199901)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199901 start(199901) end(199902)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199902 start(199902) end(199903)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199903 start(199903) end(199904)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199904 start(199904) end(199905)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199905 start(199905) end(199906)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199906 start(199906) end(199907)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199907 start(199907) end(199908)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199908 start(199908) end(199909)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199909 start(199909) end(199910)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199910 start(199910) end(199911)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199911 start(199911) end(199912)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_199912 start(199912) end(200001)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200001 start(200001) end(200002)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200002 start(200002) end(200003)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200003 start(200003) end(200004)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200004 start(200004) end(200005)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200005 start(200005) end(200006)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200006 start(200006) end(200007)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200007 start(200007) end(200008)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200008 start(200008) end(200009)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200009 start(200009) end(200010)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200010 start(200010) end(200011)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200011 start(200011) end(200012)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200012 start(200012) end(200101)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200101 start(200101) end(200102)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200102 start(200102) end(200103)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200103 start(200103) end(200104)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200104 start(200104) end(200105)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200105 start(200105) end(200106)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200106 start(200106) end(200107)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200107 start(200107) end(200108)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200108 start(200108) end(200109)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200109 start(200109) end(200110)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200110 start(200110) end(200111)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200111 start(200111) end(200112)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200112 start(200112) end(200201)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200201 start(200201) end(200202)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200202 start(200202) end(200203)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200203 start(200203) end(200204)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200204 start(200204) end(200205)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200205 start(200205) end(200206)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200206 start(200206) end(200207)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200207 start(200207) end(200208)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200208 start(200208) end(200209)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200209 start(200209) end(200210)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200210 start(200210) end(200211)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200211 start(200211) end(200212)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200212 start(200212) end(200301)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200301 start(200301) end(200302)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200302 start(200302) end(200303)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200303 start(200303) end(200304)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200304 start(200304) end(200305)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200305 start(200305) end(200306)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200306 start(200306) end(200307)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200307 start(200307) end(200308)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200308 start(200308) end(200309)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200309 start(200309) end(200310)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200310 start(200310) end(200311)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200311 start(200311) end(200312)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200312 start(200312) end(200401)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200401 start(200401) end(200402)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200402 start(200402) end(200403)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200403 start(200403) end(200404)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200404 start(200404) end(200405)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200405 start(200405) end(200406)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200406 start(200406) end(200407)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200407 start(200407) end(200408)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200408 start(200408) end(200409)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200409 start(200409) end(200410)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200410 start(200410) end(200411)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200411 start(200411) end(200412)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200412 start(200412) end(200501)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200501 start(200501) end(200502)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200502 start(200502) end(200503)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200503 start(200503) end(200504)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200504 start(200504) end(200505)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200505 start(200505) end(200506)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200506 start(200506) end(200507)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200507 start(200507) end(200508)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200508 start(200508) end(200509)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200509 start(200509) end(200510)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200510 start(200510) end(200511)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200511 start(200511) end(200512)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200512 start(200512) end(200601)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200601 start(200601) end(200602)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200602 start(200602) end(200603)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200603 start(200603) end(200604)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200604 start(200604) end(200605)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200605 start(200605) end(200606)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200606 start(200606) end(200607)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200607 start(200607) end(200608)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200608 start(200608) end(200609)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200609 start(200609) end(200610)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200610 start(200610) end(200611)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200611 start(200611) end(200612)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200612 start(200612) end(200701)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200701 start(200701) end(200702)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200702 start(200702) end(200703)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200703 start(200703) end(200704)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200704 start(200704) end(200705)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200705 start(200705) end(200706)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200706 start(200706) end(200707)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200707 start(200707) end(200708)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200708 start(200708) end(200709)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200709 start(200709) end(200710)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200710 start(200710) end(200711)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200711 start(200711) end(200712)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200712 start(200712) end(200801)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200801 start(200801) end(200802)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200802 start(200802) end(200803)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200803 start(200803) end(200804)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200804 start(200804) end(200805)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200805 start(200805) end(200806)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200806 start(200806) end(200807)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200807 start(200807) end(200808)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200808 start(200808) end(200809)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200809 start(200809) end(200810)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200810 start(200810) end(200811)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200811 start(200811) end(200812)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200812 start(200812) end(200901)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200901 start(200901) end(200902)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200902 start(200902) end(200903)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200903 start(200903) end(200904)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200904 start(200904) end(200905)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200905 start(200905) end(200906)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200906 start(200906) end(200907)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200907 start(200907) end(200908)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200908 start(200908) end(200909)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200909 start(200909) end(200910)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200910 start(200910) end(200911)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200911 start(200911) end(200912)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_200912 start(200912) end(201001)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201001 start(201001) end(201002)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201002 start(201002) end(201003)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201003 start(201003) end(201004)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201004 start(201004) end(201005)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201005 start(201005) end(201006)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201006 start(201006) end(201007)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201007 start(201007) end(201008)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201008 start(201008) end(201009)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201009 start(201009) end(201010)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201010 start(201010) end(201011)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201011 start(201011) end(201012)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201012 start(201012) end(201101)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201101 start(201101) end(201102)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201102 start(201102) end(201103)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201103 start(201103) end(201104)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201104 start(201104) end(201105)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201105 start(201105) end(201106)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201106 start(201106) end(201107)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201107 start(201107) end(201108)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201108 start(201108) end(201109)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201109 start(201109) end(201110)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201110 start(201110) end(201111)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201111 start(201111) end(201112)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201112 start(201112) end(201201)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201201 start(201201) end(201202)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201202 start(201202) end(201203)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201203 start(201203) end(201204)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201204 start(201204) end(201205)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201205 start(201205) end(201206)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201206 start(201206) end(201207)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201207 start(201207) end(201208)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201208 start(201208) end(201209)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201209 start(201209) end(201210)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201210 start(201210) end(201211)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201211 start(201211) end(201212)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201212 start(201212) end(201301)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201301 start(201301) end(201302)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201302 start(201302) end(201303)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201303 start(201303) end(201304)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201304 start(201304) end(201305)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201305 start(201305) end(201306)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201306 start(201306) end(201307)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201307 start(201307) end(201308)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201308 start(201308) end(201309)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201309 start(201309) end(201310)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201310 start(201310) end(201311)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201311 start(201311) end(201312)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201312 start(201312) end(201401)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201401 start(201401) end(201402)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201402 start(201402) end(201403)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201403 start(201403) end(201404)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201404 start(201404) end(201405)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201405 start(201405) end(201406)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201406 start(201406) end(201407)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201407 start(201407) end(201408)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201408 start(201408) end(201409)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201409 start(201409) end(201410)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201410 start(201410) end(201411)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201411 start(201411) end(201412)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201412 start(201412) end(201501)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201501 start(201501) end(201502)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201502 start(201502) end(201503)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201503 start(201503) end(201504)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201504 start(201504) end(201505)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201505 start(201505) end(201506)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201506 start(201506) end(201507)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201507 start(201507) end(201508)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201508 start(201508) end(201509)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201509 start(201509) end(201510)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201510 start(201510) end(201511)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201511 start(201511) end(201512)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201512 start(201512) end(201601)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201601 start(201601) end(201602)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201602 start(201602) end(201603)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201603 start(201603) end(201604)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201604 start(201604) end(201605)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201605 start(201605) end(201606)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201606 start(201606) end(201607)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201607 start(201607) end(201608)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201608 start(201608) end(201609)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201609 start(201609) end(201610)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201610 start(201610) end(201611)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201611 start(201611) end(201612)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201612 start(201612) end(201701)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201701 start(201701) end(201702)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201702 start(201702) end(201703)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201703 start(201703) end(201704)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201704 start(201704) end(201705)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201705 start(201705) end(201706)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201706 start(201706) end(201707)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201707 start(201707) end(201708)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201708 start(201708) end(201709)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201709 start(201709) end(201710)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201710 start(201710) end(201711)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201711 start(201711) end(201712)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201712 start(201712) end(201801)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201801 start(201801) end(201802)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201802 start(201802) end(201803)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201803 start(201803) end(201804)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201804 start(201804) end(201805)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201805 start(201805) end(201806)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201806 start(201806) end(201807)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201807 start(201807) end(201808)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201808 start(201808) end(201809)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201809 start(201809) end(201810)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201810 start(201810) end(201811)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201811 start(201811) end(201812)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201812 start(201812) end(201901)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201901 start(201901) end(201902)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201902 start(201902) end(201903)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201903 start(201903) end(201904)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201904 start(201904) end(201905)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201905 start(201905) end(201906)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201906 start(201906) end(201907)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201907 start(201907) end(201908)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201908 start(201908) end(201909)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201909 start(201909) end(201910)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201910 start(201910) end(201911)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201911 start(201911) end(201912)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_201912 start(201912) end(202001)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202001 start(202001) end(202002)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202002 start(202002) end(202003)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202003 start(202003) end(202004)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202004 start(202004) end(202005)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202005 start(202005) end(202006)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202006 start(202006) end(202007)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202007 start(202007) end(202008)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202008 start(202008) end(202009)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202009 start(202009) end(202010)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202010 start(202010) end(202011)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202011 start(202011) end(202012)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202012 start(202012) end(202101)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202101 start(202101) end(202102)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202102 start(202102) end(202103)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202103 start(202103) end(202104)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202104 start(202104) end(202105)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202105 start(202105) end(202106)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202106 start(202106) end(202107)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202107 start(202107) end(202108)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202108 start(202108) end(202109)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202109 start(202109) end(202110)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202110 start(202110) end(202111)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202111 start(202111) end(202112)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202112 start(202112) end(202201)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202201 start(202201) end(202202)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202202 start(202202) end(202203)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202203 start(202203) end(202204)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202204 start(202204) end(202205)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202205 start(202205) end(202206)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202206 start(202206) end(202207)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202207 start(202207) end(202208)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202208 start(202208) end(202209)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202209 start(202209) end(202210)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202210 start(202210) end(202211)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202211 start(202211) end(202212)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202212 start(202212) end(202301)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202301 start(202301) end(202302)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202302 start(202302) end(202303)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202303 start(202303) end(202304)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202304 start(202304) end(202305)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202305 start(202305) end(202306)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202306 start(202306) end(202307)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202307 start(202307) end(202308)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202308 start(202308) end(202309)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202309 start(202309) end(202310)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202310 start(202310) end(202311)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202311 start(202311) end(202312)
;alter table coss_dm.dm_psr_eng_cons_billing_hist_dip    add partition mh_202312 start(202312) end(202401)
```



#### Load Data

```sql
insert into coss_dm.dm_psr_eng_cons_billing_hist_dip
select
  asset_id                                                          as asset_id               -- asset id
  ,asset_name                                                       as asset_name             -- asset name
  ,asset_desc                                                       as asset_desc             -- asset description
  ,i_type_code                                                      as i_type_code            -- installation type code
  ,i_type_desc                                                      as i_type_desc            -- installation type  description
  ,region_rpt                                                       as region_rpt             -- region report
  ,bill_id                                                          as bill_id                -- bill_id
  ,bill_date                                                        as bill_date              -- bill date
  ,tariff_name                                                      as tariff_name            -- tariff name
  ,tariff_desc                                                      as tariff_desc            -- tariff description
  ,utility_name                                                     as utility_name           -- utility name
  ,utility_desc                                                     as utility_desc           -- utility description
  ,kwh_on_peak                                                      as kwh_on_peak            -- power consumption of on peak (kwh)
  ,kwh_off_peak                                                     as kwh_off_peak           -- power consumption of off peak (kwh)
  ,payout                                                           as payout                 -- pay out
  ,total_kwh                                                        as total_kwh              -- power consumption of total (kwh), the calculation logic is (kwh_on_peak + kwh_off_peak)(Unit is ML)
  ,pump_qty                                                         as pump_qty               -- water pumped this month
  ,pump_qty/EXTRACT(DAY FROM (DATE_TRUNC('month',
    to_date(mh,'yyyymm')) +
    INTERVAL '1 month' -
    INTERVAL '1 day'))                                              as avg_flow_rate          -- average rate of flow.(Unit is MLD)
  ,dw_etl_time                                                      as dw_etl_time            -- dw etl time
  ,mh                                                               as mh                     -- partitions for billing date
from coss_dws.dws_psr_eng_cons_billing_details_dip
```



### 2.coss_dm.dm_wtw_eng_cons_billing_hist_dip

#### Create Table

```sql
create table coss_dm.dm_wtw_eng_cons_billing_hist_dip(
  asset_id         decimal(11)
  ,asset_name      varchar(120)
  ,asset_desc      varchar(120)
  ,i_type_code     varchar(150)
  ,i_type_desc     varchar(150)
  ,region_rpt      varchar(150)
  ,bill_id         decimal(20)
  ,bill_date       timestamp(6)
  ,tariff_name     varchar(150)
  ,tariff_desc     varchar(300)
  ,utility_name    varchar(150)
  ,utility_desc    varchar(800)
  ,kwh_on_peak     decimal(10,0)
  ,kwh_off_peak    decimal(10,0)
  ,payout          decimal(10,0)
  ,total_kwh       decimal(10,0)
  ,pump_qty        decimal(20,5)
  ,dw_etl_time     timestamp(6)
  ,mh              decimal(10)
)
with (orientation = column, compression = middle)
distribute by hash("bill_id")
partition by range(mh)
(partition  dt_000000 start(0) end(100000))
;comment on table  coss_dm.dm_wtw_eng_cons_billing_hist_dip                    is 'pump station running billing history'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.asset_id                   is  'asset id'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.asset_name                   is  'asset name'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.asset_desc                   is  'asset description'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.i_type_code                   is  'installation type code'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.i_type_desc                   is  'installation type  description'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.region_rpt                   is  'region report'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.bill_id                   is  'bill_id'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.bill_date                   is  'bill date'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.tariff_name                   is  'tariff name'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.tariff_desc                   is  'tariff description'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.utility_name                   is  'utility name'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.utility_desc                   is  'utility description'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.kwh_on_peak                   is  'power consumption of on peak (kwh)'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.kwh_off_peak                   is  'power consumption of off peak (kwh)'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.payout                   is  'pay out'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.total_kwh                   is  'power consumption of total (kwh), the calculation logic is (kwh_on_peak + kwh_off_peak)'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.pump_qty                   is  'water pumped this month'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.dw_etl_time                   is  'dw etl time'
;comment on column coss_dm.dm_wtw_eng_cons_billing_hist_dip.mh                   is  'partitions for billing date'
```

#### Add Partition

```sql
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_100000 start(100000) end(199601)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199601 start(199601) end(199602)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199602 start(199602) end(199603)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199603 start(199603) end(199604)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199604 start(199604) end(199605)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199605 start(199605) end(199606)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199606 start(199606) end(199607)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199607 start(199607) end(199608)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199608 start(199608) end(199609)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199609 start(199609) end(199610)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199610 start(199610) end(199611)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199611 start(199611) end(199612)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199612 start(199612) end(199701)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199701 start(199701) end(199702)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199702 start(199702) end(199703)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199703 start(199703) end(199704)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199704 start(199704) end(199705)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199705 start(199705) end(199706)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199706 start(199706) end(199707)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199707 start(199707) end(199708)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199708 start(199708) end(199709)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199709 start(199709) end(199710)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199710 start(199710) end(199711)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199711 start(199711) end(199712)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199712 start(199712) end(199801)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199801 start(199801) end(199802)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199802 start(199802) end(199803)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199803 start(199803) end(199804)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199804 start(199804) end(199805)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199805 start(199805) end(199806)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199806 start(199806) end(199807)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199807 start(199807) end(199808)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199808 start(199808) end(199809)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199809 start(199809) end(199810)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199810 start(199810) end(199811)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199811 start(199811) end(199812)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199812 start(199812) end(199901)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199901 start(199901) end(199902)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199902 start(199902) end(199903)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199903 start(199903) end(199904)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199904 start(199904) end(199905)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199905 start(199905) end(199906)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199906 start(199906) end(199907)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199907 start(199907) end(199908)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199908 start(199908) end(199909)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199909 start(199909) end(199910)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199910 start(199910) end(199911)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199911 start(199911) end(199912)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_199912 start(199912) end(200001)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200001 start(200001) end(200002)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200002 start(200002) end(200003)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200003 start(200003) end(200004)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200004 start(200004) end(200005)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200005 start(200005) end(200006)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200006 start(200006) end(200007)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200007 start(200007) end(200008)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200008 start(200008) end(200009)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200009 start(200009) end(200010)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200010 start(200010) end(200011)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200011 start(200011) end(200012)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200012 start(200012) end(200101)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200101 start(200101) end(200102)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200102 start(200102) end(200103)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200103 start(200103) end(200104)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200104 start(200104) end(200105)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200105 start(200105) end(200106)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200106 start(200106) end(200107)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200107 start(200107) end(200108)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200108 start(200108) end(200109)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200109 start(200109) end(200110)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200110 start(200110) end(200111)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200111 start(200111) end(200112)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200112 start(200112) end(200201)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200201 start(200201) end(200202)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200202 start(200202) end(200203)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200203 start(200203) end(200204)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200204 start(200204) end(200205)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200205 start(200205) end(200206)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200206 start(200206) end(200207)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200207 start(200207) end(200208)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200208 start(200208) end(200209)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200209 start(200209) end(200210)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200210 start(200210) end(200211)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200211 start(200211) end(200212)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200212 start(200212) end(200301)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200301 start(200301) end(200302)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200302 start(200302) end(200303)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200303 start(200303) end(200304)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200304 start(200304) end(200305)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200305 start(200305) end(200306)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200306 start(200306) end(200307)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200307 start(200307) end(200308)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200308 start(200308) end(200309)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200309 start(200309) end(200310)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200310 start(200310) end(200311)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200311 start(200311) end(200312)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200312 start(200312) end(200401)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200401 start(200401) end(200402)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200402 start(200402) end(200403)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200403 start(200403) end(200404)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200404 start(200404) end(200405)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200405 start(200405) end(200406)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200406 start(200406) end(200407)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200407 start(200407) end(200408)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200408 start(200408) end(200409)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200409 start(200409) end(200410)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200410 start(200410) end(200411)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200411 start(200411) end(200412)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200412 start(200412) end(200501)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200501 start(200501) end(200502)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200502 start(200502) end(200503)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200503 start(200503) end(200504)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200504 start(200504) end(200505)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200505 start(200505) end(200506)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200506 start(200506) end(200507)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200507 start(200507) end(200508)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200508 start(200508) end(200509)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200509 start(200509) end(200510)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200510 start(200510) end(200511)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200511 start(200511) end(200512)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200512 start(200512) end(200601)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200601 start(200601) end(200602)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200602 start(200602) end(200603)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200603 start(200603) end(200604)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200604 start(200604) end(200605)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200605 start(200605) end(200606)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200606 start(200606) end(200607)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200607 start(200607) end(200608)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200608 start(200608) end(200609)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200609 start(200609) end(200610)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200610 start(200610) end(200611)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200611 start(200611) end(200612)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200612 start(200612) end(200701)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200701 start(200701) end(200702)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200702 start(200702) end(200703)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200703 start(200703) end(200704)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200704 start(200704) end(200705)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200705 start(200705) end(200706)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200706 start(200706) end(200707)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200707 start(200707) end(200708)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200708 start(200708) end(200709)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200709 start(200709) end(200710)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200710 start(200710) end(200711)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200711 start(200711) end(200712)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200712 start(200712) end(200801)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200801 start(200801) end(200802)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200802 start(200802) end(200803)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200803 start(200803) end(200804)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200804 start(200804) end(200805)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200805 start(200805) end(200806)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200806 start(200806) end(200807)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200807 start(200807) end(200808)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200808 start(200808) end(200809)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200809 start(200809) end(200810)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200810 start(200810) end(200811)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200811 start(200811) end(200812)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200812 start(200812) end(200901)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200901 start(200901) end(200902)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200902 start(200902) end(200903)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200903 start(200903) end(200904)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200904 start(200904) end(200905)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200905 start(200905) end(200906)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200906 start(200906) end(200907)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200907 start(200907) end(200908)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200908 start(200908) end(200909)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200909 start(200909) end(200910)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200910 start(200910) end(200911)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200911 start(200911) end(200912)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_200912 start(200912) end(201001)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201001 start(201001) end(201002)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201002 start(201002) end(201003)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201003 start(201003) end(201004)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201004 start(201004) end(201005)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201005 start(201005) end(201006)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201006 start(201006) end(201007)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201007 start(201007) end(201008)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201008 start(201008) end(201009)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201009 start(201009) end(201010)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201010 start(201010) end(201011)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201011 start(201011) end(201012)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201012 start(201012) end(201101)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201101 start(201101) end(201102)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201102 start(201102) end(201103)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201103 start(201103) end(201104)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201104 start(201104) end(201105)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201105 start(201105) end(201106)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201106 start(201106) end(201107)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201107 start(201107) end(201108)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201108 start(201108) end(201109)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201109 start(201109) end(201110)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201110 start(201110) end(201111)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201111 start(201111) end(201112)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201112 start(201112) end(201201)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201201 start(201201) end(201202)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201202 start(201202) end(201203)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201203 start(201203) end(201204)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201204 start(201204) end(201205)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201205 start(201205) end(201206)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201206 start(201206) end(201207)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201207 start(201207) end(201208)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201208 start(201208) end(201209)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201209 start(201209) end(201210)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201210 start(201210) end(201211)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201211 start(201211) end(201212)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201212 start(201212) end(201301)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201301 start(201301) end(201302)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201302 start(201302) end(201303)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201303 start(201303) end(201304)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201304 start(201304) end(201305)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201305 start(201305) end(201306)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201306 start(201306) end(201307)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201307 start(201307) end(201308)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201308 start(201308) end(201309)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201309 start(201309) end(201310)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201310 start(201310) end(201311)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201311 start(201311) end(201312)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201312 start(201312) end(201401)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201401 start(201401) end(201402)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201402 start(201402) end(201403)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201403 start(201403) end(201404)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201404 start(201404) end(201405)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201405 start(201405) end(201406)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201406 start(201406) end(201407)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201407 start(201407) end(201408)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201408 start(201408) end(201409)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201409 start(201409) end(201410)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201410 start(201410) end(201411)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201411 start(201411) end(201412)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201412 start(201412) end(201501)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201501 start(201501) end(201502)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201502 start(201502) end(201503)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201503 start(201503) end(201504)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201504 start(201504) end(201505)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201505 start(201505) end(201506)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201506 start(201506) end(201507)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201507 start(201507) end(201508)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201508 start(201508) end(201509)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201509 start(201509) end(201510)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201510 start(201510) end(201511)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201511 start(201511) end(201512)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201512 start(201512) end(201601)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201601 start(201601) end(201602)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201602 start(201602) end(201603)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201603 start(201603) end(201604)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201604 start(201604) end(201605)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201605 start(201605) end(201606)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201606 start(201606) end(201607)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201607 start(201607) end(201608)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201608 start(201608) end(201609)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201609 start(201609) end(201610)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201610 start(201610) end(201611)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201611 start(201611) end(201612)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201612 start(201612) end(201701)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201701 start(201701) end(201702)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201702 start(201702) end(201703)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201703 start(201703) end(201704)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201704 start(201704) end(201705)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201705 start(201705) end(201706)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201706 start(201706) end(201707)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201707 start(201707) end(201708)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201708 start(201708) end(201709)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201709 start(201709) end(201710)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201710 start(201710) end(201711)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201711 start(201711) end(201712)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201712 start(201712) end(201801)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201801 start(201801) end(201802)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201802 start(201802) end(201803)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201803 start(201803) end(201804)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201804 start(201804) end(201805)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201805 start(201805) end(201806)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201806 start(201806) end(201807)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201807 start(201807) end(201808)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201808 start(201808) end(201809)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201809 start(201809) end(201810)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201810 start(201810) end(201811)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201811 start(201811) end(201812)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201812 start(201812) end(201901)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201901 start(201901) end(201902)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201902 start(201902) end(201903)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201903 start(201903) end(201904)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201904 start(201904) end(201905)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201905 start(201905) end(201906)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201906 start(201906) end(201907)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201907 start(201907) end(201908)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201908 start(201908) end(201909)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201909 start(201909) end(201910)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201910 start(201910) end(201911)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201911 start(201911) end(201912)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_201912 start(201912) end(202001)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202001 start(202001) end(202002)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202002 start(202002) end(202003)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202003 start(202003) end(202004)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202004 start(202004) end(202005)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202005 start(202005) end(202006)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202006 start(202006) end(202007)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202007 start(202007) end(202008)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202008 start(202008) end(202009)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202009 start(202009) end(202010)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202010 start(202010) end(202011)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202011 start(202011) end(202012)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202012 start(202012) end(202101)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202101 start(202101) end(202102)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202102 start(202102) end(202103)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202103 start(202103) end(202104)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202104 start(202104) end(202105)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202105 start(202105) end(202106)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202106 start(202106) end(202107)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202107 start(202107) end(202108)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202108 start(202108) end(202109)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202109 start(202109) end(202110)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202110 start(202110) end(202111)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202111 start(202111) end(202112)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202112 start(202112) end(202201)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202201 start(202201) end(202202)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202202 start(202202) end(202203)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202203 start(202203) end(202204)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202204 start(202204) end(202205)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202205 start(202205) end(202206)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202206 start(202206) end(202207)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202207 start(202207) end(202208)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202208 start(202208) end(202209)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202209 start(202209) end(202210)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202210 start(202210) end(202211)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202211 start(202211) end(202212)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202212 start(202212) end(202301)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202301 start(202301) end(202302)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202302 start(202302) end(202303)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202303 start(202303) end(202304)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202304 start(202304) end(202305)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202305 start(202305) end(202306)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202306 start(202306) end(202307)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202307 start(202307) end(202308)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202308 start(202308) end(202309)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202309 start(202309) end(202310)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202310 start(202310) end(202311)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202311 start(202311) end(202312)
;alter table coss_dm.dm_wtw_eng_cons_billing_hist_dip    add partition mh_202312 start(202312) end(202401)
```

#### Load Data

```sql
insert into coss_dm.dm_wtw_eng_cons_billing_hist_dip
select
  asset_id
  ,asset_name
  ,asset_desc
  ,i_type_code
  ,i_type_desc
  ,region_rpt
  ,bill_id
  ,bill_date
  ,tariff_name
  ,tariff_desc
  ,utility_name
  ,utility_desc
  ,kwh_on_peak
  ,kwh_off_peak
  ,payout
  ,total_kwh
  ,pump_qty
  ,dw_etl_time
  ,mh
from coss_dws.dws_wtw_eng_cons_billing_details_dip

```

### 3.pump station metircs

#### 1.Fresh water pump station energy consumption(pump_qty) in  last six months

```sql
/**
 * delete history metrics data
*/

;delete 
from coss_dm.dm_psr_region_month_kpi_dip
where item_code in(
  'bi_p_001'
  ,'bi_p_002'
  ,'bi_p_015'
  ,'bi_p_016')

;with t_a as(
  select 
  mh
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where i_type_code = 'FW'
  or i_type_code = 'RW'
group by 
  mh
  ,region_rpt
), t_b as(
select 
  mh
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where i_type_code = 'FW'
  or i_type_code = 'RW'
group by 
  mh       
)
insert into coss_dm.dm_psr_region_month_kpi_dip
-- Fresh water pump station energy consumption in last six months
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_001'                        as item_code
  ,'Fresh water pump station energy consumption in last six months' as item_name                       
  ,sum(t.total_kwh) over(
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'KWH'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all
-- Fresh water pump station energy consumption in last six months
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_002'                        as item_code
  ,'Fresh water pump station energy consumption in last six months' as item_name                       
  ,sum(t.total_kwh) over(
  partition by region
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'KWH'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t

union all 
-- Fresh water pump station pumped quantity in last six months
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_015'                        as item_code
  ,'Fresh water pump station pumped quantity in last six months' as item_name                       
  ,sum(t.pump_qty) over(
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all 
-- Fresh water pump station pumped quantity in last six months
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_016'                        as item_code
  ,'Fresh water pump station pumped quantity in last six months' as item_name                       
  ,sum(t.pump_qty) over(
  partition by region
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t



```

#### 2.Salt water pump station energy consumption in  last six months

```sql
/**
 * delete history metrics data
*/
;delete 
from coss_dm.dm_psr_region_month_kpi_dip
where item_code in ('bi_p_003'
  ,'bi_p_004'
  ,'bi_p_017'
  ,'bi_p_018')


;with t_a as(
  select 
  mh
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000 pump_qty
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where i_type_code = 'SW'
group by 
  mh
  ,region_rpt
), t_b as(
select 
  mh
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000 pump_qty
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where i_type_code = 'SW'
group by 
  mh
)

insert into coss_dm.dm_psr_region_month_kpi_dip
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_003'                        as item_code
  ,'Salt water pump station energy consumption in  last six months' as item_name                       
  ,sum(t.total_kwh) over(
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'KWH'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all 
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_004'                        as item_code
  ,'Salt water pump station energy consumption in  last six months' as item_name                       
  ,sum(t.total_kwh) over(
  partition by region
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'KWH'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t

union all 
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_017'                        as item_code
  ,'Salt water pump station pumped quantity in last six months' as item_name                       
  ,sum(t.pump_qty) over(
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all 
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_018'                        as item_code
  ,'Salt water pump station pumped quantity in last six months' as item_name                       
  ,sum(t.pump_qty) over(
  partition by region
  order by mh desc
  rows between current row and 5 following ) as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t

```

#### 3.Salt water pump station Unit energy consumption

```sql
/**
 * delete history metrics data
*/
;delete 
from coss_dm.dm_psr_region_month_kpi_dip
where item_code in ('bi_p_005', 'bi_p_006')

;with t_a as(
select 
  mh
  ,region_rpt region
  ,sum(total_kwh)/(sum(pump_qty)*1000) as value
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where i_type_code = 'SW'
  and pump_qty is not null 
  and pump_qty != 0
group by 
  mh
  ,region
), t_b as(
select 
  mh
  ,sum(total_kwh)/(sum(pump_qty)*1000) as value
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where i_type_code = 'SW'
  and pump_qty is not null 
  and pump_qty != 0
group by 
  mh
)

insert into coss_dm.dm_psr_region_month_kpi_dip
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_005'                        as item_code
  ,'Salt water pump station Unit energy consumption' as item_name                       
  ,value as item_value
  ,'KWH/cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t
union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_006'                        as item_code
  ,'Salt water pump station Unit energy consumption' as item_name                       
  ,value as item_value
  ,'KWH/cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t
```

#### 4.Fresh water pump station Unit energy consumption

```sql
/**
 * delete history metrics data
*/
;delete 
from coss_dm.dm_psr_region_month_kpi_dip
where item_code in ('bi_p_007', 'bi_p_008')


;with t_a as(
select 
  mh
  ,region_rpt region
  ,sum(total_kwh)/(sum(pump_qty)*1000) as value
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where (i_type_code = 'FW'
  or i_type_code = 'RW')
  and pump_qty is not null 
  and pump_qty != 0
group by 
  mh
  ,region
), t_b as(
select 
  mh
  ,sum(total_kwh)/(sum(pump_qty)*1000) as value
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where (i_type_code = 'FW'
  or i_type_code = 'RW')
  and pump_qty is not null 
  and pump_qty != 0
group by 
  mh
)

insert into coss_dm.dm_psr_region_month_kpi_dip
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_007'                        as item_code
  ,'Fresh water pump station Unit energy consumption' as item_name                       
  ,value as item_value
  ,'KWH/cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t
union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_008'                        as item_code
  ,'Fresh water pump station Unit energy consumption' as item_name                       
  ,value as item_value
  ,'KWH/cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t

```

### 4.water treatment works metircs

```sql
/**
 * delete history metrics data
*/
;delete 
from coss_dm.dm_wtw_region_month_kpi_dip
where item_code in ('bi_p_009'
  ,'bi_p_010'
  ,'bi_p_011'
  ,'bi_p_012'
  ,'bi_p_013'
  ,'bi_p_014')

;with t_a as(
select 
mh
,region
,value
,sum(value) over(
  partition by region
  order by mh desc
  rows between current row and 5 following ) value_6
from(
select 
mh
,region_rpt as region
,sum(total_kwh)/sum(pump_qty) as value
from coss_dm.dm_wtw_eng_cons_billing_hist_dip
where pump_qty is not null 
  and pump_qty != 0
group by 
mh
,region
) t
),t_b as(
select 
mh
,value
,sum(value) over(
  order by mh desc
  rows between current row and 5 following ) value_6
from
(
select 
mh
,sum(total_kwh)/sum(pump_qty) as value
from coss_dm.dm_wtw_eng_cons_billing_hist_dip
where pump_qty is not null 
  and pump_qty != 0
group by 
mh
) t
)

insert into coss_dm.dm_wtw_region_month_kpi_dip
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_009'                        as item_code
  ,'Water treatment works of energy consumption per million litres in last six months' as item_name                       
  ,value_6 as item_value
  ,'KWH/ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all 
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_010'                        as item_code
  ,'Water treatment works of energy consumption per million litres in last six months' as item_name                       
  ,value_6 as item_value
  ,'KWH/ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t

union all
-- HKSAR Year-On-Year Rises Of Raw Water Propose Supply Volume
select
  uuid()                                                    as id
  ,'HKSAR'                                                  as region
  ,'bi_p_011'                                               as item_code
  ,'Year-On-Year Rises Of Water treatment works of energy consumption per million litres'  as item_name
  ,case
    when t1.value_6 is null then 0.0
    else (t.value_6 - t1.value_6) / t1.value_6 * 100
  end                                                       as item_value
  ,'%'                                                      as unit
  ,localtimestamp                                           as etl_time
  ,t.mh                                                     as mh
from t_b t
left join t_b t1 on  t.mh = t1.mh + 100

union all

select
  uuid()                                                   as id
  ,t.region                                                as region
  ,'bi_p_012'                                              as item_code
  ,'Year-On-Year Rises Of Water treatment works of energy consumption per million litres' as item_name
  ,case
    when t1.value_6 is null then 0.0
    else (t.value_6 - t1.value_6) / t1.value_6 * 100
  end                                                      as item_value
  ,'%'                                                     as unit
  ,localtimestamp                                          as etl_time
  ,t.mh                                                    as mh
from t_a t
left join t_a t1 on t.region = t1.region and t.mh = t1.mh+100


union all 
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_013'                        as item_code
  ,'Water treatment works of energy consumption per million litres' as item_name                       
  ,value as item_value
  ,'KWH/ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all 
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_014'                        as item_code
  ,'Water treatment works of energy consumption per million litres' as item_name                       
  ,value as item_value
  ,'KWH/ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t

```

### 5.Pump Station year accumulative

```sql
/**
 * delete history metrics data
*/

;delete 
from coss_dm.dm_psr_region_month_kpi_dip
where item_code in(
  'bi_p_022'
  ,'bi_p_023'
  ,'bi_p_024'
  ,'bi_p_025'
  ,'bi_p_026'
  ,'bi_p_027'
  ,'bi_p_028'
  ,'bi_p_029'
  ,'bi_p_031'
  ,'bi_p_032')

;with t_a as(
select
  rec_mh                                               as rec_mh
  ,region                                              as region
  ,total_kwh                                           as total_kwh
  ,pump_qty                                            as pump_qty
  ,sum(total_kwh) over(
    partition by region
    ,rec_yr
    order by rec_mh desc
    rows between current row and unbounded following ) as total_kwh_accumulated
  ,sum(pump_qty) over(
    partition by region
    ,rec_yr
    order by rec_mh desc
    rows between current row and unbounded following ) as pump_qty_accumulated
from
(select
  round(mh/100, 0)  as rec_yr
  ,mh               as rec_mh
  ,region_rpt       as region
  ,sum(total_kwh)   as total_kwh
  ,sum(pump_qty)    as pump_qty
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where (i_type_code = 'FW'
  or i_type_code = 'RW')
  and pump_qty != 0 
  and pump_qty is not null 
  and total_kwh != 0
  and pump_qty is not null 
group by
  mh
  ,region
) t
), t_b as(
select
  rec_mh                                               as rec_mh
  ,total_kwh                                           as total_kwh
  ,pump_qty                                            as pump_qty
  ,sum(total_kwh) over(
    partition by rec_yr
    order by rec_mh desc
    rows between current row and unbounded following ) as total_kwh_accumulated
  ,sum(pump_qty) over(
    partition by rec_yr
    order by rec_mh desc
    rows between current row and unbounded following ) as pump_qty_accumulated
from
(select
  round(mh/100, 0) as rec_yr
  ,mh              as rec_mh
  ,sum(total_kwh)  as total_kwh
  ,sum(pump_qty)   as pump_qty
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where (i_type_code = 'FW'
  or i_type_code = 'RW')
  and pump_qty != 0 
  and pump_qty is not null 
  and total_kwh != 0
  and pump_qty is not null 
group by
  mh ) t
)

insert into  coss_dm.dm_psr_region_month_kpi_dip
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_022'                        as item_code
  ,'Fresh water pump station of energy consumption per million litres in accumulated by year' as item_name
  ,total_kwh_accumulated/pump_qty_accumulated     as item_value
  ,'KWH/ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.rec_mh                              as mh
from t_b t

union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_023'                        as item_code
  ,'Fresh water pump station of energy consumption per million litres in accumulated by year' as item_name
  ,total_kwh_accumulated/pump_qty_accumulated     as item_value
  ,'KWH/ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.rec_mh                              as mh
from t_a t

union all
select
  uuid()                                                    as id
  ,'HKSAR'                                                  as region
  ,'bi_p_024'                                               as item_code
  ,'Year-On-Year Rises Of Fresh water pump station of energy consumption per million litres in accumulated by year'  as item_name
  ,case
    when (t1.total_kwh_accumulated/t1.pump_qty_accumulated) is null then 0.0
    else ((t.total_kwh_accumulated/t.pump_qty_accumulated) - (t1.total_kwh_accumulated/t1.pump_qty_accumulated)) / (t1.total_kwh_accumulated/t1.pump_qty_accumulated) * 100
  end                                                       as item_value
  ,'%'                                                      as unit
  ,localtimestamp                                           as etl_time
  ,t.rec_mh                                                     as mh
from t_b t
left join t_b t1 on  t.rec_mh = t1.rec_mh + 100

union all
select
  uuid()                                                   as id
  ,t.region                                                as region
  ,'bi_p_025'                                              as item_code
  ,'Year-On-Year Rises Of Fresh water pump station of energy consumption per million litres in accumulated by year' as item_name
  ,case
    when (t1.total_kwh_accumulated/t1.pump_qty_accumulated) is null then 0.0
    else ((t.total_kwh_accumulated/t.pump_qty_accumulated) - (t1.total_kwh_accumulated/t1.pump_qty_accumulated)) / (t1.total_kwh_accumulated/t1.pump_qty_accumulated) * 100
  end                                                      as item_value
  ,'%'                                                     as unit
  ,localtimestamp                                          as etl_time
  ,t.rec_mh                                                    as mh
from t_a t
left join t_a t1 on t.region = t1.region and t.rec_mh = t1.rec_mh+100

union all
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_026'                        as item_code
  ,'Fresh water pump station of water pumped volume in accumulated by year' as item_name                       
  ,pump_qty_accumulated/10     as item_value   -- convert ML to 万立方米
  ,'10ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.rec_mh                              as mh
from t_b t

union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_027'                        as item_code
  ,'Fresh water pump station of water pumped volume in accumulated by year' as item_name
  ,pump_qty_accumulated/10             as item_value  -- convert ML to 万立方米
  ,'10ML'                             as unit
  ,localtimestamp                    as etl_time
  ,t.rec_mh                              as mh
from t_a t

union all 
select
  uuid()                                                    as id
  ,'HKSAR'                                                  as region
  ,'bi_p_028'                                               as item_code
  ,'Year-On-Year Rises Of Fresh water pump station of water pumped volume in accumulated by year'  as item_name
  ,case
    when t1.pump_qty_accumulated is null then 0.0
    else (t.pump_qty_accumulated - t1.pump_qty_accumulated) / t1.pump_qty_accumulated * 100
  end                                                       as item_value
  ,'%'                                                      as unit
  ,localtimestamp                                           as etl_time
  ,t.rec_mh                                                     as mh
from t_b t
left join t_b t1 on  t.rec_mh = t1.rec_mh + 100

union all
select
  uuid()                                                   as id
  ,t.region                                                as region
  ,'bi_p_029'                                              as item_code
  ,'Year-On-Year Rises Of Fresh water pump station of water pumped volume in accumulated by year' as item_name
  ,case
    when t1.pump_qty_accumulated is null then 0.0
    else (t.pump_qty_accumulated - t1.pump_qty_accumulated) / t1.pump_qty_accumulated * 100
  end                                                      as item_value
  ,'%'                                                     as unit
  ,localtimestamp                                          as etl_time
  ,t.rec_mh                                                    as mh
from t_a t
left join t_a t1 on t.region = t1.region and t.rec_mh = t1.rec_mh+100

union all
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_031'                        as item_code
  ,'Fresh water pump station of water pumped volume in accumulated by year' as item_name                       
  ,pump_qty_accumulated*1000     as item_value   -- convert ML to 立方米
  ,'cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.rec_mh                              as mh
from t_b t

union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_032'                        as item_code
  ,'Fresh water pump station of water pumped volume in accumulated by year' as item_name
  ,pump_qty_accumulated*1000             as item_value  -- convert ML to 立方米
  ,'cum'                             as unit
  ,localtimestamp                    as etl_time
  ,t.rec_mh                              as mh
from t_a t
```

### 6.Maximum instantaneous flow

```sql
/**
 * delete history metrics data
*/

;delete 
from coss_dm.dm_psr_region_month_kpi_dip
where item_code in(
  'bi_p_034'
  ,'bi_p_035')


;with t_a as(
select 
  region_rpt           as region
  ,mh                  as mh
  ,max(avg_flow_rate)  as avg_flow_rate
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where avg_flow_rate is not null 
group by
  region_rpt
  ,mh
), t_b as(
select 
  mh                  as mh
  ,max(avg_flow_rate) as avg_flow_rate
from coss_dm.dm_psr_eng_cons_billing_hist_dip
where avg_flow_rate is not null 
group by
  mh
)
insert into coss_dm.dm_psr_region_month_kpi_dip
select
  uuid()                             as id
  ,'HKSAR'                          as region
  ,'bi_p_034'                        as item_code
  ,'Maximum instantaneous flow' as item_name                       
  ,avg_flow_rate     as item_value  
  ,'MLD'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_b t

union all
select
  uuid()                             as id
  ,t.region                          as region
  ,'bi_p_035'                        as item_code
  ,'Maximum instantaneous flow' as item_name
  ,avg_flow_rate             as item_value  
  ,'MLD'                             as unit
  ,localtimestamp                    as etl_time
  ,t.mh                              as mh
from t_a t
```





