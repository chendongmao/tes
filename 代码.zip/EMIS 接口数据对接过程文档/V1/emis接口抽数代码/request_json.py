import requests
import pandas as pd
import gaussdb
import json
# get report asset id list
def get_asset_id():
    with open('data/asset_id.txt', 'r', encoding='utf-8') as file:
        content = file.read()  # 读取全部内容为字符串
    return content.split('\n')

def get_bills(url):
    headers = {'Content-Type': 'application/json'}
    data = requests.get(url, headers=headers, verify=False).json()
    results = data['results']
    res = []
    for i in range(len(results)):
        # get head info
        location = results[i]['location']
        bills = results[i]['bills']
        # get columns info
        asset_name = location["Location"]
        asset_id = location['id']
        for j in range(len(bills)):
            bill_date = bills[j]['Date']
            traiff = bills[j]['Tariff']
            traiff_desc = bills[j]['Tariff Description']
            on_peak_kwh = bills[j]['On Peak kWh']
            off_peak_kwh = bills[j]['Off Peak kWh']
            on_peak_kva = bills[j]['On Peak kVA']
            off_peak_kva = bills[j]['Off Peak kVA']
            bill_amount = bills[j]['Bill amount']
            res.append([asset_name, asset_id, bill_date, traiff, traiff_desc, on_peak_kwh, off_peak_kwh, on_peak_kva,
                        off_peak_kva, bill_amount])

    return res

#get a asset report of history data
def get_pump_report(url, asset_id):
    re = []
    headers = {'Content-Type': 'application/json'}
    data = requests.get(url, headers=headers, verify=False)
    # print(data.json())
    # print(data.json()['location']['id'])
    rpt_id = 'null'
    asset_id = data.json()['location']['id']
    report = data.json()['reports']
    for i in range(len(report)):
        # print(report[i]['per_destination'])
        per_destination = report[i]['per_destination']
        mh = report[i]['date'].replace('-', '')
        for j in range(len(per_destination)):
            pump_num = per_destination[j]['Pump_Number']
            cat_id = 'null'
            cat_name = per_destination[j]['category']
            drive_id = 'null'
            drive_name = per_destination[j]['drive']
            del_id = 'null'
            del_name = per_destination[j]['destination']
            del_asset_id = per_destination[j]['dest_id']
            design_flow = 'null'
            run_hours = per_destination[j]['Hours_Run_This_Month']
            pump_qty = per_destination[j]['Water_Pumped_This_Month']
            avg_suct = per_destination[j]['Average_Head_Suct']
            avg_del = per_destination[j]['Average_Head_Del']
            design_flow_flag = 'null'
            run_hours_flag = 'null'
            pump_qty_flag = 'null'
            avg_suct_flag = 'null'
            avg_del_flag = 'null'
            dw_etl_time = 'null'
            # print(report[i]['per_equipment'])
            re.append([rpt_id, asset_id, pump_num, cat_id, cat_name, drive_id, drive_name, del_id, del_name, del_asset_id,
                  design_flow, run_hours, pump_qty, avg_suct, avg_del, design_flow_flag, run_hours_flag, pump_qty_flag,
                  avg_suct_flag, avg_del_flag, dw_etl_time, mh])
    return re

def fetch_data_from_api(api_url: str, headers: dict = None, params: dict = None) -> pd.DataFrame:
    """
    Fetch data from specified API and convert to DataFrame

    Args:
        api_url (str): API URL
        headers (dict): Request headers, default is None
        params (dict): Request parameters, default is None

    Returns:
        pd.DataFrame: DataFrame containing API data
    """
    try:
        response = requests.post(api_url, headers=headers, data=json.dumps(params))
        print('Response is: ',response.text[:200])
        data = response.json()['data']
        df = pd.DataFrame(data)
        print(f'Successfully fetched {len(df)} records')
        return df
    except requests.exceptions.RequestException as e:
        print(f'API request error: {e}')
        return pd.DataFrame()
    except ValueError as e:
        print(f'JSON parsing error: {e}')
        return pd.DataFrame()


def save_to_gaussdb(df: pd.DataFrame, db_config: dict, table_name: str, constraint_keys: list) -> None:
    """
    Save DataFrame to GaussDB database

    Args:
        df (pd.DataFrame): DataFrame to be saved
        db_config (dict): Database connection configuration
        table_name (str): Target table name
        constraint_keys (list): The constraint key of the table
    """
    if df.empty:
        print('DataFrame is empty, skipping database save')
        return

    # Connect to database and save the data to the database
    try:
        conn = gaussdb.GaussDB(**db_config)
        conn.insert_data(df, table_name, constraint_keys)
    except Exception as e:
        print(f'Database error: {e}')
