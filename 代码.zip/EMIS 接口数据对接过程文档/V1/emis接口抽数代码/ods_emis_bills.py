import requests
import json
import config
import request_json
import pandas as pd

# star = str(pd.Timestamp.now() - pd.DateOffset(months=6))[:8]+'01'
# end = str(pd.Timestamp.now())[:10]
star = '2025-01-01'
end = '2026-01-01'


url = 'https://wiki.sis2.wsd.gov/ems/webresources/bills?from='+star+'&to='+end
data = request_json.get_bills(url)
col = ['asset_name', 'asset_id', 'bill_date', 'traiff', 'traiff_desc', 'on_peak_kwh', 'off_peak_kwh', 'on_peak_kva',
                        'off_peak_kva', 'bill_amount']
df = pd.DataFrame(data,columns=col)
df["ods_load_time"] = pd.Timestamp.now()


# Target table name and constraint keys
TABLE_NAME = 'coss_ods.ods_emis_bills_di_year'
CONSTRAINT_KEYS = []
# Save to GaussDB if DataFrame is not empty
if not df.empty:
    request_json.save_to_gaussdb(df, config.GAUSSDB_DWS, TABLE_NAME, CONSTRAINT_KEYS)    # API Configuration
