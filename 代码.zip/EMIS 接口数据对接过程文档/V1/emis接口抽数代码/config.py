# -*- coding: utf-8 -*-
# File : Config.py
# Author : XJH
# Date : 2025/5/12 09:45

# Database configuration file
GAUSSDB_DWS = {
     'host_list': ['10.66.110.64','10.66.110.151','10.66.110.194','10.66.110.235'],
     'dbname': 'wsd',
     'user': 'coss',
     'password': 'COSS@wsd2nd',
     'port': 8000,
     'min_conn': 5,
     'max_conn': 20
 }


# API Configuration
API_URL = 'http://test.inms.wsd.hksarg/api/execSql'
#API_URL = 'http://172.16.201.10:5000/execute_sql'
HEADERS = {
    'Content-Type': 'application/json'
}
BODY = {
    'caller': 'COSS',
    'sql': ''
}

# SFTP connection parameters
SFTP = {
    'host': '10.66.131.9',
    'port': 2200,
    'username': 'coss',
    'password': 'CosS@wsd.123'
}

# Remote base directory path on SFTP server
REMOTE_BASE_DIR = r'/'

# File pattern and local directory path to save files of DMA_KPI_YEAR table
DMA_KPI_YEAR_FILE_PATTERN = 'COSS_DMA_KPI_YEAR'
DMA_KPI_YEAR_LOCAL_DIR = r'/opt/app/coss/inms/file'

# File pattern and local directory path to save files of DMA_MNF table
DMA_MNF_FILE_PATTERN = 'COSS_DMA_MNF'
DMA_MNF_LOCAL_DIR = r'/opt/app/coss/inms/file'

# File pattern and local directory path to save files of DMA_KPI_DAY table
DMA_KPI_DAY_FILE_PATTERN = 'COSS_DMA_KPI_DAY'
DMA_KPI_DAY_LOCAL_DIR = r'/opt/app/coss/inms/file'

# File pattern and local directory path to save files of DDL_DATA_RT table
DDL_DATA_RT_FILE_PATTERN = 'COSS_DDL_DATA_RT'
DDL_DATA_RT_LOCAL_DIR = r'/opt/app/coss/inms/file'

# File pattern and local directory path to save files of NOISE_LOGGER_DATA_RT table
NOISE_LOGGER_DATA_RT_FILE_PATTERN = 'COSS_NOISE_LOGGER_DATA_RT'
NOISE_LOGGER_DATA_RT_LOCAL_DIR = r'C:\Users\gddst\OneDrive\Desktop\file'

# File pattern and local directory path to save files of REGION_KPI_DAY table
REGION_KPI_DAY_FILE_PATTERN = 'COSS_REGION_KPI_DAY'
REGION_KPI_DAY_LOCAL_DIR = r'/opt/app/coss/inms/file'

