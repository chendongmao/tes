import requests
import pandas as pd
import request_json
import json
asset_list = request_json.get_asset_id()
import config
# star = str(pd.Timestamp.now() - pd.DateOffset(months=6))[:8]+'01'
# end = str(pd.Timestamp.now())[:10]
star = '2025-01-02'
end = '2026-01-01'

res = []
for ast in asset_list:
    url = 'https://wiki.sis2.wsd.gov/ems/webresources/reports?loc_id='+ast+'&from='+star+'&to='+end
    re = request_json.get_pump_report(url,ast)
    res.append(re)
    print(ast)

# 将不规则的数组转化为标准的二维数组
re = []
for ase in res:
    for i in ase:
        re.append(i)       
print(len(re))
# 把标准的二维数组转化成 pd.data_frame
col = ["rpt_id","asset_id","pump_num","cat_id","cat_name","drive_id","drive_name","del_id","del_name","del__asset_id","design_flow","run_hours","pump_qty","avg_suct","avg_del","design_flow_flag","run_hours_flag","pump_qty_flag","avg_suct_flag","avg_del_flag","dw_etl_time","mh"]
df = pd.DataFrame(re,columns=col)
df["ods_load_time"] = pd.Timestamp.now()

# Target table name and constraint keys
TABLE_NAME = 'coss_ods.ods_emis_report_di_year'
CONSTRAINT_KEYS = []
# Save to GaussDB if DataFrame is not empty
if not df.empty:
    request_json.save_to_gaussdb(df, config.GAUSSDB_DWS, TABLE_NAME, CONSTRAINT_KEYS)    # API Configuration

