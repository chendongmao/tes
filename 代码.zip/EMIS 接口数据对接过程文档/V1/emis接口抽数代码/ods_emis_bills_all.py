yr_list = """2008-01-01,2008-12-31
2009-01-01,2009-12-31
2010-01-01,2010-12-31
2011-01-01,2011-12-31
2012-01-01,2012-12-31
2013-01-01,2013-12-31
2014-01-01,2014-12-31
2015-01-01,2015-12-31
2016-01-01,2016-12-31
2017-01-01,2017-12-31
2018-01-01,2018-12-31
2019-01-01,2019-12-31
2020-01-01,2020-12-31
2021-01-01,2021-12-31
2022-01-01,2022-12-31
2023-01-01,2023-12-31
2024-01-01,2024-12-31
2025-01-01,2025-12-31""".split('\n')

import requests
import json
import config
import request_json
import pandas as pd

# star = str(pd.Timestamp.now() - pd.DateOffset(months=6))[:8]+'01'
# end = str(pd.Timestamp.now())[:10]
for i in yr_list:
    print(i)
    star = i.split(',')[0]
    end = i.split(',')[1]
    url = 'https://wiki.sis2.wsd.gov/ems/webresources/bills?from='+star+'&to='+end
    data = request_json.get_bills(url)
    col = ['asset_name', 'asset_id', 'bill_date', 'traiff', 'traiff_desc', 'on_peak_kwh', 'off_peak_kwh', 'on_peak_kva',
                            'off_peak_kva', 'bill_amount']
    df = pd.DataFrame(data,columns=col)
    df["ods_load_time"] = pd.Timestamp.now()


    # Target table name and constraint keys
    TABLE_NAME = 'coss_ods.ods_emis_bills_di_year'
    CONSTRAINT_KEYS = []
    # Save to GaussDB if DataFrame is not empty
    if not df.empty:
        request_json.save_to_gaussdb(df, config.GAUSSDB_DWS, TABLE_NAME, CONSTRAINT_KEYS)    # API Configuration
