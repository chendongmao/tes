# -*- coding: utf-8 -*-
# File : Config.py
# Author : XJH
# Date : 2025/5/12 09:45

import psycopg2
from psycopg2 import pool
import random
from typing import List, Dict, Any, Optional
import pandas as pd


class GaussDB:
    """GaussDB Database Connection and Operation Class"""

    def __init__(self, host_list: [str], dbname: str, user: str, password: str, port: int, min_conn: int, max_conn: int):
        """
         Initialize the connection pool manager

        Args:
            dbname (str): Database name
            user (str): Database user
            password (str): Database password
            host_list ([str]): List of database server hostnames or IPs
            port (int): Database port (default: 5432)
            min_conn (int): Minimum number of connections in the pool (default: 5)
            max_conn (int): Maximum number of connections in the pool (default: 20)
        """
        self.host_list = host_list
        self.dbname = dbname
        self.user = user
        self.password = password
        self.port = port
        self.min_conn = min_conn
        self.max_conn = max_conn

        # Initialize connection pools for each host
        self.pools: Dict[str, pool.SimpleConnectionPool] = {}
        for host in self.host_list:
            try:
                self.pools[host] = pool.SimpleConnectionPool(
                    self.min_conn,
                    self.max_conn,
                    dbname = self.dbname,
                    user = self.user,
                    password = self.password,
                    host = host,
                    port = self.port
                )
                print(f"Connection pool initialized for host: {host}")
            except Exception as e:
                print(f"Failed to initialize pool for host {host}: {str(e)}")

    def _get_random_host(self) -> str:
        """Get a random host from the host list for load balancing"""
        return random.choice(self.host_list)

    def get_connection(self):
        """
        Get a database connection from the pool with load balancing

        Returns:
            A database connection or None if all connections failed
        """
        # Attempt to get a connection with retry logic
        for _ in range(len(self.host_list)):
            host = self._get_random_host()
            pool = self.pools.get(host)

            if not pool:
                continue

            try:
                conn = pool.getconn()
                print(f"Connection acquired from pool of host: {host}")
                return conn
            except Exception as e:
                print(f"Failed to get connection from host {host}: {str(e)}")

        print("Failed to get connection from all hosts")
        return None

    def release_connection(self, conn: psycopg2.extensions.connection) -> None:
        """
        Release a database connection back to the pool

        Args:
            conn: Database connection to release
        """
        if not conn:
            return

        host = conn.info.host
        if host and host in self.pools:
            self.pools[host].putconn(conn)
            print(f"Connection released back to pool of host: {host}")
        else:
            print("Warning: Could not determine host for connection release")

    def close_all_connections(self) -> None:
        """Close all connections in the pools and clean up resources"""
        for host, pool in self.pools.items():
            try:
                if pool:
                    pool.closeall()
                    print(f"All connections closed for host: {host}")
            except Exception as e:
                print(f"Error closing connections for host {host}: {str(e)}")

    def __enter__(self) -> 'GaussDB':
        """Support for context manager (with statement)"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Ensure resources are cleaned up when exiting context manager"""
        self.close_all_connections()

    def insert_data(self, df: pd.DataFrame, table_name: str, constraint_keys: list) -> bool | None:
        """
        Batch insert data into specified table, handle null values and support conflict updates

        Args:
            df (pd.DataFrame): pandas DataFrame data
            table_name (str): Target table name
            constraint_keys (list): The constraint key of the table

        Returns:
            True if insertion is successful, False otherwise
        """
        conn = self.get_connection()
        if not conn:
            return False

        try:
            # Get column names
            columns = df.columns.tolist()

            # Construct SQL insert statement
            insert_sql = f"insert into {table_name} ({', '.join(columns)}) values ({','.join(['%s'] * len(columns))})"

            final_sql = insert_sql

            # Convert DataFrame to list of tuples and clean data
            data = [tuple(None if pd.isna(value) else value for value in row) for row in df.values]

            # Use executemany to batch insert data
            with conn.cursor() as cur:
                cur.executemany(final_sql, data)
                conn.commit()
                print(f'Successfully inserted {len(data)} records into table: {table_name}')

            return True

        except Exception as e:
            print(f'Data insertion failed: {e}')
            conn.rollback()
            return False

        finally:
            if conn:
                self.release_connection(conn)

    def fetch_data(self, query: str):
        """
        Retrieve data from table, supporting batch retrieval

        Args:
            query (str): SELECT query statement

        Returns:
            Query results if successful, None otherwise
        """
        conn = self.get_connection()
        if not conn:
            return None

        try:
            # Execute query and return results
            with conn.cursor() as cur:
                cur.execute(query)
                result = cur.fetchall()

            return result

        except Exception as e:
            print(f'Error retrieving table data: {e}')
            return None

        finally:
            if conn:
                self.release_connection(conn)
