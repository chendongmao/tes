<center><h1>EMIS 数仓代码</h1></center>

```tex
==================================================================================
表结构修改情况:
1.coss_dm.dm_wtw_eng_cons_billing_hist_dip 表结构更新为：coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di
2.coss_dm.dm_psr_daily_ps_running_item_di  表结构更新为：coss_dm.dm_psr_monthly_ps_running_item_di
3.coss_dim.dim_ps_installation_info        该表未新增维度表
==================================================================================
数据更新情况:
1.公司opengaussdb 已经更新
2.HK DEV 已经更新
==================================================================================
指标更新情况：
1.抽水站、滤水厂二级页面的 kwh/cum 修改未 kwh/ML  指标数据还已修改
==================================================================================
双周会修改新增表：
1.coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di
2.coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di
3.coss_dim.dim_wtw_installation_info
==================================================================================
EMIS接口抽取数据后数仓代码250916：（数据抽取到dev）
1. 调用emis接口需要在10.66.169.48,在该台window service 调试接口代码
2. 在10.66.168.253 window service 通过MobaXterm 登录dp服务器10.66.169.236执行调度，代码文件为：/opt/app/coss/emis/
目前存在问题：
1. 新版本的指标删除IT_PS_000029，将其合并到IT_PS_000019
2. coss_dm.dm_psr_monthly_ps_running_item_di 更新了2024年后的数据在帆软页面上无法展示
==================================================================================
EMIS接口抽取数据后数仓代码250916：（数据抽取到PRE）
10.66.168.253 window service(开发机器)
10.66.168.212 pre dp
10.66.168.11 pre dp
10.66.168.85 pre dp
https://wiki.sis2.wsd.gov/ems/webresources/reports?loc_id=24&from=2023-01-01&to=2023-02-28
10.66.168.11 tiaoshejiqi
wsd_admin
Wsd@CLOUD9!
==================================================================================
1.预生产AI优化了接口代码

```

# ods

## bill shell

```shell

# Log storage directory
LOG_DIR="/opt/app/coss/emis/log/ods_emis_bills" 

# Create a log directory (if it doesn't exist)
mkdir -p "$LOG_DIR"

# Generate the current date in the format of YYYYMMDD
CURRENT_DATE=$(date +%Y%m%d)

# Log file name
LOG_FILE="${LOG_DIR}/ods_emis_bills_${CURRENT_DATE}.log"

# Run the Python program and redirect the output to the log file
python3 /opt/app/coss/emis/script/ods_emis_bills.py ${mh1} >> "$LOG_FILE" 2>&1

# Delete log files that exceed the specified number of days
find "$LOG_DIR" -name "*.log" -type f -mtime +90 -delete
```

## pump report shell

```shell

# Log storage directory
LOG_DIR="/opt/app/coss/emis/log/ods_emis_report" 

# Create a log directory (if it doesn't exist)
mkdir -p "$LOG_DIR"

# Generate the current date in the format of YYYYMMDD
CURRENT_DATE=$(date +%Y%m%d)

# Log file name
LOG_FILE="${LOG_DIR}/ods_emis_report_${CURRENT_DATE}.log"

# Run the Python program and redirect the output to the log file
python3 /opt/app/coss/emis/script/ods_emis_report.py ${mh1}  >> "$LOG_FILE" 2>&1

# Delete log files that exceed the specified number of days
find "$LOG_DIR" -name "*.log" -type f -mtime +90 -delete
```



## 1.coss_ods.ods_emis_bills_di_year

```sql
DROP TABLE if  exists  coss_ods.ods_emis_bills_di_year;
CREATE TABLE if not exists coss_ods.ods_emis_bills_di_year (
	asset_name varchar(255) NULL,
	asset_id int4 NULL,
	bill_date varchar(50) NULL,
	traiff varchar(255) NULL,
	traiff_desc varchar(255) NULL,
	on_peak_kwh numeric(15, 5) NULL,
	off_peak_kwh numeric(15, 5) NULL,
	on_peak_kva numeric(15, 5) NULL,
	off_peak_kva numeric(15, 5) NULL,
	bill_amount numeric(15, 5) NULL,
    ods_update_time   timestamp(6) default current_timestamp,
    ods_load_time     timestamp(6) default current_timestamp,
    primary key(asset_id,bill_date )
)
WITH (
	orientation=row,
	compression=no
)distribute by hash(asset_id)
partition by range (ods_update_time)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
);
;comment on table  coss_ods.ods_emis_bills_di_year                         is 'bills'
;comment on column coss_ods.ods_emis_bills_di_year.asset_name              is 'asset name'
;comment on column coss_ods.ods_emis_bills_di_year.asset_id                is 'asset id'
;comment on column coss_ods.ods_emis_bills_di_year.bill_date               is 'bill date'
;comment on column coss_ods.ods_emis_bills_di_year.traiff                  is 'traiff'
;comment on column coss_ods.ods_emis_bills_di_year.traiff_desc             is 'traiff desc'
;comment on column coss_ods.ods_emis_bills_di_year.on_peak_kwh             is 'on peak kwh'
;comment on column coss_ods.ods_emis_bills_di_year.off_peak_kwh            is 'off peak kwh'
;comment on column coss_ods.ods_emis_bills_di_year.on_peak_kva             is 'on peak kva'
;comment on column coss_ods.ods_emis_bills_di_year.off_peak_kva            is 'off peak kva'
;comment on column coss_ods.ods_emis_bills_di_year.bill_amount             is 'bill amount'
;comment on column coss_ods.ods_emis_bills_di_year.ods_update_time         is 'ods update time'
;comment on column coss_ods.ods_emis_bills_di_year.ods_load_time           is 'ods load time'

```



```sql
-- ****************************************************************************************
-- SUBJECT AREAS    : EMS Electricity Bills Data Filtering
-- FUNCTION DESCRIBE: Retrieve the latest record for each (asset_id, bill_date) combination
--                    by filtering the most recent ods_update_time using window function
-- TARGET TABLE     : coss_ods.ods_emis_bills_di_year_tmp
-- WINDOW FUNCTION  : ROW_NUMBER() - Assigns unique rank to records in each (asset_id, bill_date) group
--                    PARTITION BY : Groups data by asset_id and bill_date (core dimensions)
--                    ORDER BY     : Sorts records in each group by ods_update_time descending (newest first)
-- ****************************************************************************************
insert into coss_ods.ods_emis_bills_di_year
SELECT
    asset_name,
    asset_id,
    bill_date,
    traiff,
    traiff_desc,
    on_peak_kwh,
    off_peak_kwh,
    on_peak_kva,
    off_peak_kva,
    bill_amount,
    localtimestamp ods_update_time,
    localtimestamp ods_load_time
FROM
    (
    SELECT
        -- Include all required fields from the target table
        asset_name,
        asset_id,
        bill_date,
        traiff,
        traiff_desc,
        on_peak_kwh,
        off_peak_kwh,
        on_peak_kva,
        off_peak_kva,
        bill_amount,
        ods_update_time,
        ods_load_time,
        -- Window function: Rank records in each (asset_id, bill_date) group by update time
        ROW_NUMBER() OVER (
            PARTITION BY asset_id, bill_date  -- Group records by asset ID and bill date
            ORDER BY ods_update_time DESC     -- Sort within group by latest update time first
        ) AS record_rank  -- Rank label: 1 = latest record in the group
    FROM
        coss_ods.ods_emis_bills_di_year_tmp
    -- Optional: Filter invalid records to improve performance
    WHERE
        asset_id IS NOT NULL  -- Exclude records with empty asset ID
        AND bill_date IS NOT NULL  -- Exclude records with empty bill date
)  -- Select only the latest record (rank = 1) for each (asset_id, bill_date) group
WHERE
    record_rank = 1  -- Retain only the most recent record per group
-- Optional: Sort result by core dimensions for readability
ORDER BY
    asset_id,
    bill_date
ON DUPLICATE KEY UPDATE
    asset_name = values(asset_name),
    traiff = values(traiff),
    traiff_desc = values(traiff_desc),
    on_peak_kwh = values(on_peak_kwh),
    off_peak_kwh = values(off_peak_kwh),
    on_peak_kva = values(on_peak_kva),
    off_peak_kva = values(off_peak_kva),
    bill_amount = values(bill_amount),
    ods_update_time = values(ods_update_time)
```



## 2.coss_ods.ods_emis_report_di_year

```sql
DROP TABLE if  exists  coss_ods.ods_emis_report_di_year;
CREATE TABLE if not  exists  coss_ods.ods_emis_report_di_year (
	rpt_id text NULL,
	asset_id int8 NULL,
	pump_num int8 NULL,
	cat_id text NULL,
	cat_name text NULL,
	drive_id text NULL,
	drive_name text NULL,
	del_id text NULL,
	del_name text NULL,
	del__asset_id int8 NULL,
	design_flow text NULL,
	run_hours float8 NULL,
	pump_qty float8 NULL,
	avg_suct float8 NULL,
	avg_del float8 NULL,
	design_flow_flag text NULL,
	run_hours_flag text NULL,
	pump_qty_flag text NULL,
	avg_suct_flag text NULL,
	avg_del_flag text NULL,
	dw_etl_time text NULL,
	mh text NULL,
    ods_update_time   timestamp(6) default current_timestamp,
    ods_load_time     timestamp(6) default current_timestamp,
    primary key(asset_id, mh, del__asset_id, pump_num)
)
WITH (
	orientation=row,
	compression=no
)distribute by hash(asset_id)
partition by range (ods_update_time)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
);
;comment on table  coss_ods.ods_emis_report_di_year                         is 'pump report'
;comment on column coss_ods.ods_emis_report_di_year.rpt_id                  is 'rpt id'
;comment on column coss_ods.ods_emis_report_di_year.asset_id                is 'asset id'
;comment on column coss_ods.ods_emis_report_di_year.pump_num                is 'pump num'
;comment on column coss_ods.ods_emis_report_di_year.cat_id                  is 'cat id'
;comment on column coss_ods.ods_emis_report_di_year.cat_name                is 'cat name'
;comment on column coss_ods.ods_emis_report_di_year.drive_id                is 'drive id'
;comment on column coss_ods.ods_emis_report_di_year.drive_name              is 'drive name'
;comment on column coss_ods.ods_emis_report_di_year.del_id                  is 'del id'
;comment on column coss_ods.ods_emis_report_di_year.del_name                is 'del name'
;comment on column coss_ods.ods_emis_report_di_year.del__asset_id           is 'del asset id'
;comment on column coss_ods.ods_emis_report_di_year.design_flow             is 'design flow'
;comment on column coss_ods.ods_emis_report_di_year.run_hours               is 'run hours'
;comment on column coss_ods.ods_emis_report_di_year.pump_qty                is 'pump qty'
;comment on column coss_ods.ods_emis_report_di_year.avg_suct                is 'avg suct'
;comment on column coss_ods.ods_emis_report_di_year.avg_del                 is 'avg del'
;comment on column coss_ods.ods_emis_report_di_year.design_flow_flag        is 'design flow flag'
;comment on column coss_ods.ods_emis_report_di_year.run_hours_flag          is 'run hours flag'
;comment on column coss_ods.ods_emis_report_di_year.pump_qty_flag           is 'pump qty flag'
;comment on column coss_ods.ods_emis_report_di_year.avg_suct_flag           is 'avg suct flag'
;comment on column coss_ods.ods_emis_report_di_year.avg_del_flag            is 'avg del flag'
;comment on column coss_ods.ods_emis_report_di_year.dw_etl_time             is 'dw etl time'
;comment on column coss_ods.ods_emis_report_di_year.mh                      is 'month'
;comment on column coss_ods.ods_emis_report_di_year.ods_update_time         is 'ods update time'
;comment on column coss_ods.ods_emis_report_di_year.ods_load_time           is 'ods load time'
```

```sql
-- ****************************************************************************************
-- SUBJECT AREAS    : EMS Pump Report Data Filtering
-- FUNCTION DESCRIBE: Retrieve the latest record for each combination of (asset_id, mh, del__asset_id, pump_num)
--                    by filtering the most recent ods_update_time using window function
-- TARGET TABLE     : coss_ods.ods_emis_report_di_year_tmp
-- WINDOW FUNCTION  : ROW_NUMBER() - Assigns unique rank to records in each target dimension group
--                    PARTITION BY : Groups data by 4 core dimensions (asset_id, mh, del__asset_id, pump_num)
--                    ORDER BY     : Sorts records in each group by ods_update_time descending (newest first)
-- ****************************************************************************************
insert into coss_ods.ods_emis_report_di_year
SELECT
    rpt_id,
    asset_id,
    pump_num,
    cat_id,
    cat_name,
    drive_id,
    drive_name,
    del_id,
    del_name,
    del__asset_id,
    design_flow,
    run_hours,
    pump_qty,
    avg_suct,
    avg_del,
    design_flow_flag,
    run_hours_flag,
    pump_qty_flag,
    avg_suct_flag,
    avg_del_flag,
    dw_etl_time,
    mh,
    ods_update_time,
    ods_load_time
FROM
    (
    SELECT
        -- Include all required fields from the target table (match the specified field list)
        rpt_id,
        asset_id,
        pump_num,
        cat_id,
        cat_name,
        drive_id,
        drive_name,
        del_id,
        del_name,
        del__asset_id,  -- Note: Field with double underscore as per table structure
        design_flow,
        run_hours,
        pump_qty,
        avg_suct,
        avg_del,
        design_flow_flag,
        run_hours_flag,
        pump_qty_flag,
        avg_suct_flag,
        avg_del_flag,
        dw_etl_time,
        mh,
        localtimestamp ods_update_time,
        localtimestamp ods_load_time,
        -- Window function: Rank records in each (asset_id, mh, del__asset_id, pump_num) group
        ROW_NUMBER() OVER (
            PARTITION BY
                asset_id,
                mh,
                del__asset_id,
                pump_num  -- 4 core dimensions for grouping
            ORDER BY
                ods_update_time DESC  -- Sort by update time: newest record ranks 1
        ) AS record_rank  -- Rank label: 1 = latest record in the group
    FROM
        coss_ods.ods_emis_report_di_year_tmp
    -- Optional: Filter invalid records to avoid meaningless groups
    WHERE
        asset_id IS NOT NULL
        AND mh IS NOT NULL
        AND del__asset_id IS NOT NULL
        AND pump_num IS NOT NULL
) -- Select only the latest record (rank = 1) for each target dimension group
WHERE
    record_rank = 1  -- Retain only the most recent record per (asset_id, mh, del__asset_id, pump_num)
-- Optional: Sort result by core dimensions for readability
ORDER BY
    asset_id,
    mh,
    del__asset_id,
    pump_num
ON DUPLICATE KEY UPDATE
        rpt_id = values(rpt_id),
        cat_id = values(cat_id),
        cat_name = values(cat_name),
        drive_id = values(drive_id),
        drive_name = values(drive_name),
        del_id = values(del_id),
        del_name = values(del_name),
        design_flow = values(design_flow),
        run_hours = values(run_hours),
        pump_qty = values(pump_qty),
        avg_suct = values(avg_suct),
        avg_del = values(avg_del),
        design_flow_flag = values(design_flow_flag),
        run_hours_flag = values(run_hours_flag),
        pump_qty_flag = values(pump_qty_flag),
        avg_suct_flag = values(avg_suct_flag),
        avg_del_flag = values(avg_del_flag),
        dw_etl_time = values(dw_etl_time),
        ods_update_time = values(ods_update_time)
```





# dim

## 1.coss_dim.dim_ass_energy_cons_installation_df

> 老版本的表还没删除

```sql
;drop table if exists coss_dim.dim_ass_energy_cons_installation_df
;create table if not exists coss_dim.dim_ass_energy_cons_installation_df(
  asset_id                    decimal(11)         -- asset id
  ,asset_name                 varchar(120)        -- asset name
  ,asset_desc                 varchar(120)        -- asset description
  ,loca_code                  varchar(15)         -- location code
  ,acc_no                     varchar(120)        -- account no
  ,region_id                  decimal(11)         -- region id
  ,region_code                varchar(150)        -- region code
  ,region_desc                varchar(800)        -- region description
  ,i_type_id                  decimal(11)         -- installation type id
  ,i_type_code                varchar(150)        -- installation type code
  ,i_type_desc                varchar(150)        -- installation type  description
  ,fw_portion                 decimal(20,5)       -- fresh portion
  ,sw_portion                 decimal(20,5)       -- salt water portion
  ,rw_portion                 decimal(20,5)       -- raw water portion
  ,tw_portion                 decimal(20,5)       -- treatment works portion
  ,remarks                    varchar(120)        -- remarks
  ,is_active                  decimal(5)          -- is active
  ,official_name              varchar(120)        -- official name
  ,station_code               varchar(120)        -- station code
  ,is_billing                 decimal(5)          -- billing is active
  ,is_ps                      decimal(5)          -- pump station is active
  ,is_ecw                     decimal(5)          -- ecw is active
  ,region_rpt                 varchar(150)        -- region report
  ,is_hkp                     decimal(5)          -- hkp is active
  ,is_fy                      decimal(5)          -- fy is active
  ,is_water_eff               decimal(5)          -- waterefficiency is active
  ,water_eff_type_id          decimal(11)         -- installation type id for waterefficiency
  ,i_num                      varchar(30)         -- installation number
  ,dim_update_time            timestamp(6) default current_timestamp
  ,dim_load_time              timestamp(6) default current_timestamp
  ,dt                         decimal(10)         -- daily partitions
  ,primary key(asset_id)
)
distribute by hash("asset_id")
;comment on table  coss_dim.dim_ass_energy_cons_installation_df                    is  'energy consumption installations'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.asset_id           is 'asset id'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.asset_name         is 'asset name'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.asset_desc         is 'asset description'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.loca_code          is 'location code'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.acc_no             is 'account no'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.region_id          is 'region id'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.region_code        is 'region code'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.region_desc        is 'region description'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.i_type_id          is 'installation type id'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.i_type_code        is 'installation type code'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.i_type_desc        is 'installation type  description'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.fw_portion         is 'fresh portion'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.sw_portion         is 'salt water portion'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.rw_portion         is 'raw water portion'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.tw_portion         is 'treatment works portion'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.remarks            is 'remarks'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_active          is 'is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.official_name      is 'official name'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.station_code       is 'station code'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_billing         is 'billing is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_ps              is 'pump station is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_ecw             is 'ecw is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.region_rpt         is 'region report'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_hkp             is 'hkp is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_fy              is 'fy is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.is_water_eff       is 'water efficiency is active'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.water_eff_type_id  is 'installation type id for water efficiency'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.i_num              is 'installation number'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.dim_update_time    is 'Data Update Time'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.dim_load_time      is 'Data Loading Time'
;comment on column coss_dim.dim_ass_energy_cons_installation_df.dt                 is 'daily partitions'
```

Load Date

```sql
insert into coss_dim.dim_ass_energy_cons_installation_df
select
  asset_id                                -- energy consumption installations
  ,asset_name                             -- asset id
  ,asset_desc                             -- asset name
  ,loca_code                              -- asset description
  ,acc_no                                 -- location code
  ,region_id                              -- account no
  ,region_code                            -- region id
  ,region_desc                            -- region code
  ,i_type_id                              -- region description
  ,i_type_code                            -- installation type id
  ,i_type_desc                            -- installation type code
  ,fw_portion                             -- installation type  description
  ,sw_portion                             -- fresh portion
  ,rw_portion                             -- salt water portion
  ,tw_portion                             -- raw water portion
  ,remarks                                -- treatment works portion
  ,is_active                              -- remarks
  ,official_name                          -- is active
  ,station_code                           -- official name
  ,is_billing                             -- station code
  ,is_ps                                  -- billing is active
  ,is_ecw                                 -- pump station is active
  ,region_rpt                             -- ecw is active
  ,is_hkp                                 -- region report
  ,is_fy                                  -- hkp is active
  ,is_water_eff                           -- fy is active
  ,water_eff_type_id                      -- water efficiency is active
  ,i_num                                  -- installation type id for water efficiency
  ,localtimestamp dim_update_time         -- installation number
  ,localtimestamp dim_load_time           -- Data Update Time
  ,dt                                     -- Data Loading Time
  from
  coss_dwd.dim_ass_energy_cons_installation_dfp
```



# dwd

## 1.coss_dwd.dwd_psr_billing_details_di_year

> old table 还没删除coss_dwd.dwd_psr_billing_details_dip

```sql
;drop table if exists coss_dwd.dwd_psr_billing_details_di_year
;create table if not exists coss_dwd.dwd_psr_billing_details_di_year(
  bill_id            varchar(60)      -- bill_id
  ,bill_date         timestamp(6)     -- bill date
  ,asset_id          decimal(11)      -- asset id
  ,tariff_id         decimal(11)      -- tariff id
  ,tariff_name       varchar(150)     -- tariff name
  ,tariff_desc       varchar(300)     -- tariff description
  ,utility_id        decimal(11)      -- utility id
  ,utility_name      varchar(150)     -- utility name
  ,utility_desc      varchar(800)     -- utility description
  ,kwh_on_peak       decimal(10,0)    -- power consumption of on peak (kwh)
  ,kwh_off_peak      decimal(10,0)    -- power consumption of off peak (kwh)
  ,kva_on_peak       decimal(10,0)    -- capacity of on peak (kva)
  ,kva_off_peak      decimal(10,0)    -- capacity of off peak (kva)
  ,flow_volume       decimal(20,5)    -- flow volume
  ,avg_pressure      decimal(20,5)    -- average pressure
  ,payout            decimal(10,0)    -- pay out
  ,dwd_update_time   timestamp(6) default current_timestamp
  ,dwd_load_time     timestamp(6) default current_timestamp
  ,mh                decimal(10)      -- partitions for billing month
  ,primary key(bill_id,asset_id,bill_date)
)
distribute by hash("bill_id")
partition by range (bill_date)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_psr_billing_details_di_year                         is 'pump station billing details'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.bill_id                 is 'bill_id'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.bill_date               is 'bill date'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.asset_id                is 'asset id'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.tariff_id               is 'tariff id'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.tariff_name             is 'tariff name'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.tariff_desc             is 'tariff description'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.utility_id              is 'utility id'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.utility_name            is 'utility name'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.utility_desc            is 'utility description'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.kwh_on_peak             is 'power consumption of on peak (kwh)'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.kwh_off_peak            is 'power consumption of off peak (kwh)'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.kva_on_peak             is 'capacity of on peak (kva)'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.kva_off_peak            is 'capacity of off peak (kva)'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.flow_volume             is 'flow volume'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.avg_pressure            is 'average pressure'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.payout                  is 'pay out'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.dwd_update_time  is 'Data Update Time'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.dwd_load_time    is 'Data Loading Time'
;comment on column coss_dwd.dwd_psr_billing_details_di_year.mh                      is 'partitions for billing month'
```

Load Date

> history data inserted

```sql
insert into coss_dwd.dwd_psr_billing_details_di_year
select 
  bill_id                         -- bill_id
  ,bill_date                      -- bill date
  ,asset_id                       -- asset id
  ,tariff_id                      -- tariff id
  ,tariff_name                    -- tariff name
  ,tariff_desc                    -- tariff description
  ,utility_id                     -- utility id
  ,utility_name                   -- utility name
  ,utility_desc                   -- utility description
  ,kwh_on_peak                    -- power consumption of on peak (kwh)
  ,kwh_off_peak                   -- power consumption of off peak (kwh)
  ,kva_on_peak                    -- capacity of on peak (kva)
  ,kva_off_peak                   -- capacity of off peak (kva)
  ,flow_volume                    -- flow volume
  ,avg_pressure                   -- average pressure
  ,payout                         -- pay out
  ,localtimestamp dwd_update_time -- Data Update Time
  ,localtimestamp dwd_load_time   -- Data Loading Time
  ,mh                             -- partitions for billing month
from 
  coss_dwd.dwd_psr_billing_details_dip
```

> interface new data inserted

```sql
;delete from coss_dwd.dwd_psr_billing_details_di_year where mh >= ${mh1}
;insert into coss_dwd.dwd_psr_billing_details_di_year
select
  uuid()                                  as bill_id              -- pump station billing details
  ,bill_date                              as bill_date            -- bill_id
  ,asset_id                               as asset_id             -- bill date
  ,null                                   as tariff_id            -- asset id
  ,traiff                                 as tariff_name          -- tariff id
  ,traiff_desc                            as tariff_desc          -- tariff name
  ,null                                   as utility_id           -- tariff description
  ,null                                   as utility_name         -- utility id
  ,null                                   as utility_desc         -- utility name
  ,on_peak_kwh                            as kwh_on_peak          -- utility description
  ,off_peak_kwh                           as kwh_off_peak         -- power consumption of on peak (kwh)
  ,on_peak_kva                            as kva_on_peak          -- power consumption of off peak (kwh)
  ,off_peak_kva                           as kva_off_peak         -- capacity of on peak (kva)
  ,null                                   as flow_volume          -- capacity of off peak (kva)
  ,null                                   as avg_pressure         -- flow volume
  ,bill_amount                            as payout               -- average pressure
  ,localtimestamp                         as dwd_update_time      -- pay out
  ,localtimestamp                         as dwd_load_time        -- Data Update Time
  ,to_char(to_date(bill_date), 'yyyyMM')  as mh                   -- Data Loading Time
from coss_ods.ods_emis_bills_di_year
where mh >= ${mh1}
```



## 2.coss_dwd.dwd_psr_pump_running_details_di_year

```sql
;drop table if exists coss_dwd.dwd_psr_pump_running_details_di_year
;create table if not exists coss_dwd.dwd_psr_pump_running_details_di_year(
  rpt_id              varchar(60)       -- report pump id
  ,asset_id           decimal(11)       -- assert id
  ,pump_num           decimal(11)       -- pump number
  ,cat_id             decimal(11)       -- category id
  ,cat_name           varchar(150)      -- category name
  ,drive_id           decimal(11)       -- drive id
  ,drive_name         varchar(150)      -- drive name
  ,del_id             decimal(11)       -- delivery to id
  ,del_name           varchar(600)      -- delivery to name
  ,del_asset_id       decimal(11)        -- delivery to asset id
  ,design_flow        decimal(20,5)     -- flow rate design
  ,run_hours          decimal(20,5)     -- hours run this month
  ,pump_qty           decimal(20,5)     -- water pumped this month
  ,avg_suct           decimal(20,5)     -- average head suction
  ,avg_del            decimal(20,5)     -- average head delivery
  ,design_flow_flag   decimal(11)       -- flow rate design flag
  ,run_hours_flag     decimal(11)       -- hours run this month flag
  ,pump_qty_flag      decimal(11)       -- water pumped this month flag
  ,avg_suct_flag      decimal(11)       -- average head suction flag
  ,avg_del_flag       decimal(11)       -- average head delivery flag
  ,dwd_update_time    timestamp(6)      default current_timestamp
  ,dwd_load_time      timestamp(6)      default current_timestamp
  ,rpt_date           timestamp(6)
  ,mh                 decimal(10)       -- partitions for report month
  ,primary key( asset_id, mh, pump_num, del_asset_id)
)
distribute by hash("rpt_id")
partition by range (rpt_date)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dwd.dwd_psr_pump_running_details_di_year                    is 'pump station billing details'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.rpt_id             is 'report pump id'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.asset_id           is 'assert id'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.pump_num           is 'pump number'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.cat_id             is 'category id'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.cat_name           is 'category name'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.drive_id           is 'drive id'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.drive_name         is 'drive name'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.del_id             is 'delivery to id'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.del_name           is 'delivery to name'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.del_asset_id       is 'delivery to asset id'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.design_flow        is 'flow rate design'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.run_hours          is 'hours run this month'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.pump_qty           is 'water pumped this month'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.avg_suct           is 'average head suction'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.avg_del            is 'average head delivery'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.design_flow_flag   is 'flow rate design flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.run_hours_flag     is 'hours run this month flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.pump_qty_flag      is 'water pumped this month flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.avg_suct_flag      is 'average head suction flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.avg_del_flag       is 'average head delivery flag'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.dwd_update_time    is 'Data Update Time'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.dwd_load_time      is 'Data Loading Time'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.rpt_date           is 'report date'
;comment on column coss_dwd.dwd_psr_pump_running_details_di_year.mh                 is 'partitions for report month'
```

> load old date

```sql
insert into coss_dwd.dwd_psr_pump_running_details_di_year
select 
  rpt_id                           -- report pump id
  ,asset_id                        -- assert id
  ,pump_num                        -- pump number
  ,cat_id                          -- category id
  ,cat_name                        -- category name
  ,drive_id                        -- drive id
  ,drive_name                      -- drive name
  ,del_id                          -- delivery to id
  ,del_name                        -- delivery to name
  ,del__asset_id                    -- delivery to asset id
  ,design_flow                     -- flow rate design
  ,run_hours                       -- hours run this month
  ,pump_qty                        -- water pumped this month
  ,avg_suct                        -- average head suction
  ,avg_del                         -- average head delivery
  ,design_flow_flag                -- flow rate design flag
  ,run_hours_flag                  -- hours run this month flag
  ,pump_qty_flag                   -- water pumped this month flag
  ,avg_suct_flag                   -- average head suction flag
  ,avg_del_flag                    -- average head delivery flag
  ,localtimestamp dwd_update_time  -- Data Update Time'
  ,localtimestamp dwd_load_time    -- Data Loading Time'
  ,to_date(mh,'yyyyMM') rpt_date   -- report date
  ,mh                              -- partitions for report month
from
  coss_dwd.dwd_psr_pump_running_details_dip
```

> load interface new data

```sql
;delete from coss_dwd.dwd_psr_pump_running_details_di_year where mh>=${mh1}
;insert into coss_dwd.dwd_psr_pump_running_details_di_year
select 
  uuid()                   as rpt_id            -- report pump id
  ,asset_id                as asset_id          -- assert id
  ,pump_num                as pump_num          -- pump number
  ,null                    as cat_id            -- category id
  ,cat_name                as cat_name          -- category name
  ,null                    as drive_id          -- drive id
  ,drive_name              as drive_name        -- drive name
  ,null                    as del_id            -- delivery to id
  ,del_name                as del_name          -- delivery to name
  ,del_asset_id           as del_asset_id     -- delivery to asset id
  ,null                    as design_flow       -- flow rate design
  ,run_hours               as run_hours         -- hours run this month
  ,pump_qty                as pump_qty          -- water pumped this month
  ,avg_suct                as avg_suct          -- average head suction
  ,avg_del                 as avg_del           -- average head delivery
  ,null                    as design_flow_flag  -- flow rate design flag
  ,null                    as run_hours_flag    -- hours run this month flag
  ,null                    as pump_qty_flag     -- water pumped this month flag
  ,null                    as avg_suct_flag     -- average head suction flag
  ,null                    as avg_del_flag      -- average head delivery flag
  ,localtimestamp          as dwd_update_time   -- Data Update Time
  ,localtimestamp          as dwd_load_time     -- Data Loading Time
  ,to_date(mh, 'yyyyMM')   as rpt_date          -- report date
  ,mh                      as mh                -- partitions for report month
from coss_ods.ods_emis_report_di_year
where mh>=${mh1}
```



# dws

## 1.coss_dws.dws_psr_eng_cons_billing_details_di_year

```sql
;drop table if exists coss_dws.dws_psr_eng_cons_billing_details_di_year
;create table if not exists coss_dws.dws_psr_eng_cons_billing_details_di_year(
  asset_id            decimal(11)          -- asset id
  ,asset_name         varchar(120)         -- asset name
  ,asset_desc         varchar(120)         -- asset description
  ,loca_code          varchar(15)          -- location code
  ,acc_no             varchar(120)         -- account no
  ,region_id          decimal(11)          -- region id
  ,region_code        varchar(150)         -- region code
  ,region_desc        varchar(800)         -- region description
  ,i_type_id          decimal(11)          -- installation type id
  ,i_type_code        varchar(150)         -- installation type code
  ,i_type_desc        varchar(150)         -- installation type  description
  ,fw_portion         decimal(20,5)        -- fresh portion
  ,sw_portion         decimal(20,5)        -- salt water portion
  ,rw_portion         decimal(20,5)        -- raw water portion
  ,tw_portion         decimal(20,5)        -- treatment works portion
  ,remarks            varchar(120)         -- remarks
  ,is_active          decimal(5)           -- is active
  ,official_name      varchar(120)         -- official name
  ,station_code       varchar(120)         -- station code
  ,is_billing         decimal(5)           -- billing is active
  ,is_ps              decimal(5)           -- pump station is active
  ,is_ecw             decimal(5)           -- ecw is active
  ,region_rpt         varchar(150)         -- region report
  ,is_hkp             decimal(5)           -- hkp is active
  ,is_fy              decimal(5)           -- fy is active
  ,is_water_eff       decimal(5)           -- water efficiency is active
  ,water_eff_type_id  decimal(11)          -- installation type id for water efficiency
  ,i_num              varchar(30)          -- installation number
  ,bill_id            varchar(60)          -- bill_id
  ,bill_date          timestamp(6)         -- bill date
  ,tariff_id          decimal(11)          -- tariff id
  ,tariff_name        varchar(150)         -- tariff name
  ,tariff_desc        varchar(300)         -- tariff description
  ,utility_id         decimal(11)          -- utility id
  ,utility_name       varchar(150)         -- utility name
  ,utility_desc       varchar(800)         -- utility description
  ,kwh_on_peak        decimal(10,0)        -- power consumption of on peak (kwh)
  ,kwh_off_peak       decimal(10,0)        -- power consumption of off peak (kwh)
  ,kva_on_peak        decimal(10,0)        -- capacity of on peak (kva)
  ,kva_off_peak       decimal(10,0)        -- capacity of off peak (kva)
  ,flow_volume        decimal(20,5)        -- flow volume
  ,avg_pressure       decimal(20,5)        -- average pressure
  ,payout             decimal(10,0)        -- pay out
  ,total_kwh          decimal(10,0)        -- power consumption of on peak (kwh)
  ,pump_qty           decimal(20,5)        -- water pumped this month
  ,dws_update_time    timestamp(6) default current_timestamp
  ,dws_load_time      timestamp(6) default current_timestamp
  ,mh                 decimal(10)          -- partitions for billing date
  ,primary key(asset_id, bill_id, bill_date)
)
distribute by hash("bill_id")
partition by range (bill_date)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dws.dws_psr_eng_cons_billing_details_di_year                    is 'pump station running billing details'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.asset_id           is  'asset id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.asset_name         is  'asset name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.asset_desc         is  'asset description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.loca_code          is  'location code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.acc_no             is  'account no'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.region_id          is  'region id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.region_code        is  'region code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.region_desc        is  'region description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.i_type_id          is  'installation type id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.i_type_code        is  'installation type code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.i_type_desc        is  'installation type  description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.fw_portion         is  'fresh portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.sw_portion         is  'salt water portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.rw_portion         is  'raw water portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.tw_portion         is  'treatment works portion'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.remarks            is  'remarks'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_active          is  'is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.official_name      is  'official name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.station_code       is  'station code'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_billing         is  'billing is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_ps              is  'pump station is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_ecw             is  'ecw is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.region_rpt         is  'region report'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_hkp             is  'hkp is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_fy              is  'fy is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.is_water_eff       is  'water efficiency is active'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.water_eff_type_id  is  'installation type id for water efficiency'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.i_num              is  'installation number'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.bill_id            is  'bill_id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.bill_date          is  'bill date'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.tariff_id          is  'tariff id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.tariff_name        is  'tariff name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.tariff_desc        is  'tariff description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.utility_id         is  'utility id'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.utility_name       is  'utility name'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.utility_desc       is  'utility description'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.kva_on_peak        is  'capacity of on peak (kva)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.kva_off_peak       is  'capacity of off peak (kva)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.flow_volume        is  'flow volume'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.avg_pressure       is  'average pressure'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.payout             is  'pay out'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.total_kwh          is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.pump_qty           is  'water pumped this month'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.dws_update_time    is 'Data Update Time'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.dws_load_time      is 'Data Loading Time'
;comment on column coss_dws.dws_psr_eng_cons_billing_details_di_year.mh                 is  'partitions for billing date'

```

Load Data

```sql
delete from coss_dws.dws_psr_eng_cons_billing_details_di_year where mh >= ${mh1}
;insert into coss_dws.dws_psr_eng_cons_billing_details_di_year
select
  t1.asset_id                     as asset_id           -- asset id
  ,t1.asset_name                  as asset_name         -- asset name
  ,t1.asset_desc                  as asset_desc         -- asset description
  ,t1.loca_code                   as loca_code          -- location code
  ,t1.acc_no                      as acc_no             -- account no
  ,t1.region_id                   as region_id          -- region id
  ,t1.region_code                 as region_code        -- region code
  ,t1.region_desc                 as region_desc        -- region description
  ,t1.i_type_id                   as i_type_id          -- installation type id
  ,t1.i_type_code                 as i_type_code        -- installation type code
  ,t1.i_type_desc                 as i_type_desc        -- installation type  description
  ,t1.fw_portion                  as fw_portion         -- fresh portion
  ,t1.sw_portion                  as sw_portion         -- salt water portion
  ,t1.rw_portion                  as rw_portion         -- raw water portion
  ,t1.tw_portion                  as tw_portion         -- treatment works portion
  ,t1.remarks                     as remarks            -- remarks
  ,t1.is_active                   as is_active          -- is active
  ,t1.official_name               as official_name      -- official name
  ,t1.station_code                as station_code       -- station code
  ,t1.is_billing                  as is_billing         -- billing is active
  ,t1.is_ps                       as is_ps              -- pump station is active
  ,t1.is_ecw                      as is_ecw             -- ecw is active
  ,t1.region_rpt                  as region_rpt         -- region report
  ,t1.is_hkp                      as is_hkp             -- hkp is active
  ,t1.is_fy                       as is_fy              -- fy is active
  ,t1.is_water_eff                as is_water_eff       -- water efficiency is active
  ,t1.water_eff_type_id           as water_eff_type_id  -- installation type id for water efficiency
  ,t1.i_num                       as i_num              -- installation number
  ,t.bill_id                      as bill_id            -- bill_id
  ,t.bill_date                    as bill_date          -- bill date
  ,t.tariff_id                    as tariff_id          -- tariff id
  ,t.tariff_name                  as tariff_name        -- tariff name
  ,t.tariff_desc                  as tariff_desc        -- tariff description
  ,t.utility_id                   as utility_id         -- utility id
  ,t.utility_name                 as utility_name       -- utility name
  ,t.utility_desc                 as utility_desc       -- utility description
  ,t.kwh_on_peak                  as kwh_on_peak        -- power consumption of on peak (kwh)
  ,t.kwh_off_peak                 as kwh_off_peak       -- power consumption of off peak (kwh)
  ,t.kva_on_peak                  as kva_on_peak        -- capacity of on peak (kva)
  ,t.kva_off_peak                 as kva_off_peak       -- capacity of off peak (kva)
  ,t.flow_volume                  as flow_volume        -- flow volume
  ,t.avg_pressure                 as avg_pressure       -- average pressure
  ,t.payout                       as payout             -- pay out
  ,t.kwh_on_peak+t.kwh_off_peak   as total_kwh          -- power consumption of on peak (kwh)
  ,t2.pump_qty                    as pump_qty           -- water pumped this month
  ,localtimestamp                 as dws_update_time    -- Data Update Time
  ,localtimestamp                 as dws_load_time      -- Data Loading Time
  ,t.mh                           as mh                 -- partitions for billing date
from coss_dwd.dwd_psr_billing_details_di_year t
inner join coss_dim.dim_ass_energy_cons_installation_df t1 on t.asset_id = t1.asset_id
left join (select mh,asset_id,sum(pump_qty) pump_qty from coss_dwd.dwd_psr_pump_running_details_di_year group by mh,asset_id ) t2 on t.asset_id  = t2.asset_id and t.mh = t2.mh
where t1.asset_name like '%PS%'
  and lower(t1.asset_name) not like '%ceased%'
  and lower(t1.asset_name) not like '%decommissi%'
  and lower(t1.asset_name) not like '%TW%'
  and t.mh >= ${mh1}
  and t2.mh >= ${mh1}

```

## 2.coss_dws.dws_wtw_eng_cons_billing_details_di_year

```sql
;drop table if exists coss_dws.dws_wtw_eng_cons_billing_details_di_year
;create table if not exists coss_dws.dws_wtw_eng_cons_billing_details_di_year(
  asset_id            decimal(11)          -- asset id
  ,asset_name         varchar(120)         -- asset name
  ,asset_desc         varchar(120)         -- asset description
  ,loca_code          varchar(15)          -- location code
  ,acc_no             varchar(120)         -- account no
  ,region_id          decimal(11)          -- region id
  ,region_code        varchar(150)         -- region code
  ,region_desc        varchar(800)         -- region description
  ,i_type_id          decimal(11)          -- installation type id
  ,i_type_code        varchar(150)         -- installation type code
  ,i_type_desc        varchar(150)         -- installation type  description
  ,fw_portion         decimal(20,5)        -- fresh portion
  ,sw_portion         decimal(20,5)        -- salt water portion
  ,rw_portion         decimal(20,5)        -- raw water portion
  ,tw_portion         decimal(20,5)        -- treatment works portion
  ,remarks            varchar(120)         -- remarks
  ,is_active          decimal(5)           -- is active
  ,official_name      varchar(120)         -- official name
  ,station_code       varchar(120)         -- station code
  ,is_billing         decimal(5)           -- billing is active
  ,is_ps              decimal(5)           -- pump station is active
  ,is_ecw             decimal(5)           -- ecw is active
  ,region_rpt         varchar(150)         -- region report
  ,is_hkp             decimal(5)           -- hkp is active
  ,is_fy              decimal(5)           -- fy is active
  ,is_water_eff       decimal(5)           -- water efficiency is active
  ,water_eff_type_id  decimal(11)          -- installation type id for water efficiency
  ,i_num              varchar(30)          -- installation number
  ,bill_id            varchar(60)          -- bill_id
  ,bill_date          timestamp(6)         -- bill date
  ,tariff_id          decimal(11)          -- tariff id
  ,tariff_name        varchar(150)         -- tariff name
  ,tariff_desc        varchar(300)         -- tariff description
  ,utility_id         decimal(11)          -- utility id
  ,utility_name       varchar(150)         -- utility name
  ,utility_desc       varchar(800)         -- utility description
  ,kwh_on_peak        decimal(10,0)        -- power consumption of on peak (kwh)
  ,kwh_off_peak       decimal(10,0)        -- power consumption of off peak (kwh)
  ,kva_on_peak        decimal(10,0)        -- capacity of on peak (kva)
  ,kva_off_peak       decimal(10,0)        -- capacity of off peak (kva)
  ,flow_volume        decimal(20,5)        -- flow volume
  ,avg_pressure       decimal(20,5)        -- average pressure
  ,payout             decimal(10,0)        -- pay out
  ,total_kwh          decimal(10,0)        -- power consumption of on peak (kwh)
  ,pump_qty           decimal(20,5)        -- water pumped this month
  ,dws_update_time    timestamp(6) default current_timestamp
  ,dws_load_time      timestamp(6) default current_timestamp
  ,mh                 decimal(10)          -- partitions for billing date
  ,primary key(asset_id, bill_id, bill_date)
)
distribute by hash("bill_id")
partition by range (bill_date)
(
	partition yr_2005 values less than ('2006-01-01 00:00:00'),
	partition yr_2006 values less than ('2007-01-01 00:00:00'),
	partition yr_2007 values less than ('2008-01-01 00:00:00'),
	partition yr_2008 values less than ('2009-01-01 00:00:00'),
	partition yr_2009 values less than ('2010-01-01 00:00:00'),
	partition yr_2010 values less than ('2011-01-01 00:00:00'),
	partition yr_2011 values less than ('2012-01-01 00:00:00'),
	partition yr_2012 values less than ('2013-01-01 00:00:00'),
	partition yr_2013 values less than ('2014-01-01 00:00:00'),
	partition yr_2014 values less than ('2015-01-01 00:00:00'),
	partition yr_2015 values less than ('2016-01-01 00:00:00'),
	partition yr_2016 values less than ('2017-01-01 00:00:00'),
	partition yr_2017 values less than ('2018-01-01 00:00:00'),
	partition yr_2018 values less than ('2019-01-01 00:00:00'),
	partition yr_2019 values less than ('2020-01-01 00:00:00'),
	partition yr_2020 values less than ('2021-01-01 00:00:00'),
	partition yr_2021 values less than ('2022-01-01 00:00:00'),
	partition yr_2022 values less than ('2023-01-01 00:00:00'),
	partition yr_2023 values less than ('2024-01-01 00:00:00'),
	partition yr_2024 values less than ('2025-01-01 00:00:00'),
	partition yr_2025 values less than ('2026-01-01 00:00:00'),
	partition yr_2026 values less than ('2027-01-01 00:00:00'),
	partition yr_future values less than ('9999-01-01 00:00:00')
)
;comment on table  coss_dws.dws_wtw_eng_cons_billing_details_di_year                    is 'pump station running billing details'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.asset_id           is  'asset id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.asset_name         is  'asset name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.asset_desc         is  'asset description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.loca_code          is  'location code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.acc_no             is  'account no'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.region_id          is  'region id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.region_code        is  'region code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.region_desc        is  'region description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.i_type_id          is  'installation type id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.i_type_code        is  'installation type code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.i_type_desc        is  'installation type  description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.fw_portion         is  'fresh portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.sw_portion         is  'salt water portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.rw_portion         is  'raw water portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.tw_portion         is  'treatment works portion'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.remarks            is  'remarks'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_active          is  'is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.official_name      is  'official name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.station_code       is  'station code'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_billing         is  'billing is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_ps              is  'pump station is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_ecw             is  'ecw is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.region_rpt         is  'region report'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_hkp             is  'hkp is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_fy              is  'fy is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.is_water_eff       is  'water efficiency is active'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.water_eff_type_id  is  'installation type id for water efficiency'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.i_num              is  'installation number'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.bill_id            is  'bill_id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.bill_date          is  'bill date'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.tariff_id          is  'tariff id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.tariff_name        is  'tariff name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.tariff_desc        is  'tariff description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.utility_id         is  'utility id'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.utility_name       is  'utility name'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.utility_desc       is  'utility description'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.kva_on_peak        is  'capacity of on peak (kva)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.kva_off_peak       is  'capacity of off peak (kva)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.flow_volume        is  'flow volume'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.avg_pressure       is  'average pressure'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.payout             is  'pay out'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.total_kwh          is  'power consumption of on peak (kwh)'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.pump_qty           is  'water pumped this month'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.dws_update_time    is 'Data Update Time'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.dws_load_time      is 'Data Loading Time'
;comment on column coss_dws.dws_wtw_eng_cons_billing_details_di_year.mh                 is  'partitions for billing date'

```

Load Date

```sql
; delete from coss_dws.dws_wtw_eng_cons_billing_details_di_year where mh >= ${mh1}
;insert into coss_dws.dws_wtw_eng_cons_billing_details_di_year
select
  t1.asset_id                     as asset_id           -- asset id
  ,t1.asset_name                  as asset_name         -- asset name
  ,t1.asset_desc                  as asset_desc         -- asset description
  ,t1.loca_code                   as loca_code          -- location code
  ,t1.acc_no                      as acc_no             -- account no
  ,t1.region_id                   as region_id          -- region id
  ,t1.region_code                 as region_code        -- region code
  ,t1.region_desc                 as region_desc        -- region description
  ,t1.i_type_id                   as i_type_id          -- installation type id
  ,t1.i_type_code                 as i_type_code        -- installation type code
  ,t1.i_type_desc                 as i_type_desc        -- installation type  description
  ,t1.fw_portion                  as fw_portion         -- fresh portion
  ,t1.sw_portion                  as sw_portion         -- salt water portion
  ,t1.rw_portion                  as rw_portion         -- raw water portion
  ,t1.tw_portion                  as tw_portion         -- treatment works portion
  ,t1.remarks                     as remarks            -- remarks
  ,t1.is_active                   as is_active          -- is active
  ,t1.official_name               as official_name      -- official name
  ,t1.station_code                as station_code       -- station code
  ,t1.is_billing                  as is_billing         -- billing is active
  ,t1.is_ps                       as is_ps              -- pump station is active
  ,t1.is_ecw                      as is_ecw             -- ecw is active
  ,t1.region_rpt                  as region_rpt         -- region report
  ,t1.is_hkp                      as is_hkp             -- hkp is active
  ,t1.is_fy                       as is_fy              -- fy is active
  ,t1.is_water_eff                as is_water_eff       -- water efficiency is active
  ,t1.water_eff_type_id           as water_eff_type_id  -- installation type id for water efficiency
  ,t1.i_num                       as i_num              -- installation number
  ,t.bill_id                      as bill_id            -- bill_id
  ,t.bill_date                    as bill_date          -- bill date
  ,t.tariff_id                    as tariff_id          -- tariff id
  ,t.tariff_name                  as tariff_name        -- tariff name
  ,t.tariff_desc                  as tariff_desc        -- tariff description
  ,t.utility_id                   as utility_id         -- utility id
  ,t.utility_name                 as utility_name       -- utility name
  ,t.utility_desc                 as utility_desc       -- utility description
  ,t.kwh_on_peak                  as kwh_on_peak        -- power consumption of on peak (kwh)
  ,t.kwh_off_peak                 as kwh_off_peak       -- power consumption of off peak (kwh)
  ,t.kva_on_peak                  as kva_on_peak        -- capacity of on peak (kva)
  ,t.kva_off_peak                 as kva_off_peak       -- capacity of off peak (kva)
  ,t.flow_volume                  as flow_volume        -- flow volume
  ,t.avg_pressure                 as avg_pressure       -- average pressure
  ,t.payout                       as payout             -- pay out
  ,t.kwh_on_peak+t.kwh_off_peak   as total_kwh          -- power consumption of on peak (kwh)
  ,t2.pump_qty                    as pump_qty           -- water pumped this month
  ,localtimestamp                 as dws_update_time    -- Data Update Time
  ,localtimestamp                 as dws_load_time      -- Data Loading Time
  ,t.mh                           as mh                 -- partitions for billing date
from coss_dwd.dwd_psr_billing_details_di_year t
inner join coss_dim.dim_ass_energy_cons_installation_df t1 on t.asset_id = t1.asset_id 
left join (select mh,asset_id,sum(pump_qty) pump_qty from coss_dwd.dwd_psr_pump_running_details_di_year group by mh,asset_id ) t2 on t.asset_id  = t2.asset_id and t.mh = t2.mh 
where t1.asset_name like '%WTW%' 
  and lower(t1.asset_name) not like '%ceased%' 
  and lower(t1.asset_name) not like '%decommissi%'
  and t.mh >= ${mh1}
  and t2.mh >= ${mh1}
```

# dm

## 1.coss_dm.dm_psr_annual_pump_station_item_di

```sql
;drop table if exists coss_dm.dm_psr_annual_pump_station_item_di
;create table if not exists coss_dm.dm_psr_annual_pump_station_item_di(
  id                           varchar(50)
  ,statistical_year            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_item_year_region_code unique (statistical_year,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_year,region_abbr)
;comment on table  coss_dm.dm_psr_annual_pump_station_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.statistical_year     is 'Statistical Year'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_psr_annual_pump_station_item_di.dm_load_time         is 'Data Loading Time'
```

### 1.1 累计抽水两和电耗量

```sql
/**
 * 入参：当年的1月1号,例如：202501
 * 功能：统计当年各种类型抽水站的累计抽水两和累计电耗量
 */
;delete 
from 
coss_dm.dm_psr_annual_pump_station_item_di
where 
inter_item_code in(
-- water pumped
 'IT_PS_000001'
,'IT_PS_000002'
,'IT_PS_000003'
,'IT_PS_000005'
-- pump consumption of power 
,'IT_PS_000007'
,'IT_PS_000008'
,'IT_PS_000009'
,'IT_PS_000011'
) 
and statistical_year >= round(${mh1}/100,0)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'FW'
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
), t_ar as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'RW'
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),t_as as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'SW'
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),t_afs as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'Combine'
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),
t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'FW'
  and mh >= ${mh1}
group by 
  yr
),
t_br as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'RW'
  and mh >= ${mh1}
group by 
  yr
),
t_bs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'SW'
  and mh >= ${mh1}
group by 
  yr
),t_bfs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year
where i_type_code = 'Combine'
  and mh >= ${mh1}
group by 
  yr
)
insert into coss_dm.dm_psr_annual_pump_station_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000001'                        as item_code
  ,'食水抽水站电耗量' as item_name_cn
  ,'食水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Fresh Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000001'                        as item_code
  ,'食水抽水站电耗量' as item_name_cn
  ,'食水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Fresh Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000002'                        as item_code
  ,'原水抽水站电耗量' as item_name_cn
  ,'原水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Raw Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_br t
union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000002'                        as item_code
  ,'原水站电耗量' as item_name_cn
  ,'原水食水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Raw Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_ar t
union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000003'                        as item_code
  ,'海水抽水站电耗量' as item_name_cn
  ,'海水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Salt Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000003'                        as item_code
  ,'海水抽水站电耗量' as item_name_cn
  ,'海水抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Salt Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000005'                        as item_code
  ,'其他(combine)抽水站电耗量' as item_name_cn
  ,'其他(combine)抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000005'                        as item_code
  ,'其他(combine)抽水站电耗量' as item_name_cn
  ,'其他(combine)抽水站電耗量' as item_name_tc  
  ,'Power Consumption Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.total_kwh                       as item_value
  ,'kwh'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_afs t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000007'                        as item_code
  ,'食水抽水站抽水量' as item_name_cn
  ,'食水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000007'                        as item_code
  ,'食水抽水站抽水量' as item_name_cn
  ,'食水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000008'                        as item_code
  ,'原水抽水站抽水量' as item_name_cn
  ,'原水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Raw Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000008'                        as item_code
  ,'原水抽水站抽水量' as item_name_cn
  ,'原水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Raw Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000009'                        as item_code
  ,'海水抽水站抽水量' as item_name_cn
  ,'海水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Salt Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000009'                        as item_code
  ,'海水抽水站抽水量' as item_name_cn
  ,'海水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Salt Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000011'                        as item_code
  ,'食水海水抽水站抽水量' as item_name_cn
  ,'食水海水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000011'                        as item_code
  ,'食水海水抽水站抽水量' as item_name_cn
  ,'食水海水抽水站抽水量' as item_name_tc  
  ,'Pumping Volume Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,pump_qty                       as item_value
  ,'mcm'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_afs t
)
```

### 1.2 吨水电耗

```sql
/**
 * 入参：当年的1月1号,例如：202501
 * 功能：统计当年各种类型抽水站的吨水电耗
 */
;delete from coss_dm.dm_psr_annual_pump_station_item_di
where 
inter_item_code in( 
'IT_PS_000019'
,'IT_PS_000020'
,'IT_PS_000021'
,'IT_PS_000023'
)
and statistical_year >= round(${mh1}/100,0)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'FW')
  and pump_qty is not null and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),t_ar as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'RW')
  and pump_qty is not null and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),t_as as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),t_afs as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),
t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'FW'
  or i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
),
t_br as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
)
,t_bs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
),t_bfs as(
select 
  round(mh/100) as yr
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
)
insert into coss_dm.dm_psr_annual_pump_station_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'食水海水抽水站单位电耗' as item_name_cn
  ,'食水海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit  Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'食水海水抽水站单位电耗' as item_name_cn
  ,'食水海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_afs t
)
```



### 1.3 食水电耗量和吨水电耗量同比增长率{年离散计算}

```sql
;delete 
from 
coss_dm.dm_psr_annual_pump_station_item_di
where 
inter_item_code in(
'IT_PS_000030'
,'IT_PS_000031'
)
and statistical_year = round(${mh1}/100,0)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'FW'
  and round(mh/100,0) = round(${mh1}/100,0)
  or mh in (select distinct mh-100 mh from coss_dws.dws_wtw_eng_cons_billing_details_di_year where round(mh/100,0) = round(${mh1}/100,0))
group by 
  yr
  ,region_rpt
),
t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh) total_kwh
  ,sum(pump_qty)/1000  pump_qty  --convert ML to mcm
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'FW'
  and round(mh/100,0) = round(${mh1}/100,0)
  or mh in (select distinct mh-100 mh from coss_dws.dws_wtw_eng_cons_billing_details_di_year where round(mh/100,0) = round(${mh1}/100,0))
group by 
  yr
)
insert into coss_dm.dm_psr_annual_pump_station_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000030'                        as item_code
  ,'食水抽水站kwh/Ml同比整张率' as item_name_cn
  ,'食水抽水站kwh/Ml年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Power Consumption kwh/Ml Of Fresh Water Pumping Stations' as item_name_en  
  ,((t.total_kwh/(t.pump_qty*1000)) - (t1.total_kwh/(t1.pump_qty*1000)))/(t1.total_kwh/(t1.pump_qty*1000)) * 100   as item_value  -- convert pump_qty mcm to Ml
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
  left join t_bf t1 on t.region = t1.region and t.yr = t1.yr+1
where t.pump_qty is not null 
  and t.pump_qty !=0 
  and t1.pump_qty is not null 
  and t1.pump_qty !=0  
  and t.yr = round(${mh1}/100,0)

union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000030'                        as item_code
  ,'食水抽水站kwh/Ml同比整张率' as item_name_cn
  ,'食水抽水站kwh/Ml年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Power Consumption kwh/Ml Of Fresh Water Pumping Stations' as item_name_en  
  ,((t.total_kwh/(t.pump_qty*1000)) - (t1.total_kwh/(t1.pump_qty*1000)))/(t1.total_kwh/(t1.pump_qty*1000)) * 100   as item_value  -- convert pump_qty mcm to Ml
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
  left join t_af t1 on t.region = t1.region and t.yr = t1.yr+1
where t.pump_qty is not null 
  and t.pump_qty !=0 
  and t1.pump_qty is not null 
  and t1.pump_qty !=0 
  and t.yr = round(${mh1}/100,0)
    
union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000031'                        as item_code
  ,'食水抽水站抽水量同比增长率' as item_name_cn
  ,'食水抽水站抽水量年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,(t.pump_qty - t1.pump_qty)/t1.pump_qty * 100                       as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
left join t_bf t1 on t.region = t1.region and t.yr = t1.yr+1
where t1.pump_qty is not null 
  and t1.pump_qty != 0
  and t.yr = round(${mh1}/100,0)

union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_PS_000031'                        as item_code
  ,'食水抽水站抽水量同比增长率' as item_name_cn
  ,'食水抽水站抽水量年比成長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Pumping Volume Of Fresh Water Pumping Stations' as item_name_en  
  ,(t.pump_qty - t1.pump_qty)/t1.pump_qty * 100                       as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
left join t_af t1 on t.region = t1.region and t.yr = t1.yr+1
where t1.pump_qty is not null 
  and t1.pump_qty != 0
  and t.yr = round(${mh1}/100,0)
)
```



## 2.coss_dm.dm_psr_monthly_pump_station_item_di

```sql
;drop table if exists coss_dm.dm_psr_monthly_pump_station_item_di
;create table if not exists coss_dm.dm_psr_monthly_pump_station_item_di(
  id                           varchar(50)
  ,statistical_month            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_item_month_region_code unique (statistical_month,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_month,region_abbr)
;comment on table  coss_dm.dm_psr_monthly_pump_station_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.statistical_month     is 'Statistical month'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_psr_monthly_pump_station_item_di.dm_load_time         is 'Data Loading Time'
```

### 2.1 吨水电耗指标

```sql
/**
 * 入参：当年的1月,例如：202501
 * 功能：统计当年每个月的吨水电耗量
 */
;delete from coss_dm.dm_psr_monthly_pump_station_item_di
where 
inter_item_code in( 
'IT_PS_000019'
,'IT_PS_000020'
,'IT_PS_000021'
,'IT_PS_000023'
)
and statistical_month >= ${mh1}

;with t_af as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'FW')
  and pump_qty is not null and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
  ,region_rpt
),
t_ar as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'RW')
  and pump_qty is not null and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
  ,region_rpt
),t_as as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
  ,region_rpt
),t_afs as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
  ,region_rpt
),
t_bf as(
select 
  mh as mh
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'FW')
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
)
,t_br as(
select 
  mh as mh
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where (i_type_code = 'RW')
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
)
,t_bs as(
select 
  mh as mh
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year 
where i_type_code = 'SW'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
),t_bfs as(
select 
  mh as mh
  ,'HKSAR' region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_psr_eng_cons_billing_details_di_year  
where i_type_code = 'Combine'
  and pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
)
insert into coss_dm.dm_psr_monthly_pump_station_item_di
select 
id
,mh statistical_month
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000019'                        as item_code
  ,'食水抽水站单位电耗' as item_name_cn
  ,'食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_af t

union all 
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_br t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000020'                        as item_code
  ,'原水抽水站单位电耗' as item_name_cn
  ,'原水食水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Pump Station' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_ar t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000021'                        as item_code
  ,'海水抽水站单位电耗' as item_name_cn
  ,'海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_as t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'食水海水抽水站单位电耗' as item_name_cn
  ,'食水海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit  Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bfs t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_PS_000023'                        as item_code
  ,'食水海水抽水站单位电耗' as item_name_cn
  ,'食水海水抽水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Fresh&Salt Water Pumping Stations' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_afs t
)
```

## 3.coss_dm.dm_wtw_annual_water_treatment_works_item_di

```sql
;drop table if exists coss_dm.dm_wtw_annual_water_treatment_works_item_di
;create table if not exists coss_dm.dm_wtw_annual_water_treatment_works_item_di(
  id                           varchar(50)
  ,statistical_year            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_year_region_code unique (statistical_year,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_year,region_abbr)
;comment on table  coss_dm.dm_wtw_annual_water_treatment_works_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.statistical_year     is 'Statistical Year'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_annual_water_treatment_works_item_di.dm_load_time         is 'Data Loading Time'
```

### 3.1 吨水电耗

```sql
;delete from coss_dm.dm_wtw_annual_water_treatment_works_item_di
where inter_item_code in (
'IT_TW_000025'
)
and statistical_year >= round(${mh1}/100,0)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_di_year 
where  pump_qty is not null and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
  ,region_rpt
),t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_di_year
where pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  yr
)
insert into coss_dm.dm_wtw_annual_water_treatment_works_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/Ml'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
)

```

### 3.2 吨水电耗同比增长率{年离散计算}

```sql
;delete from coss_dm.dm_wtw_annual_water_treatment_works_item_di
where inter_item_code in (
'IT_TW_000027'
)
and statistical_year = round(${mh1}/100,0)

;with t_af as(
select 
  round(mh/100) as yr
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_di_year 
where  pump_qty is not null and pump_qty !=0
  and round(mh/100,0) = round(${mh1}/100,0)
  or mh in (select distinct mh-100 mh from coss_dws.dws_wtw_eng_cons_billing_details_di_year where round(mh/100,0) = round(${mh1}/100,0))
group by 
  yr
  ,region_rpt
),t_bf as(
select 
  round(mh/100) as yr
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_di_year
where pump_qty is not null  and pump_qty !=0
  and round(mh/100,0) = round(${mh1}/100,0)
  or mh in (select distinct mh-100 mh from coss_dws.dws_wtw_eng_cons_billing_details_di_year where round(mh/100,0) = round(${mh1}/100,0))
group by 
  yr
)
insert into coss_dm.dm_wtw_annual_water_treatment_works_item_di
select 
id
,yr statistical_year
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_TW_000027'                        as item_code
  ,'滤水厂单位电耗同比增长率' as item_name_cn
  ,'濾水廠單位電耗同比增長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Electricity Consumption Per Unit In Water Treatment Works' as item_name_en  
  ,case when t1.kwh_qty is null or t1.kwh_qty = 0 then 0
  else  (t.kwh_qty - t1.kwh_qty)/t1.kwh_qty * 100 end   as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_bf t
  left join t_bf t1 on t.yr = t1.yr+1 and t.region = t1.region
where t.yr = round(${mh1}/100,0)
  
union all
select
  uuid()                             as id
  ,t.region                           as region
  ,'IT_TW_000027'                        as item_code
  ,'滤水厂单位电耗同比增长率' as item_name_cn
  ,'濾水廠水站單位電耗同比增長率' as item_name_tc  
  ,'Year on Year Growth Rate Of Electricity Consumption Per Unit In Water Treatment Works' as item_name_en  
  ,case when t1.kwh_qty is null or t1.kwh_qty = 0 then 0
  else  (t.kwh_qty - t1.kwh_qty)/t1.kwh_qty * 100 end   as item_value
  ,'%'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.yr                              as yr
from t_af t
  left join t_af t1 on t.yr = t1.yr+1 and t.region = t1.region
  where t.yr = round(${mh1}/100,0)
)

```

## 4.coss_dm.dm_wtw_monthly_water_treatment_works_item_di

```sql
;drop table if exists coss_dm.dm_wtw_monthly_water_treatment_works_item_di
;create table if not exists coss_dm.dm_wtw_monthly_water_treatment_works_item_di(
  id                           varchar(50)
  ,statistical_month            decimal(10,0)
  ,region_abbr                 varchar(120)
  ,inter_item_code             varchar(120)
  ,item_value                  decimal(20,5)
  ,dm_update_time              timestamp(6) default current_timestamp
  ,dm_load_time                timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_water_treatment_works_item_month_region_code unique (statistical_month,region_abbr,inter_item_code)
)
with (orientation = row, compression = no)
distribute by hash (statistical_month,region_abbr)
;comment on table  coss_dm.dm_wtw_monthly_water_treatment_works_item_di                       is 'The Annual Pump Station items'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.id                   is 'Primary Key'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.statistical_month     is 'Statistical month'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.region_abbr          is 'Regional Abbreviation'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.inter_item_code      is 'internal item code'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.item_value           is 'item value'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.dm_update_time       is 'Data Update Time'
;comment on column coss_dm.dm_wtw_monthly_water_treatment_works_item_di.dm_load_time         is 'Data Loading Time'

```

### 4.1 吨水电耗

```sql
;delete from coss_dm.dm_wtw_monthly_water_treatment_works_item_di
where 
inter_item_code in( 
'IT_TW_000025'
)
and statistical_month >= ${mh1}

;with t_af as(
select 
  mh as mh
  ,region_rpt region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_di_year
where  pump_qty is not null and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
  ,region_rpt
),t_bf as(
select 
  mh as mh
  ,'HKSAR'     region
  ,sum(total_kwh)/sum(pump_qty) kwh_qty
from coss_dws.dws_wtw_eng_cons_billing_details_di_year 
where pump_qty is not null  and pump_qty !=0
  and mh >= ${mh1}
group by 
  mh
)
insert into coss_dm.dm_wtw_monthly_water_treatment_works_item_di
select 
id
,mh statistical_month
,region region_abbr
,item_code inter_item_code
,item_value
,dm_update_time
,dm_load_time
from 
(
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/ML'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_bf t

union all
select
  uuid()                             as id
  ,region                           as region
  ,'IT_TW_000025'                        as item_code
  ,'滤水厂单位电耗' as item_name_cn
  ,'濾水廠水站單位電耗' as item_name_tc  
  ,'Electricity Consumption Per Unit Of Water Treatment Works' as item_name_en  
  ,t.kwh_qty                       as item_value
  ,'kwh/ML'                             as unit
  ,localtimestamp                    as dm_update_time
  ,localtimestamp                    as dm_load_time
  ,t.mh                              as mh
from t_af t)

```



## 5.history data

### 5.1coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di

> 滤水厂一张图-水厂能耗历史数据
> 供水运行一张图-水厂能耗历史数据

```sql
;drop table if exists coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di
;create table if not exists coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di(
  id                     varchar(50)
  ,asset_id              decimal(11)
  ,asset_name            varchar(120)
  ,asset_desc            varchar(120)
  ,i_type_code           varchar(150)
  ,i_type_desc           varchar(150)
  ,region_rpt            varchar(150)
  ,bill_id               varchar(60)
  ,bill_date             timestamp(6)
  ,tariff_name           varchar(150)
  ,tariff_desc           varchar(300)
  ,utility_name          varchar(150)
  ,utility_desc          varchar(800)
  ,kwh_on_peak           decimal(10,0)
  ,kwh_off_peak          decimal(10,0)
  ,payout                decimal(10,0)
  ,total_kwh             decimal(10,0)
  ,pump_qty              decimal(20,5)
  ,dm_update_time        timestamp(6) default current_timestamp
  ,dm_load_time          timestamp(6) default current_timestamp
  ,statistical_month     decimal(10)
  ,primary key (id)
  ,constraint uk_eng_cons_billing_bill_id unique (bill_id)

)
with (orientation = row, compression = no)
-- distribute by hash (bill_id)
;comment on table  coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di                    is 'pump station running billing history'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.asset_id           is  'asset id'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.asset_name         is  'asset name'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.asset_desc         is  'asset description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.i_type_code        is  'installation type code'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.i_type_desc        is  'installation type  description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.region_rpt         is  'region report'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.bill_id            is  'bill_id'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.bill_date          is  'bill date'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.tariff_name        is  'tariff name'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.tariff_desc        is  'tariff description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.utility_name       is  'utility name'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.utility_desc       is  'utility description'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.kwh_on_peak        is  'power consumption of on peak (kwh)'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.kwh_off_peak       is  'power consumption of off peak (kwh)'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.payout             is  'pay out'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.total_kwh          is  'power consumption of total (kwh), the calculation logic is (kwh_on_peak + kwh_off_peak)'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.pump_qty           is  'water pumped this month'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.dm_update_time     is  'dm update time'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.dm_load_time       is  'dm load time'
;comment on column coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di.statistical_month  is  'statistical month'
```

> 计算代码

```sql
;delete from coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di where statistical_month  >= ${mh1}
;insert into coss_dm.dm_wtw_monthly_eng_cons_billing_hist_di
select
  uuid()            as id                 -- id
  ,asset_id         as asset_id           -- asset id
  ,asset_name       as asset_name         -- asset name
  ,asset_desc       as asset_desc         -- asset description
  ,i_type_code      as i_type_code        -- installation type code
  ,i_type_desc      as i_type_desc        -- installation type  description
  ,region_rpt       as region_rpt         -- region report
  ,bill_id          as bill_id            -- bill_id
  ,bill_date        as bill_date          -- bill date
  ,tariff_name      as tariff_name        -- tariff name
  ,tariff_desc      as tariff_desc        -- tariff description
  ,utility_name     as utility_name       -- utility name
  ,utility_desc     as utility_desc       -- utility description
  ,kwh_on_peak      as kwh_on_peak        -- power consumption of on peak (kwh)
  ,kwh_off_peak     as kwh_off_peak       -- power consumption of off peak (kwh)
  ,payout           as payout             -- pay out
  ,total_kwh        as total_kwh          -- power consumption of total (kwh), the calculation logic is (kwh_on_peak + kwh_off_peak)
  ,pump_qty         as pump_qty           -- water pumped this month
  ,localtimestamp   as dm_update_time     -- dm update time
  ,localtimestamp   as dm_load_time       -- dm load time
  ,mh               as statistical_month  -- statistical month
from coss_dws.dws_wtw_eng_cons_billing_details_di_year 
where mh >= ${mh1}

```

### 5.2coss_dm.dm_psr_monthly_ps_running_item_di

> 抽水站一张图-泵房泵机运行情况

```sql
;drop table if exists coss_dm.dm_psr_monthly_ps_running_item_di
;create table if not exists coss_dm.dm_psr_monthly_ps_running_item_di(
  id                  varchar(50)
  ,asset_id           decimal(10)
  ,region_abbr        varchar(50)
  ,sub_region         varchar(50)
  ,installation_no    varchar(50)
  ,ps_en              varchar(100)
  ,ps_cn              varchar(100)
  ,address_en         varchar(100)
  ,address_cn         varchar(100)
  ,kwh_ml             decimal(20,5)
  ,running_pumps      decimal(20,5)
  ,total_pumps        decimal(20,5)
  ,statistical_month  decimal(10,0)
  ,dm_update_time     timestamp(6) default current_timestamp
  ,dm_load_time       timestamp(6) default current_timestamp
  ,primary key (id)
  ,constraint uk_pump_station_running_item_month_region_code unique (statistical_month,region_abbr,asset_id)
)
with (orientation = row, compression = no)
-- distribute by hash (statistical_month, region_abbr)
;comment on table  coss_dm.dm_psr_monthly_ps_running_item_di                       is 'The Monthly Pump Station Running items'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.id                    is 'Primary Key'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.asset_id              is 'asset id'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.region_abbr           is 'region abbr'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.sub_region            is 'sub region'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.installation_no       is 'installation_no'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.ps_en                 is 'pump station en name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.ps_cn                 is 'pump station cn name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.address_en            is 'address en name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.address_cn            is 'address cn name'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.kwh_ml                is 'kwh/ml'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.running_pumps         is 'running pump number'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.total_pumps           is 'total pump number'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.statistical_month     is 'statistical month'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.dm_update_time        is  'dm update time'
;comment on column coss_dm.dm_psr_monthly_ps_running_item_di.dm_load_time          is  'dm load time'
```

> 计算代码

```sql
;delete from coss_dm.dm_psr_monthly_ps_running_item_di where statistical_month >= ${mh1}
;with t_a as (
select
  asset_id                  as asset_id
  ,mh                       as mh
  ,sum(if(run_hours>0,1,0)) as running_pumps
  ,count(1)                 as total_pumps
from coss_dwd.dwd_psr_pump_running_details_di_year
where mh >= ${mh1}
group by
  asset_id
  ,mh
), t_b as(
select
  asset_id            as asset_id
  ,mh                 as mh
  ,sum(total_kwh)/sum(pump_qty) as kwh_ml
  from coss_dws.dws_psr_eng_cons_billing_details_di_year 
  where pump_qty is not null and pump_qty != 0
   and  mh >= ${mh1}
  group by
  asset_id
  ,mh
)
insert into coss_dm.dm_psr_monthly_ps_running_item_di
select 
  uuid() id
  ,t2.asset_id
  ,t2.region_abbr
  ,t2.sub_region
  ,t2.i_code installation_no
  ,t2.ps_en
  ,t2.ps_cn
  ,t2.address_en
  ,t2.address_cn
  ,t1.kwh_ml
  ,t.running_pumps
  ,t.total_pumps 
  ,t.mh statistical_month
  ,localtimestamp dm_update_time
  ,localtimestamp dm_load_time
from 
t_a t inner join t_b t1 on t.asset_id = t1.asset_id and t.mh = t1.mh
inner join coss_dim.dim_ps_installation_info t2 on t.asset_id = t2.asset_id

```



# 重要数据表





## 1.coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di

```sql
-- coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di definition

-- Drop table

-- DROP TABLE coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di;

CREATE TABLE coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di (
	id varchar(50) NOT NULL, -- Primary Key
	statistical_year numeric(10) NULL, -- Statistical Year
	region_abbr varchar(120) NULL, -- Regional Abbreviation
	asset_id int4 NULL, -- asset id
	wtw_name_en varchar(250) NULL, -- Water Treatment Work English Name
	inter_item_code varchar(120) NULL, -- internal item code
	item_value numeric(20, 5) NULL, -- item value
	dm_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Update Time
	dm_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Loading Time
	CONSTRAINT dm_wtw_annual_water_treatment_works_item_detail_di_pkey_g PRIMARY KEY (id) BY GLOBAL INDEX,
	CONSTRAINT uk_water_treatment_works_item_year_wtw_code UNIQUE (statistical_year, region_abbr, wtw_name_en, inter_item_code)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di IS 'The Water Treatment Works items';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.id IS 'Primary Key';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.statistical_year IS 'Statistical Year';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.region_abbr IS 'Regional Abbreviation';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.asset_id IS 'asset id';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.wtw_name_en IS 'Water Treatment Work English Name';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.inter_item_code IS 'internal item code';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.item_value IS 'item value';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.dm_update_time IS 'Data Update Time';
COMMENT ON COLUMN coss_dm.dm_wtw_annual_water_treatment_works_item_detail_di.dm_load_time IS 'Data Loading Time';


```



## 2.coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di

```sql
-- coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di definition

-- Drop table

-- DROP TABLE coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di;

CREATE TABLE coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di (
	id varchar(50) NOT NULL, -- Primary Key
	statistical_month numeric(10) NULL, -- Statistical month
	region_abbr varchar(120) NULL, -- Regional Abbreviation
	asset_id int4 NULL, -- asset_id
	wtw_name_en varchar(250) NULL, -- Water Treatmemt Works
	inter_item_code varchar(120) NULL, -- internal item code
	item_value numeric(20, 5) NULL, -- item value
	dm_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Update Time
	dm_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- Data Loading Time
	CONSTRAINT dm_wtw_monthly_water_treatment_works_item_detail_di_pkey_g PRIMARY KEY (id) BY GLOBAL INDEX,
	CONSTRAINT uk_water_treatment_works_item_month_wtw_code UNIQUE (statistical_month, wtw_name_en, inter_item_code) BY GLOBAL INDEX
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di IS 'The Annual Pump Station items';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.id IS 'Primary Key';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.statistical_month IS 'Statistical month';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.region_abbr IS 'Regional Abbreviation';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.asset_id IS 'asset_id';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.wtw_name_en IS 'Water Treatmemt Works';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.inter_item_code IS 'internal item code';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.item_value IS 'item value';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.dm_update_time IS 'Data Update Time';
COMMENT ON COLUMN coss_dm.dm_wtw_monthly_water_treatment_works_item_detail_di.dm_load_time IS 'Data Loading Time';
```



## 3.coss_dim.dim_wtw_installation_info definition

```sql
-- coss_dim.dim_wtw_installation_info definition

-- Drop table

-- DROP TABLE coss_dim.dim_wtw_installation_info;

CREATE TABLE coss_dim.dim_wtw_installation_info (
	asset_id numeric(11) NOT NULL, -- asset id 
	asset_name varchar(120) NULL, -- asset name
	asset_desc varchar(120) NULL, -- asset descrip
	loca_code varchar(15) NULL, -- local code
	region_abbr varchar(150) NULL, -- region
	i_type_id numeric(11) NULL, -- installation type id 
	i_type_code varchar(150) NULL, -- installation code 
	i_type_desc varchar(150) NULL, -- installation type descrip
	dim_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm update time
	dim_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm load time
	CONSTRAINT dim_wtw_installation_info_pkey PRIMARY KEY (asset_id)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dim.dim_wtw_installation_info IS 'The Water Treatment Works items';

-- Column comments

COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.asset_id IS 'asset id ';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.asset_name IS 'asset name';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.asset_desc IS 'asset descrip';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.loca_code IS 'local code';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.region_abbr IS 'region';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.i_type_id IS 'installation type id ';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.i_type_code IS 'installation code ';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.i_type_desc IS 'installation type descrip';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.dim_update_time IS 'dm update time';
COMMENT ON COLUMN coss_dim.dim_wtw_installation_info.dim_load_time IS 'dm load time';
```



## 4.coss_dm.dm_psr_daily_ps_running_item_di definition

```sql
-- coss_dm.dm_psr_daily_ps_running_item_di definition

-- Drop table

-- DROP TABLE coss_dm.dm_psr_daily_ps_running_item_di;

CREATE TABLE coss_dm.dm_psr_daily_ps_running_item_di (
	asset_id numeric(10) NULL,
	region varchar(50) NULL,
	sub_region varchar(50) NULL,
	installation_no varchar(50) NULL,
	offical_eng_name varchar(100) NULL,
	offical_chi_name varchar(100) NULL,
	address_eng varchar(100) NULL,
	address_chi varchar(100) NULL,
	kwh_ml numeric(20, 5) NULL,
	running_pumps numeric(20, 5) NULL,
	total_pumps numeric(20, 5) NULL,
	mh numeric(10) NULL
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_psr_daily_ps_running_item_di IS 'The daily Pump Station Running items';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'assetid';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'region';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'subregion';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'installationno';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'officalengname';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'officalchiname';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'addresseng';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'addresschi';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'kwhml';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'runningpumps';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'totalpumps';
COMMENT ON COLUMN coss_dm.dm_psr_daily_ps_running_item_di.asset_id IS 'mh';

```

## 5.coss_dim.dim_ps_installation_info definition

```sql
-- coss_dim.dim_ps_installation_info definition

-- Drop table

-- DROP TABLE coss_dim.dim_ps_installation_info;

CREATE TABLE coss_dim.dim_ps_installation_info (
	asset_id numeric(10) NOT NULL, -- asset id
	region_abbr varchar(50) NULL, -- region abbr
	sub_region varchar(50) NULL, -- sub region
	i_code   varchar(50) NULL, -- installation_no
	ps_en varchar(100) NULL, -- pump station en name
	ps_cn varchar(100) NULL, -- pump station cn name
	address_en varchar(100) NULL, -- address en name
	address_cn varchar(100) NULL, -- address cn name
	dim_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm update time
	dim_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm load time
	CONSTRAINT dim_ps_installation_info_pkey_g PRIMARY KEY (asset_id) BY GLOBAL INDEX
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dim.dim_ps_installation_info IS 'The Monthly Pump Station Running items';

-- Column comments

COMMENT ON COLUMN coss_dim.dim_ps_installation_info.asset_id IS 'asset id';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.region_abbr IS 'region abbr';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.sub_region IS 'sub region';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.i_code IS 'installation_no';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.ps_en IS 'pump station en name';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.ps_cn IS 'pump station cn name';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.address_en IS 'address en name';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.address_cn IS 'address cn name';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.dim_update_time IS 'dm update time';
COMMENT ON COLUMN coss_dim.dim_ps_installation_info.dim_load_time IS 'dm load time';
```





## tmp sql



```sql
;create table coss_tmp.dm_wtw_monthly_water_treatment_works_item_di as 
select * from coss_dm.dm_wtw_monthly_water_treatment_works_item_di where region_abbr = 'HK'

;delete  from coss_dm.dm_wtw_monthly_water_treatment_works_item_di where region_abbr = 'HK' 

;update coss_tmp.dm_wtw_monthly_water_treatment_works_item_di   set region_abbr = 'HKI' where region_abbr ='HK'

;insert into coss_dm.dm_wtw_monthly_water_treatment_works_item_di select * from coss_tmp.dm_wtw_monthly_water_treatment_works_item_di

;drop table coss_tmp.dm_wtw_monthly_water_treatment_works_item_di

;select * from coss_dm.dm_wtw_monthly_water_treatment_works_item_di where region_abbr = 'HKI'
```







```shell
80
/usr/lib/python3/dist-packages/urllib3/connectionpool.py:1015: InsecureRequestWarning: Unverified HTTPS request is being made to host 'wiki.sis2.wsd.gov'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
  warnings.warn(
130
/usr/lib/python3/dist-packages/urllib3/connectionpool.py:1015: InsecureRequestWarning: Unverified HTTPS request is being made to host 'wiki.sis2.wsd.gov'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
  warnings.warn(
190
/usr/lib/python3/dist-packages/urllib3/connectionpool.py:1015: InsecureRequestWarning: Unverified HTTPS request is being made to host 'wiki.sis2.wsd.gov'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
  warnings.warn(
Traceback (most recent call last):
  File "/opt/app/coss/emis/ods_emis_report_all.py", line 35, in <module>
    re = request_json.get_pump_report(url,ast)
  File "/opt/app/coss/emis/request_json.py", line 49, in get_pump_report
    per_destination = report[i]['per_destination']
KeyError: 'per_destination'

```

