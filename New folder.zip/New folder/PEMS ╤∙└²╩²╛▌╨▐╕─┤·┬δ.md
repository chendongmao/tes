## 建表语句

### 1.dm_cus_monthly_skill_hotline_item_di

```sql
-- coss_dm.dm_cus_monthly_skill_hotline_item_di definition

-- Drop table

-- DROP TABLE coss_dm.dm_cus_monthly_skill_hotline_item_di;

CREATE TABLE coss_dm.dm_cus_monthly_skill_hotline_item_di (
	skill_code varchar(50) NOT NULL, -- Skill Code
	statistical_month varchar(7) NOT NULL, -- statistical month
	skill_cn varchar(100) NULL, -- Skill Chinese Simplified
	skill_tc varchar(100) NULL, -- Skill Chinese Traditional
	skill_en varchar(100) NULL, -- Skill English
	vdn numeric(20) NULL, -- Number of calls [Hotline calls]
	acd numeric(20) NULL, -- Successful call [hotline call]
	other_way numeric(20) NULL, -- Number of queues [hotline calls]
	aban numeric(20) NULL, -- Number of abandonments [Hotline calls]
	ans_rate numeric(10, 5) NULL, -- Connection rate [hotline calls]
	vdn_callout numeric(20) NULL, -- Outgoing call volume [hotline outgoing call]
	acd_callout numeric(20) NULL, -- Number of calls [hotline outbound calls]
	acd_hw numeric(20) NULL, -- Call volume
	wo_num_hw numeric(20) NULL, -- Work order volume
	dm_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm update time
	dm_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm load time 
	CONSTRAINT dm_cus_monthly_skill_hotline_item_di_pkey PRIMARY KEY (skill_code, statistical_month)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_cus_monthly_skill_hotline_item_di IS 'Monthly Skill Hotline';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.skill_code IS 'Skill Code';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.statistical_month IS 'statistical month';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.skill_cn IS 'Skill Chinese Simplified';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.skill_tc IS 'Skill Chinese Traditional';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.skill_en IS 'Skill English';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.vdn IS 'Number of calls [Hotline calls]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.acd IS 'Successful call [hotline call]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.other_way IS 'Number of queues [hotline calls]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.aban IS 'Number of abandonments [Hotline calls]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.ans_rate IS 'Connection rate [hotline calls]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.vdn_callout IS 'Outgoing call volume [hotline outgoing call]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.acd_callout IS 'Number of calls [hotline outbound calls]';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.acd_hw IS 'Call volume';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.wo_num_hw IS 'Work order volume';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.dm_update_time IS 'dm update time';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_item_di.dm_load_time IS 'dm load time ';


```

### 2.dim_cus_skill_info

```sql
-- coss_dim.dim_cus_skill_info definition

-- Drop table

-- DROP TABLE coss_dim.dim_cus_skill_info;

CREATE TABLE coss_dim.dim_cus_skill_info (
	skill_code varchar(50) NOT NULL, -- Skill Code
	skill_cn varchar(100) NULL, -- Skill Chinese Simplified
	skill_tc varchar(100) NULL, -- Skill Chinese Traditional
	skill_en varchar(100) NULL, -- Skill English
	dim_update_time timestamp(6) NOT NULL DEFAULT pg_systimestamp(), -- dim update time
	dim_load_time timestamp(6) NOT NULL DEFAULT pg_systimestamp(), -- dim load time
	CONSTRAINT dim_cus_skill_info_pkey PRIMARY KEY (skill_code)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dim.dim_cus_skill_info IS 'customer service skills information';

-- Column comments

COMMENT ON COLUMN coss_dim.dim_cus_skill_info.skill_code IS 'Skill Code';
COMMENT ON COLUMN coss_dim.dim_cus_skill_info.skill_cn IS 'Skill Chinese Simplified';
COMMENT ON COLUMN coss_dim.dim_cus_skill_info.skill_tc IS 'Skill Chinese Traditional';
COMMENT ON COLUMN coss_dim.dim_cus_skill_info.skill_en IS 'Skill English';
COMMENT ON COLUMN coss_dim.dim_cus_skill_info.dim_update_time IS 'dim update time';
COMMENT ON COLUMN coss_dim.dim_cus_skill_info.dim_load_time IS 'dim load time';

-- Permissions

ALTER TABLE coss_dim.dim_cus_skill_info OWNER TO gddst01;
GRANT ALL ON TABLE coss_dim.dim_cus_skill_info TO gddst01;
```

### 3.dm_cus_monthly_skill_hotline_wo_item_di

```sql
-- DROP TABLE coss_dm.dm_cus_monthly_skill_hotline_wo_item_di;

CREATE TABLE coss_dm.dm_cus_monthly_skill_hotline_wo_item_di (
	skill_code varchar(50) NOT NULL, -- Skill Code
	statistical_month varchar(7) NOT NULL, -- statistical month
	skill_cn varchar(100) NULL, -- Skill Chinese Simplified
	skill_tc varchar(100) NULL, -- Skill Chinese Traditional
	skill_en varchar(100) NULL, -- Skill English
	wo_num_hw int8 NULL, -- Total Work Orders
	wo_pending int8 NULL, -- Pending (orders)
	wo_process int8 NULL, -- In Progress (orders)
	wo_processed int8 NULL, -- Completed (orders)
	wo_undelay int8 NULL, -- Non-delayed
	wo_delay int8 NULL, -- Delayed
	cpt_tot int8 NULL, -- CTEC-Complaints_Total Orders
	cpt_account int8 NULL, -- CTEC-Account Complaints
	cpt_trees int8 NULL, -- CTEC-Tree Complaints
	cpt_slopes int8 NULL, -- CTEC-Slope Complaints
	cpt_water_facility int8 NULL, -- CTEC-Water Supply Facility Complaints
	cpt_inside_service int8 NULL, -- CTEC-Private Pipe Complaints
	cpt_coc int8 NULL, -- CTEC-User Rights Complaints
	other_cpt_tot int8 NULL, -- Non-CTEC-Complaints_Total Orders
	other_cpt_account int8 NULL, -- Non-CTEC-Account Complaints
	other_cpt_trees int8 NULL, -- Non-CTEC-Tree Complaints
	other_cpt_slopes int8 NULL, -- Non-CTEC-Slope Complaints
	other_cpt_water_facility int8 NULL, -- Non-CTEC-Water Supply Facility Complaints
	other_cpt_inside_service int8 NULL, -- Non-CTEC-Private Pipe Complaints
	other_cpt_coc int8 NULL, -- Non-CTEC-User Rights Complaints
	dm_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm update time
	dm_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm load time 
	CONSTRAINT dm_cus_monthly_skill_hotline_wo_item_di_pkey PRIMARY KEY (skill_code, statistical_month)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_cus_monthly_skill_hotline_wo_item_di IS 'skill hotline work orders';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.skill_code IS 'Skill Code';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.statistical_month IS 'statistical month';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.skill_cn IS 'Skill Chinese Simplified';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.skill_tc IS 'Skill Chinese Traditional';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.skill_en IS 'Skill English';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.wo_num_hw IS 'Total Work Orders';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.wo_pending IS 'Pending (orders)';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.wo_process IS 'In Progress (orders)';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.wo_processed IS 'Completed (orders)';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.wo_undelay IS 'Non-delayed';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.wo_delay IS 'Delayed';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_tot IS 'CTEC-Complaints_Total Orders';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_account IS 'CTEC-Account Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_trees IS 'CTEC-Tree Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_slopes IS 'CTEC-Slope Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_water_facility IS 'CTEC-Water Supply Facility Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_inside_service IS 'CTEC-Private Pipe Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.cpt_coc IS 'CTEC-User Rights Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_tot IS 'Non-CTEC-Complaints_Total Orders';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_account IS 'Non-CTEC-Account Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_trees IS 'Non-CTEC-Tree Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_slopes IS 'Non-CTEC-Slope Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_water_facility IS 'Non-CTEC-Water Supply Facility Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_inside_service IS 'Non-CTEC-Private Pipe Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.other_cpt_coc IS 'Non-CTEC-User Rights Complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.dm_update_time IS 'dm update time';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_skill_hotline_wo_item_di.dm_load_time IS 'dm load time ';


```

### 4.dm_cus_monthly_water_quality_cpt_di

```sql
-- coss_dm.dm_cus_monthly_water_quality_cpt_di definition

-- Drop table

-- DROP TABLE coss_dm.dm_cus_monthly_water_quality_cpt_di;

CREATE TABLE coss_dm.dm_cus_monthly_water_quality_cpt_di (
	region_abbr varchar(50) NOT NULL, -- region code
	statistical_month varchar(7) NOT NULL, -- statistical month
	water_facility int8 NULL, -- water facility complaints
	water_supply int8 NULL, -- water supply complaints
	dm_update_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm update time
	dm_load_time timestamp(6) NULL DEFAULT pg_systimestamp(), -- dm load time 
	CONSTRAINT dm_cus_monthly_water_quality_cpt_di_pkey PRIMARY KEY (region_abbr, statistical_month)
)
WITH (
	orientation=row,
	compression=no
);
COMMENT ON TABLE coss_dm.dm_cus_monthly_water_quality_cpt_di IS 'water quality complaints';

-- Column comments

COMMENT ON COLUMN coss_dm.dm_cus_monthly_water_quality_cpt_di.region_abbr IS 'region code';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_water_quality_cpt_di.statistical_month IS 'statistical month';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_water_quality_cpt_di.water_facility IS 'water facility complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_water_quality_cpt_di.water_supply IS 'water supply complaints';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_water_quality_cpt_di.dm_update_time IS 'dm update time';
COMMENT ON COLUMN coss_dm.dm_cus_monthly_water_quality_cpt_di.dm_load_time IS 'dm load time ';

-- Permissions

ALTER TABLE coss_dm.dm_cus_monthly_water_quality_cpt_di OWNER TO gddst01;
GRANT ALL ON TABLE coss_dm.dm_cus_monthly_water_quality_cpt_di TO gddst01;
```



## 创建样例数据

### dm_cus_monthly_skill_hotline_item_di

> 样例数据的生成在公司GS 环境

```sql
-- 获取11个技能组样例数据
create table coss_tmp.dm_cus_monthly_hotline_item_di_arch_251119 as 
select 
case 
		when agentgroup = 'Account'                then 'CU_SK_000001'
	when agentgroup = 'C of C Application'     then 'CU_SK_000002'
	when agentgroup = 'C of C Enquiry'         then 'CU_SK_000003'
	when agentgroup = 'General'                then 'CU_SK_000004'
	when agentgroup = 'Main Burst'             then 'CU_SK_000005'
	when agentgroup = 'SAT Account'            then 'CU_SK_000006'
	when agentgroup = 'SAT Take up + Give up'  then 'CU_SK_000007'
	when agentgroup = 'Technical '             then 'CU_SK_000011'
end skill_code,
*
from coss_dm.dm_cus_monthly_hotline_item_di
union all 
select 'CU_SK_000008' as skill_code , * from coss_dm.dm_cus_monthly_hotline_item_di where agentgroup = 'Main Burst'
union all select 'CU_SK_000009' as skill_code , *  from coss_dm.dm_cus_monthly_hotline_item_di where agentgroup = 'C of C Application'
union all select 'CU_SK_000010' as skill_code , *  from coss_dm.dm_cus_monthly_hotline_item_di where agentgroup = 'Technical '

-- 获取目标表展示数据
select
t1.skill_code              ,
to_char(mh, 'yyyymm') as statistical_month ,
t1.skill_cn ,
t1.skill_tc ,
t1.skill_en ,
vdn                     ,
acd                     ,
other_way               ,
aban                    ,
ans_rate                ,
vdn_callout             ,
acd_callout             ,
acd_hw                  ,
wo_num_hw               ,
now() dm_update_time          ,
now() dm_load_time            
from coss_tmp.dm_cus_monthly_hotline_item_di_arch_251119  t
inner join coss_dim.dim_cus_skill_info t1 on t.skill_code =  t1.skill_code 

-- 模拟2024 和2025 年数据
insert into coss_dm.dm_cus_monthly_skill_hotline_item_di
select 
skill_code
,statistical_month + 100 statistical_month
,skill_cn
,skill_tc
,skill_en
,vdn
,acd
,other_way
,aban
,ans_rate
,vdn_callout
,acd_callout
,acd_hw
,wo_num_hw
,dm_update_time
,dm_load_time
from coss_dm.dm_cus_monthly_skill_hotline_item_di

union all 

select 
skill_code
,statistical_month + 200 statistical_month
,skill_cn
,skill_tc
,skill_en
,vdn
,acd
,other_way
,aban
,ans_rate
,vdn_callout
,acd_callout
,acd_hw
,wo_num_hw
,dm_update_time
,dm_load_time
from coss_dm.dm_cus_monthly_skill_hotline_item_di


```



### dm_cus_monthly_skill_hotline_wo_item_di

```sql
-- 拼接skill code
create table coss_tmp.dm_cus_monthly_hotline_wo_item_di_01 as 
select 
case 
    when region = 'NTE' then 'CU_SK_000001'
    when region = 'NTW' then 'CU_SK_000002'
    when region = 'HK'  then 'CU_SK_000003'
    when region = 'K'   then 'CU_SK_000004'
end skill_code,
*
from coss_dm.dm_cus_monthly_hotline_wo_item_di
where skill_code is not null 

union all 

select 
case 
    when region = 'NTE' then 'CU_SK_000005'
    when region = 'NTW' then 'CU_SK_000006'
    when region = 'HK'  then 'CU_SK_000007'
    when region = 'K'   then 'CU_SK_000008'
end skill_code,
*
from coss_dm.dm_cus_monthly_hotline_wo_item_di
where skill_code is not null 

union all

select 
case 
    when region = 'NTE' then 'CU_SK_000009'
    when region = 'NTW' then 'CU_SK_000010'
    when region = 'HK'  then 'CU_SK_000011'
end skill_code,
*
from coss_dm.dm_cus_monthly_hotline_wo_item_di
where skill_code is not null 

-- 关联生成目标表
create table coss_tmp.dm_cus_monthly_hotline_wo_item_di_02 as
select 
t1.skill_code                as skill_code 
,to_char(t.mh,'yyyyMM')                        as statistical_month
,t1.skill_cn                 as skill_cn
,t1.skill_tc                 as skill_tc
,t1.skill_en                 as skill_en
,t.wo_num_hw                 as wo_num_hw
,t.wo_pending                as wo_pending
,t.wo_process                as wo_process
,t.wo_processed              as wo_processed
,t.wo_undelay                as wo_undelay
,t.wo_delay                  as wo_delay
,t.cpt_tot                   as cpt_tot
,t.cpt_account               as cpt_account
,t.cpt_trees                 as cpt_trees
,t.cpt_slopes                as cpt_slopes
,t.cpt_water_facility        as cpt_water_facility
,t.cpt_inside_service        as cpt_inside_service
,t.cpt_coc                   as cpt_coc
,t.other_cpt_tot             as other_cpt_tot
,t.other_cpt_account         as other_cpt_account
,t.other_cpt_trees           as other_cpt_trees
,t.other_cpt_slopes          as other_cpt_slopes
,t.other_cpt_water_facility  as other_cpt_water_facility
,t.other_cpt_inside_service  as other_cpt_inside_service
,t.other_cpt_coc             as other_cpt_coc
,localtimestamp              as dm_update_time
,localtimestamp              as dm_load_time
from 
coss_tmp.dm_cus_monthly_hotline_wo_item_di_01 t 
inner join coss_dim.dim_cus_skill_info t1 on t.skill_code = t1.skill_code

-- 导入数据
insert into coss_dm.dm_cus_monthly_skill_hotline_wo_item_di
select * from coss_tmp.dm_cus_monthly_hotline_wo_item_di_02

```

### dm_cus_monthly_water_quality_cpt_di

```sql
insert into coss_dm.dm_cus_monthly_water_quality_cpt_di
select 
   region                          region_abbr
   ,to_char(mh,'yyyyMM')                              statistical_month
   ,other_cpt_water_facility        water_facility
   ,other_cpt_inside_service        water_supply
   ,current_timestamp               dm_update_time
   ,current_timestamp               dm_load_time
from 
coss_dm.dm_cus_monthly_hotline_wo_item_di
```

