# 1.客服数据量统计

## 数据质量表

| 清洗级别                       | 数据量   |
| ------------------------------ | -------- |
| 1.全表数据量                   | 48695340 |
| 2.rmk字段食水或咸水数据量      | 610548   |
| 3.primise id数据量             | 45487    |
| 4.关联上ISMS数据量（内部供水） | 101      |
| 5.关联上IMWMS数量              | 1191     |
| 6.关联上CCBS系统的FA表         | 20357    |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```sql
   select count(1) from  coss_tmp.in_comm 
   ```

2. rmk字段食水或咸水数据量：610548

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   
   ```

3. primise id数据量：45487

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

4. 关联上ISMS数据量：101

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   ```

5. 关联上IMWMS数量:1191

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccid from coss_tmp.wr_ccbs )
   	)
   
   ```

6. 关联上CCBS系统的FA表：20357

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联CCBS FA表
   	and(
   	in_comm_id  in (select cust_comm_id from coss_tmp.fld_act )
   	)
   ```

   

# 2.投诉专题数据量统计

## 数据质量表

| 清洗级别                                    | 数据量   |
| ------------------------------------------- | -------- |
| 1.全表数据量                                | 48695340 |
| 2.根据cust_comm_type_desc过滤客服投诉数据量 | 165698   |
| 3.rmk字段食水或咸水数据量                   | 53085    |
| 4.primise id数据量                          | 2691     |
| 5.关联上ISMS数据量                          | 16       |
| 6.关联上IMWMS数量                           | 0        |
| 7.关联上CCBS系统的FA表                      | 727      |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```sql
   select count(1) from  coss_tmp.in_comm 
   ```

2. 根据cust_comm_type_desc过滤客服投诉数据量:165698

   - 获取投诉cust_comm_type_code：

     ```sql
     select 
     cust_comm_type_code  from cfg_cust_comm_type where lower(cust_comm_type_desc) like '%comp%' and  lower(cust_comm_type_desc) not like '%comple%'  and  lower(cust_comm_type_desc) not like '%company%'
     ```

   - 客服投诉数据量

     ```sql
     select count(1) from  coss_tmp.in_comm where 
     -- 过滤所有投诉类型的数据
         in_comm_type_code in(
         'FKDISCLTRC',
         'FKDISCLTRE',
         'DIARCOMP',
         'DIRTCFLU',
         'DIRTCPOT',
         'OTHRCOMP',
         'SALICOMP',
         'TASTCOMP',
         'WORMCOMP',
         'NONWSDCMPLNS',
         'LWORMWTRC',
         'RWWCSPIIC',
         'RWWCSPIIE',
         'RWWCSPIVC',
         'RWWCSPIVE',
         'LUNSATWSC',
         'LUNSATWSE',
         'RWWCSVC',
         'RWWCSVE',
         'LWORMWTRE',
         'AW1001C',
         'LDISWTRC',
         'LDISWTRE',
         'RWWCSVIE',
         'RWWCSVIIC',
         'RWWCSVIIE',
         'AW1001E',
         'AW1009M',
         'COMPLAINTS',
         'COMPUTER_SYS'
         )
     ```

3. rmk字段食水或咸水数据量：53085

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   ```

4. primise id数据量：2691

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

5. 关联上ISMS数据量：16

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   
   ```

6. 关联上IMWMS数量: 0

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
    in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.wr_ccbs )
   	)
   
   ```

7. 关联上CCBS系统的FA表:727

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联CCBS FA表
   	and(
   	in_comm_id  in (select cust_comm_id from coss_tmp.fld_act )
   	)
   ```

# 3.水质事故数据量统计

## 数据质量统计表

| 清洗级别                           | 数据量   |
| ---------------------------------- | -------- |
| 1.全表数据量                       | 48695340 |
| 2.根据code(WTCQ)过滤水质投诉数据量 | 160096   |
| 3.rmk字段食水或咸水数据量          | 52962    |
| 4.水质事件类型S1..P1..数据量       | 13891    |
| 5.primise id数据量                 | 555      |
| 6.关联上ISMS                       | 13       |
| 7.关联上IMWMS                      | 0        |
| 8.关联上CCBS系统的FA表             | 281      |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```
   select count(1) from  coss_tmp.in_comm 
   ```

2. 根据code(WTCQ)过滤水质投诉数据量：160096

   ```
   select count(1) from  coss_tmp.in_comm where in_comm_cls_code = 'WTCQ'
   ```

3. rmk字段食水或咸水数据量：52962

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   ```

4. 水质事件类型S1..P1..数据量：13891

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   ```

5. primise id数据量：555

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

6. 关联上ISMS: 13

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   ```

7. 关联上IMWMS：0

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联IMWMS 数据
   	and(
   	in_comm_id  in (select ccid from coss_tmp.wr_ccbs )
   	)
   ```

8. 关联上CCBS系统的FA表：281

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联CCBS FA表
   	and(
   	in_comm_id  in (select cust_comm_id from coss_tmp.fld_act )
   	)
   ```

   

# 4.爆管事故管理

## 数据质量统计表

| 清洗级别                           | 数据量   |
| ---------------------------------- | -------- |
| 1.全表数据量                       | 48695340 |
| 2.根据爆管或渗漏关键字过滤客服数据 | 828869   |
| 3.rmk字段食水或咸水数据量          | 47844    |
| 4.primise id数据量                 | 1749     |
| 5.关联上ISMS                       | 12       |
| 6.关联上IMWMS                      | 1        |
| 7.关联上CCBS系统的FA表             | 728      |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```
   select count(1) from  coss_tmp.in_comm 
   ```

2. 根据爆管或渗漏关键字过滤客服数据：828869

   - 过滤爆管或渗漏

     ```sql
     select cust_comm_type_code  from cfg_cust_comm_type where lower(cust_comm_type_desc) like '%bur%' or  lower(cust_comm_type_desc)  like '%leak%'
     ```

   - 统计爆管或渗漏数据条数

     ```sql
     select 
     count(1) 
     from  coss_tmp.in_comm 
     where
     -- 过滤爆管或渗漏
         in_comm_type_code  in(
         'CMAINLEAK',
         'MAINBURST',
         'MAINLEAK',
         'CMAINBURST',
         'MDEPLEAKAGE',
         'WWO1050A1C',
         'WWO1050C',
         'WWO1050E',
         'WWO1050A1E',
         'WWO1050A2C',
         'WWO1050A2E',
         'IOLEAKISE',
         'IOLEAKISC',
         'HYDTLEAK',
         'ISBURST',
         'ISLEAK',
         'MRLEAK',
         'LEAKWAVR'
         )
     ```

3. rmk字段食水或咸水数据量:47844

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   -- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   ```

4. primise id数据：1749

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

5. 关联上ISMS:12

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   ```

   

6. 关联上IMWMS:1

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联IMWMS 数据
   	and(
   	in_comm_id  in (select ccid from coss_tmp.wr_ccbs )
   	)
   ```

7. 关联上CCBS系统的FA表：728

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联CCBS FA表
   	and(
   	in_comm_id  in (select cust_comm_id from coss_tmp.fld_act )
   	)
   	
   ```

   



















STTSS数据配置说明

```
Raw Water Actual Supply Volume = bi_p_224
Raw Water Actual Supply Volume = bi_p_225
```



```
Raw Water Propose Supply Volume = bi_p_226
Raw Water Propose Supply Volume = bi_p_227
```





```

```

滤水厂一张图-水厂能耗情况柱状图二级下钻页面坐标乱序

![image-20260305150940984](img/main/image-20260305150940984.png)

抽水站一张图水质坐标乱序

![image-20260305180114752](img/main/image-20260305180114752.png)



抽水站一张图历史数据错误

![image-20260305195658313](img/main/image-20260305195658313.png)







投诉单表`cms_complaint`数据基本信息

1. 数据日期范围2020-11-19 18:04:48.000 至 2025-06-06 18:07:49.000
2. 数据量：4956

水质事故管理新旧数据对比

1. location 是手动输入，很多数据为空，在地图上落点有难度
2. 楼层数据也是手动输入，很多数据为空
3. 状态



```
jdbc:postgresql://10.66.110.64:8000,10.66.110.151:8000,10.66.110.194:8000,10.66.110.235:8000/wsd_dm?loadBalanceHosts=true&refreshCNIpListTime=3


db_mid_arcadm_0926
db_mid_batchadm_0926
db_mid_ccbsder_0926
db_mid_cdsadm_0926
db_mid_ctaws_0926
db_mid_ctccbs_0926
db_mid_dsg_0926
db_mid_edmsradm_0926
db_mid_esdadm_0926
db_mid_kbadm_0926
db_mid_patchadm_0926
db_mid_ppctaws_0926
db_mid_ppctccbs_0926
db_mid_updba_0926
db_mid_wfmadm_0926
db_mid_wsmsadm_0926
isms
```





# CC表数据分析

## 水质投诉类型

WTCQ

C&E - Water Quality Related Matters (Water Quality)

| cust_comm_cls_code | cust_comm_type_code | cust_comm_type_desc                    |
| ------------------ | ------------------- | -------------------------------------- |
| WTCQ               | DIARCOMP            | Diarrhea Pot Quality Complaint         |
| WTCQ               | DIRTCFLU            | TMF / Flushing Water Quality Complaint |
| WTCQ               | DIRTCPOT            | Potable Water Quality Complaint        |
| WTCQ               | OTHRCOMP            | Other Technical Complaint              |
| WTCQ               | SALICOMP            | Salinity Quality Complaint             |
| WTCQ               | TASTCOMP            | Odor/Taste Quality Comp                |
| WTCQ               | WORMCOMP            | Worm Quality Complaint                 |
| WTCQ               | WQSTCT              | Water Quality Sample Collection        |

新的码值

| wo_biz_type_code | origin_code | topic_type    | biz_type_cn        | biz_type_tc      | biz_type_en                                                  |
| ---------------- | ----------- | ------------- | ------------------ | ---------------- | ------------------------------------------------------------ |
| CP_WQ_000008     | C1          | WATER_QUALITY | 水黄; 奶白; 所有色 | 水黃;奶白;所有色 | discoloured water                                            |
| CP_WQ_000004     | S3          | WATER_QUALITY | 氯气; 漂白水       | 氯氣;漂白水      | excessive chlorine                                           |
| CP_WQ_000003     | S2          | WATER_QUALITY | 怪味; 异味; 锈味   | 怪味;異味;鏽味   | unknown odour other than solvent smell and excessive chlorine |
| CP_WQ_000005     | P1          | WATER_QUALITY | 黑点; 黑粒         | 黑點;黑粒        | bitumen particles in water                                   |
| CP_WQ_000007     | P3          | WATER_QUALITY | 粒粒               | 粒粒             | unknown particles other than bitumen and sand in water       |
| CP_WQ_000006     | P2          | WATER_QUALITY | 沙粒               | 沙粒             | sand in water                                                |
| CP_WQ_000001     | L1          | WATER_QUALITY | 集水区             | 集水區           | water gathering ground                                       |
| CP_WQ_000002     | S1          | WATER_QUALITY | 天拿水,油漆        | 天拿水,油漆      | odour with solvent smell                                     |

## 水质投诉数据基本信息

1. 数据总条数为：160096

2. 起止日期为：2022-06-12 14:15:22.000 至 2025-09-26 16:58:49.000	

3. 有带premise_id的数据量：5790  (占总数据量的：3.6%)

4. 水质投诉类型格式化的数据量：16490(占投诉总数据量的10.3%)

   ```sql
   select *  from db_mid_ctccbs_0926.cust_comm where  cust_comm_cls_code ='WTCQ'  and (rmk like '%(I)%' or rmk like '%(M)%')
   ```

## 水质事故ParentID 在rmk字段中

| rmk                                                          |
| ------------------------------------------------------------ |
| CASE#3-8943679794 - APS250920A32331 有關沙頭角邨水有微粒生物事宜 Due date: 22.10.2025 (day end)    *Related CCID 8291175998 (WR no. 25G014765) 不留名 |
| 17/F, BLOCK D, CHUN KUI HOUSE; KAM CHUN COURT; MA ON SHAN, NEW TERRITORIES TEL: 9867-2383 陳慧女仕 (PCCID 6360079843) (I) (P1) 食水有啡黑色雜質 Case No. 2521/2025. |
| 29 PINACEAE DRIVE; PALM SPRINGS; YUEN LONG, NEW TERRITORIES (I) (S2) PCCID 9501579343 |
| HOUSE 29, PINACEAE DRIVE, PALM SPRINGS, YUEN LONG, NT. *(I)(S2) toxic and contaminated water and chemical gas smell *Parent CC: 9501579343 Related CCID 8461681055 |
| (I)(S2) 大埔 中心圍 9A 地下 近日食水有類似鏽味 要求盡快到場 REF CCID:2590872474 馮先生 TEL: 91521321 |
| (I)(P1) 大埔 汀角路 布心排村68H號 1/F . 食水有黑色沉澱物 (來電人稱今早師傅到場檢查食水弱後, 單位食水出現黑色沉潑物, REFER CCID: 5867663093) 蔡小姐 TEL: 60511701 CR: 60981877 |
| FLAT B07, 11/F, TOWER 5, PHASE 2, HIGH PARK, 1 HUNG ON LANE, HUNG SHUI KIU YUEN LONG, NT * (I) (P1) 食水發現有小黑點 * PCCID : 1209824085 Case No.2416/2025. |
| (I)(P1)(S2) 馬鞍山 富寶花園 4座 27樓 K室, 食水有黑點 及 不用水一段時間再開水, 食水會若大的金屬異味 (REFER CCID 8258670117 & 6813119016: 來電人稱換錶後食水仍然出現黑點 及 會有金屬異味的情況, 要求本署再次跟進 及 回覆能否安排驗水) 鄭太 TEL: 97845523 (要求回覆到場時間 及 檢查結果) CR: 10749187 |
| (I)(P1) FLAT 4, 13/F, BLOCK D, CHUN KUI HOUSE, KAM CHUN COURT, 150 MA ON SHAN ROAD, MA ON SHAN, NT * PCCID : 7554512933 |
| HOUSE 29, PINACEAE DRIVE, PALM SPRINGS, YUEN LONG, NT * (I)(S2) toxic and contaminated water and chemical gas smell * P.CCID: 9501579343 |
| NOVUM EAST, 856 KING'S ROAD, QUARRY BAY, HONG KONG  (I) : (S2)  MO 3990 0788  Par. CCID:7598302411 ***DMCCT Case - Deadline: 2025/10/11 Case No.2475/2025. |
| HOUSE 29, PINACEAE DRIVE, PALM SPRINGS, YUEN LONG, NT * (I)(S2) toxic and contaminated water and chemical gas smell * P.CCID: 9501579343 |
| BLOCK D, CHUN KUI HOUSE; KAM CHUN COURT; MA ON SHAN, NEW TERRITORIES TEL: 5118-1192 HSU PING 小姐 (PCCID 8680602916) (I) (P1) 水質有黑色一點點 Case No. 2522/2025. |
| FLAT 3, 26/F, BLOCK D, CHUN KUI HOUSE; KAM CHUN COURT; 150 MA ON SHAN ROAD; MA ON SHAN, NEW TERRITORIES TEL: 9075-9350 CAROL 雷小姐 (PCCID 3846943815) (I) (P1)  水喉出水時有黑色雜質, 過濾器變了黑色 Case No. 2523/2025. |
| ST MICHEL, 33 TO SHEK STREET, SHA TIN, NT TEL: 6088-4796 FRANKIE TSUI (PCCID 3636261604) |
| 2/F, 16, YAU YUE WAN VILLAGE ROAD, YAU YUE WAN VILLAGE, TSEUNG KWAN O, NT * (I) (C1)  * PCCID : 6286515541 Case No.2419/2025. |
| (I)(O1) 九龍灣 麗晶花園 15座3H室 食水乸皮膚,會痛及麻痺 來電人要求師傅明日到場檢查水質情況 王小姐 TEL: 61673797  RELATED CCID: 4365732089 CR: 10727579 |
| (I)(P1)屯門 青山公路 飛揚 2期3座 9樓H室 食水有黑點 馮小姐 66079092 related CCID 2289346274 |
| (I)(C1) 油柑頭村49號 1/F, 水黃 謝小姐 RELATED CCID # 8855029305 |
| HOUSE 29, PINACEAE DRIVE, PALM SPRINGS, YUEN LONG, NT * (I)(S2) toxic and contaminated water and chemical gas smell * P.CCID: 9501579343 |
| Wrong type please refer CCID 9500310452                      |
| *強烈要求今天必須再來* 緊急*  (I)(C1)大角咀 福利街 8號 港灣豪庭 第1座 13樓 A室 食水弱 及 食水黃 師傅今日來過維修完後情況差過未維修前 有沒有其他師傅跟進? 要求師傅盡快維修好 湯先生TEL:9370 6281 (請師傅回覆到場時間及維修結果) related to CCID: 8475812205 |
| (I)(C1) 油麻地 石壁道 15號 3/F, 食水黃泥色 (來電人該單位今天開始出現食水黃泥色, 但暫未發現其他住戶有黃泥水, 及大廈並沒有進行內部維修, 唯近日該街其他大廈單位有過此問題, 來電人希望本署留意跟進, 早前同街其他大廈單位 CCID: 1191201088, 3653781905) 鄭小姐 (業主代表) TEL: 65583633 (要求回覆到場時間 及 檢查結果) CR: 61027261 |
| (I)(P1) 將軍澳 廣明苑 廣隆閣516室, 食水有黑色沙泥 (來電人稱由昨天開始已出現黑色沙泥, 管理處表示沒有其他住戶通報此情況) 陳先生 TEL: 98646334 / 陳太 TEL: 60777401 (請師傅先盡快回覆能否今天內到場) (另外 食水弱CCID: 1989199982) CR: 60990849 |
| (I) (O1) ROOM A, 8/F, HANG LUNG BANK TSIMSHATSUI BRANCH BUILDING; 46-48 GRANVILLE ROAD; TSIM SHA TSUI, KOWLOON RELATED CCID: 9500310452 Case No.2358/2025. |
| (I)(P1) 牛頭角 樂華南邨 敏華樓 B座 23/F B2308室 食水仍有黑點 本電人稱知道本署師傅今天曾到場換了新水錶, 已告知初步紀錄師傅拆錶來水清, 無黑點, 但今天晚上回家發現仍有黑點情況, 要求再次跟進 她稱暫時上網見到有其他單位有食水白色情況, 不清楚大廈何時進行過洗水缸工程, 要求跟進 REF CCID:7347404291 吳小姐 TEL: 61595707 |
| (I)(P1)洪水橋 洪安里1號 滙都 第三座1樓A02室 食水有黑點。 來電人指7月尾收樓開始發現，向管理處查問，指收到其他住戶投訴但不多。 本人已告知來電人本署9月9號 到場跟進結果，因有黑點，不敢飲用，要求本署盡快跟進 張小姐 T: 69223312  CR: 10725292 RELATED CCID: 6222197570 |
| HOUSE 29, PINACEAE DRIVE, PALM SPRINGS, YUEN LONG, NT * (I)(S2) toxic and contaminated water and chemical gas smell * P.CCID: 9501579343 |
| (I)(P1)馬鞍山 馬鞍山路150號 錦駿苑C座 駿驃閣 1106室  來電人陳生是上址住戶，表示昨日已經報告食水有黑點情況，本署亦已到場清洗了水錶， 但情況沒有改善，食水仍然有黑點。 陳生不滿此情況，表示大廈會安排今天洗水缸，不知道有沒有洗。 陳生表示整個屋苑都有同樣情況，認爲是街喉供水問題，要求本署解決， 若不然就找東張西望協助，要求儘快到場跟進。  RELATED CCID:8421264679 陳先生 Tel:69294294(要求回覆到場時間) |
| (I)(C1) 大埔 龍尾村52C 2/F食水有黑點  8月20號到場冲表，水質改善，今日又再出現黑點 不知道鄰居有沒有相同情況/大廈沒有維修工程 RELATED CCID#8174814180 麥小姐 T: 93193883  （水錶在花園内需要開門 要求師傅明天下1點後致電約到場時間） |
| BLOCK D, CHUN KUI HOUSE, KAM CHUN COURT, MA ON SHAN, NT * (I) (P1) 水濁及有黑色的物質 * PCCID : 4649913290 |
| (I)(P1) 馬鞍山 富寶花園4座27樓 K室 食水有黑點 來電人稱上星期報過水質問題，本署到場換錶後黑點有減少。但現時又再出現黑點問題，要求本署再跟進。不清楚鄰居有否這情況及不知道大廈近期有否做維修。 鄭太 TEL:97845523 RECCID: 8258670117 |
| 29 PINACEAE DRIVE; PALM SPRINGS; YUEN LONG, NEW TERRITORIES (I) (S2) PCCID 9501579343 |
| (Letter from MO) 有關: 投訴 Wetland Seasons Bay 沖廁水骯髒及發黃 馬小姐 T: 3704 5555 PCCID 2938060548 |

## 客服数据类型

| 系统     | 大类 | 小类 |
| -------- | ---- | ---- |
| CCBS客服 | 82   | 1201 |
| PEMS客服 | 24   | 350  |

### CCBS客服大类cfg_cust_comm_cls

| cust_comm_cls_code | cust_comm_cls_desc                                          | cust_comm_cls_desc_tc                                       |
| ------------------ | ----------------------------------------------------------- | ----------------------------------------------------------- |
| MML                | Meter Management - Letter                                   | Meter Management - Letter                                   |
| TENQ               | DSD - Telephone Enquiry                                     | DSD - Telephone Enquiry                                     |
| AOPF               | PF- (Out) Fittings Acceptance                               | PF- (Out) Fittings Acceptance                               |
| CAAD               | Consumer Account/Address                                    | Consumer Account/Address                                    |
| CAAP               | Consumer Account/Auto                                       | Consumer Account/Auto                                       |
| DSPT               | Dispute Request                                             | Dispute Request                                             |
| NTES               | DSD - Newly identified TES Account                          | DSD - Newly identified TES Account                          |
| PRMR               | Processing Routine Meter Reading                            | Processing Routine Meter Reading                            |
| WMSC               | C&E - Non-WSD Complaints                                    | C&E - Non-WSD Complaints                                    |
| WTIS               | C&E - Inside Service Related Matters (Inside Service Fault) | C&E - Inside Service Related Matters (Inside Service Fault) |
| WTMD               | C&E - Meter Related Matters (Meter Defects)                 | C&E - Meter Related Matters (Meter Defects)                 |
| PCTS               | AWS- (In) Conversion to Salt Water for Flushing             | AWS- (In) Conversion to Salt Water for Flushing             |
| PMWS               | AWS- (In) Others                                            | AWS- (In) Others                                            |
| PRFA               | AWS- (In) Refixing                                          | AWS- (In) Refixing                                          |
| PTWC               | AWS- (In) Temporary Water Supply for Construction Site      | AWS- (In) Temporary Water Supply for Construction Site      |
| PVHA               | AWS- (In) Village Type House                                | AWS- (In) Village Type House                                |
| MIC                | Converted MIC record                                        | Converted MIC record                                        |
| ZAOW               | AWS - (Out) Water Supply Application                        | AWS - (Out) Water Supply Application                        |
| CUAC               | Customer Account                                            | Customer Account                                            |
| BSCR               | DSD - Bulk SC Refund                                        | DSD - Bulk SC Refund                                        |
| LSCR               | DSD - Notification Letter for Bulk Refund SC                | DSD - Notification Letter for Bulk Refund SC                |
| EDMS               | EDMS                                                        | EDMS                                                        |
| CODR               | DSD - COD Reassessment                                      | DSD - COD Reassessment                                      |
| MTRD               | Meter Read                                                  | Meter Read                                                  |
| RCG                | Revenue & Credit Control/General                            | Revenue & Credit Control/General                            |
| RFS                | Request for Services                                        | Request for Services                                        |
| SCSD               | DSD - Sewer Connection Status Dispute                       | DSD - Sewer Connection Status Dispute                       |
| WFCE               | C&E - General Enquiry (First Contact Enquiry solved)        | C&E - General Enquiry (First Contact Enquiry solved)        |
| WSD                | WSD                                                         | WSD                                                         |
| WTCQ               | C&E - Water Quality Related Matters (Water Quality)         | C&E - Water Quality Related Matters (Water Quality)         |
| WTSF               | C&E - Water Supply Related Matters (Water Supply Fault)     | C&E - Water Supply Related Matters (Water Supply Fault)     |
| PPMA               | AWS- (In) Portable Meter                                    | AWS- (In) Portable Meter                                    |
| PRPA               | AWS- (In) Replumbing                                        | AWS- (In) Replumbing                                        |
| AOWM               | AWS - (Out) Water Supply Application (Memo)                 | AWS - (Out) Water Supply Application (Memo)                 |
| IVRO               | IVRS Outgoing Form                                          | IVRS Outgoing Form                                          |
| OGDN               | Outstanding GDNS Demand Notes                               | Outstanding GDNS Demand Notes                               |
| BSCB               | DSD - Bulk SC Backdated                                     | DSD - Bulk SC Backdated                                     |
| DMC                | DMC - Incoming Customer Contact                             | DMC - Incoming Customer Contact                             |
| RFSL               | Request for Services - Letter                               | Request for Services - Letter                               |
| AOLP               | LP - (Out) Issue Plumber's Licence                          | LP - (Out) Issue Plumber's Licence                          |
| CASA               | Consumer Account/SA                                         | Consumer Account/SA                                         |
| CNC                | Credit and collection contacts                              | Credit and collection contacts                              |
| DMIS               | DSD - Miscellaneous                                         | DSD - Miscellaneous                                         |
| DPTU               | Dispute                                                     | Dispute                                                     |
| FINC               | Finance                                                     | Finance                                                     |
| NSWC               | DSD - New Sewer Connection                                  | DSD - New Sewer Connection                                  |
| NWAC               | New A/C                                                     | New A/C                                                     |
| RMDR               | WSD Reminders                                               | WSD Reminders                                               |
| WARC               | C&E - Account-related Matters                               | C&E - Account-related Complaints                            |
| WFLA               | C&E - Fishing Licence Application                           | C&E - Fishing Licence Application                           |
| APNF               | PF- (In) Application for Fittings                           | PF- (In) Application for Fittings                           |
| IPWB               | AWS - (In) Water Boat Application                           | AWS - (In) Water Boat Application                           |
| PSMA               | AWS- (In) Separate Meter                                    | AWS- (In) Separate Metering                                 |
| AOWC               | AWS - (Out) Water Supply Application (Chinese)              | AWS - (Out) Water Supply Application (Chinese)              |
| COCI               | C of C - Incoming                                           | C of C - Incoming                                           |
| PAYP               | Instalment Plan Schedule                                    | Instalment Plan Schedule                                    |
| IVRS               | Interactive Voice Response System                           | Interactive Voice Response System                           |
| WWTA               | C&E - Water Ticket Application                              | C&E - Water Ticket Application                              |
| WDSF               | C&E - Distribution Related Matters (Distribution Fault)     | C&E - Distribution Related Matters (Distribution Fault)     |
| ENQ                | Enquiry                                                     | Enquiry                                                     |
| CENQ               | DSD - Counter Enquiry                                       | DSD - Counter Enquiry                                       |
| WLTR               | C&E - Written Reply                                         | C&E - Written Reply - Letter                                |
| DMAR               | DSD - Mixed Account Re-assessment                           | DSD - Mixed Account Re-assessment                           |
| ALPL               | LP - (In) Apply Plumber's Licence                           | LP - (In) Apply Plumber's Licence                           |
| BSRE               | DSD - Business Reclassification                             | DSD - Business Reclassification                             |
| CAST               | Consumer Account/Stat                                       | Consumer Account/Stat                                       |
| CLAC               | Closed A/C                                                  | Closed A/C                                                  |
| DBCT               | Debt Collection                                             | Debt Collection                                             |
| DFRV               | DSD - Discharge Factor Review                               | DSD - Discharge Factor Review                               |
| RCBG               | Revenue & Credit Control/Bank Guarantee & Deposit           | Revenue & Credit Control/Bank Guarantee & Deposit           |
| TESD               | DSD - Newly Identified TES A/C Dispute                      | DSD - Newly Identified TES A/C Dispute                      |
| PMEA               | AWS- (In) Relocate/Enlarge Meter                            | AWS- (In) Relocate/Enlarge Meter                            |
| PNBA               | AWS- (In) New Building                                      | AWS- (In) New Building                                      |
| COCO               | C of C Outgoing                                             | C of C Outgoing                                             |
| AOWE               | AWS - (Out) Water Supply Application (English)              | AWS - (Out) Water Supply Application (English)              |
| SMRR               | Special Meter Read                                          | Special Meter Read                                          |
| AWFA               | AWS FA                                                      | AWS FA                                                      |
| WDSR               | C&E - Distribution Rel. Mat.(Distribution fault)            | C&E - Distribution Rel. Mat.(Distribution fault)            |
| OFCH               | Official Channel                                            | Official Channel                                            |
| AATE               | test                                                        | test                                                        |
| WGEN               | C&E - General                                               | C&E - General                                               |
| WWOM               | C&E - New Works, Operation and Maintenance                  | C&E - New Works, Operation and Maintenance                  |

数据条数为：82

### CCBS客服小类cfg_cust_comm_type

| cust_comm_cls_code | cust_comm_type_code | cust_comm_type_desc                                          |
| ------------------ | ------------------- | ------------------------------------------------------------ |
| PMWS               | PMWS-INSTP          | MIS- Inspection Stage (WWO1149)                              |
| PTWC               | PTWC-INSTP          | CON- Inspection Stage (WWO1149)                              |
| CUAC               | DISPUTESD           | Dispute Service Detail                                       |
| WTIS               | MISCELLANEOU        | Miscellaneous                                                |
| AOPF               | AW3005D2C           | Approval Letter - P and F (Flush Valve - Cat C) (Chinese)    |
| AOPF               | AW3005D2E           | Approval Letter - P and F (Flush Valve - Cat C) (English)    |
| AOPF               | AW3005D3E           | Approval Letter - P and F (Salt Use Only - Cat C) (English)  |
| AOPF               | AW3005D3C           | Approval Letter - P and F (Salt Use Only - Cat C) (Chinese)  |
| CAAP               | WWO1060             | Letter to consumer advising the reverse dishonour autopay    |
| AOPF               | AW3029C             | Enquiry Letter (Chinese)                                     |
| AOPF               | AW3029E             | Enquiry Letter (English)                                     |
| CAAP               | CEBLKLTR            | Blank Letter Sheet                                           |
| AOPF               | AW3003E             | Interim Acknowledgement Advise (English)                     |
| PTWC               | PTWC-IRSTR          | CON- Installation or Removal Stage (Incoming from Other/Mis) |
| PCTS               | PCTS-IRSTR          | FLU- Installation or Removal Stage (Incoming from Other/Mis) |
| ...                | ...                 | ...                                                          |

总类型的数据条数为：1201

### PEMS 大类：t_dic_bigclass

| ID   | center | nameCN               | nameGN               | nameEN                                     | parentID | level   |
| ---- | ------ | -------------------- | -------------------- | ------------------------------------------ | -------- | ------- |
| 5    | [NULL] | 账户账单相关         | 賬戶賬單相關         | Account matters                            | [NULL]   | 00:00.0 |
| 8    | [NULL] | 咨询                 | 咨詢                 | Enquiry                                    | 00:00.0  | 00:00.0 |
| 9    | [NULL] | 用户权相关           | 用戶權相關           | CoC matters                                | [NULL]   | 00:00.0 |
| 18   | [NULL] | 咨询                 | 咨詢                 | Enquiry                                    | 00:00.0  | 00:00.0 |
| 19   | [NULL] | 申请                 | 申請                 | Application                                | 00:00.0  | 00:00.0 |
| 20   | [NULL] | 供水相关             | 供水相關             | Water Supply matters                       | [NULL]   | 00:00.0 |
| 21   | [NULL] | 水务设施相关         | 水務設施相關         | Water Facility matters                     | [NULL]   | 00:00.0 |
| 22   | [NULL] | 一般                 | 壹般                 | General                                    | [NULL]   | 00:00.0 |
| 24   | [NULL] | 投诉                 | 投訴                 | Complaints                                 | 00:00.0  | 00:00.0 |
| 25   | [NULL] | 申请                 | 申請                 | Application                                | 00:00.0  | 00:00.0 |
| 26   | [NULL] | 投诉                 | 投訴                 | Complaints                                 | 9        | 2       |
| 27   | [NULL] | 咨询                 | 咨詢                 | Enquiry                                    | 20       | 2       |
| 28   | [NULL] | 故障（输配管网）     | 故障（輸配管網）     | Fault (Supply & Distribution Network)      | 20       | 2       |
| 29   | [NULL] | 服务要求（私人水管） | 服務要求（私人水管） | Request for Services (Inside Service)      | 20       | 2       |
| 30   | [NULL] | 投诉（输配管网）     | 投訴（輸配管網）     | Complaints (Supply & Distribution Network) | 20       | 2       |
| 31   | [NULL] | 投诉（私人水管）     | 投訴（私人水管）     | Complaints (Inside Service)                | 20       | 2       |
| 32   | [NULL] | 视察要求（私人水管） | 視察要求（私人水管） | Request for Inspection (Inside Service)    | 20       | 2       |
| 37   | [NULL] | 咨询                 | 咨詢                 | Enquiry                                    | 22       | 2       |
| 69   | [NULL] | 咨询                 | 咨詢                 | Enquiry                                    | 21       | 2       |
| 70   | [NULL] | 投诉                 | 投訴                 | Complaints                                 | 21       | 2       |
| 78   | [NULL] | 要求调查             | 要求調查             | Request for Investigation                  | 5        | 2       |
| 79   | [NULL] | 水费争议             | 水費爭議             | Water Charge Dispute                       | 5        | 2       |
| 80   | [NULL] | 用戶权争议           | 用戶權爭議           | CoC Dispute                                | 9        | 2       |
| 81   | [NULL] | 投诉                 | 投訴                 | Complaints                                 | 22       | 2       |

大类总数据量24

### PEMS 小类t_dic_subclass

| ID   | nameCN                  | nameGN                  | nameEN                                                    |
| ---- | ----------------------- | ----------------------- | --------------------------------------------------------- |
| 4    | 主管道爆裂              | 主管道爆裂              | Main Burst                                                |
| 7    | 水管爆管/严重渗漏       | 水管爆管/嚴重滲漏       | Pipe Burst or Serious Leakage of Inside Service           |
| 10   | 水质                    | 水質                    | Water Quality                                             |
| 11   | 停水/水量小             | 停水/水量小             | Lack of Potable/Flushing Supply                           |
| 12   | 渗漏                    | 渗漏                    | Seepage                                                   |
| 16   | 确认水表安装位置        | 確認水表安裝位置        | Confirm Meter Arrangement                                 |
| 17   | 检查水表更换            | 檢查水表更換            | Inspection for Meter Replacement                          |
| 19   | 非法改管                | 非法改管                | Unauthorized Extension                                    |
| 20   | I/S公共服务疑似缺陷检查 | I/S公共服務疑似缺陷檢查 | Suspected Defective I/S Inspection for Communal Service   |
| 21   | I/S楼宇疑似缺陷检查     | I/S樓宇疑似缺陷檢查     | Suspected Defective I/S Inspection for Individual Premise |
| 22   | PU调查                  | PU調查                  | PU Investigation                                          |
| 23   | 其他                    | 其他                    | Others                                                    |
| 24   | 账户相关事项            | 賬戶相關事項            | Account-related Matters                                   |
| 25   | 分期付款                | 分期付款                | Instalment Plan SD                                        |
| 27   | 水费争议                | 水費爭議                | Dispute                                                   |
| 28   | 退还水费                | 退還水費                | Refund of Water Charges                                   |
| 30   | 截断供水                | 截斷供水                | Disconnection                                             |
| 31   | 更改注册用户名称        | 更改註冊用戶名稱        | Correction of RC's Name                                   |
| 32   | 退还水费按金/收费       | 退还水费按金/收費       | Refund of Water Deposit / Fee Account                     |
| 33   | 水表读数相关            | 水錶讀數相關            | Meter Read Matters                                        |
| 34   | 更改用水地址            | 更改用水地址            | Change of service address                                 |
| 35   | 客户帐户服务            | 客戶帳戶服務            | Customer Accounts Services                                |
| 36   | CoC相关事项             | CoC相關事項             | C of C                                                    |
| 37   | 申请承接账户            | 申請承接賬戶            | TAKEAPPS - Take-up Application                            |
| 38   | 申请承接账户相关回复    | 申請承接賬戶相關回復    | TAKEREPY - Take-up Other Reply                            |
| 39   | 申请结束账户相关回复    | 申請結束賬戶相關回復    | GIVEREPY - Give-up Other Reply                            |
| 60   | 申请结束账户            | 申請結束賬戶            | GIVEAPPS - Give-up Application                            |
| 133  | 非法钓鱼                | 非法釣魚                | Complaint against illegal fishing                         |
| 145  | PU随机检查              | PU隨機檢查              | PU Random Check                                           |
| 147  | form k                  | form k                  | form k                                                    |
| 148  | 内部设施爆管            | 內部設施爆管            | Inside Service Burst                                      |
| 149  | 内部设施渗漏            | 內部設施滲漏            | Inside Service Leak                                       |
| 150  | 冲洗水浑浊              | 沖洗水渾濁              | Dirty Flush Water                                         |

总数据量：350

## 客服数据的基本信息

1. 数据总条数为：48695310
2. 起止日期为：2022-06-12 14:15:22.000 至 2025-09-26 17:59:23.000
3. 带有premise_id的数据量：16126445 (占总数的33.12%)
4. rmk 为空的数量：546567(占总数的1.12%)



# 客服数据系统关联分析

水质关联分析

ISIT 库

isms.css_work_order_test

DM库

db_mid_ctccbs_0926.cust_comm

```sql
select * from db_mid_ctccbs_0926.cust_comm cc where cust_comm_id in(4873431077,
7343121282,
2571333919)
```

工单表关联分析

ISIT 库

imwms.wr_ccbs

DM库

db_mid_ctccbs_0926.cust_comm









1. 投诉代码

   | complaint_type_grp | complaint_type_grp_descr                                    |
   | ------------------ | ----------------------------------------------------------- |
   | WDSF               | C&E - Distribution Related Matters (Distribution fault)     |
   | OFCH               | Official Channel                                            |
   | **WTCQ**           | **C&E - Water Quality Related Matters (Water Quality)**     |
   | WTMD               | C&E - Meter Related Matters (Meter Defects)                 |
   | WTSF               | C&E - Water Supply Related Matters (Water Supply Fault)     |
   | WTIS               | C&E - Inside Service Related Matters (Inside Service Fault) |
   | WTMD               | C&E - Meter Related Matters (Meter defects)                 |
   | WTIS               | C&E - Inside Service Related Matters (Inside service fault) |
   | WWOM               | C&E - New Works, Operation and Maintenance                  |
   | WTSF               | C&E - Water Supply Related Matters (Water Supply fault)     |
   | WGEN               | C&E - General                                               |
   | WMSC               | C&E - Non-WSD Complaints                                    |
   | **WTCQ**           | **C&E - Water Quality Related Matters (Water quality)**     |
   | WARC               | C&E - Account-related Matters                               |
   | WDSF               | C&E - Distribution Related Matters (Distribution Fault)     |

2. 过滤出水质投诉记录

   ```sql
   select * 
   from coss_ods.ods_pems_cus_cms_complaint_df opcccd 
   where complaint_type_grp ='WTCQ'
   ```

3. 谁知投诉类型映射

   >cms投诉类型

   | complaint_type_cd | complaint_type_cd_descr                |
   | ----------------- | -------------------------------------- |
   | OTHRCOMP          | Other Technical Complaint (Obsolete)   |
   | **WQSTCT**        | Water Quality Sample Collection        |
   | DIRTCPOT          | Potable Water Quality Complaint        |
   | **DIRTCFLU**      | TMF / Flushing Water Quality Complaint |
   | TASTCOMP          | Odor/Taste Quality Comp (Obsolete)     |

   > pems新的投诉类型
   >
   > 48条数据中，只有一条按照格式书写
   >
   > (I)(P1) 1823-3-7461218023 西灣河 西灣河街9號 25樓E室 食水有黑色沈澱物

   | wo_biz_type_code | origin_code | topic_type    | biz_type_cn                  | biz_type_tc               | biz_type_en                                                  |
   | ---------------- | ----------- | ------------- | ---------------------------- | ------------------------- | ------------------------------------------------------------ |
   | CP_WQ_000001     | L1          | WATER_QUALITY | 集水区                       | 集水區                    | water gathering ground                                       |
   | CP_WQ_000002     | S1          | WATER_QUALITY | 天拿水,油漆                  | 天拿水,油漆               | odour with solvent smell                                     |
   | CP_WQ_000009     | O1          | WATER_QUALITY | 虫; 咸; 味; 其它安全水质问题 | 蟲;咸;味;其它安全水質問題 | other abnormal conditions related to water safety            |
   | CP_WQ_000004     | S3          | WATER_QUALITY | 氯气; 漂白水                 | 氯氣;漂白水               | excessive chlorine                                           |
   | CP_WQ_000003     | S2          | WATER_QUALITY | 怪味; 异味; 锈味             | 怪味;異味;鏽味            | unknown odour other than solvent smell and excessive chlorine |
   | CP_WQ_000005     | P1          | WATER_QUALITY | 黑点; 黑粒                   | 黑點;黑粒                 | bitumen particles in water                                   |
   | CP_WQ_000007     | P3          | WATER_QUALITY | 粒粒                         | 粒粒                      | unknown particles other than bitumen and sand in water       |
   | CP_WQ_000006     | P2          | WATER_QUALITY | 沙粒                         | 沙粒                      | sand in water                                                |
   | CP_WQ_000008     | C1          | WATER_QUALITY | 水黄; 奶白; 所有色           | 水黃;奶白;所有色          | discoloured water                                            |





```sql
-- isms
select * from coss_tmp.css_work_order
where ccbs_cc_id in (
select cc_id  from coss_tmp.cms_complaint
)

-- ccbs
select count(*) from db_mid_ctccbs_0926.cust_comm cc 
where cust_comm_id in(
select cc_id 
from db_mid_ctccbs_0926.cms_complaint cc 
-- where complaint_type_grp ='WTCQ'
)
and  premise_id is not null 

```



cms_complaintx下游表关联情况

| 系统 | 表明           | 关联数据量 | premise_id非空 |      |
| ---- | -------------- | ---------- | -------------- | ---- |
| ISMS | css_work_order | 7          | 5              |      |
| ccbs | cust_comm      | 5395       | 486            |      |
|      |                |            |                |      |
|      |                |            |                |      |







投诉来源渠道

| 代码  | 投诉来源渠道（中文名称） |
| :---- | :----------------------- |
| PST   | 现场投诉                 |
| FAX   | 传真投诉                 |
| IP-TK | 电话热线投诉             |
| IP-TM | 短信投诉                 |
| IP-WC | 网上/网页投诉            |
| PHN   | 电话投诉                 |
| MISC  | 其他渠道                 |
| EML   | 电子邮件投诉             |









## 父级投诉ID数据量：19

```sql
select
	count(1)
from
	coss_tmp.in_comm
where
-- 水质类型
	in_comm_cls_code = 'WTCQ'	
-- 包含食水海水分类
	and (
	 -- 食水
     rmk like '%食水%'
     or lower(rmk) like '%fresh%'
	-- 冲厕水
	or rmk like '%鹹水%'
	or rmk like '%咸水%'
	or lower(rmk) like '%flush%'
	or lower(rmk) like '%salt water%'
	)
-- 水质类型分类
   and(
	   upper(rmk) like '%(L1)%'
	or upper(rmk) like '%(S1)%'
	or upper(rmk) like '%(C1)%'
	or upper(rmk) like '%(O1)%'
	or upper(rmk) like '%(S3)%'
	or upper(rmk) like '%(S2)%'
	or upper(rmk) like '%(P1)%'
	or upper(rmk) like '%(P3)%'
	or upper(rmk) like '%(P2)%'
	)	
-- premise 内容
   and(
	   lower(rmk) like '%premise%'
	   or premise_id is not null 
	)
-- 关联p ccid
   and(
	   lower(rmk) like '%pccid%'
	   or lower(rmk) like '%parent ccid%'
	   or lower(rmk) like '%p.ccid%'
	)
```

# 





| complaint_type_cd | complaint_type_cd_descr                                  |
| ----------------- | -------------------------------------------------------- |
| UNAUTEXT          | Unauthorized Extension                                   |
| LICENCE_PLUM      | Licence Plumber                                          |
| MAINLEAK          | Main Leak                                                |
| COMPUTER_SYS      | Computer Systems                                         |
| MRRUNABN          | Meter Running Abnormal                                   |
| OTHRCOMP          | Other Technical Complaint (Obsolete)                     |
| VEGETATION        | Vegetation other than Tree                               |
| WATER_CONSER      | Water Conservation                                       |
| METERNR           | Meter Non-Registering                                    |
| METERREPLACE      | Meter Replacement                                        |
| NOPOTSUP          | No / Weak Potable Supply                                 |
| NOPOTSUP          | No / Poor Potable Supply                                 |
| UNMETERUE         | Unmetered Unauthorized Extension                         |
| WQSTCT            | Water Quality Sample Collection                          |
| OUTSWSD           | Handled outside WSD (not DSD)                            |
| EXISTINGFEAT      | Existing features                                        |
| POLICYMATTER      | Policy Matters                                           |
| PLCMRWC           | Policy Matter Related to Water Charges                   |
| HYDTLEAK          | Hydrant Leak                                             |
| CSBRNHSM          | Handled by CS Branch - CS Branch staff manner (Obsolete) |
| TREEGN            | Tree (General)                                           |
| VEGETATIONEN      | Vegetation other than Tree (Enquiry)                     |
| SEEPAGE           | Seepage                                                  |
| CUSACCTS          | Customer Accounts Services                               |
| ISLEAK            | Inside Service Leak                                      |
| MAINBURST         | Main Burst                                               |
| MATERIALS         | Materials                                                |
| WSD_STAFF         | WSD Staff                                                |
| WORKS             | Works                                                    |
| PROMOTION         | Promotion / Education Matters                            |
| OFCSBRCH          | Handled outside Region(CS) within WSD-CCBS User          |
| ISBURST           | Inside Service Burst                                     |
| NONWSDCMPLNS      | Non-WSD Complaints                                       |
| TREEUR            | Tree (Urgent)                                            |
| DIRTCPOT          | Potable Water Quality Complaint                          |
| TOTAL_WATER       | Total Water Management                                   |
| OFCSNCCBS         | Handled outside Region(CS) within WSD-non CCBS           |
| VEGETATIONTR      | Vegetation and Tree                                      |
| MRNOISE           | Meter Noise                                              |
| DISTFMISC         | Miscellaneous                                            |
| CONTRACTOR_S      | Contractor Staff / Consultant Staff                      |
| SLOPESRETAIN      | Slopes / Retaining Wall                                  |
| TREEID            | Tree (Imminent Danger)                                   |
| TREEEN            | Tree (Enquiry)                                           |
| VEGETATIONTR      | Vegetation and Tree (NA)                                 |
| DBOARD            | District Board                                           |
| MRLEAK            | Meter Leak                                               |
| MISCELLANEOU      | Miscellaneous                                            |
| STFACCTM          | WSD Staff Handling Customer Account Matters              |
| VALVEDEFECT       | Valve Defect                                             |
| CSOTHERS          | Handled by CS Branch - Others                            |
| SERVICE_WSD       | Service of WSD                                           |
| NOFLUSUP          | No / Weak Flushing Supply                                |
| TASTCOMP          | Odor/Taste Quality Comp (Obsolete)                       |
| TREEBP            | Tree (Buck-passing)                                      |
| DIRTCFLU          | TMF / Flushing Water Quality Complaint                   |
| NOFLUSUP          | No / Poor Flushing Supply                                |
| CSOTHERS          | Handled by Region (CS) - Others                          |





投诉单处理状态

| 状态代码 | 投诉单处理状态（具体码值说明）                             |
| -------- | ---------------------------------------------------------- |
| C        | 已结案（投诉问题已处理完毕，同步反馈投诉人，归档完成）     |
| I        | 处理中（投诉已派单至对应水务班组，正在推进问题核查/处置）  |
| P        | 已派单（投诉单审核通过，分配至对应水务责任部门/人员）      |
| S        | 已受理（投诉单已录入系统，完成初步审核，确认符合受理条件） |
| W        | 待处理（投诉单已接收，暂未分配处理人员/未启动审核）        |
| X        | 已撤销（投诉人主动申请撤销，或核实为无效投诉后撤销）       |





| 平台代码 | 平台码值翻译（中文名称+具体说明）                           |
| -------- | ----------------------------------------------------------- |
| C        | 客服平台（水务人工客服专属平台，用于人工录入、处理投诉）    |
| E        | 电子平台（线上自助投诉平台，含官网、小程序、APP等电子渠道） |