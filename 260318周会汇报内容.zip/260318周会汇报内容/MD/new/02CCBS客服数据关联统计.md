# 1.客服数据量统计

## 数据质量表

| 清洗级别                       | 数据量   |
| ------------------------------ | -------- |
| 1.全表数据量                   | 48695340 |
| 2.rmk字段食水或咸水数据量      | 610548   |
| 3.primise id数据量             | 45487    |
| 4.关联上ISMS数据量（内部供水） | 101      |
| 5.关联上IMWMS数量              | 1191     |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```sql
   select count(1) from  coss_tmp.in_comm 
   ```

2. rmk字段食水或咸水数据量：610548

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   
   ```

3. primise id数据量：45487

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

4. 关联上ISMS数据量：101

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   ```

5. 关联上IMWMS数量:1191

   ```sql
   select 
     count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 包含食水海水分类
   	(
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccid from coss_tmp.wr_ccbs )
   	)
   
   ```

   


# 2.投诉专题数据量统计

## 数据质量表

| 清洗级别                                    | 数据量   |
| ------------------------------------------- | -------- |
| 1.全表数据量                                | 48695340 |
| 2.根据cust_comm_type_desc过滤客服投诉数据量 | 165698   |
| 3.rmk字段食水或咸水数据量                   | 53085    |
| 4.primise id数据量                          | 2691     |
| 5.关联上ISMS数据量                          | 16       |
| 6.关联上IMWMS数量                           | 0        |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```sql
   select count(1) from  coss_tmp.in_comm 
   ```

2. 根据cust_comm_type_desc过滤客服投诉数据量:165698

   - 获取投诉cust_comm_type_code：

     ```sql
     select 
     cust_comm_type_code  from cfg_cust_comm_type where lower(cust_comm_type_desc) like '%comp%' and  lower(cust_comm_type_desc) not like '%comple%'  and  lower(cust_comm_type_desc) not like '%company%'
     ```

   - 客服投诉数据量

     ```sql
     select count(1) from  coss_tmp.in_comm where 
     -- 过滤所有投诉类型的数据
         in_comm_type_code in(
         'FKDISCLTRC',
         'FKDISCLTRE',
         'DIARCOMP',
         'DIRTCFLU',
         'DIRTCPOT',
         'OTHRCOMP',
         'SALICOMP',
         'TASTCOMP',
         'WORMCOMP',
         'NONWSDCMPLNS',
         'LWORMWTRC',
         'RWWCSPIIC',
         'RWWCSPIIE',
         'RWWCSPIVC',
         'RWWCSPIVE',
         'LUNSATWSC',
         'LUNSATWSE',
         'RWWCSVC',
         'RWWCSVE',
         'LWORMWTRE',
         'AW1001C',
         'LDISWTRC',
         'LDISWTRE',
         'RWWCSVIE',
         'RWWCSVIIC',
         'RWWCSVIIE',
         'AW1001E',
         'AW1009M',
         'COMPLAINTS',
         'COMPUTER_SYS'
         )
     ```

3. rmk字段食水或咸水数据量：53085

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   ```

4. primise id数据量：2691

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

5. 关联上ISMS数据量：16

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
       in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   
   ```

6. 关联上IMWMS数量: 0

   ```sql
   select count(1) from  coss_tmp.in_comm where 
   -- 过滤所有投诉类型的数据
    in_comm_type_code in(
       'FKDISCLTRC',
       'FKDISCLTRE',
       'DIARCOMP',
       'DIRTCFLU',
       'DIRTCPOT',
       'OTHRCOMP',
       'SALICOMP',
       'TASTCOMP',
       'WORMCOMP',
       'NONWSDCMPLNS',
       'LWORMWTRC',
       'RWWCSPIIC',
       'RWWCSPIIE',
       'RWWCSPIVC',
       'RWWCSPIVE',
       'LUNSATWSC',
       'LUNSATWSE',
       'RWWCSVC',
       'RWWCSVE',
       'LWORMWTRE',
       'AW1001C',
       'LDISWTRC',
       'LDISWTRE',
       'RWWCSVIE',
       'RWWCSVIIC',
       'RWWCSVIIE',
       'AW1001E',
       'AW1009M',
       'COMPLAINTS',
       'COMPUTER_SYS'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.wr_ccbs )
   	)
   
   ```


# 3.水质事故数据量统计

## 数据质量统计表

| 清洗级别                           | 数据量   |
| ---------------------------------- | -------- |
| 1.全表数据量                       | 48695340 |
| 2.根据code(WTCQ)过滤水质投诉数据量 | 160096   |
| 3.rmk字段食水或咸水数据量          | 52962    |
| 4.水质事件类型S1..P1..数据量       | 13891    |
| 5.primise id数据量                 | 555      |
| 6.关联上ISMS                       | 13       |
| 7.关联上IMWMS                      | 0        |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```
   select count(1) from  coss_tmp.in_comm 
   ```

2. 根据code(WTCQ)过滤水质投诉数据量：160096

   ```
   select count(1) from  coss_tmp.in_comm where in_comm_cls_code = 'WTCQ'
   ```

3. rmk字段食水或咸水数据量：52962

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   ```

4. 水质事件类型S1..P1..数据量：13891

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   ```

5. primise id数据量：555

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

6. 关联上ISMS: 13

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   ```

7. 关联上IMWMS：0

   ```sql
   select
   	count(1)
   from
   	coss_tmp.in_comm
   where
   -- 水质类型
   	in_comm_cls_code = 'WTCQ'
   	
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- 水质类型分类
      and(
   	   upper(rmk) like '%(L1)%'
   	or upper(rmk) like '%(S1)%'
   	or upper(rmk) like '%(C1)%'
   	or upper(rmk) like '%(O1)%'
   	or upper(rmk) like '%(S3)%'
   	or upper(rmk) like '%(S2)%'
   	or upper(rmk) like '%(P1)%'
   	or upper(rmk) like '%(P3)%'
   	or upper(rmk) like '%(P2)%'
   	)	
   -- premise id
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联IMWMS 数据
   	and(
   	in_comm_id  in (select ccid from coss_tmp.wr_ccbs )
   	)
   ```


# 4.爆管事故管理

## 数据质量统计表

| 清洗级别                           | 数据量   |
| ---------------------------------- | -------- |
| 1.全表数据量                       | 48695340 |
| 2.根据爆管或渗漏关键字过滤客服数据 | 828869   |
| 3.rmk字段食水或咸水数据量          | 47844    |
| 4.primise id数据量                 | 1749     |
| 5.关联上ISMS                       | 12       |
| 6.关联上IMWMS                      | 1        |

## 数据质量统计逻辑

1. 全表数据量：48695340

   ```
   select count(1) from  coss_tmp.in_comm 
   ```

2. 根据爆管或渗漏关键字过滤客服数据：828869

   - 过滤爆管或渗漏

     ```sql
     select cust_comm_type_code  from cfg_cust_comm_type where lower(cust_comm_type_desc) like '%bur%' or  lower(cust_comm_type_desc)  like '%leak%'
     ```

   - 统计爆管或渗漏数据条数

     ```sql
     select 
     count(1) 
     from  coss_tmp.in_comm 
     where
     -- 过滤爆管或渗漏
         in_comm_type_code  in(
         'CMAINLEAK',
         'MAINBURST',
         'MAINLEAK',
         'CMAINBURST',
         'MDEPLEAKAGE',
         'WWO1050A1C',
         'WWO1050C',
         'WWO1050E',
         'WWO1050A1E',
         'WWO1050A2C',
         'WWO1050A2E',
         'IOLEAKISE',
         'IOLEAKISC',
         'HYDTLEAK',
         'ISBURST',
         'ISLEAK',
         'MRLEAK',
         'LEAKWAVR'
         )
     ```

3. rmk字段食水或咸水数据量:47844

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   -- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   ```

4. primise id数据：1749

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   ```

5. 关联上ISMS:12

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联ISMS 数据
   	and(
   	in_comm_id  in (select ccbs_cc_id from coss_tmp.css_work_order_test )
   	)
   ```

   

6. 关联上IMWMS:1

   ```sql
   select 
   count(1) 
   from  coss_tmp.in_comm 
   where 
   -- 过滤爆管或渗漏
       in_comm_type_code  in(
       'CMAINLEAK',
       'MAINBURST',
       'MAINLEAK',
       'CMAINBURST',
       'MDEPLEAKAGE',
       'WWO1050A1C',
       'WWO1050C',
       'WWO1050E',
       'WWO1050A1E',
       'WWO1050A2C',
       'WWO1050A2E',
       'IOLEAKISE',
       'IOLEAKISC',
       'HYDTLEAK',
       'ISBURST',
       'ISLEAK',
       'MRLEAK',
       'LEAKWAVR'
       )
   -- 包含食水海水分类
   	and (
   	 -- 食水
        rmk like '%食水%'
        or lower(rmk) like '%fresh%'
   	-- 冲厕水
   	or rmk like '%鹹水%'
   	or rmk like '%咸水%'
   	or lower(rmk) like '%flush%'
   	or lower(rmk) like '%salt water%'
   	)
   -- premise 内容
      and(
   	   lower(rmk) like '%premise%'
   	   or premise_id is not null 
   	)
   -- 关联IMWMS 数据
   	and(
   	in_comm_id  in (select ccid from coss_tmp.wr_ccbs )
   	)
   ```

   


